import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService } from '../../core/data.service';

@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [RouterLink],
  template: `
    <section class="card overflow-hidden">
      <div class="flex flex-col gap-4 p-5 sm:flex-row">
        <div class="h-36 w-full shrink-0 rounded-lg bg-linear-to-br sm:w-56" [class]="course.gradient"></div>
        <div class="flex-1">
          <h1 class="text-xl font-bold">{{ course.title }}</h1>
          <p class="mt-1 text-sm text-slate-500">
            {{ course.code }} · {{ course.lessons }} lessons · <span class="text-success">{{ course.level }}</span>
          </p>
          @if (course.progress !== null) {
            <p class="mt-2 text-xs text-slate-500">{{ course.progress }}% Complete</p>
            <div class="mt-1 h-1.5 max-w-xs rounded-full bg-slate-100">
              <div class="h-full rounded-full bg-primary" [style.width.%]="course.progress"></div>
            </div>
          }
          <div class="mt-4 flex gap-2">
            <a [routerLink]="['/courses', course.id, 'lessons', 2]" class="btn-primary">
              {{ course.progress !== null ? 'Continue Learning' : 'Enroll Now' }}
            </a>
            <button class="btn-secondary" aria-label="More options">•••</button>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="flex gap-6 overflow-x-auto border-t border-slate-200 px-5">
        @for (t of tabs; track t) {
          <button (click)="tab.set(t)" class="whitespace-nowrap border-b-2 py-3 text-sm font-medium"
                  [class]="tab() === t ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-800'">
            {{ t }}
          </button>
        }
      </div>
    </section>

    <section class="mt-4 grid gap-4 lg:grid-cols-3">
      <div class="card p-5 lg:col-span-2">
        @switch (tab()) {
          @case ('Overview') {
            <h2 class="font-semibold">About This Course</h2>
            <p class="mt-2 text-sm text-slate-600">
              Learn modern web development with HTML, CSS, JavaScript and Angular. Build real-world projects and gain hands-on experience.
            </p>
            <div class="mt-4 flex flex-wrap gap-x-6 gap-y-1 text-sm text-slate-500">
              <span>{{ course.lessons }} Lessons</span><span>4 Assignments</span>
              <span class="text-amber-500">★ {{ course.rating }} ({{ course.reviews }} reviews)</span>
            </div>
            <p class="mt-4 text-sm">Instructor: <span class="font-semibold">{{ course.instructor }}</span></p>

            <h2 class="mt-6 font-semibold">Course Syllabus</h2>
            <ul class="mt-3 divide-y divide-slate-100 rounded-lg border border-slate-200">
              @for (m of data.syllabus; track m.title) {
                <li class="flex items-center justify-between px-4 py-3 text-sm">
                  <span>{{ m.title }} <span class="text-slate-400">({{ m.lessons }} lessons)</span></span>
                  <span class="flex h-5 w-5 items-center justify-center rounded-full text-xs"
                        [class]="m.done ? 'bg-success text-white' : 'border border-slate-300'">{{ m.done ? '✓' : '' }}</span>
                </li>
              }
            </ul>
          }
          @case ('Lessons') {
            <ul class="divide-y divide-slate-100">
              @for (l of data.outline; track l.id) {
                <li>
                  <a [routerLink]="['/courses', course.id, 'lessons', l.id]" class="flex items-center justify-between py-3 text-sm hover:text-primary">
                    <span>{{ l.id }}. {{ l.title }}</span>
                    @if (l.done) { <span class="badge-success">Done</span> }
                  </a>
                </li>
              }
            </ul>
          }
          @case ('Assignments') {
            <a routerLink="/assignments/2" class="flex items-center justify-between rounded-lg border border-slate-200 p-4 text-sm hover:bg-slate-50">
              <span>Assignment 2: Build a Simple To-Do App</span><span class="badge-warning">Open</span>
            </a>
          }
          @case ('Discussions') {
            <p class="py-8 text-center text-sm text-slate-500">No discussions yet. Start the first thread for this course.</p>
          }
        }
      </div>

      <aside class="card h-fit p-5 text-sm">
        <h2 class="font-semibold">Instructor</h2>
        <div class="mt-3 flex items-center gap-3">
          <span class="flex h-10 w-10 items-center justify-center rounded-full bg-slate-200 font-semibold">{{ course.instructor[4] }}</span>
          <span>{{ course.instructor }}</span>
        </div>
      </aside>
    </section>
  `,
})
export class CourseDetailComponent {
  data = inject(DataService);
  course = this.data.getCourse(Number(inject(ActivatedRoute).snapshot.paramMap.get('id')));
  tabs = ['Overview', 'Lessons', 'Assignments', 'Discussions'];
  tab = signal('Overview');
}
