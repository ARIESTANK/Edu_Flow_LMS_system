import { Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService } from '../../core/data.service';

@Component({
  selector: 'app-course-list',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="flex flex-wrap items-center justify-between gap-3">
      <h1 class="text-xl font-bold">{{ enrolledOnly ? 'My Courses' : 'Browse Courses' }}</h1>
      <input class="input max-w-xs" placeholder="Search for courses..." (input)="query.set($any($event.target).value)" />
    </div>

    <div class="mt-4 flex flex-wrap gap-2">
      @for (c of data.categories; track c) {
        <button (click)="category.set(c)"
                class="rounded-full px-4 py-1.5 text-sm font-medium transition"
                [class]="category() === c ? 'bg-primary text-white' : 'bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50'">
          {{ c }}
        </button>
      }
    </div>

    <h2 class="mt-6 text-sm font-semibold text-slate-500">{{ enrolledOnly ? 'Enrolled' : 'Featured' }} Courses</h2>

    <div class="mt-3 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      @for (c of filtered(); track c.id) {
        <article class="card flex flex-col overflow-hidden">
          <div class="h-28 bg-linear-to-br" [class]="c.gradient"></div>
          <div class="flex flex-1 flex-col p-3">
            <a [routerLink]="['/courses', c.id]" class="text-sm font-semibold hover:text-primary">{{ c.title }}</a>
            <p class="text-xs text-slate-500">{{ c.code }} · {{ c.lessons }} lessons</p>
            <div class="mt-auto flex items-center justify-between pt-3">
              <span class="text-xs text-amber-500">★ {{ c.rating }} <span class="text-slate-400">({{ c.reviews }})</span></span>
              <a [routerLink]="['/courses', c.id]" class="rounded-md bg-primary px-3 py-1 text-xs font-semibold text-white hover:bg-primary-dark">
                {{ c.progress !== null ? 'Continue' : 'Enroll' }}
              </a>
            </div>
          </div>
        </article>
      } @empty {
        <p class="col-span-full py-12 text-center text-sm text-slate-500">No courses match your search. Try another category.</p>
      }
    </div>
  `,
})
export class CourseListComponent {
  data = inject(DataService);
  enrolledOnly = !!inject(ActivatedRoute).snapshot.data['enrolledOnly'];

  query = signal('');
  category = signal('All');

  filtered = computed(() => {
    const q = this.query().toLowerCase();
    const cat = this.category();
    return this.data.courses.filter(c =>
      (!this.enrolledOnly || c.progress !== null) &&
      (cat === 'All' || c.category === cat) &&
      (c.title.toLowerCase().includes(q) || c.code.toLowerCase().includes(q)));
  });
}
