import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../core/admin.service';
import { CourseItem, CoursePayload, CourseStatus } from '../../core/admin.models';
import { ToastService } from '../../core/toast.service';
import { IconComponent } from '../../layout/icon.component';
import { ModalComponent } from '../../shared/modal.component';

const BLANK: CoursePayload = { title: '', code: '', category: 'Programming', level: 'Beginner', instructor: '', lessons: 8, status: 'DRAFT' };

@Component({
  selector: 'app-course-management',
  imports: [FormsModule, IconComponent, ModalComponent],
  template: `
    <div class="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1 class="text-xl font-bold">Manage courses</h1>
        <p class="text-sm text-slate-500">{{ filtered().length }} of {{ courses().length }} courses</p>
      </div>
      <button class="btn-primary gap-2" (click)="openCreate()"><app-icon name="plus" cls="h-4 w-4" /> Add course</button>
    </div>

    <div class="mt-4 flex flex-wrap gap-3">
      <input class="input max-w-xs" placeholder="Search title, code or instructor..." [ngModel]="search()" (ngModelChange)="search.set($event)" aria-label="Search courses" />
      <select class="input w-auto" [ngModel]="status()" (ngModelChange)="status.set($event)" aria-label="Filter by status">
        <option value="ALL">Any status</option><option value="PUBLISHED">Published</option><option value="DRAFT">Draft</option><option value="ARCHIVED">Archived</option>
      </select>
    </div>

    @if (loadError()) { <p class="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-danger" role="alert">{{ loadError() }}</p> }

    <section class="card mt-4 overflow-x-auto">
      <table class="w-full min-w-[48rem] text-left text-sm">
        <thead class="border-b border-slate-200 text-xs text-slate-500">
          <tr><th class="px-4 py-3 font-medium">Course</th><th class="px-4 py-3 font-medium">Instructor</th><th class="px-4 py-3 font-medium">Level</th>
              <th class="px-4 py-3 font-medium">Lessons</th><th class="px-4 py-3 font-medium">Enrolled</th><th class="px-4 py-3 font-medium">Status</th><th class="px-4 py-3 text-right font-medium">Actions</th></tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          @for (c of filtered(); track c.id) {
            <tr>
              <td class="px-4 py-3 font-medium">{{ c.title }}<span class="block text-xs font-normal text-slate-500">{{ c.code }} · {{ c.category }}</span></td>
              <td class="px-4 py-3">{{ c.instructor }}</td>
              <td class="px-4 py-3">{{ c.level }}</td>
              <td class="px-4 py-3">{{ c.lessons }}</td>
              <td class="px-4 py-3">{{ c.enrolled }}</td>
              <td class="px-4 py-3"><span [class]="badge(c.status)">{{ c.status.toLowerCase() }}</span></td>
              <td class="px-4 py-3">
                <span class="flex justify-end gap-1">
                  <button class="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-primary" title="Edit" [attr.aria-label]="'Edit ' + c.title" (click)="openEdit(c)"><app-icon name="edit" cls="h-4 w-4" /></button>
                  <button class="rounded p-1.5 text-slate-500 hover:bg-red-50 hover:text-danger" title="Delete" [attr.aria-label]="'Delete ' + c.title" (click)="toDelete.set(c)"><app-icon name="trash" cls="h-4 w-4" /></button>
                </span>
              </td>
            </tr>
          } @empty {
            <tr><td colspan="7" class="px-4 py-10 text-center text-slate-500">{{ loading() ? 'Loading courses…' : 'No courses match your filters.' }}</td></tr>
          }
        </tbody>
      </table>
    </section>

    <app-modal [open]="showForm()" [title]="editing() ? 'Edit course' : 'Add course'" (closed)="showForm.set(false)">
      <form class="grid gap-4 sm:grid-cols-2" (ngSubmit)="save()" novalidate>
        @if (formError()) { <p class="rounded-lg bg-red-50 px-3 py-2 text-sm text-danger sm:col-span-2" role="alert">{{ formError() }}</p> }

        <div class="sm:col-span-2">
          <label for="c-title" class="mb-1 block text-sm font-medium">Title</label>
          <input id="c-title" name="title" class="input" [(ngModel)]="form.title" />
          @if (errors()['title']) { <p class="mt-1 text-xs text-danger">{{ errors()['title'] }}</p> }
        </div>
        <div>
          <label for="c-code" class="mb-1 block text-sm font-medium">Code</label>
          <input id="c-code" name="code" class="input uppercase" [(ngModel)]="form.code" placeholder="CS105" />
          @if (errors()['code']) { <p class="mt-1 text-xs text-danger">{{ errors()['code'] }}</p> }
        </div>
        <div>
          <label for="c-cat" class="mb-1 block text-sm font-medium">Category</label>
          <select id="c-cat" name="category" class="input" [(ngModel)]="form.category">
            @for (c of categories; track c) { <option [value]="c">{{ c }}</option> }
          </select>
        </div>
        <div>
          <label for="c-level" class="mb-1 block text-sm font-medium">Level</label>
          <select id="c-level" name="level" class="input" [(ngModel)]="form.level">
            <option>Beginner</option><option>Intermediate</option><option>Advanced</option>
          </select>
        </div>
        <div>
          <label for="c-lessons" class="mb-1 block text-sm font-medium">Lessons</label>
          <input id="c-lessons" name="lessons" type="number" min="1" class="input" [(ngModel)]="form.lessons" />
          @if (errors()['lessons']) { <p class="mt-1 text-xs text-danger">{{ errors()['lessons'] }}</p> }
        </div>
        <div>
          <label for="c-inst" class="mb-1 block text-sm font-medium">Instructor</label>
          <input id="c-inst" name="instructor" class="input" [(ngModel)]="form.instructor" />
          @if (errors()['instructor']) { <p class="mt-1 text-xs text-danger">{{ errors()['instructor'] }}</p> }
        </div>
        <div>
          <label for="c-status" class="mb-1 block text-sm font-medium">Status</label>
          <select id="c-status" name="status" class="input" [(ngModel)]="form.status">
            <option value="DRAFT">Draft</option><option value="PUBLISHED">Published</option><option value="ARCHIVED">Archived</option>
          </select>
        </div>

        <div class="flex justify-end gap-2 pt-2 sm:col-span-2">
          <button type="button" class="btn-secondary" (click)="showForm.set(false)">Cancel</button>
          <button type="submit" class="btn-primary" [disabled]="saving()">{{ saving() ? 'Saving…' : (editing() ? 'Save changes' : 'Create course') }}</button>
        </div>
      </form>
    </app-modal>

    <app-modal [open]="!!toDelete()" title="Delete course" (closed)="toDelete.set(null)">
      <p class="text-sm text-slate-600">Delete <strong>{{ toDelete()?.title }}</strong>?
        @if ((toDelete()?.enrolled ?? 0) > 0) { <span class="text-danger"> {{ toDelete()?.enrolled }} students are enrolled.</span> }
        Archiving keeps their grades; deleting removes the course for good.</p>
      <div class="mt-5 flex justify-end gap-2">
        <button class="btn-secondary" (click)="toDelete.set(null)">Cancel</button>
        <button class="inline-flex items-center justify-center rounded-lg bg-danger px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-600 disabled:opacity-50" [disabled]="saving()" (click)="confirmDelete()">Delete course</button>
      </div>
    </app-modal>
  `,
})
export class CourseManagementComponent {
  private api = inject(AdminService);
  private toast = inject(ToastService);

  categories = ['Programming', 'Database', 'Design', 'Business', 'Others'];
  courses = signal<CourseItem[]>([]);
  loading = signal(true);
  loadError = signal('');
  search = signal('');
  status = signal<'ALL' | CourseStatus>('ALL');

  filtered = computed(() => {
    const q = this.search().trim().toLowerCase(), s = this.status();
    return this.courses().filter(c => (s === 'ALL' || c.status === s) &&
      (!q || c.title.toLowerCase().includes(q) || c.code.toLowerCase().includes(q) || c.instructor.toLowerCase().includes(q)));
  });

  showForm = signal(false);
  editing = signal<CourseItem | null>(null);
  form: CoursePayload = { ...BLANK };
  errors = signal<Record<string, string>>({});
  formError = signal('');
  saving = signal(false);
  toDelete = signal<CourseItem | null>(null);

  constructor() { this.load(); }

  badge(s: CourseStatus) { return s === 'PUBLISHED' ? 'badge-success capitalize' : s === 'DRAFT' ? 'badge-warning capitalize' : 'rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium capitalize text-slate-600'; }

  private async load() {
    this.loading.set(true);
    try { this.courses.set(await this.api.listCourses()); this.loadError.set(''); }
    catch { this.loadError.set('Could not load courses. Check that the server is running and try again.'); }
    finally { this.loading.set(false); }
  }

  openCreate() { this.editing.set(null); this.form = { ...BLANK }; this.errors.set({}); this.formError.set(''); this.showForm.set(true); }
  openEdit(c: CourseItem) {
    this.editing.set(c);
    this.form = { title: c.title, code: c.code, category: c.category, level: c.level, instructor: c.instructor, lessons: c.lessons, status: c.status };
    this.errors.set({}); this.formError.set(''); this.showForm.set(true);
  }

  async save() {
    const f = this.form, e: Record<string, string> = {};
    if (f.title.trim().length < 3) e['title'] = 'Enter a course title.';
    if (!/^[A-Za-z]{2,4}\d{2,4}$/.test(f.code.trim())) e['code'] = 'Use a code like CS101.';
    if (!f.instructor.trim()) e['instructor'] = 'Enter the instructor name.';
    if (!Number.isInteger(Number(f.lessons)) || Number(f.lessons) < 1) e['lessons'] = 'Lessons must be 1 or more.';
    this.errors.set(e);
    if (Object.keys(e).length) return;

    this.saving.set(true); this.formError.set('');
    const payload: CoursePayload = { ...f, title: f.title.trim(), code: f.code.trim().toUpperCase(), instructor: f.instructor.trim(), lessons: Number(f.lessons) };
    try {
      const editing = this.editing();
      if (editing) await this.api.updateCourse(editing.id, payload); else await this.api.createCourse(payload);
      this.showForm.set(false); this.toast.show(editing ? 'Course updated.' : 'Course created.'); await this.load();
    } catch (err: any) {
      this.formError.set(err?.status === 409 ? 'A course with this code already exists.' : (err?.message && !err.message.startsWith('Http failure') ? err.message : 'Could not save the course. Try again.'));
    } finally { this.saving.set(false); }
  }

  async confirmDelete() {
    const c = this.toDelete(); if (!c) return;
    this.saving.set(true);
    try { await this.api.deleteCourse(c); this.toDelete.set(null); this.toast.show('Course deleted.'); await this.load(); }
    catch { this.toast.error('Could not delete the course. Try archiving it instead.'); }
    finally { this.saving.set(false); }
  }
}
