import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { DataService } from '../../core/data.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [RouterLink],
  template: `
    <h1 class="text-xl font-bold">Good morning, {{ auth.user()?.name }}! 👋</h1>
    <p class="text-sm text-slate-500">Keep going! You're doing great.</p>

    <!-- Stats -->
    <div class="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
      @for (s of stats; track s.label) {
        <div class="card flex items-center gap-3 p-4">
          <span class="flex h-10 w-10 items-center justify-center rounded-lg text-lg font-bold" [class]="s.tone">{{ s.value }}</span>
          <span class="text-xs text-slate-500">{{ s.label }}</span>
        </div>
      }
    </div>

    <!-- My courses -->
    <div class="mt-6 flex items-center justify-between">
      <h2 class="font-semibold">My Courses</h2>
      <a routerLink="/my-courses" class="text-sm font-medium text-primary hover:underline">View all</a>
    </div>
    <div class="mt-3 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      @for (c of enrolled; track c.id) {
        <a [routerLink]="['/courses', c.id]" class="card overflow-hidden transition hover:shadow-md">
          <div class="h-24 bg-linear-to-br" [class]="c.gradient"></div>
          <div class="p-3">
            <p class="text-sm font-semibold">{{ c.title }}</p>
            <p class="text-xs text-slate-500">{{ c.code }} · {{ c.lessons }} lessons</p>
            <div class="mt-3 flex items-center gap-2">
              <div class="h-1.5 flex-1 rounded-full bg-slate-100">
                <div class="h-full rounded-full bg-primary" [style.width.%]="c.progress"></div>
              </div>
              <span class="text-xs text-slate-500">{{ c.progress }}%</span>
            </div>
          </div>
        </a>
      }
    </div>

    <div class="mt-6 grid gap-4 lg:grid-cols-2">
      <section class="card p-4">
        <div class="flex items-center justify-between">
          <h2 class="font-semibold">Upcoming Deadlines</h2>
          <a routerLink="/calendar" class="text-sm font-medium text-primary hover:underline">View all</a>
        </div>
        <ul class="mt-3 divide-y divide-slate-100">
          @for (d of data.deadlines; track d.title) {
            <li class="flex items-center justify-between py-3 text-sm">
              <span>{{ d.title }}</span>
              <span [class]="d.urgent ? 'badge-error' : 'badge-warning'">{{ d.due }}</span>
            </li>
          }
        </ul>
      </section>

      <section class="card p-4">
        <h2 class="font-semibold">Recent Activity</h2>
        <ul class="mt-3 space-y-3">
          @for (a of data.activity; track a.text) {
            <li class="flex gap-3 text-sm">
              <span class="mt-1.5 h-2 w-2 shrink-0 rounded-full" [class]="a.color"></span>
              <span>{{ a.text }}<br><span class="text-xs text-slate-400">{{ a.time }}</span></span>
            </li>
          }
        </ul>
      </section>
    </div>
  `,
})
export class DashboardComponent {
  auth = inject(AuthService);
  data = inject(DataService);
  enrolled = this.data.courses.filter(c => c.progress !== null);

  stats = [
    { label: 'Enrolled Courses', value: 5, tone: 'bg-blue-50 text-primary' },
    { label: 'Completed Courses', value: 2, tone: 'bg-violet-50 text-secondary' },
    { label: 'Pending Assignments', value: 3, tone: 'bg-emerald-50 text-success' },
    { label: 'Average Grade', value: '89%', tone: 'bg-amber-50 text-warning' },
  ];
}
