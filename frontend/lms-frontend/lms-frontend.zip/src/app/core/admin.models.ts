import { Role } from './auth.service';

export interface AdminUser {
  id: number;
  username: string;
  email: string;
  role: Role;
  active: boolean;
  createdAt: string;        // ISO date
  lastLogin: string | null; // ISO date
}

export interface UserPayload {
  username: string;
  email: string;
  role: Role;
  password?: string; // only on create
  active?: boolean;
}

export type CourseStatus = 'PUBLISHED' | 'DRAFT' | 'ARCHIVED';

export interface CourseItem {
  id: number;
  title: string;
  code: string;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  instructor: string;
  lessons: number;
  enrolled: number;
  status: CourseStatus;
}
export type CoursePayload = Omit<CourseItem, 'id' | 'enrolled'>;

export interface Department { id: number; name: string; head: string; }
export type DepartmentPayload = Omit<Department, 'id'>;

export interface AuditLog { id: number; time: string; actor: string; action: string; target: string; }

export interface SystemSettings {
  siteName: string;
  allowRegistration: boolean;
  defaultRole: Role;
  sessionTimeoutMin: number;
  passwordMinLength: number;
  maxUploadMb: number;
  maintenanceMode: boolean;
}

export interface Overview {
  totalUsers: number; students: number; teachers: number; admins: number;
  courses: number; activeToday: number; newThisWeek: number;
}

export interface StudentPerf {
  id: number;
  name: string;
  email: string;
  avgGrade: number;    // 0-100
  completion: number;  // 0-100 (% of lessons completed)
  attendance: number;  // 0-100
  trend: number;       // grade change vs previous term, in points
  courses: { course: string; grade: number }[];
}
