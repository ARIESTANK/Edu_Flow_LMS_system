import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService, Role } from './auth.service';
import {
  AdminUser, AuditLog, CourseItem, CoursePayload, Department, DepartmentPayload,
  Overview, StudentPerf, SystemSettings, UserPayload,
} from './admin.models';
import { randomPassword } from './stats';

const API_URL = 'http://localhost:8080/api';

/**
 * Flip each flag to false once that endpoint exists in Spring Boot.
 * While true, the page runs on in-memory sample data (resets on reload).
 */
export const MOCK = {
  users: true,
  courses: true,
  departments: true,
  settings: true,
  audit: true,
  analytics: true,
};

// ---------------- sample data ----------------
const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000).toISOString();

let users: AdminUser[] = [
  { id: 1, username: 'admin', email: 'admin@eduflow.com', role: 'ADMIN', active: true, createdAt: daysAgo(200), lastLogin: daysAgo(0) },
  { id: 2, username: 'kyaw.zaw', email: 'kyaw.zaw@eduflow.com', role: 'TEACHER', active: true, createdAt: daysAgo(150), lastLogin: daysAgo(1) },
  { id: 3, username: 'hnin.su', email: 'hnin.su@eduflow.com', role: 'TEACHER', active: true, createdAt: daysAgo(140), lastLogin: daysAgo(3) },
  { id: 4, username: 'min.thu', email: 'min.thu@eduflow.com', role: 'TEACHER', active: false, createdAt: daysAgo(120), lastLogin: daysAgo(40) },
  ...['Aye Chan', 'Su Su', 'Zin Mar', 'Htet Htet', 'Thura', 'Nandar', 'Kaung Khant Lin', 'Phyo Wai'].map((n, i) => ({
    id: 10 + i,
    username: n.toLowerCase().replace(/ /g, '.'),
    email: n.toLowerCase().replace(/ /g, '.') + '@student.eduflow.com',
    role: 'STUDENT' as Role,
    active: i !== 5,
    createdAt: daysAgo(90 - i * 9),
    lastLogin: i % 3 === 0 ? daysAgo(0) : daysAgo(i + 1),
  })),
];

let courses: CourseItem[] = [
  { id: 1, title: 'Web Development', code: 'CS101', category: 'Programming', level: 'Beginner', instructor: 'Dr. Kyaw Zaw', lessons: 12, enrolled: 120, status: 'PUBLISHED' },
  { id: 2, title: 'Database Systems', code: 'CS102', category: 'Database', level: 'Intermediate', instructor: 'Daw Hnin Su', lessons: 10, enrolled: 98, status: 'PUBLISHED' },
  { id: 3, title: 'Data Structures & Algorithms', code: 'CS103', category: 'Programming', level: 'Intermediate', instructor: 'U Min Thu', lessons: 14, enrolled: 112, status: 'PUBLISHED' },
  { id: 4, title: 'English for IT', code: 'EN101', category: 'Others', level: 'Beginner', instructor: 'Daw Mya Thandar', lessons: 8, enrolled: 64, status: 'PUBLISHED' },
  { id: 5, title: 'Mobile App Development', code: 'CS104', category: 'Programming', level: 'Intermediate', instructor: 'U Aung Ko', lessons: 14, enrolled: 0, status: 'DRAFT' },
  { id: 6, title: 'Cloud Computing', code: 'CS106', category: 'Others', level: 'Advanced', instructor: 'Dr. Thida Aye', lessons: 10, enrolled: 40, status: 'ARCHIVED' },
];

let departments: Department[] = [
  { id: 1, name: 'Computer Science', head: 'Dr. Kyaw Zaw' },
  { id: 2, name: 'Information Systems', head: 'Daw Hnin Su' },
  { id: 3, name: 'Languages', head: 'Daw Mya Thandar' },
];

let settings: SystemSettings = {
  siteName: 'EduFlow LMS', allowRegistration: true, defaultRole: 'STUDENT',
  sessionTimeoutMin: 60, passwordMinLength: 8, maxUploadMb: 10, maintenanceMode: false,
};

let audit: AuditLog[] = [
  { id: 1, time: daysAgo(0), actor: 'admin', action: 'Logged in', target: '-' },
  { id: 2, time: daysAgo(1), actor: 'admin', action: 'Created user', target: 'phyo.wai' },
  { id: 3, time: daysAgo(2), actor: 'admin', action: 'Published course', target: 'CS101' },
];

// Deterministic sample performance data
function seedPerformance(): StudentPerf[] {
  let seed = 7;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const names = ['Aye Chan', 'Su Su', 'Zin Mar', 'Htet Htet', 'Thura', 'Nandar', 'Kaung Khant Lin', 'Phyo Wai',
    'Min Khant', 'Ei Ei', 'Yadanar', 'Wai Yan', 'Moe Moe', 'Hein Htet', 'Thiri', 'Kyaw Kyaw', 'Shwe Sin', 'Lin Lin',
    'Pyae Sone', 'Nay Chi', 'Hla Hla', 'Zaw Zaw', 'Mya Mya', 'Tun Tun', 'San San', 'Aung Aung', 'Cho Cho', 'Ko Ko'];
  const clamp = (n: number) => Math.max(20, Math.min(100, Math.round(n)));
  return names.map((name, i) => {
    const base = 45 + rnd() * 50;
    return {
      id: 100 + i,
      name,
      email: name.toLowerCase().replace(/ /g, '.') + '@student.eduflow.com',
      avgGrade: 0,
      completion: clamp(base + (rnd() - 0.5) * 30),
      attendance: clamp(base + 10 + (rnd() - 0.5) * 25),
      trend: Math.round((rnd() - 0.4) * 16),
      courses: ['Web Development', 'Database Systems', 'Data Structures & Algorithms', 'English for IT']
        .map(course => ({ course, grade: clamp(base + (rnd() - 0.5) * 24) })),
    };
  }).map(s => ({ ...s, avgGrade: Math.round(s.courses.reduce((a, c) => a + c.grade, 0) / s.courses.length) }));
}
const performance = seedPerformance();

// ---------------- service ----------------
@Injectable({ providedIn: 'root' })
export class AdminService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  private log(action: string, target: string) {
    audit = [{ id: Date.now(), time: new Date().toISOString(), actor: this.auth.user()?.name ?? 'admin', action, target }, ...audit];
  }
  private nextId(list: { id: number }[]) { return Math.max(0, ...list.map(x => x.id)) + 1; }

  // ----- Users  (GET/POST /users, PUT/DELETE /users/{id}) -----
  async listUsers(): Promise<AdminUser[]> {
    if (MOCK.users) return [...users];
    const rows = await firstValueFrom(this.http.get<Partial<AdminUser>[]>(`${API_URL}/users`));
    return rows.map(u => ({
      id: u.id!, username: u.username ?? '', email: u.email ?? '', role: u.role ?? 'STUDENT',
      active: u.active ?? true, createdAt: u.createdAt ?? '', lastLogin: u.lastLogin ?? null,
    }));
  }

  async createUser(p: UserPayload): Promise<void> {
    if (MOCK.users) {
      if (users.some(u => u.email.toLowerCase() === p.email.toLowerCase())) throw new Error('A user with this email already exists.');
      users = [...users, { id: this.nextId(users), username: p.username, email: p.email, role: p.role, active: p.active ?? true, createdAt: new Date().toISOString(), lastLogin: null }];
      return this.log('Created user', p.username);
    }
    await firstValueFrom(this.http.post(`${API_URL}/users`, p));
  }

  async updateUser(id: number, p: UserPayload): Promise<void> {
    if (MOCK.users) {
      if (users.some(u => u.id !== id && u.email.toLowerCase() === p.email.toLowerCase())) throw new Error('Another user already uses this email.');
      users = users.map(u => (u.id === id ? { ...u, username: p.username, email: p.email, role: p.role, active: p.active ?? u.active } : u));
      return this.log('Updated user', p.username);
    }
    await firstValueFrom(this.http.put(`${API_URL}/users/${id}`, p));
  }

  async setUserActive(u: AdminUser, active: boolean): Promise<void> {
    if (MOCK.users) {
      users = users.map(x => (x.id === u.id ? { ...x, active } : x));
      return this.log(active ? 'Activated user' : 'Deactivated user', u.username);
    }
    await firstValueFrom(this.http.patch(`${API_URL}/users/${u.id}/status`, { active }));
  }

  async deleteUser(u: AdminUser): Promise<void> {
    if (MOCK.users) { users = users.filter(x => x.id !== u.id); return this.log('Deleted user', u.username); }
    await firstValueFrom(this.http.delete(`${API_URL}/users/${u.id}`));
  }

  /** Admin sets a new password directly. POST /users/{id}/reset-password */
  async resetPassword(u: AdminUser, newPassword: string, mustChangePassword: boolean): Promise<void> {
    if (MOCK.users) return this.log('Reset password', u.username);
    await firstValueFrom(this.http.post(`${API_URL}/users/${u.id}/reset-password`, { newPassword, mustChangePassword }));
  }

  /** Emails a reset link to the user. POST /auth/forgot-password */
  async sendResetLink(email: string): Promise<void> {
    if (MOCK.users) return this.log('Sent reset link', email);
    await firstValueFrom(this.http.post(`${API_URL}/auth/forgot-password`, { email }));
  }

  generatePassword() { return randomPassword(12); }

  // ----- Courses  (/courses) -----
  async listCourses(): Promise<CourseItem[]> {
    if (MOCK.courses) return [...courses];
    return firstValueFrom(this.http.get<CourseItem[]>(`${API_URL}/courses`));
  }
  async createCourse(p: CoursePayload): Promise<void> {
    if (MOCK.courses) {
      if (courses.some(c => c.code.toLowerCase() === p.code.toLowerCase())) throw new Error('A course with this code already exists.');
      courses = [...courses, { ...p, id: this.nextId(courses), enrolled: 0 }];
      return this.log('Created course', p.code);
    }
    await firstValueFrom(this.http.post(`${API_URL}/courses`, p));
  }
  async updateCourse(id: number, p: CoursePayload): Promise<void> {
    if (MOCK.courses) {
      if (courses.some(c => c.id !== id && c.code.toLowerCase() === p.code.toLowerCase())) throw new Error('Another course already uses this code.');
      courses = courses.map(c => (c.id === id ? { ...c, ...p } : c));
      return this.log('Updated course', p.code);
    }
    await firstValueFrom(this.http.put(`${API_URL}/courses/${id}`, p));
  }
  async deleteCourse(c: CourseItem): Promise<void> {
    if (MOCK.courses) { courses = courses.filter(x => x.id !== c.id); return this.log('Deleted course', c.code); }
    await firstValueFrom(this.http.delete(`${API_URL}/courses/${c.id}`));
  }

  // ----- Departments  (/departments) -----
  async listDepartments(): Promise<Department[]> {
    if (MOCK.departments) return [...departments];
    return firstValueFrom(this.http.get<Department[]>(`${API_URL}/departments`));
  }
  async createDepartment(p: DepartmentPayload): Promise<void> {
    if (MOCK.departments) { departments = [...departments, { ...p, id: this.nextId(departments) }]; return this.log('Created department', p.name); }
    await firstValueFrom(this.http.post(`${API_URL}/departments`, p));
  }
  async updateDepartment(id: number, p: DepartmentPayload): Promise<void> {
    if (MOCK.departments) { departments = departments.map(d => (d.id === id ? { ...d, ...p } : d)); return this.log('Updated department', p.name); }
    await firstValueFrom(this.http.put(`${API_URL}/departments/${id}`, p));
  }
  async deleteDepartment(d: Department): Promise<void> {
    if (MOCK.departments) { departments = departments.filter(x => x.id !== d.id); return this.log('Deleted department', d.name); }
    await firstValueFrom(this.http.delete(`${API_URL}/departments/${d.id}`));
  }

  // ----- System settings  (GET/PUT /admin/settings) -----
  async getSettings(): Promise<SystemSettings> {
    if (MOCK.settings) return { ...settings };
    return firstValueFrom(this.http.get<SystemSettings>(`${API_URL}/admin/settings`));
  }
  async saveSettings(s: SystemSettings): Promise<void> {
    if (MOCK.settings) { settings = { ...s }; return this.log('Updated system settings', '-'); }
    await firstValueFrom(this.http.put(`${API_URL}/admin/settings`, s));
  }

  // ----- Audit log  (GET /admin/audit-logs) -----
  async listAuditLogs(): Promise<AuditLog[]> {
    if (MOCK.audit) return [...audit];
    return firstValueFrom(this.http.get<AuditLog[]>(`${API_URL}/admin/audit-logs`));
  }

  // ----- Overview  (GET /admin/overview) -----
  async getOverview(): Promise<Overview> {
    if (MOCK.users || MOCK.courses) {
      const week = Date.now() - 7 * 86_400_000;
      return {
        totalUsers: users.length,
        students: users.filter(u => u.role === 'STUDENT').length,
        teachers: users.filter(u => u.role === 'TEACHER').length,
        admins: users.filter(u => u.role === 'ADMIN').length,
        courses: courses.length,
        activeToday: users.filter(u => u.lastLogin && Date.now() - new Date(u.lastLogin).getTime() < 86_400_000).length,
        newThisWeek: users.filter(u => new Date(u.createdAt).getTime() > week).length,
      };
    }
    return firstValueFrom(this.http.get<Overview>(`${API_URL}/admin/overview`));
  }

  // ----- Student analytics  (GET /admin/analytics/students) -----
  async studentPerformance(): Promise<StudentPerf[]> {
    if (MOCK.analytics) return performance.map(s => ({ ...s, courses: [...s.courses] }));
    return firstValueFrom(this.http.get<StudentPerf[]>(`${API_URL}/admin/analytics/students`));
  }
}
