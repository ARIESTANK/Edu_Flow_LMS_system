import { Injectable, computed, inject, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';

export type Role = 'STUDENT' | 'TEACHER' | 'ADMIN';

export interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  role: Exclude<Role, 'ADMIN'>;
}

interface LoginResponse {
  token: string;
  userId: number;
  username: string;
  email: string;
  role: Role;
}

/** Set to false once your Spring Boot API is running. */
const USE_MOCK = true;
const API_URL = 'http://localhost:8080/api';

const TOKEN_KEY = 'eduflow_token';
const USER_KEY = 'eduflow_user';
const MOCK_USERS_KEY = 'eduflow_mock_users';

interface MockUser extends User {
  password: string; // dev-only: the real backend must store a hash
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private platformId = inject(PLATFORM_ID);
  private http = inject(HttpClient);
  private router = inject(Router);

  private _user = signal<User | null>(this.loadUser());
  user = this._user.asReadonly();
  isLoggedIn = computed(() => !!this._user());

  private isBrowser(): boolean {
    return isPlatformBrowser(this.platformId);
  }

  private loadUser(): User | null {
    if (!this.isBrowser()) return null;
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? (JSON.parse(raw) as User) : null;
    } catch {
      localStorage.removeItem(USER_KEY);
      return null;
    }
  }

  get token(): string | null {
    return this.isBrowser() ? localStorage.getItem(TOKEN_KEY) : null;
  }

  async register(req: RegisterRequest): Promise<void> {
    try {
      // Expected: POST /api/auth/register -> 201 Created
      console.log(req);
      await firstValueFrom(this.http.post(`${API_URL}/users`, req));
    } catch (e: any) {
      if (e?.status === 409) throw new Error('An account with this email already exists. Sign in instead.');
      if (e?.status === 400) throw new Error(e?.error?.message ?? 'Some details are invalid. Check the form and try again.');
      throw new Error('Could not reach the server. Try again in a moment.');
    }
  }

  // ---------- Login ----------
  async login(email: string, password: string): Promise<void> {
    if (!email || !password) throw new Error('Email and password are required');

    let res: LoginResponse;
    try {
      // POST /api/auth/login returns token, userId, username, email, and role.
      res = await firstValueFrom(this.http.post<LoginResponse>(`${API_URL}/auth/login`, { email, password }));
    } catch (e: any) {
      if (e?.status === 401 || e?.status === 403) throw new Error('Wrong email or password.');
      throw new Error('Could not reach the server. Try again in a moment.');
    }

    const user: User = {
      id: res.userId,
      name: res.username,
      email: res.email,
      role: res.role,
    };

    if (this.isBrowser()) {
      localStorage.setItem(TOKEN_KEY, res.token);
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    }
    this._user.set(user);
    await this.router.navigate([user.role=="ADMIN" ? '/admin/dashboard' : '/student/dashboard']);
  }

  logout(): void {
    if (this.isBrowser()) {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    }
    this._user.set(null);
    this.router.navigate(['/login']);
  }

  hasRole(...roles: Role[]): boolean {
    const u = this._user();
    return !!u && roles.includes(u.role);
  }

  private mockUsers(): MockUser[] {
    try {
      return JSON.parse(localStorage.getItem(MOCK_USERS_KEY) ?? '[]');
    } catch {
      return [];
    }
  }
}
