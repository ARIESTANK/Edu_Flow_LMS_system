import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService, Role } from './auth.service';

/** Usage: { canActivate: [authGuard], data: { roles: ['TEACHER','ADMIN'] } } */
export const authGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  if (!auth.isLoggedIn()) return router.createUrlTree(['/login']);
  const roles = route.data?.['roles'] as Role[] | undefined;
  if (roles && !auth.hasRole(...roles)) return router.createUrlTree(['/dashboard']);
  return true;
};
