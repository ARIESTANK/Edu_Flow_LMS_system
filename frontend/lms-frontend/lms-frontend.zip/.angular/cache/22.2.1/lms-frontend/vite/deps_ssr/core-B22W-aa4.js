import { t as __commonJSMin } from "./rolldown-runtime-B4iAMlE-.js";
import { $ as require_flatMap, $t as require_concatAll, A as require_share, At as require_count, B as require_publishReplay, Bt as require_toArray, C as require_startWith, Ct as require_delayWhen, D as require_skip, Dt as require_defaultIfEmpty, E as require_skipLast, Et as require_take, F as require_retryWhen, Ft as require_concatMap, G as require_pairwise, Gt as require_bufferTime, H as require_publishBehavior, Ht as require_catchError, I as require_retry, It as require_combineLatestWith, J as require_min, Jt as require_auditTime, K as require_onErrorResumeNextWith, Kt as require_bufferCount, L as require_repeatWhen, Lt as require_combineLatest, M as require_scan, Mt as require_concatWith, N as require_sampleTime, Nt as require_concat, O as require_single, Ot as require_debounceTime, P as require_sample, Pt as require_concatMapTo, Q as require_mergeMapTo, Qt as require_argsOrArgArray, R as require_repeat, Rt as require_combineAll, S as require_switchMap, St as require_delay, T as require_skipUntil, Tt as require_ignoreElements, U as require_publish, Ut as require_bufferWhen, V as require_publishLast, Vt as require_reduce, W as require_pluck, Wt as require_bufferToggle, X as require_merge, Xt as require_filter, Y as require_mergeWith, Yt as require_audit, Z as require_mergeScan, Zt as require_not, _ as require_takeWhile, _t as require_throwIfEmpty, a as require_withLatestFrom, an as require_observeOn, at as require_groupBy, b as require_switchMapTo, bt as require_distinct, c as require_windowTime, ct as require_find, d as require_timestamp, dt as require_exhaust, en as require_mergeAll, et as require_max, f as require_timeoutWith, ft as require_exhaustAll, g as require_tap, gt as require_elementAt, h as require_throttle, ht as require_endWith, i as require_zipAll, in as require_subscribeOn, it as require_isEmpty, j as require_sequenceEqual, jt as require_connect, k as require_shareReplay, kt as require_debounce, l as require_windowCount, lt as require_finalize, m as require_throttleTime, mt as require_every, n as require_zipWith, nn as require_map, nt as require_last, o as require_windowWhen, on as require_refCount, ot as require_first, p as require_timeInterval, pt as require_exhaustMap, q as require_multicast, qt as require_buffer, r as require_zip, rn as require_timeout, rt as require_takeLast, s as require_windowToggle, st as require_findIndex, t as require_cjs, tn as require_mergeMap, tt as require_materialize, u as require_window, ut as require_expand, v as require_takeUntil, vt as require_distinctUntilKeyChanged, w as require_skipWhile, wt as require_mapTo, x as require_switchAll, xt as require_dematerialize, y as require_switchScan, yt as require_distinctUntilChanged, z as require_raceWith, zt as require_combineLatestAll } from "./rxjs.js";
//#region node_modules/@angular/core/fesm2022/_effect-chunk.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var activeConsumer = null;
var inNotificationPhase = false;
var epoch = 1;
var postProducerCreatedFn = null;
var SIGNAL = /* @__PURE__ */ Symbol("SIGNAL");
function setActiveConsumer(consumer) {
	const prev = activeConsumer;
	activeConsumer = consumer;
	return prev;
}
function getActiveConsumer() {
	return activeConsumer;
}
function isInNotificationPhase() {
	return inNotificationPhase;
}
var REACTIVE_NODE = {
	version: 0,
	lastCleanEpoch: 0,
	dirty: false,
	producers: void 0,
	producersTail: void 0,
	consumers: void 0,
	consumersTail: void 0,
	recomputing: false,
	consumerAllowSignalWrites: false,
	consumerIsAlwaysLive: false,
	kind: "unknown",
	producerMustRecompute: () => false,
	producerRecomputeValue: () => {},
	consumerMarkedDirty: () => {},
	consumerOnSignalRead: () => {}
};
function producerAccessed(node) {
	if (inNotificationPhase) throw new Error(typeof ngDevMode !== "undefined" && ngDevMode ? `Assertion error: signal read during notification phase` : "");
	if (activeConsumer === null) return;
	activeConsumer.consumerOnSignalRead(node);
	const prevProducerLink = activeConsumer.producersTail;
	if (prevProducerLink !== void 0 && prevProducerLink.producer === node) return;
	let nextProducerLink = void 0;
	const isRecomputing = activeConsumer.recomputing;
	if (isRecomputing) {
		nextProducerLink = prevProducerLink !== void 0 ? prevProducerLink.nextProducer : activeConsumer.producers;
		if (nextProducerLink !== void 0 && nextProducerLink.producer === node) {
			activeConsumer.producersTail = nextProducerLink;
			nextProducerLink.lastReadVersion = node.version;
			nextProducerLink.knownValidAtEpoch = epoch;
			return;
		}
	}
	const prevConsumerLink = node.consumersTail;
	if (prevConsumerLink !== void 0 && prevConsumerLink.consumer === activeConsumer && (!isRecomputing || prevConsumerLink.knownValidAtEpoch === epoch)) return;
	const isLive = consumerIsLive(activeConsumer);
	const newLink = {
		producer: node,
		consumer: activeConsumer,
		nextProducer: nextProducerLink,
		prevConsumer: void 0,
		knownValidAtEpoch: epoch,
		lastReadVersion: node.version,
		nextConsumer: void 0
	};
	activeConsumer.producersTail = newLink;
	if (prevProducerLink !== void 0) prevProducerLink.nextProducer = newLink;
	else activeConsumer.producers = newLink;
	if (isLive) producerAddLiveConsumer(node, newLink);
}
function producerIncrementEpoch() {
	epoch++;
}
function producerUpdateValueVersion(node) {
	if (consumerIsLive(node) && !node.dirty) return;
	if (!node.dirty && node.lastCleanEpoch === epoch) return;
	if (!node.producerMustRecompute(node) && !consumerPollProducersForChange(node)) {
		producerMarkClean(node);
		return;
	}
	node.producerRecomputeValue(node);
	producerMarkClean(node);
}
function producerNotifyConsumers(node) {
	if (node.consumers === void 0) return;
	const prev = inNotificationPhase;
	inNotificationPhase = true;
	try {
		for (let link = node.consumers; link !== void 0; link = link.nextConsumer) {
			const consumer = link.consumer;
			if (!consumer.dirty) consumerMarkDirty(consumer);
		}
	} finally {
		inNotificationPhase = prev;
	}
}
function producerUpdatesAllowed() {
	return activeConsumer?.consumerAllowSignalWrites !== false;
}
function consumerMarkDirty(node) {
	node.dirty = true;
	producerNotifyConsumers(node);
	node.consumerMarkedDirty?.(node);
}
function producerMarkClean(node) {
	node.dirty = false;
	node.lastCleanEpoch = epoch;
}
function consumerBeforeComputation(node) {
	if (node) resetConsumerBeforeComputation(node);
	return setActiveConsumer(node);
}
function resetConsumerBeforeComputation(node) {
	if (node.producersTail?.knownValidAtEpoch === epoch) {
		let producer = node.producers;
		while (producer !== void 0) {
			producer.knownValidAtEpoch = null;
			producer = producer.nextProducer;
		}
	}
	node.producersTail = void 0;
	node.recomputing = true;
}
function consumerAfterComputation(node, prevConsumer) {
	setActiveConsumer(prevConsumer);
	if (node) finalizeConsumerAfterComputation(node);
}
function finalizeConsumerAfterComputation(node) {
	node.recomputing = false;
	const producersTail = node.producersTail;
	let toRemove = producersTail !== void 0 ? producersTail.nextProducer : node.producers;
	if (toRemove !== void 0) {
		if (consumerIsLive(node)) do
			toRemove = producerRemoveLiveConsumerLink(toRemove);
		while (toRemove !== void 0);
		if (producersTail !== void 0) producersTail.nextProducer = void 0;
		else node.producers = void 0;
	}
}
function consumerPollProducersForChange(node) {
	for (let link = node.producers; link !== void 0; link = link.nextProducer) {
		const producer = link.producer;
		const seenVersion = link.lastReadVersion;
		if (seenVersion !== producer.version) return true;
		producerUpdateValueVersion(producer);
		if (seenVersion !== producer.version) return true;
	}
	return false;
}
function consumerDestroy(node) {
	if (consumerIsLive(node)) {
		let link = node.producers;
		while (link !== void 0) link = producerRemoveLiveConsumerLink(link);
	}
	node.producers = void 0;
	node.producersTail = void 0;
	node.consumers = void 0;
	node.consumersTail = void 0;
}
function producerAddLiveConsumer(node, link) {
	const consumersTail = node.consumersTail;
	const wasLive = consumerIsLive(node);
	if (consumersTail !== void 0) {
		link.nextConsumer = consumersTail.nextConsumer;
		consumersTail.nextConsumer = link;
	} else {
		link.nextConsumer = void 0;
		node.consumers = link;
	}
	link.prevConsumer = consumersTail;
	node.consumersTail = link;
	if (!wasLive) for (let link = node.producers; link !== void 0; link = link.nextProducer) producerAddLiveConsumer(link.producer, link);
}
function producerRemoveLiveConsumerLink(link) {
	const producer = link.producer;
	const nextProducer = link.nextProducer;
	const nextConsumer = link.nextConsumer;
	const prevConsumer = link.prevConsumer;
	link.nextConsumer = void 0;
	link.prevConsumer = void 0;
	if (nextConsumer !== void 0) nextConsumer.prevConsumer = prevConsumer;
	else producer.consumersTail = prevConsumer;
	if (prevConsumer !== void 0) prevConsumer.nextConsumer = nextConsumer;
	else {
		producer.consumers = nextConsumer;
		if (!consumerIsLive(producer)) {
			let producerLink = producer.producers;
			while (producerLink !== void 0) producerLink = producerRemoveLiveConsumerLink(producerLink);
		}
	}
	return nextProducer;
}
function consumerIsLive(node) {
	return node.consumerIsAlwaysLive || node.consumers !== void 0;
}
function runPostProducerCreatedFn(node) {
	postProducerCreatedFn?.(node);
}
function defaultEquals(a, b) {
	return Object.is(a, b);
}
function createComputed(computation, equal) {
	const node = Object.create(COMPUTED_NODE);
	node.computation = computation;
	if (equal !== void 0) node.equal = equal;
	const computed = () => {
		producerUpdateValueVersion(node);
		producerAccessed(node);
		if (node.value === ERRORED) throw node.error;
		return node.value;
	};
	computed[SIGNAL] = node;
	if (typeof ngDevMode !== "undefined" && ngDevMode) computed.toString = () => `[Computed${node.debugName ? " (" + node.debugName + ")" : ""}: ${String(node.value)}]`;
	runPostProducerCreatedFn(node);
	return computed;
}
var UNSET = /* @__PURE__ */ Symbol("UNSET");
var COMPUTING = /* @__PURE__ */ Symbol("COMPUTING");
var ERRORED = /* @__PURE__ */ Symbol("ERRORED");
var COMPUTED_NODE = /* @__PURE__ */ (() => {
	return {
		...REACTIVE_NODE,
		value: UNSET,
		dirty: true,
		error: null,
		equal: defaultEquals,
		kind: "computed",
		producerMustRecompute(node) {
			return node.value === UNSET || node.value === COMPUTING;
		},
		producerRecomputeValue(node) {
			if (node.value === COMPUTING) throw new Error(typeof ngDevMode !== "undefined" && ngDevMode ? "Detected cycle in computations." : "");
			const oldValue = node.value;
			node.value = COMPUTING;
			const prevConsumer = consumerBeforeComputation(node);
			let newValue;
			let wasEqual = false;
			try {
				newValue = node.computation();
				setActiveConsumer(null);
				wasEqual = oldValue !== UNSET && oldValue !== ERRORED && newValue !== ERRORED && node.equal(oldValue, newValue);
			} catch (err) {
				newValue = ERRORED;
				node.error = err;
			} finally {
				consumerAfterComputation(node, prevConsumer);
			}
			if (wasEqual) {
				node.value = oldValue;
				return;
			}
			node.value = newValue;
			node.version++;
		}
	};
})();
function defaultThrowError() {
	throw new Error();
}
var throwInvalidWriteToSignalErrorFn = defaultThrowError;
function throwInvalidWriteToSignalError(node) {
	throwInvalidWriteToSignalErrorFn(node);
}
function setThrowInvalidWriteToSignalError(fn) {
	throwInvalidWriteToSignalErrorFn = fn;
}
var postSignalSetFn = null;
function createSignal(initialValue, equal) {
	const node = Object.create(SIGNAL_NODE);
	node.value = initialValue;
	if (equal !== void 0) node.equal = equal;
	const getter = () => signalGetFn(node);
	getter[SIGNAL] = node;
	if (typeof ngDevMode !== "undefined" && ngDevMode) getter.toString = () => `[Signal${node.debugName ? " (" + node.debugName + ")" : ""}: ${String(node.value)}]`;
	runPostProducerCreatedFn(node);
	const set = (newValue) => signalSetFn(node, newValue);
	const update = (updateFn) => signalUpdateFn(node, updateFn);
	return [
		getter,
		set,
		update
	];
}
function signalGetFn(node) {
	producerAccessed(node);
	return node.value;
}
function signalSetFn(node, newValue) {
	if (!producerUpdatesAllowed()) throwInvalidWriteToSignalError(node);
	if (!node.equal(node.value, newValue)) {
		node.value = newValue;
		signalValueChanged(node);
	}
}
function signalUpdateFn(node, updater) {
	if (!producerUpdatesAllowed()) throwInvalidWriteToSignalError(node);
	signalSetFn(node, updater(node.value));
}
var SIGNAL_NODE = /* @__PURE__ */ (() => {
	return {
		...REACTIVE_NODE,
		equal: defaultEquals,
		value: void 0,
		kind: "signal"
	};
})();
function signalValueChanged(node) {
	node.version++;
	producerIncrementEpoch();
	producerNotifyConsumers(node);
	postSignalSetFn?.(node);
}
var BASE_EFFECT_NODE = /* @__PURE__ */ (() => ({
	...REACTIVE_NODE,
	consumerIsAlwaysLive: true,
	consumerAllowSignalWrites: true,
	dirty: true,
	kind: "effect"
}))();
function runEffect(node) {
	node.dirty = false;
	if (node.version > 0 && !consumerPollProducersForChange(node)) return;
	node.version++;
	const prevNode = consumerBeforeComputation(node);
	try {
		node.cleanup();
		node.fn();
	} finally {
		consumerAfterComputation(node, prevNode);
	}
}
//#endregion
//#region node_modules/@angular/core/fesm2022/_not_found-chunk.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _currentInjector = void 0;
function getCurrentInjector() {
	return _currentInjector;
}
function setCurrentInjector(injector) {
	const former = _currentInjector;
	_currentInjector = injector;
	return former;
}
var NOT_FOUND$1 = Symbol("NotFound");
function isNotFound(e) {
	return e === NOT_FOUND$1 || e?.name === "ɵNotFound";
}
//#endregion
//#region node_modules/@angular/core/fesm2022/_untracked-chunk.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function createLinkedSignal(sourceFn, computationFn, equalityFn) {
	const node = Object.create(LINKED_SIGNAL_NODE);
	node.source = sourceFn;
	node.computation = computationFn;
	if (equalityFn != void 0) node.equal = equalityFn;
	const linkedSignalGetter = () => {
		producerUpdateValueVersion(node);
		producerAccessed(node);
		if (node.value === ERRORED) throw node.error;
		return node.value;
	};
	const getter = linkedSignalGetter;
	getter[SIGNAL] = node;
	if (typeof ngDevMode !== "undefined" && ngDevMode) getter.toString = () => `[LinkedSignal${node.debugName ? " (" + node.debugName + ")" : ""}: ${String(node.value)}]`;
	runPostProducerCreatedFn(node);
	return getter;
}
function linkedSignalSetFn(node, newValue) {
	producerUpdateValueVersion(node);
	signalSetFn(node, newValue);
	producerMarkClean(node);
}
function linkedSignalUpdateFn(node, updater) {
	producerUpdateValueVersion(node);
	if (node.value === ERRORED) throw node.error;
	signalUpdateFn(node, updater);
	producerMarkClean(node);
}
var LINKED_SIGNAL_NODE = /* @__PURE__ */ (() => {
	return {
		...REACTIVE_NODE,
		value: UNSET,
		dirty: true,
		error: null,
		equal: defaultEquals,
		kind: "linkedSignal",
		producerMustRecompute(node) {
			return node.value === UNSET || node.value === COMPUTING;
		},
		producerRecomputeValue(node) {
			if (node.value === COMPUTING) throw new Error(typeof ngDevMode !== "undefined" && ngDevMode ? "Detected cycle in computations." : "");
			const oldValue = node.value;
			node.value = COMPUTING;
			const prevConsumer = consumerBeforeComputation(node);
			let newValue;
			let wasEqual = false;
			try {
				const newSourceValue = node.source();
				const oldValueValid = oldValue !== UNSET && oldValue !== ERRORED;
				const prev = oldValueValid ? {
					source: node.sourceValue,
					value: oldValue
				} : void 0;
				newValue = node.computation(newSourceValue, prev);
				node.sourceValue = newSourceValue;
				setActiveConsumer(null);
				wasEqual = oldValueValid && newValue !== ERRORED && node.equal(oldValue, newValue);
			} catch (err) {
				newValue = ERRORED;
				node.error = err;
			} finally {
				consumerAfterComputation(node, prevConsumer);
			}
			if (wasEqual) {
				node.value = oldValue;
				return;
			}
			node.value = newValue;
			node.version++;
		}
	};
})();
function untracked$1(nonReactiveReadsFn) {
	const prevConsumer = setActiveConsumer(null);
	try {
		return nonReactiveReadsFn();
	} finally {
		setActiveConsumer(prevConsumer);
	}
}
//#endregion
//#region node_modules/@angular/core/fesm2022/_weak_ref-chunk.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function setAlternateWeakRefImpl(impl) {}
//#endregion
//#region node_modules/@angular/core/fesm2022/primitives-signals.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var formatter = {
	header: (sig, config) => {
		if (!isSignal$1(sig) || config?.ngSkipFormatting) return null;
		let value;
		try {
			value = sig();
		} catch (e) {
			return ["span", `Signal(⚠️ Error)${e.message ? `: ${e.message}` : ""}`];
		}
		const kind = "computation" in sig[SIGNAL] ? "Computed" : "Signal";
		const isPrimitive = value === null || !Array.isArray(value) && typeof value !== "object";
		return [
			"span",
			{},
			[
				"span",
				{},
				`${kind}(`
			],
			(() => {
				if (isSignal$1(value)) return formatter.header(value, config);
				else if (isPrimitive && value !== void 0 && typeof value !== "function") return ["object", { object: value }];
				else return prettifyPreview(value);
			})(),
			[
				"span",
				{},
				`)`
			]
		];
	},
	hasBody: (sig, config) => {
		if (!isSignal$1(sig)) return false;
		try {
			sig();
		} catch {
			return false;
		}
		return !config?.ngSkipFormatting;
	},
	body: (sig, config) => {
		const color = "var(--sys-color-primary)";
		return [
			"div",
			{ style: `background: #FFFFFF10; padding-left: 4px; padding-top: 2px; padding-bottom: 2px;` },
			[
				"div",
				{ style: `color: ${color}` },
				"Signal value: "
			],
			[
				"div",
				{ style: `padding-left: .5rem;` },
				["object", {
					object: sig(),
					config
				}]
			],
			[
				"div",
				{ style: `color: ${color}` },
				"Signal function: "
			],
			[
				"div",
				{ style: `padding-left: .5rem;` },
				["object", {
					object: sig,
					config: {
						...config,
						ngSkipFormatting: true
					}
				}]
			]
		];
	}
};
function prettifyPreview(value) {
	if (value === null) return "null";
	if (Array.isArray(value)) return `Array(${value.length})`;
	if (value instanceof Element) return `<${value.tagName.toLowerCase()}>`;
	if (value instanceof URL) return `URL`;
	switch (typeof value) {
		case "undefined": return "undefined";
		case "function": if ("prototype" in value) return "class";
		else return "() => {…}";
		case "object": if (value.constructor.name === "Object") return "{…}";
		else return `${value.constructor.name} {}`;
		default: return ["object", {
			object: value,
			config: { ngSkipFormatting: true }
		}];
	}
}
function isSignal$1(value) {
	return value[SIGNAL] !== void 0;
}
function installDevToolsSignalFormatter() {
	globalThis.devtoolsFormatters ??= [];
	if (!globalThis.devtoolsFormatters.some((f) => f === formatter)) globalThis.devtoolsFormatters.push(formatter);
}
if (typeof ngDevMode === "undefined" || ngDevMode) installDevToolsSignalFormatter();
//#endregion
//#region node_modules/@angular/core/fesm2022/_pending_tasks-chunk.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var import_cjs = require_cjs();
var Version = class {
	full;
	major;
	minor;
	patch;
	constructor(full) {
		this.full = full;
		const parts = full.split(".");
		this.major = parts[0];
		this.minor = parts[1];
		this.patch = parts.slice(2).join(".");
	}
};
var VERSION = /* @__PURE__ */ new Version("22.2.1");
var DOC_PAGE_BASE_URL = (() => {
	const full = VERSION.full;
	return `https://${full.includes("-next") || full.includes("-rc") || full === "0.0.0-PLACEHOLDER" ? "next" : `v${VERSION.major}`}.angular.dev`;
})();
var ERROR_DETAILS_PAGE_BASE_URL = (() => {
	return `${DOC_PAGE_BASE_URL}/errors`;
})();
var XSS_SECURITY_URL = "https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss";
var RuntimeError = class extends Error {
	code;
	constructor(code, message) {
		super(formatRuntimeError(code, message));
		this.code = code;
	}
};
function formatRuntimeErrorCode(code) {
	return `NG0${Math.abs(code)}`;
}
function formatRuntimeError(code, message) {
	const fullCode = formatRuntimeErrorCode(code);
	let errorMessage = `${fullCode}${message ? ": " + message : ""}`;
	if (ngDevMode && code < 0) {
		const separator = !errorMessage.match(/[.,;!?\n]$/) ? "." : "";
		errorMessage = `${errorMessage}${separator} Find more at ${ERROR_DETAILS_PAGE_BASE_URL}/${fullCode}`;
	}
	return errorMessage;
}
function getClosureSafeProperty(objWithPropertyToExtract) {
	for (let key in objWithPropertyToExtract) if (objWithPropertyToExtract[key] === getClosureSafeProperty) return key;
	throw Error(typeof ngDevMode !== "undefined" && ngDevMode ? "Could not find renamed property on target object." : "");
}
function fillProperties(target, source) {
	for (const key in source) if (Object.hasOwn(source, key) && !Object.hasOwn(target, key)) target[key] = source[key];
}
function stringify(token) {
	if (typeof token === "string") return token;
	if (Array.isArray(token)) return `[${token.map(stringify).join(", ")}]`;
	if (token == null) return "" + token;
	const name = token.overriddenName || token.name;
	if (name) return `${name}`;
	const result = token.toString();
	if (result == null) return "" + result;
	const newLineIndex = result.indexOf("\n");
	return newLineIndex >= 0 ? result.slice(0, newLineIndex) : result;
}
function concatStringsWithSpace(before, after) {
	if (!before) return after || "";
	if (!after) return before;
	return `${before} ${after}`;
}
function truncateMiddle(str, maxLength = 100) {
	if (!str || maxLength < 1 || str.length <= maxLength) return str;
	if (maxLength == 1) return str.substring(0, 1) + "...";
	const halfLimit = Math.round(maxLength / 2);
	return str.substring(0, halfLimit) + "..." + str.substring(str.length - halfLimit);
}
var __forward_ref__ = getClosureSafeProperty({ __forward_ref__: getClosureSafeProperty });
function forwardRef(forwardRefFn) {
	forwardRefFn.__forward_ref__ = forwardRef;
	if (ngDevMode) forwardRefFn.toString = function() {
		return stringify(this());
	};
	return forwardRefFn;
}
function resolveForwardRef(type) {
	return isForwardRef(type) ? type() : type;
}
function isForwardRef(fn) {
	return typeof fn === "function" && Object.hasOwn(fn, __forward_ref__) && fn.__forward_ref__ === forwardRef;
}
function assertNumber(actual, msg) {
	if (!(typeof actual === "number")) throwError(msg, typeof actual, "number", "===");
}
function assertNumberInRange(actual, minInclusive, maxInclusive) {
	assertNumber(actual, "Expected a number");
	assertLessThanOrEqual(actual, maxInclusive, "Expected number to be less than or equal to");
	assertGreaterThanOrEqual(actual, minInclusive, "Expected number to be greater than or equal to");
}
function assertString(actual, msg) {
	if (!(typeof actual === "string")) throwError(msg, actual === null ? "null" : typeof actual, "string", "===");
}
function assertFunction(actual, msg) {
	if (!(typeof actual === "function")) throwError(msg, actual === null ? "null" : typeof actual, "function", "===");
}
function assertEqual(actual, expected, msg) {
	if (!(actual == expected)) throwError(msg, actual, expected, "==");
}
function assertNotEqual(actual, expected, msg) {
	if (!(actual != expected)) throwError(msg, actual, expected, "!=");
}
function assertSame(actual, expected, msg) {
	if (!(actual === expected)) throwError(msg, actual, expected, "===");
}
function assertNotSame(actual, expected, msg) {
	if (!(actual !== expected)) throwError(msg, actual, expected, "!==");
}
function assertLessThan(actual, expected, msg) {
	if (!(actual < expected)) throwError(msg, actual, expected, "<");
}
function assertLessThanOrEqual(actual, expected, msg) {
	if (!(actual <= expected)) throwError(msg, actual, expected, "<=");
}
function assertGreaterThan(actual, expected, msg) {
	if (!(actual > expected)) throwError(msg, actual, expected, ">");
}
function assertGreaterThanOrEqual(actual, expected, msg) {
	if (!(actual >= expected)) throwError(msg, actual, expected, ">=");
}
function assertNotDefined(actual, msg) {
	if (actual != null) throwError(msg, actual, null, "==");
}
function assertDefined(actual, msg) {
	if (actual == null) throwError(msg, actual, null, "!=");
}
function throwError(msg, actual, expected, comparison) {
	throw new Error(`ASSERTION ERROR: ${msg}` + (comparison == null ? "" : ` [Expected=> ${expected} ${comparison} ${actual} <=Actual]`));
}
function assertDomNode(node) {
	if (!(node instanceof Node)) throwError(`The provided value must be an instance of a DOM Node but got ${stringify(node)}`);
}
function assertElement(node) {
	if (!(node instanceof Element)) throwError(`The provided value must be an element but got ${stringify(node)}`);
}
function assertIndexInRange(arr, index) {
	assertDefined(arr, "Array must be defined.");
	const maxLen = arr.length;
	if (index < 0 || index >= maxLen) throwError(`Index expected to be less than ${maxLen} but got ${index}`);
}
function assertOneOf(value, ...validValues) {
	if (validValues.indexOf(value) !== -1) return true;
	throwError(`Expected value to be one of ${JSON.stringify(validValues)} but was ${JSON.stringify(value)}.`);
}
function assertNotReactive(fn) {
	if (getActiveConsumer() !== null) throwError(`${fn}() should never be called in a reactive context.`);
}
function ɵɵdefineInjectable(opts) {
	return {
		token: opts.token,
		providedIn: opts.providedIn || null,
		factory: opts.factory,
		value: void 0
	};
}
function ɵɵdefineInjector(options) {
	return {
		providers: options.providers || [],
		imports: options.imports || []
	};
}
function getInjectableDef(type) {
	return getOwnDefinition(type, NG_PROV_DEF);
}
function isInjectable(type) {
	return getInjectableDef(type) !== null;
}
function getOwnDefinition(type, field) {
	return Object.hasOwn(type, field) && type[field] || null;
}
function getInheritedInjectableDef(type) {
	const def = type?.[NG_PROV_DEF] ?? null;
	if (def) {
		ngDevMode && console.warn(`DEPRECATED: DI is instantiating a token "${type.name}" that inherits its @Injectable decorator but does not provide one itself.\nThis will become an error in a future version of Angular. Please add @Injectable() to the "${type.name}" class.`);
		return def;
	} else return null;
}
function getInjectorDef(type) {
	return type && Object.hasOwn(type, NG_INJ_DEF) ? type[NG_INJ_DEF] : null;
}
var NG_PROV_DEF = getClosureSafeProperty({ ɵprov: getClosureSafeProperty });
var NG_INJ_DEF = getClosureSafeProperty({ ɵinj: getClosureSafeProperty });
var InjectionToken = class {
	_desc;
	ngMetadataName = "InjectionToken";
	ɵprov;
	constructor(_desc, options) {
		this._desc = _desc;
		this.ɵprov = void 0;
		if (typeof options == "number") {
			(typeof ngDevMode === "undefined" || ngDevMode) && assertLessThan(options, 0, "Only negative numbers are supported here");
			this.__NG_ELEMENT_ID__ = options;
		} else if (options !== void 0) this.ɵprov = ɵɵdefineInjectable({
			token: this,
			providedIn: options.providedIn || "root",
			factory: options.factory
		});
	}
	get multi() {
		return this;
	}
	toString() {
		return `InjectionToken ${this._desc}`;
	}
};
var _injectorProfilerContext;
function getInjectorProfilerContext() {
	!ngDevMode && throwError("getInjectorProfilerContext should never be called in production mode");
	return _injectorProfilerContext;
}
function setInjectorProfilerContext(context) {
	!ngDevMode && throwError("setInjectorProfilerContext should never be called in production mode");
	const previous = _injectorProfilerContext;
	_injectorProfilerContext = context;
	return previous;
}
var injectorProfilerCallbacks = [];
var NOOP_PROFILER_REMOVAL$1 = () => {};
function removeProfiler$1(profiler) {
	const profilerIdx = injectorProfilerCallbacks.indexOf(profiler);
	if (profilerIdx !== -1) injectorProfilerCallbacks.splice(profilerIdx, 1);
}
function setInjectorProfiler(injectorProfiler) {
	!ngDevMode && throwError("setInjectorProfiler should never be called in production mode");
	if (injectorProfiler !== null) {
		if (!injectorProfilerCallbacks.includes(injectorProfiler)) injectorProfilerCallbacks.push(injectorProfiler);
		return () => removeProfiler$1(injectorProfiler);
	} else {
		injectorProfilerCallbacks.length = 0;
		return NOOP_PROFILER_REMOVAL$1;
	}
}
function injectorProfiler(event) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	for (let i = 0; i < injectorProfilerCallbacks.length; i++) {
		const injectorProfilerCallback = injectorProfilerCallbacks[i];
		injectorProfilerCallback(event);
	}
}
function emitProviderConfiguredEvent(eventProvider, isViewProvider = false) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	let token;
	if (typeof eventProvider === "function") token = eventProvider;
	else if (eventProvider instanceof InjectionToken) token = eventProvider;
	else token = resolveForwardRef(eventProvider.provide);
	let provider = eventProvider;
	if (eventProvider instanceof InjectionToken) provider = eventProvider.ɵprov || eventProvider;
	injectorProfiler({
		type: 2,
		context: getInjectorProfilerContext(),
		providerRecord: {
			token,
			provider,
			isViewProvider
		}
	});
}
function emitInjectorToCreateInstanceEvent(token) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 5,
		context: getInjectorProfilerContext(),
		token
	});
}
function emitInstanceCreatedByInjectorEvent(instance) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 1,
		context: getInjectorProfilerContext(),
		instance: { value: instance }
	});
}
function emitInjectEvent(token, value, flags) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 0,
		context: getInjectorProfilerContext(),
		service: {
			token,
			value,
			flags
		}
	});
}
function emitEffectCreatedEvent(effect) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 3,
		context: getInjectorProfilerContext(),
		effect
	});
}
function runInInjectorProfilerContext(injector, token, callback) {
	!ngDevMode && throwError("runInInjectorProfilerContext should never be called in production mode");
	const prevInjectContext = setInjectorProfilerContext({
		injector,
		token
	});
	try {
		callback();
	} finally {
		setInjectorProfilerContext(prevInjectContext);
	}
}
function isEnvironmentProviders(value) {
	return value && !!value.ɵproviders;
}
var NG_COMP_DEF = getClosureSafeProperty({ ɵcmp: getClosureSafeProperty });
var NG_DIR_DEF = getClosureSafeProperty({ ɵdir: getClosureSafeProperty });
var NG_PIPE_DEF = getClosureSafeProperty({ ɵpipe: getClosureSafeProperty });
var NG_MOD_DEF = getClosureSafeProperty({ ɵmod: getClosureSafeProperty });
var NG_FACTORY_DEF = getClosureSafeProperty({ ɵfac: getClosureSafeProperty });
var NG_ELEMENT_ID = getClosureSafeProperty({ __NG_ELEMENT_ID__: getClosureSafeProperty });
var NG_ENV_ID = getClosureSafeProperty({ __NG_ENV_ID__: getClosureSafeProperty });
function getNgModuleDef(type) {
	assertTypeDefined(type, "@NgModule");
	return type[NG_MOD_DEF] || null;
}
function getNgModuleDefOrThrow(type) {
	const ngModuleDef = getNgModuleDef(type);
	if (!ngModuleDef) throw new RuntimeError(915, (typeof ngDevMode === "undefined" || ngDevMode) && `Type ${stringify(type)} does not have 'ɵmod' property.`);
	return ngModuleDef;
}
function getComponentDef(type) {
	assertTypeDefined(type, "@Component");
	return type[NG_COMP_DEF] || null;
}
function getDirectiveDefOrThrow(type) {
	const def = getDirectiveDef(type);
	if (!def) throw new RuntimeError(916, (typeof ngDevMode === "undefined" || ngDevMode) && `Type ${stringify(type)} does not have 'ɵdir' property.`);
	return def;
}
function getDirectiveDef(type) {
	assertTypeDefined(type, "@Directive");
	return type[NG_DIR_DEF] || null;
}
function getPipeDef$1(type) {
	assertTypeDefined(type, "@Pipe");
	return type[NG_PIPE_DEF] || null;
}
function assertTypeDefined(type, symbolType) {
	if (type == null) throw new RuntimeError(-919, (typeof ngDevMode === "undefined" || ngDevMode) && `Cannot read ${symbolType} metadata. This can indicate a runtime circular dependency in your app that needs to be resolved.`);
}
function isStandalone(type) {
	const def = getComponentDef(type) || getDirectiveDef(type) || getPipeDef$1(type);
	return def !== null && def.standalone;
}
function renderStringify(value) {
	if (typeof value === "string") return value;
	if (value == null) return "";
	return String(value);
}
function stringifyForError(value) {
	if (typeof value === "function") return value.name || value.toString();
	if (typeof value === "object" && value != null && typeof value.type === "function") return value.type.name || value.type.toString();
	return renderStringify(value);
}
function debugStringifyTypeForError(type) {
	const componentDef = getComponentDef(type);
	if (componentDef !== null && componentDef.debugInfo) return stringifyTypeFromDebugInfo(componentDef.debugInfo);
	return stringifyForError(type);
}
function stringifyTypeFromDebugInfo(debugInfo) {
	if (!debugInfo.filePath || !debugInfo.lineNumber) return debugInfo.className;
	else return `${debugInfo.className} (at ${debugInfo.filePath}:${debugInfo.lineNumber})`;
}
var NG_RUNTIME_ERROR_CODE = getClosureSafeProperty({ "ngErrorCode": getClosureSafeProperty });
var NG_RUNTIME_ERROR_MESSAGE = getClosureSafeProperty({ "ngErrorMessage": getClosureSafeProperty });
var NG_TOKEN_PATH = getClosureSafeProperty({ "ngTokenPath": getClosureSafeProperty });
function cyclicDependencyError(token, path) {
	return createRuntimeError(ngDevMode ? `Circular dependency detected for \`${token}\`.` : "", -200, path);
}
function cyclicDependencyErrorWithDetails(token, path) {
	return augmentRuntimeError(cyclicDependencyError(token, path), null);
}
function throwMixedMultiProviderError() {
	throw new Error(`Cannot mix multi providers and regular providers`);
}
function throwInvalidProviderError(ngModuleType, providers, provider) {
	if (ngModuleType && providers) {
		const providerDetail = providers.map((v) => v == provider ? "?" + provider + "?" : "...");
		throw new Error(`Invalid provider for the NgModule '${stringify(ngModuleType)}' - only instances of Provider and Type are allowed, got: [${providerDetail.join(", ")}]`);
	} else if (isEnvironmentProviders(provider)) {
		if (provider.ɵfromNgModule) throw new RuntimeError(-207, `Invalid providers from 'importProvidersFrom' present in a non-environment injector. 'importProvidersFrom' can't be used for component providers.`);
		else throw new RuntimeError(-207, `Invalid providers present in a non-environment injector. 'EnvironmentProviders' can't be used for component providers.`);
	} else throw new Error("Invalid provider");
}
function throwProviderNotFoundError(token, injectorName) {
	throw new RuntimeError(-201, ngDevMode && `No provider for ${stringifyForError(token)} found${injectorName ? ` in ${injectorName}` : ""}`);
}
function prependTokenToDependencyPath(error, token) {
	error[NG_TOKEN_PATH] ??= [];
	const currentPath = error[NG_TOKEN_PATH];
	let pathStr;
	if (typeof token === "object" && "multi" in token && token?.multi === true) {
		assertDefined(token.provide, "Token with multi: true should have a provide property");
		pathStr = stringifyForError(token.provide);
	} else pathStr = stringifyForError(token);
	if (currentPath[0] !== pathStr) error[NG_TOKEN_PATH].unshift(pathStr);
}
function augmentRuntimeError(error, source) {
	const tokenPath = error[NG_TOKEN_PATH];
	const errorCode = error[NG_RUNTIME_ERROR_CODE];
	error.message = formatErrorMessage(error[NG_RUNTIME_ERROR_MESSAGE] || error.message, errorCode, tokenPath, source);
	return error;
}
function createRuntimeError(message, code, path) {
	const error = new RuntimeError(code, message);
	error[NG_RUNTIME_ERROR_CODE] = code;
	error[NG_RUNTIME_ERROR_MESSAGE] = message;
	if (path) error[NG_TOKEN_PATH] = path;
	return error;
}
function getRuntimeErrorCode(error) {
	return error[NG_RUNTIME_ERROR_CODE];
}
function formatErrorMessage(text, code, path = [], source = null) {
	let pathDetails = "";
	if (path && path.length > 1) pathDetails = ` Path: ${path.join(" -> ")}.`;
	return formatRuntimeError(code, `${text}${source ? ` Source: ${source}.` : ""}${pathDetails}`);
}
var _injectImplementation;
function getInjectImplementation() {
	return _injectImplementation;
}
function setInjectImplementation(impl) {
	const previous = _injectImplementation;
	_injectImplementation = impl;
	return previous;
}
function injectRootLimpMode(token, notFoundValue, flags) {
	const injectableDef = getInjectableDef(token);
	if (injectableDef && injectableDef.providedIn == "root") return injectableDef.value === void 0 ? injectableDef.value = injectableDef.factory() : injectableDef.value;
	if (flags & 8) return null;
	if (notFoundValue !== void 0) return notFoundValue;
	throwProviderNotFoundError(token, typeof ngDevMode !== "undefined" && ngDevMode ? "Injector" : "");
}
function assertInjectImplementationNotEqual(fn) {
	ngDevMode && assertNotEqual(_injectImplementation, fn, "Calling ɵɵinject would cause infinite recursion");
}
var _global = globalThis;
function ngDevModeResetPerfCounters() {
	const locationString = typeof location !== "undefined" ? location.toString() : "";
	const newCounters = {
		hydratedNodes: 0,
		hydratedComponents: 0,
		dehydratedViewsRemoved: 0,
		dehydratedViewsCleanupRuns: 0,
		componentsSkippedHydration: 0,
		deferBlocksWithIncrementalHydration: 0
	};
	if (!(locationString.indexOf("ngDevMode=false") === -1)) _global["ngDevMode"] = false;
	else {
		if (typeof _global["ngDevMode"] !== "object") _global["ngDevMode"] = {};
		Object.assign(_global["ngDevMode"], newCounters);
	}
	return newCounters;
}
function initNgDevMode() {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		if (typeof ngDevMode !== "object" || Object.keys(ngDevMode).length === 0) ngDevModeResetPerfCounters();
		return typeof ngDevMode !== "undefined" && !!ngDevMode;
	}
	return false;
}
var THROW_IF_NOT_FOUND = {};
var DI_DECORATOR_FLAG = "__NG_DI_FLAG__";
var RetrievingInjector = class {
	injector;
	constructor(injector) {
		this.injector = injector;
	}
	retrieve(token, options) {
		const flags = convertToBitFlags(options) || 0;
		try {
			return this.injector.get(token, flags & 8 ? null : THROW_IF_NOT_FOUND, flags);
		} catch (e) {
			if (isNotFound(e)) return e;
			throw e;
		}
	}
};
function injectInjectorOnly(token, flags = 0) {
	const currentInjector = getCurrentInjector();
	if (currentInjector === void 0) throw new RuntimeError(-203, ngDevMode && `The \`${stringify(token)}\` token injection failed. \`inject()\` function must be called from an injection context such as a constructor, a factory function, a field initializer, or a function used with \`runInInjectionContext\`.`);
	else if (currentInjector === null) return injectRootLimpMode(token, void 0, flags);
	else {
		const options = convertToInjectOptions(flags);
		const value = currentInjector.retrieve(token, options);
		ngDevMode && emitInjectEvent(token, value, flags);
		if (isNotFound(value)) {
			if (options.optional) return null;
			throw value;
		}
		return value;
	}
}
function ɵɵinject(token, flags = 0) {
	return (getInjectImplementation() || injectInjectorOnly)(resolveForwardRef(token), flags);
}
function ɵɵinvalidFactoryDep(index) {
	throw new RuntimeError(202, ngDevMode && `This constructor is not compatible with Angular Dependency Injection because its dependency at index ${index} of the parameter list is invalid.
This can happen if the dependency type is a primitive like a string or if an ancestor of this class is missing an Angular decorator.

Please check that 1) the type for the parameter at index ${index} is correct and 2) the correct Angular decorators are defined for this class and its ancestors.`);
}
function inject(token, options) {
	return ɵɵinject(token, convertToBitFlags(options));
}
function convertToBitFlags(flags) {
	if (typeof flags === "undefined" || typeof flags === "number") return flags;
	return 0 | (flags.optional && 8) | (flags.host && 1) | (flags.self && 2) | (flags.skipSelf && 4);
}
function convertToInjectOptions(flags) {
	return {
		optional: !!(flags & 8),
		host: !!(flags & 1),
		self: !!(flags & 2),
		skipSelf: !!(flags & 4)
	};
}
function injectArgs(types) {
	const args = [];
	for (let i = 0; i < types.length; i++) {
		const arg = resolveForwardRef(types[i]);
		if (Array.isArray(arg)) {
			if (arg.length === 0) throw new RuntimeError(900, ngDevMode && "Arguments array must have arguments.");
			let type = void 0;
			let flags = 0;
			for (let j = 0; j < arg.length; j++) {
				const meta = arg[j];
				const flag = getInjectFlag(meta);
				if (typeof flag === "number") {
					if (flag === -1) type = meta.token;
					else flags |= flag;
				} else type = meta;
			}
			args.push(ɵɵinject(type, flags));
		} else args.push(ɵɵinject(arg));
	}
	return args;
}
function attachInjectFlag(decorator, flag) {
	decorator[DI_DECORATOR_FLAG] = flag;
	decorator.prototype[DI_DECORATOR_FLAG] = flag;
	return decorator;
}
function getInjectFlag(token) {
	return token[DI_DECORATOR_FLAG];
}
function getFactoryDef(type, throwNotFound) {
	const hasFactoryDef = Object.hasOwn(type, NG_FACTORY_DEF);
	if (!hasFactoryDef && throwNotFound === true && ngDevMode) throw new Error(`Type ${stringify(type)} does not have 'ɵfac' property.`);
	return hasFactoryDef ? type[NG_FACTORY_DEF] : null;
}
function arrayEquals(a, b, identityAccessor) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) {
		let valueA = a[i];
		let valueB = b[i];
		if (identityAccessor) {
			valueA = identityAccessor(valueA);
			valueB = identityAccessor(valueB);
		}
		if (valueB !== valueA) return false;
	}
	return true;
}
function flatten(list) {
	return list.flat(Number.POSITIVE_INFINITY);
}
function deepForEach(input, fn) {
	input.forEach((value) => Array.isArray(value) ? deepForEach(value, fn) : fn(value));
}
function addToArray(arr, index, value) {
	if (index >= arr.length) arr.push(value);
	else arr.splice(index, 0, value);
}
function removeFromArray(arr, index) {
	if (index >= arr.length - 1) return arr.pop();
	else return arr.splice(index, 1)[0];
}
function newArray(size, value) {
	const list = [];
	for (let i = 0; i < size; i++) list.push(value);
	return list;
}
function arraySplice(array, index, count) {
	const length = array.length - count;
	while (index < length) {
		array[index] = array[index + count];
		index++;
	}
	while (count--) array.pop();
}
function arrayInsert2(array, index, value1, value2) {
	ngDevMode && assertLessThanOrEqual(index, array.length, "Can't insert past array end.");
	let end = array.length;
	if (end == index) array.push(value1, value2);
	else if (end === 1) {
		array.push(value2, array[0]);
		array[0] = value1;
	} else {
		end--;
		array.push(array[end - 1], array[end]);
		while (end > index) {
			const previousEnd = end - 2;
			array[end] = array[previousEnd];
			end--;
		}
		array[index] = value1;
		array[index + 1] = value2;
	}
}
function keyValueArraySet(keyValueArray, key, value) {
	let index = keyValueArrayIndexOf(keyValueArray, key);
	if (index >= 0) keyValueArray[index | 1] = value;
	else {
		index = ~index;
		arrayInsert2(keyValueArray, index, key, value);
	}
	return index;
}
function keyValueArrayGet(keyValueArray, key) {
	const index = keyValueArrayIndexOf(keyValueArray, key);
	if (index >= 0) return keyValueArray[index | 1];
}
function keyValueArrayIndexOf(keyValueArray, key) {
	return _arrayIndexOfSorted(keyValueArray, key, 1);
}
function _arrayIndexOfSorted(array, value, shift) {
	ngDevMode && assertEqual(Array.isArray(array), true, "Expecting an array");
	let start = 0;
	let end = array.length >> shift;
	while (end !== start) {
		const middle = start + (end - start >> 1);
		const current = array[middle << shift];
		if (value === current) return middle << shift;
		else if (current > value) end = middle;
		else start = middle + 1;
	}
	return ~(end << shift);
}
var EMPTY_OBJ = {};
var EMPTY_ARRAY = [];
if ((typeof ngDevMode === "undefined" || ngDevMode) && initNgDevMode()) {
	Object.freeze(EMPTY_OBJ);
	Object.freeze(EMPTY_ARRAY);
}
var ENVIRONMENT_INITIALIZER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ENVIRONMENT_INITIALIZER" : "");
var INJECTOR$1 = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "INJECTOR" : "", -1);
var INJECTOR_DEF_TYPES = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "INJECTOR_DEF_TYPES" : "");
var NullInjector = class {
	get(token, notFoundValue = THROW_IF_NOT_FOUND) {
		if (notFoundValue === THROW_IF_NOT_FOUND) {
			const error = createRuntimeError(ngDevMode ? `No provider found for \`${stringify(token)}\`.` : "", -201);
			error.name = "ɵNotFound";
			throw error;
		}
		return notFoundValue;
	}
};
function makeEnvironmentProviders(providers) {
	return { ɵproviders: providers };
}
function provideEnvironmentInitializer(initializerFn) {
	return makeEnvironmentProviders([{
		provide: ENVIRONMENT_INITIALIZER,
		multi: true,
		useValue: initializerFn
	}]);
}
function importProvidersFrom(...sources) {
	return {
		ɵproviders: internalImportProvidersFrom(true, sources),
		ɵfromNgModule: true
	};
}
function internalImportProvidersFrom(checkForStandaloneCmp, ...sources) {
	const providersOut = [];
	const dedup = /* @__PURE__ */ new Set();
	let injectorTypesWithProviders;
	const collectProviders = (provider) => {
		providersOut.push(provider);
	};
	deepForEach(sources, (source) => {
		if ((typeof ngDevMode === "undefined" || ngDevMode) && checkForStandaloneCmp) {
			if (getComponentDef(source)?.standalone) throw new RuntimeError(800, `Importing providers supports NgModule or ModuleWithProviders but got a standalone component "${stringifyForError(source)}"`);
		}
		const internalSource = source;
		if (walkProviderTree(internalSource, collectProviders, [], dedup)) {
			injectorTypesWithProviders ||= [];
			injectorTypesWithProviders.push(internalSource);
		}
	});
	if (injectorTypesWithProviders !== void 0) processInjectorTypesWithProviders(injectorTypesWithProviders, collectProviders);
	return providersOut;
}
function processInjectorTypesWithProviders(typesWithProviders, visitor) {
	for (let i = 0; i < typesWithProviders.length; i++) {
		const { ngModule, providers } = typesWithProviders[i];
		deepForEachProvider(providers, (provider) => {
			ngDevMode && validateProvider(provider, providers || EMPTY_ARRAY, ngModule);
			visitor(provider, ngModule);
		});
	}
}
function walkProviderTree(container, visitor, parents, dedup) {
	container = resolveForwardRef(container);
	if (!container) return false;
	let defType = null;
	let injDef = getInjectorDef(container);
	const cmpDef = !injDef && getComponentDef(container);
	if (!injDef && !cmpDef) {
		const ngModule = container.ngModule;
		injDef = getInjectorDef(ngModule);
		if (injDef) defType = ngModule;
		else return false;
	} else if (cmpDef && !cmpDef.standalone) return false;
	else defType = container;
	if (ngDevMode && parents.indexOf(defType) !== -1) {
		const defName = stringify(defType);
		throw cyclicDependencyErrorWithDetails(defName, parents.map(stringify).concat(defName));
	}
	const isDuplicate = dedup.has(defType);
	if (cmpDef) {
		if (isDuplicate) return false;
		dedup.add(defType);
		if (cmpDef.dependencies) {
			const deps = typeof cmpDef.dependencies === "function" ? cmpDef.dependencies() : cmpDef.dependencies;
			for (const dep of deps) walkProviderTree(dep, visitor, parents, dedup);
		}
	} else if (injDef) {
		if (injDef.imports != null && !isDuplicate) {
			ngDevMode && parents.push(defType);
			dedup.add(defType);
			let importTypesWithProviders;
			try {
				deepForEach(injDef.imports, (imported) => {
					if (walkProviderTree(imported, visitor, parents, dedup)) {
						importTypesWithProviders ||= [];
						importTypesWithProviders.push(imported);
					}
				});
			} finally {
				ngDevMode && parents.pop();
			}
			if (importTypesWithProviders !== void 0) processInjectorTypesWithProviders(importTypesWithProviders, visitor);
		}
		if (!isDuplicate) {
			const factory = getFactoryDef(defType) || (() => new defType());
			visitor({
				provide: defType,
				useFactory: factory,
				deps: EMPTY_ARRAY
			}, defType);
			visitor({
				provide: INJECTOR_DEF_TYPES,
				useValue: defType,
				multi: true
			}, defType);
			visitor({
				provide: ENVIRONMENT_INITIALIZER,
				useValue: () => ɵɵinject(defType),
				multi: true
			}, defType);
		}
		const defProviders = injDef.providers;
		if (defProviders != null && !isDuplicate) {
			const injectorType = container;
			deepForEachProvider(defProviders, (provider) => {
				ngDevMode && validateProvider(provider, defProviders, injectorType);
				visitor(provider, injectorType);
			});
		}
	} else return false;
	return defType !== container && container.providers !== void 0;
}
function validateProvider(provider, providers, containerType) {
	if (isTypeProvider(provider) || isValueProvider(provider) || isFactoryProvider(provider) || isExistingProvider(provider)) return;
	if (!resolveForwardRef(provider && (provider.useClass || provider.provide))) throwInvalidProviderError(containerType, providers, provider);
}
function deepForEachProvider(providers, fn) {
	for (let provider of providers) {
		if (isEnvironmentProviders(provider)) provider = provider.ɵproviders;
		if (Array.isArray(provider)) deepForEachProvider(provider, fn);
		else fn(provider);
	}
}
var USE_VALUE$1 = getClosureSafeProperty({
	provide: String,
	useValue: getClosureSafeProperty
});
function isValueProvider(value) {
	return value !== null && typeof value == "object" && USE_VALUE$1 in value;
}
function isExistingProvider(value) {
	return !!(value && value.useExisting);
}
function isFactoryProvider(value) {
	return !!(value && value.useFactory);
}
function isTypeProvider(value) {
	return typeof value === "function";
}
function isClassProvider(value) {
	return !!value.useClass;
}
var INJECTOR_SCOPE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Set Injector scope." : "");
var NOT_YET = {};
var CIRCULAR = {};
var NULL_INJECTOR = void 0;
function getNullInjector() {
	if (NULL_INJECTOR === void 0) NULL_INJECTOR = new NullInjector();
	return NULL_INJECTOR;
}
var EnvironmentInjector = class {};
var R3Injector = class extends EnvironmentInjector {
	parent;
	source;
	scopes;
	records = /* @__PURE__ */ new Map();
	_ngOnDestroyHooks = /* @__PURE__ */ new Set();
	_onDestroyHooks = [];
	get destroyed() {
		return this._destroyed;
	}
	_destroyed = false;
	injectorDefTypes;
	constructor(providers, parent, source, scopes) {
		super();
		this.parent = parent;
		this.source = source;
		this.scopes = scopes;
		forEachSingleProvider(providers, (provider) => this.processProvider(provider));
		this.records.set(INJECTOR$1, makeRecord(void 0, this));
		if (scopes.has("environment")) this.records.set(EnvironmentInjector, makeRecord(void 0, this));
		const record = this.records.get(INJECTOR_SCOPE);
		if (record != null && typeof record.value === "string") this.scopes.add(record.value);
		this.injectorDefTypes = new Set(this.get(INJECTOR_DEF_TYPES, EMPTY_ARRAY, { self: true }));
	}
	retrieve(token, options) {
		const flags = convertToBitFlags(options) || 0;
		try {
			return this.get(token, THROW_IF_NOT_FOUND, flags);
		} catch (e) {
			if (isNotFound(e)) return e;
			throw e;
		}
	}
	destroy() {
		assertNotDestroyed(this);
		this._destroyed = true;
		const prevConsumer = setActiveConsumer(null);
		try {
			for (const service of this._ngOnDestroyHooks) service.ngOnDestroy();
			const onDestroyHooks = this._onDestroyHooks;
			this._onDestroyHooks = [];
			for (const hook of onDestroyHooks) hook();
		} finally {
			this.records.clear();
			this._ngOnDestroyHooks.clear();
			this.injectorDefTypes.clear();
			setActiveConsumer(prevConsumer);
		}
	}
	onDestroy(callback) {
		assertNotDestroyed(this);
		this._onDestroyHooks.push(callback);
		return () => this.removeOnDestroy(callback);
	}
	runInContext(fn) {
		assertNotDestroyed(this);
		const previousInjector = setCurrentInjector(this);
		const previousInjectImplementation = setInjectImplementation(void 0);
		let prevInjectContext;
		if (ngDevMode) prevInjectContext = setInjectorProfilerContext({
			injector: this,
			token: null
		});
		try {
			return fn();
		} finally {
			setCurrentInjector(previousInjector);
			setInjectImplementation(previousInjectImplementation);
			ngDevMode && setInjectorProfilerContext(prevInjectContext);
		}
	}
	get(token, notFoundValue = THROW_IF_NOT_FOUND, options) {
		assertNotDestroyed(this);
		if (Object.hasOwn(token, NG_ENV_ID)) return token[NG_ENV_ID](this);
		const flags = convertToBitFlags(options);
		let prevInjectContext;
		if (ngDevMode) prevInjectContext = setInjectorProfilerContext({
			injector: this,
			token
		});
		const previousInjector = setCurrentInjector(this);
		const previousInjectImplementation = setInjectImplementation(void 0);
		try {
			if (!(flags & 4)) {
				let record = this.records.get(token);
				if (record === void 0) {
					const def = couldBeInjectableType(token) && getInjectableDef(token);
					if (def && this.injectableDefInScope(def)) {
						if (ngDevMode) runInInjectorProfilerContext(this, token, () => {
							emitProviderConfiguredEvent(token);
						});
						record = makeRecord(injectableDefOrInjectorDefFactory(token), NOT_YET);
					} else record = null;
					this.records.set(token, record);
				}
				if (record != null) return this.hydrate(token, record, flags);
			}
			const nextInjector = !(flags & 2) ? this.parent : getNullInjector();
			notFoundValue = flags & 8 && notFoundValue === THROW_IF_NOT_FOUND ? null : notFoundValue;
			return nextInjector.get(token, notFoundValue);
		} catch (error) {
			const errorCode = getRuntimeErrorCode(error);
			if (errorCode === -200 || errorCode === -201) {
				if (ngDevMode) {
					prependTokenToDependencyPath(error, token);
					if (previousInjector) throw error;
					else throw augmentRuntimeError(error, this.source);
				} else throw new RuntimeError(errorCode, null);
			} else throw error;
		} finally {
			setInjectImplementation(previousInjectImplementation);
			setCurrentInjector(previousInjector);
			ngDevMode && setInjectorProfilerContext(prevInjectContext);
		}
	}
	resolveInjectorInitializers() {
		const prevConsumer = setActiveConsumer(null);
		const previousInjector = setCurrentInjector(this);
		const previousInjectImplementation = setInjectImplementation(void 0);
		let prevInjectContext;
		if (ngDevMode) prevInjectContext = setInjectorProfilerContext({
			injector: this,
			token: null
		});
		try {
			const initializers = this.get(ENVIRONMENT_INITIALIZER, EMPTY_ARRAY, { self: true });
			if (ngDevMode && !Array.isArray(initializers)) throw new RuntimeError(-209, `Unexpected type of the \`ENVIRONMENT_INITIALIZER\` token value (expected an array, but got ${typeof initializers}). Please check that the \`ENVIRONMENT_INITIALIZER\` token is configured as a \`multi: true\` provider.`);
			for (const initializer of initializers) initializer();
		} finally {
			setCurrentInjector(previousInjector);
			setInjectImplementation(previousInjectImplementation);
			ngDevMode && setInjectorProfilerContext(prevInjectContext);
			setActiveConsumer(prevConsumer);
		}
	}
	toString() {
		if (ngDevMode) {
			const tokens = [];
			const records = this.records;
			for (const token of records.keys()) tokens.push(stringify(token));
			return `R3Injector[${tokens.join(", ")}]`;
		}
		return "R3Injector[...]";
	}
	processProvider(provider) {
		provider = resolveForwardRef(provider);
		let token = isTypeProvider(provider) ? provider : resolveForwardRef(provider && provider.provide);
		const record = providerToRecord(provider);
		if (ngDevMode) runInInjectorProfilerContext(this, token, () => {
			if (isValueProvider(provider)) {
				emitInjectorToCreateInstanceEvent(token);
				emitInstanceCreatedByInjectorEvent(provider.useValue);
			}
			emitProviderConfiguredEvent(provider);
		});
		if (!isTypeProvider(provider) && provider.multi === true) {
			let multiRecord = this.records.get(token);
			if (multiRecord) {
				if (ngDevMode && multiRecord.multi === void 0) throwMixedMultiProviderError();
			} else {
				multiRecord = makeRecord(void 0, NOT_YET, true);
				multiRecord.factory = () => injectArgs(multiRecord.multi);
				this.records.set(token, multiRecord);
			}
			token = provider;
			multiRecord.multi.push(provider);
		} else if (ngDevMode) {
			const existing = this.records.get(token);
			if (existing && existing.multi !== void 0) throwMixedMultiProviderError();
		}
		this.records.set(token, record);
	}
	hydrate(token, record, flags) {
		const prevConsumer = setActiveConsumer(null);
		try {
			if (record.value === CIRCULAR) throw cyclicDependencyError(ngDevMode ? stringify(token) : "");
			else if (record.value === NOT_YET) {
				record.value = CIRCULAR;
				if (ngDevMode) runInInjectorProfilerContext(this, token, () => {
					emitInjectorToCreateInstanceEvent(token);
					record.value = record.factory(void 0, flags);
					emitInstanceCreatedByInjectorEvent(record.value);
				});
				else record.value = record.factory(void 0, flags);
			}
			if (typeof record.value === "object" && record.value && hasOnDestroy(record.value)) this._ngOnDestroyHooks.add(record.value);
			return record.value;
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
	injectableDefInScope(def) {
		if (!def.providedIn) return false;
		const providedIn = resolveForwardRef(def.providedIn);
		if (typeof providedIn === "string") return providedIn === "any" || this.scopes.has(providedIn);
		else return this.injectorDefTypes.has(providedIn);
	}
	removeOnDestroy(callback) {
		const destroyCBIdx = this._onDestroyHooks.indexOf(callback);
		if (destroyCBIdx !== -1) this._onDestroyHooks.splice(destroyCBIdx, 1);
	}
};
function injectableDefOrInjectorDefFactory(token) {
	const injectableDef = getInjectableDef(token);
	const factory = injectableDef !== null ? injectableDef.factory : getFactoryDef(token);
	if (factory !== null) return factory;
	if (token instanceof InjectionToken) throw new RuntimeError(-204, ngDevMode && `Token ${stringify(token)} is missing a ɵprov definition.`);
	if (token instanceof Function) return getUndecoratedInjectableFactory(token);
	throw new RuntimeError(-204, ngDevMode && "unreachable");
}
function getUndecoratedInjectableFactory(token) {
	const paramLength = token.length;
	if (paramLength > 0) throw new RuntimeError(-204, ngDevMode && `Can't resolve all parameters for ${stringify(token)}: (${newArray(paramLength, "?").join(", ")}).`);
	const inheritedInjectableDef = getInheritedInjectableDef(token);
	if (inheritedInjectableDef !== null) return () => inheritedInjectableDef.factory(token);
	else return () => new token();
}
function providerToRecord(provider) {
	if (isValueProvider(provider)) return makeRecord(void 0, provider.useValue);
	else return makeRecord(providerToFactory(provider), NOT_YET);
}
function providerToFactory(provider, ngModuleType, providers) {
	let factory = void 0;
	if (ngDevMode && isEnvironmentProviders(provider)) throwInvalidProviderError(void 0, providers, provider);
	if (isTypeProvider(provider)) {
		const unwrappedProvider = resolveForwardRef(provider);
		return getFactoryDef(unwrappedProvider) || injectableDefOrInjectorDefFactory(unwrappedProvider);
	} else if (isValueProvider(provider)) factory = () => resolveForwardRef(provider.useValue);
	else if (isFactoryProvider(provider)) factory = () => provider.useFactory(...injectArgs(provider.deps || []));
	else if (isExistingProvider(provider)) factory = (_, flags) => ɵɵinject(resolveForwardRef(provider.useExisting), flags !== void 0 && flags & 8 ? 8 : void 0);
	else {
		const classRef = resolveForwardRef(provider && (provider.useClass || provider.provide));
		if (ngDevMode && !classRef) throwInvalidProviderError(ngModuleType, providers, provider);
		if (hasDeps(provider)) factory = () => new classRef(...injectArgs(provider.deps));
		else return getFactoryDef(classRef) || injectableDefOrInjectorDefFactory(classRef);
	}
	return factory;
}
function assertNotDestroyed(injector) {
	if (injector.destroyed) throw new RuntimeError(-205, ngDevMode && "Injector has already been destroyed.");
}
function makeRecord(factory, value, multi = false) {
	return {
		factory,
		value,
		multi: multi ? [] : void 0
	};
}
function hasDeps(value) {
	return !!value.deps;
}
function hasOnDestroy(value) {
	return value !== null && typeof value === "object" && typeof value.ngOnDestroy === "function";
}
function couldBeInjectableType(value) {
	return typeof value === "function" || typeof value === "object" && value.ngMetadataName === "InjectionToken";
}
function forEachSingleProvider(providers, fn) {
	for (const provider of providers) if (Array.isArray(provider)) forEachSingleProvider(provider, fn);
	else if (provider && isEnvironmentProviders(provider)) forEachSingleProvider(provider.ɵproviders, fn);
	else fn(provider);
}
function runInInjectionContext(injector, fn) {
	let internalInjector;
	if (injector instanceof R3Injector) {
		assertNotDestroyed(injector);
		internalInjector = injector;
	} else internalInjector = new RetrievingInjector(injector);
	let prevInjectorProfilerContext;
	if (ngDevMode) prevInjectorProfilerContext = setInjectorProfilerContext({
		injector,
		token: null
	});
	const prevInjector = setCurrentInjector(internalInjector);
	const previousInjectImplementation = setInjectImplementation(void 0);
	try {
		return fn();
	} finally {
		setCurrentInjector(prevInjector);
		ngDevMode && setInjectorProfilerContext(prevInjectorProfilerContext);
		setInjectImplementation(previousInjectImplementation);
	}
}
function isInInjectionContext() {
	return getInjectImplementation() !== void 0 || getCurrentInjector() != null;
}
function assertInInjectionContext(debugFn) {
	if (!isInInjectionContext()) throw new RuntimeError(-203, ngDevMode && debugFn.name + "() can only be used within an injection context such as a constructor, a factory function, a field initializer, or a function used with `runInInjectionContext`");
}
var TYPE = 1;
var CONTAINER_HEADER_OFFSET = 10;
function isLView(value) {
	return Array.isArray(value) && typeof value[TYPE] === "object";
}
function isLContainer(value) {
	return Array.isArray(value) && value[TYPE] === true;
}
function isContentQueryHost(tNode) {
	return (tNode.flags & 4) !== 0;
}
function isComponentHost(tNode) {
	return tNode.componentOffset > -1;
}
function isDirectiveHost(tNode) {
	return (tNode.flags & 1) === 1;
}
function isComponentDef(def) {
	return !!def.template;
}
function isRootView(target) {
	return (target[2] & 512) !== 0;
}
function isProjectionTNode(tNode) {
	return (tNode.type & 16) === 16;
}
function hasI18n(lView) {
	return (lView[2] & 32) === 32;
}
function isDestroyed(lView) {
	return (lView[2] & 256) === 256;
}
function assertTNodeForLView(tNode, lView) {
	assertTNodeForTView(tNode, lView[1]);
}
function assertTNodeCreationIndex(lView, index) {
	const adjustedIndex = index + 28;
	assertIndexInRange(lView, adjustedIndex);
	assertLessThan(adjustedIndex, lView[1].bindingStartIndex, "TNodes should be created before any bindings");
}
function assertTNodeForTView(tNode, tView) {
	assertTNode(tNode);
	const tData = tView.data;
	for (let i = 28; i < tData.length; i++) if (tData[i] === tNode) return;
	throwError("This TNode does not belong to this TView.");
}
function assertTNode(tNode) {
	assertDefined(tNode, "TNode must be defined");
	if (!(tNode && typeof tNode === "object" && Object.hasOwn(tNode, "directiveStylingLast"))) throwError("Not of type TNode, got: " + tNode);
}
function assertTIcu(tIcu) {
	assertDefined(tIcu, "Expected TIcu to be defined");
	if (!(typeof tIcu.currentCaseLViewIndex === "number")) throwError("Object is not of TIcu type.");
}
function assertNgModuleType(actual, msg = "Type passed in is not NgModuleType, it does not have 'ɵmod' property.") {
	if (!getNgModuleDef(actual)) throwError(msg);
}
function assertHasParent(tNode) {
	assertDefined(tNode, "currentTNode should exist!");
	assertDefined(tNode.parent, "currentTNode should have a parent");
}
function assertLContainer(value) {
	assertDefined(value, "LContainer must be defined");
	assertEqual(isLContainer(value), true, "Expecting LContainer");
}
function assertLViewOrUndefined(value) {
	value && assertEqual(isLView(value), true, "Expecting LView or undefined or null");
}
function assertLView(value) {
	assertDefined(value, "LView must be defined");
	assertEqual(isLView(value), true, "Expecting LView");
}
function assertFirstCreatePass(tView, errMessage) {
	assertEqual(tView.firstCreatePass, true, errMessage || "Should only be called in first create pass.");
}
function assertFirstUpdatePass(tView, errMessage) {
	assertEqual(tView.firstUpdatePass, true, "Should only be called in first update pass.");
}
function assertDirectiveDef(obj) {
	if (obj.type === void 0 || obj.selectors == void 0 || obj.inputs === void 0) throwError(`Expected a DirectiveDef/ComponentDef and this object does not seem to have the expected shape.`);
}
function assertIndexInDeclRange(tView, index) {
	assertBetween(28, tView.bindingStartIndex, index);
}
function assertIndexInExpandoRange(lView, index) {
	const tView = lView[1];
	assertBetween(tView.expandoStartIndex, lView.length, index);
}
function assertBetween(lower, upper, index) {
	if (!(lower <= index && index < upper)) throwError(`Index out of range (expecting ${lower} <= ${index} < ${upper})`);
}
function assertProjectionSlots(lView, errMessage) {
	assertDefined(lView[15], "Component views should exist.");
	assertDefined(lView[15][5].projection, "Components with projection nodes (<ng-content>) must have projection slots defined.");
}
function assertParentView(lView, errMessage) {
	assertDefined(lView, "Component views should always have a parent view (component's host view)");
}
function assertNodeInjector(lView, injectorIndex) {
	assertIndexInExpandoRange(lView, injectorIndex);
	assertIndexInExpandoRange(lView, injectorIndex + 8);
	assertNumber(lView[injectorIndex + 0], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 1], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 2], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 3], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 4], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 5], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 6], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 7], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 8], "injectorIndex should point to parent injector");
}
var SecurityContext;
(function(SecurityContext) {
	SecurityContext[SecurityContext["NONE"] = 0] = "NONE";
	SecurityContext[SecurityContext["HTML"] = 1] = "HTML";
	SecurityContext[SecurityContext["STYLE"] = 2] = "STYLE";
	SecurityContext[SecurityContext["SCRIPT"] = 3] = "SCRIPT";
	SecurityContext[SecurityContext["URL"] = 4] = "URL";
	SecurityContext[SecurityContext["RESOURCE_URL"] = 5] = "RESOURCE_URL";
	SecurityContext[SecurityContext["ATTRIBUTE_NO_BINDING"] = 6] = "ATTRIBUTE_NO_BINDING";
})(SecurityContext || (SecurityContext = {}));
var _SECURITY_SCHEMA;
var MATH_ML_NAMESPACE = "math";
var NO_NAMESPACE = "";
var MATCH_ALL_ELEMENTS = "*";
var createNullObj = () => Object.create(null);
function SECURITY_SCHEMA() {
	if (_SECURITY_SCHEMA) return _SECURITY_SCHEMA;
	_SECURITY_SCHEMA = createNullObj();
	registerContext(SecurityContext.HTML, void 0, [["iframe", ["srcdoc"]], ["*", ["innerHTML", "outerHTML"]]]);
	registerContext(SecurityContext.STYLE, void 0, [["*", ["style"]]]);
	registerContext(SecurityContext.URL, void 0, [
		["*", ["formAction"]],
		["area", ["href"]],
		["a", ["href", "xlink:href"]],
		["form", ["action"]],
		["img", ["src"]],
		["video", ["src"]]
	]);
	registerContext(SecurityContext.URL, MATH_ML_NAMESPACE, [["*", ["href", "xlink:href"]]]);
	registerContext(SecurityContext.RESOURCE_URL, void 0, [
		["base", ["href"]],
		["embed", ["src"]],
		["frame", ["src"]],
		["iframe", ["src"]],
		["link", ["href"]],
		["object", ["codebase", "data"]]
	]);
	registerContext(SecurityContext.URL, "svg", [["a", ["href", "xlink:href"]]]);
	registerContext(SecurityContext.ATTRIBUTE_NO_BINDING, "svg", [
		["animate", [
			"attributeName",
			"values",
			"to",
			"from"
		]],
		["set", ["to", "attributeName"]],
		["animateMotion", ["attributeName"]],
		["animateTransform", ["attributeName"]]
	]);
	registerContext(SecurityContext.ATTRIBUTE_NO_BINDING, void 0, [["unknown", [
		"attributeName",
		"values",
		"to",
		"from",
		"sandbox",
		"allow",
		"allowFullscreen",
		"referrerPolicy",
		"csp",
		"fetchPriority",
		"credentialless"
	]], ["iframe", [
		"sandbox",
		"allow",
		"allowFullscreen",
		"referrerPolicy",
		"csp",
		"fetchPriority",
		"credentialless"
	]]]);
	return _SECURITY_SCHEMA;
}
function registerContext(ctx, namespace, specs) {
	const nsKey = namespace ?? NO_NAMESPACE;
	for (const [element, attributeNames] of specs) {
		const tagName = element.toLowerCase();
		for (const attr of attributeNames) {
			const attrLower = attr.toLowerCase();
			const attrSchema = _SECURITY_SCHEMA[attrLower] ??= createNullObj();
			const nsSchema = attrSchema[nsKey] ??= createNullObj();
			nsSchema[tagName] = ctx;
		}
	}
}
function checkSecurityContext(tagName, propName, namespace) {
	const attrSchema = SECURITY_SCHEMA()[propName.toLowerCase()];
	if (!attrSchema) return SecurityContext.NONE;
	const tagLower = tagName.toLowerCase();
	let context;
	if (namespace) {
		const nsSchema = attrSchema[namespace];
		if (nsSchema) context = nsSchema[tagLower] ?? nsSchema[MATCH_ALL_ELEMENTS];
	}
	if (context === void 0) {
		const defaultSchema = attrSchema[NO_NAMESPACE];
		if (defaultSchema) context = defaultSchema[tagLower] ?? defaultSchema[MATCH_ALL_ELEMENTS];
	}
	if (context === void 0 && (!namespace || namespace === NO_NAMESPACE)) {
		const svgSchema = attrSchema["svg"];
		if (svgSchema) context = svgSchema[tagLower];
	}
	return context ?? SecurityContext.NONE;
}
function unwrapRNode(value) {
	while (Array.isArray(value)) value = value[0];
	return value;
}
function unwrapLView(value) {
	while (Array.isArray(value)) {
		if (typeof value[TYPE] === "object") return value;
		value = value[0];
	}
	return null;
}
function getNativeByIndex(index, lView) {
	ngDevMode && assertIndexInRange(lView, index);
	ngDevMode && assertGreaterThanOrEqual(index, 28, "Expected to be past HEADER_OFFSET");
	return unwrapRNode(lView[index]);
}
function getNativeByTNode(tNode, lView) {
	ngDevMode && assertTNodeForLView(tNode, lView);
	ngDevMode && assertIndexInRange(lView, tNode.index);
	return unwrapRNode(lView[tNode.index]);
}
function getNativeByTNodeOrNull(tNode, lView) {
	const index = tNode === null ? -1 : tNode.index;
	if (index !== -1) {
		ngDevMode && assertTNodeForLView(tNode, lView);
		return unwrapRNode(lView[index]);
	}
	return null;
}
function getTNode(tView, index) {
	ngDevMode && assertGreaterThan(index, -1, "wrong index for TNode");
	ngDevMode && assertLessThan(index, tView.data.length, "wrong index for TNode");
	const tNode = tView.data[index];
	ngDevMode && tNode !== null && assertTNode(tNode);
	return tNode;
}
function load(view, index) {
	ngDevMode && assertIndexInRange(view, index);
	return view[index];
}
function store(tView, lView, index, value) {
	if (index >= tView.data.length) {
		tView.data[index] = null;
		tView.blueprint[index] = null;
	}
	lView[index] = value;
}
function getComponentLViewByIndex(nodeIndex, hostView) {
	ngDevMode && assertIndexInRange(hostView, nodeIndex);
	const slotValue = hostView[nodeIndex];
	return isLView(slotValue) ? slotValue : slotValue[0];
}
function isCreationMode(view) {
	return (view[2] & 4) === 4;
}
function viewAttachedToChangeDetector(view) {
	return (view[2] & 128) === 128;
}
function viewAttachedToContainer(view) {
	return isLContainer(view[3]);
}
function getConstant(consts, index) {
	if (index === null || index === void 0) return null;
	ngDevMode && assertIndexInRange(consts, index);
	return consts[index];
}
function resetPreOrderHookFlags(lView) {
	lView[17] = 0;
}
function markViewForRefresh(lView) {
	if (lView[2] & 1024) return;
	lView[2] |= 1024;
	if (viewAttachedToChangeDetector(lView)) markAncestorsForTraversal(lView);
}
function walkUpViews(nestingLevel, currentView) {
	while (nestingLevel > 0) {
		ngDevMode && assertDefined(currentView[14], "Declaration view should be defined if nesting level is greater than 0.");
		currentView = currentView[14];
		nestingLevel--;
	}
	return currentView;
}
function requiresRefreshOrTraversal(lView) {
	return !!(lView[2] & 9216 || lView[24]?.dirty);
}
function updateAncestorTraversalFlagsOnAttach(lView) {
	lView[10].changeDetectionScheduler?.notify(8);
	if (lView[2] & 64) lView[2] |= 1024;
	if (requiresRefreshOrTraversal(lView)) markAncestorsForTraversal(lView);
}
function markAncestorsForTraversal(lView) {
	lView[10].changeDetectionScheduler?.notify(0);
	let parent = getLViewParent(lView);
	while (parent !== null) {
		if (parent[2] & 8192) break;
		parent[2] |= 8192;
		if (!viewAttachedToChangeDetector(parent)) break;
		parent = getLViewParent(parent);
	}
}
function storeLViewOnDestroy(lView, onDestroyCallback) {
	if (isDestroyed(lView)) throw new RuntimeError(911, ngDevMode && "View has already been destroyed.");
	if (lView[21] === null) lView[21] = [];
	lView[21].push(onDestroyCallback);
}
function removeLViewOnDestroy(lView, onDestroyCallback) {
	if (lView[21] === null) return;
	const destroyCBIdx = lView[21].indexOf(onDestroyCallback);
	if (destroyCBIdx !== -1) lView[21].splice(destroyCBIdx, 1);
}
function getLViewParent(lView) {
	ngDevMode && assertLView(lView);
	const parent = lView[3];
	return isLContainer(parent) ? parent[3] : parent;
}
function getOrCreateLViewCleanup(view) {
	return view[7] ??= [];
}
function getOrCreateTViewCleanup(tView) {
	return tView.cleanup ??= [];
}
function storeCleanupWithContext(tView, lView, context, cleanupFn) {
	const lCleanup = getOrCreateLViewCleanup(lView);
	ngDevMode && assertDefined(context, "Cleanup context is mandatory when registering framework-level destroy hooks");
	lCleanup.push(context);
	if (tView.firstCreatePass) getOrCreateTViewCleanup(tView).push(cleanupFn, lCleanup.length - 1);
	else if (ngDevMode) Object.freeze(getOrCreateTViewCleanup(tView));
}
var instructionState = {
	lFrame: createLFrame(null),
	bindingsEnabled: true,
	skipHydrationRootTNode: null
};
var CheckNoChangesMode;
(function(CheckNoChangesMode) {
	CheckNoChangesMode[CheckNoChangesMode["Off"] = 0] = "Off";
	CheckNoChangesMode[CheckNoChangesMode["Exhaustive"] = 1] = "Exhaustive";
	CheckNoChangesMode[CheckNoChangesMode["OnlyDirtyViews"] = 2] = "OnlyDirtyViews";
})(CheckNoChangesMode || (CheckNoChangesMode = {}));
var _checkNoChangesMode = 0;
var _isRefreshingViews = false;
function getElementDepthCount() {
	return instructionState.lFrame.elementDepthCount;
}
function increaseElementDepthCount() {
	instructionState.lFrame.elementDepthCount++;
}
function decreaseElementDepthCount() {
	instructionState.lFrame.elementDepthCount--;
}
function getBindingsEnabled() {
	return instructionState.bindingsEnabled;
}
function isInSkipHydrationBlock$1() {
	return instructionState.skipHydrationRootTNode !== null;
}
function isSkipHydrationRootTNode(tNode) {
	return instructionState.skipHydrationRootTNode === tNode;
}
function ɵɵenableBindings() {
	instructionState.bindingsEnabled = true;
}
function ɵɵdisableBindings() {
	instructionState.bindingsEnabled = false;
}
function leaveSkipHydrationBlock() {
	instructionState.skipHydrationRootTNode = null;
}
function getLView() {
	return instructionState.lFrame.lView;
}
function getTView() {
	return instructionState.lFrame.tView;
}
function ɵɵrestoreView(viewToRestore) {
	instructionState.lFrame.contextLView = viewToRestore;
	return viewToRestore[8];
}
function ɵɵresetView(value) {
	instructionState.lFrame.contextLView = null;
	return value;
}
function getCurrentTNode() {
	let currentTNode = getCurrentTNodePlaceholderOk();
	while (currentTNode !== null && currentTNode.type === 64) currentTNode = currentTNode.parent;
	return currentTNode;
}
function getCurrentTNodePlaceholderOk() {
	return instructionState.lFrame.currentTNode;
}
function getCurrentParentTNode() {
	const lFrame = instructionState.lFrame;
	const currentTNode = lFrame.currentTNode;
	return lFrame.isParent ? currentTNode : currentTNode.parent;
}
function setCurrentTNode(tNode, isParent) {
	ngDevMode && tNode && assertTNodeForTView(tNode, instructionState.lFrame.tView);
	const lFrame = instructionState.lFrame;
	lFrame.currentTNode = tNode;
	lFrame.isParent = isParent;
}
function isCurrentTNodeParent() {
	return instructionState.lFrame.isParent;
}
function setCurrentTNodeAsNotParent() {
	instructionState.lFrame.isParent = false;
}
function getContextLView() {
	const contextLView = instructionState.lFrame.contextLView;
	ngDevMode && assertDefined(contextLView, "contextLView must be defined.");
	return contextLView;
}
function isInCheckNoChangesMode() {
	!ngDevMode && throwError("Must never be called in production mode");
	return _checkNoChangesMode !== CheckNoChangesMode.Off;
}
function isExhaustiveCheckNoChanges() {
	!ngDevMode && throwError("Must never be called in production mode");
	return _checkNoChangesMode === CheckNoChangesMode.Exhaustive;
}
function setIsInCheckNoChangesMode(mode) {
	!ngDevMode && throwError("Must never be called in production mode");
	_checkNoChangesMode = mode;
}
function isRefreshingViews() {
	return _isRefreshingViews;
}
function setIsRefreshingViews(mode) {
	const prev = _isRefreshingViews;
	_isRefreshingViews = mode;
	return prev;
}
function getBindingRoot() {
	const lFrame = instructionState.lFrame;
	let index = lFrame.bindingRootIndex;
	if (index === -1) index = lFrame.bindingRootIndex = lFrame.tView.bindingStartIndex;
	return index;
}
function getBindingIndex() {
	return instructionState.lFrame.bindingIndex;
}
function setBindingIndex(value) {
	return instructionState.lFrame.bindingIndex = value;
}
function nextBindingIndex() {
	return instructionState.lFrame.bindingIndex++;
}
function incrementBindingIndex(count) {
	const lFrame = instructionState.lFrame;
	const index = lFrame.bindingIndex;
	lFrame.bindingIndex = lFrame.bindingIndex + count;
	return index;
}
function isInI18nBlock() {
	return instructionState.lFrame.inI18n;
}
function setInI18nBlock(isInI18nBlock) {
	instructionState.lFrame.inI18n = isInI18nBlock;
}
function setBindingRootForHostBindings(bindingRootIndex, currentDirectiveIndex) {
	const lFrame = instructionState.lFrame;
	lFrame.bindingIndex = lFrame.bindingRootIndex = bindingRootIndex;
	setCurrentDirectiveIndex(currentDirectiveIndex);
}
function getCurrentDirectiveIndex() {
	return instructionState.lFrame.currentDirectiveIndex;
}
function setCurrentDirectiveIndex(currentDirectiveIndex) {
	instructionState.lFrame.currentDirectiveIndex = currentDirectiveIndex;
}
function getCurrentDirectiveDef(tData) {
	const currentDirectiveIndex = instructionState.lFrame.currentDirectiveIndex;
	return currentDirectiveIndex === -1 ? null : tData[currentDirectiveIndex];
}
function getCurrentQueryIndex() {
	return instructionState.lFrame.currentQueryIndex;
}
function setCurrentQueryIndex(value) {
	instructionState.lFrame.currentQueryIndex = value;
}
function getDeclarationTNode(lView) {
	const tView = lView[1];
	if (tView.type === 2) {
		ngDevMode && assertDefined(tView.declTNode, "Embedded TNodes should have declaration parents.");
		return tView.declTNode;
	}
	if (tView.type === 1) return lView[5];
	return null;
}
function enterDI(lView, tNode, flags) {
	ngDevMode && assertLViewOrUndefined(lView);
	if (flags & 4) {
		ngDevMode && assertTNodeForTView(tNode, lView[1]);
		let parentTNode = tNode;
		let parentLView = lView;
		while (true) {
			ngDevMode && assertDefined(parentTNode, "Parent TNode should be defined");
			parentTNode = parentTNode.parent;
			if (parentTNode === null && !(flags & 1)) {
				parentTNode = getDeclarationTNode(parentLView);
				if (parentTNode === null) break;
				ngDevMode && assertDefined(parentLView, "Parent LView should be defined");
				parentLView = parentLView[14];
				if (parentTNode.type & 10) break;
			} else break;
		}
		if (parentTNode === null) return false;
		else {
			tNode = parentTNode;
			lView = parentLView;
		}
	}
	ngDevMode && assertTNodeForLView(tNode, lView);
	const lFrame = instructionState.lFrame = allocLFrame();
	lFrame.currentTNode = tNode;
	lFrame.lView = lView;
	return true;
}
function enterView(newView) {
	ngDevMode && assertNotEqual(newView[0], newView[1], "????");
	ngDevMode && assertLViewOrUndefined(newView);
	const newLFrame = allocLFrame();
	if (ngDevMode) {
		assertEqual(newLFrame.isParent, true, "Expected clean LFrame");
		assertEqual(newLFrame.lView, null, "Expected clean LFrame");
		assertEqual(newLFrame.tView, null, "Expected clean LFrame");
		assertEqual(newLFrame.selectedIndex, -1, "Expected clean LFrame");
		assertEqual(newLFrame.elementDepthCount, 0, "Expected clean LFrame");
		assertEqual(newLFrame.currentDirectiveIndex, -1, "Expected clean LFrame");
		assertEqual(newLFrame.currentNamespace, null, "Expected clean LFrame");
		assertEqual(newLFrame.bindingRootIndex, -1, "Expected clean LFrame");
		assertEqual(newLFrame.currentQueryIndex, 0, "Expected clean LFrame");
	}
	const tView = newView[1];
	instructionState.lFrame = newLFrame;
	ngDevMode && tView.firstChild && assertTNodeForTView(tView.firstChild, tView);
	newLFrame.currentTNode = tView.firstChild;
	newLFrame.lView = newView;
	newLFrame.tView = tView;
	newLFrame.contextLView = newView;
	newLFrame.bindingIndex = tView.bindingStartIndex;
	newLFrame.inI18n = false;
}
function allocLFrame() {
	const currentLFrame = instructionState.lFrame;
	const childLFrame = currentLFrame === null ? null : currentLFrame.child;
	return childLFrame === null ? createLFrame(currentLFrame) : childLFrame;
}
function createLFrame(parent) {
	const lFrame = {
		currentTNode: null,
		isParent: true,
		lView: null,
		tView: null,
		selectedIndex: -1,
		contextLView: null,
		elementDepthCount: 0,
		currentNamespace: null,
		currentDirectiveIndex: -1,
		bindingRootIndex: -1,
		bindingIndex: -1,
		currentQueryIndex: 0,
		parent,
		child: null,
		inI18n: false
	};
	parent !== null && (parent.child = lFrame);
	return lFrame;
}
function leaveViewLight() {
	const oldLFrame = instructionState.lFrame;
	instructionState.lFrame = oldLFrame.parent;
	oldLFrame.currentTNode = null;
	oldLFrame.lView = null;
	return oldLFrame;
}
var leaveDI = leaveViewLight;
function leaveView() {
	const oldLFrame = leaveViewLight();
	oldLFrame.isParent = true;
	oldLFrame.tView = null;
	oldLFrame.selectedIndex = -1;
	oldLFrame.contextLView = null;
	oldLFrame.elementDepthCount = 0;
	oldLFrame.currentDirectiveIndex = -1;
	oldLFrame.currentNamespace = null;
	oldLFrame.bindingRootIndex = -1;
	oldLFrame.bindingIndex = -1;
	oldLFrame.currentQueryIndex = 0;
}
function nextContextImpl(level) {
	return (instructionState.lFrame.contextLView = walkUpViews(level, instructionState.lFrame.contextLView))[8];
}
function getSelectedIndex() {
	return instructionState.lFrame.selectedIndex;
}
function setSelectedIndex(index) {
	ngDevMode && index !== -1 && assertGreaterThanOrEqual(index, 28, "Index must be past HEADER_OFFSET (or -1).");
	ngDevMode && assertLessThan(index, instructionState.lFrame.lView.length, "Can't set index passed end of LView");
	instructionState.lFrame.selectedIndex = index;
}
function getSelectedTNode() {
	const lFrame = instructionState.lFrame;
	return getTNode(lFrame.tView, lFrame.selectedIndex);
}
function ɵɵnamespaceSVG() {
	instructionState.lFrame.currentNamespace = "svg";
}
function ɵɵnamespaceMathML() {
	instructionState.lFrame.currentNamespace = MATH_ML_NAMESPACE;
}
function ɵɵnamespaceHTML() {
	namespaceHTMLInternal();
}
function namespaceHTMLInternal() {
	instructionState.lFrame.currentNamespace = null;
}
function getNamespace() {
	return instructionState.lFrame.currentNamespace;
}
var _wasLastNodeCreated = true;
function wasLastNodeCreated() {
	return _wasLastNodeCreated;
}
function lastNodeWasCreated(flag) {
	_wasLastNodeCreated = flag;
}
function promiseWithResolvers() {
	let resolve;
	let reject;
	return {
		promise: new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		}),
		resolve,
		reject
	};
}
function createInjector(defType, parent = null, additionalProviders = null, name) {
	const injector = createInjectorWithoutInjectorInstances(defType, parent, additionalProviders, name);
	injector.resolveInjectorInitializers();
	return injector;
}
function createInjectorWithoutInjectorInstances(defType, parent = null, additionalProviders = null, name, scopes = /* @__PURE__ */ new Set()) {
	const providers = [additionalProviders || EMPTY_ARRAY, importProvidersFrom(defType)];
	let source = void 0;
	if (ngDevMode) source = name || (typeof defType === "object" ? void 0 : stringify(defType));
	return new R3Injector(providers, parent || getNullInjector(), source || null, scopes);
}
var specialProviders = /* @__PURE__ */ new Set();
function registerSpecialProvider(clazz) {
	if (typeof ngDevMode !== "undefined" && ngDevMode) specialProviders.add(clazz);
}
function getAllSpecialProviders() {
	return specialProviders;
}
var Injector = class Injector {
	static THROW_IF_NOT_FOUND = THROW_IF_NOT_FOUND;
	static NULL = new NullInjector();
	static create(options, parent) {
		if (Array.isArray(options)) return createInjector({ name: "" }, parent, options, "");
		else {
			const name = options.name ?? "";
			return createInjector({ name }, options.parent, options.providers, name);
		}
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: Injector,
		providedIn: "any",
		factory: () => ɵɵinject(INJECTOR$1)
	});
	static __NG_ELEMENT_ID__ = -1;
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(Injector);
var DOCUMENT$1 = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DocumentToken" : "");
var DestroyRef = class {
	static __NG_ELEMENT_ID__ = injectDestroyRef;
	static __NG_ENV_ID__ = (injector) => injector;
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(DestroyRef);
var NodeInjectorDestroyRef = class extends DestroyRef {
	_lView;
	constructor(_lView) {
		super();
		this._lView = _lView;
	}
	get destroyed() {
		return isDestroyed(this._lView);
	}
	onDestroy(callback) {
		const lView = this._lView;
		storeLViewOnDestroy(lView, callback);
		return () => removeLViewOnDestroy(lView, callback);
	}
};
function injectDestroyRef() {
	return new NodeInjectorDestroyRef(getLView());
}
var DEBUG_TASK_TRACKER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DEBUG_TASK_TRACKER" : "");
var PendingTasksInternal = class PendingTasksInternal {
	taskId = 0;
	pendingTasks = /* @__PURE__ */ new Set();
	destroyed = false;
	pendingTask = new import_cjs.BehaviorSubject(false);
	debugTaskTracker = inject(DEBUG_TASK_TRACKER, { optional: true });
	get hasPendingTasks() {
		return this.destroyed ? false : this.pendingTask.value;
	}
	get hasPendingTasksObservable() {
		if (this.destroyed) return new import_cjs.Observable((subscriber) => {
			subscriber.next(false);
			subscriber.complete();
		});
		return this.pendingTask;
	}
	add() {
		if (!this.hasPendingTasks && !this.destroyed) this.pendingTask.next(true);
		const taskId = this.taskId++;
		this.pendingTasks.add(taskId);
		this.debugTaskTracker?.add(taskId);
		return taskId;
	}
	has(taskId) {
		return this.pendingTasks.has(taskId);
	}
	remove(taskId) {
		this.pendingTasks.delete(taskId);
		this.debugTaskTracker?.remove(taskId);
		if (this.pendingTasks.size === 0 && this.hasPendingTasks) this.pendingTask.next(false);
	}
	ngOnDestroy() {
		this.pendingTasks.clear();
		if (this.hasPendingTasks) this.pendingTask.next(false);
		this.destroyed = true;
		this.pendingTask.unsubscribe();
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: PendingTasksInternal,
		providedIn: "root",
		factory: () => new PendingTasksInternal()
	});
};
var EventEmitter_ = class extends import_cjs.Subject {
	__isAsync;
	destroyRef = void 0;
	pendingTasks = void 0;
	constructor(isAsync = false) {
		super();
		this.__isAsync = isAsync;
		if (isInInjectionContext()) {
			this.destroyRef = inject(DestroyRef, { optional: true }) ?? void 0;
			this.pendingTasks = inject(PendingTasksInternal, { optional: true }) ?? void 0;
		}
	}
	emit(value) {
		const prevConsumer = setActiveConsumer(null);
		try {
			super.next(value);
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
	subscribe(observerOrNext, error, complete) {
		let nextFn = observerOrNext;
		let errorFn = error || (() => null);
		let completeFn = complete;
		if (observerOrNext && typeof observerOrNext === "object") {
			const observer = observerOrNext;
			nextFn = observer.next?.bind(observer);
			errorFn = observer.error?.bind(observer);
			completeFn = observer.complete?.bind(observer);
		}
		if (this.__isAsync) {
			errorFn = this.wrapInTimeout(errorFn);
			if (nextFn) nextFn = this.wrapInTimeout(nextFn);
			if (completeFn) completeFn = this.wrapInTimeout(completeFn);
		}
		const sink = super.subscribe({
			next: nextFn,
			error: errorFn,
			complete: completeFn
		});
		if (observerOrNext instanceof import_cjs.Subscription) observerOrNext.add(sink);
		return sink;
	}
	wrapInTimeout(fn) {
		return (value) => {
			const taskId = this.pendingTasks?.add();
			setTimeout(() => {
				try {
					fn(value);
				} finally {
					if (taskId !== void 0) this.pendingTasks?.remove(taskId);
				}
			});
		};
	}
};
var EventEmitter = EventEmitter_;
function noop(...args) {}
function scheduleCallbackWithRafRace(callback) {
	let timeoutId;
	let animationFrameId;
	function cleanup() {
		callback = noop;
		try {
			if (animationFrameId !== void 0 && typeof cancelAnimationFrame === "function") cancelAnimationFrame(animationFrameId);
			if (timeoutId !== void 0) clearTimeout(timeoutId);
		} catch {}
	}
	timeoutId = setTimeout(() => {
		callback();
		cleanup();
	});
	if (typeof requestAnimationFrame === "function") animationFrameId = requestAnimationFrame(() => {
		callback();
		cleanup();
	});
	return () => cleanup();
}
function scheduleCallbackWithMicrotask(callback) {
	queueMicrotask(() => callback());
	return () => {
		callback = noop;
	};
}
var AsyncStackTaggingZoneSpec = class {
	createTask;
	constructor(namePrefix, consoleAsyncStackTaggingImpl = console) {
		this.name = "asyncStackTagging for " + namePrefix;
		this.createTask = consoleAsyncStackTaggingImpl?.createTask ?? (() => null);
	}
	name;
	onScheduleTask(delegate, _current, target, task) {
		task.consoleTask = this.createTask(`Zone - ${task.source || task.type}`);
		return delegate.scheduleTask(target, task);
	}
	onInvokeTask(delegate, _currentZone, targetZone, task, applyThis, applyArgs) {
		let ret;
		if (task.consoleTask) ret = task.consoleTask.run(() => delegate.invokeTask(targetZone, task, applyThis, applyArgs));
		else ret = delegate.invokeTask(targetZone, task, applyThis, applyArgs);
		return ret;
	}
};
var isAngularZoneProperty = "isAngularZone";
var angularZoneInstanceIdProperty = "isAngularZone_ID";
var ngZoneInstanceId = 0;
var NgZone = class NgZone {
	hasPendingMacrotasks = false;
	hasPendingMicrotasks = false;
	isStable = true;
	onUnstable = new EventEmitter(false);
	onMicrotaskEmpty = new EventEmitter(false);
	onStable = new EventEmitter(false);
	onError = new EventEmitter(false);
	constructor(options) {
		const { enableLongStackTrace = false, shouldCoalesceEventChangeDetection = false, shouldCoalesceRunChangeDetection = false, scheduleInRootZone = false } = options;
		if (typeof Zone == "undefined") throw new RuntimeError(908, ngDevMode && `In this configuration Angular requires Zone.js`);
		Zone.assertZonePatched();
		const self = this;
		self._nesting = 0;
		self._outer = self._inner = Zone.current;
		if (ngDevMode) self._inner = self._inner.fork(new AsyncStackTaggingZoneSpec("Angular"));
		if (Zone["TaskTrackingZoneSpec"]) self._inner = self._inner.fork(new Zone["TaskTrackingZoneSpec"]());
		if (enableLongStackTrace && Zone["longStackTraceZoneSpec"]) self._inner = self._inner.fork(Zone["longStackTraceZoneSpec"]);
		self.shouldCoalesceEventChangeDetection = !shouldCoalesceRunChangeDetection && shouldCoalesceEventChangeDetection;
		self.shouldCoalesceRunChangeDetection = shouldCoalesceRunChangeDetection;
		self.callbackScheduled = false;
		self.scheduleInRootZone = scheduleInRootZone;
		forkInnerZoneWithAngularBehavior(self);
	}
	static isInAngularZone() {
		return typeof Zone !== "undefined" && Zone.current.get(isAngularZoneProperty) === true;
	}
	static assertInAngularZone() {
		if (!NgZone.isInAngularZone()) throw new RuntimeError(909, ngDevMode && "Expected to be in Angular Zone, but it is not!");
	}
	static assertNotInAngularZone() {
		if (NgZone.isInAngularZone()) throw new RuntimeError(909, ngDevMode && "Expected to not be in Angular Zone, but it is!");
	}
	run(fn, applyThis, applyArgs) {
		return this._inner.run(fn, applyThis, applyArgs);
	}
	runTask(fn, applyThis, applyArgs, name) {
		const zone = this._inner;
		const task = zone.scheduleEventTask("NgZoneEvent: " + name, fn, EMPTY_PAYLOAD, noop, noop);
		try {
			return zone.runTask(task, applyThis, applyArgs);
		} finally {
			zone.cancelTask(task);
		}
	}
	runGuarded(fn, applyThis, applyArgs) {
		return this._inner.runGuarded(fn, applyThis, applyArgs);
	}
	runOutsideAngular(fn) {
		return this._outer.run(fn);
	}
};
var EMPTY_PAYLOAD = {};
function checkStable(zone) {
	if (zone._nesting == 0 && !zone.hasPendingMicrotasks && !zone.isStable) try {
		zone._nesting++;
		zone.onMicrotaskEmpty.emit(null);
	} finally {
		zone._nesting--;
		if (!zone.hasPendingMicrotasks) try {
			zone.runOutsideAngular(() => zone.onStable.emit(null));
		} finally {
			zone.isStable = true;
		}
	}
}
function delayChangeDetectionForEvents(zone) {
	if (zone.isCheckStableRunning || zone.callbackScheduled) return;
	zone.callbackScheduled = true;
	function scheduleCheckStable() {
		scheduleCallbackWithRafRace(() => {
			zone.callbackScheduled = false;
			updateMicroTaskStatus(zone);
			zone.isCheckStableRunning = true;
			checkStable(zone);
			zone.isCheckStableRunning = false;
		});
	}
	if (zone.scheduleInRootZone) Zone.root.run(() => {
		scheduleCheckStable();
	});
	else zone._outer.run(() => {
		scheduleCheckStable();
	});
	updateMicroTaskStatus(zone);
}
function forkInnerZoneWithAngularBehavior(zone) {
	const delayChangeDetectionForEventsDelegate = () => {
		delayChangeDetectionForEvents(zone);
	};
	const instanceId = ngZoneInstanceId++;
	zone._inner = zone._inner.fork({
		name: "angular",
		properties: {
			[isAngularZoneProperty]: true,
			[angularZoneInstanceIdProperty]: instanceId,
			[angularZoneInstanceIdProperty + instanceId]: true
		},
		onInvokeTask: (delegate, current, target, task, applyThis, applyArgs) => {
			if (shouldBeIgnoredByZone(applyArgs)) return delegate.invokeTask(target, task, applyThis, applyArgs);
			try {
				onEnter(zone);
				return delegate.invokeTask(target, task, applyThis, applyArgs);
			} finally {
				if (zone.shouldCoalesceEventChangeDetection && task.type === "eventTask" || zone.shouldCoalesceRunChangeDetection) delayChangeDetectionForEventsDelegate();
				onLeave(zone);
			}
		},
		onInvoke: (delegate, current, target, callback, applyThis, applyArgs, source) => {
			try {
				onEnter(zone);
				return delegate.invoke(target, callback, applyThis, applyArgs, source);
			} finally {
				if (zone.shouldCoalesceRunChangeDetection && !zone.callbackScheduled && !isSchedulerTick(applyArgs)) delayChangeDetectionForEventsDelegate();
				onLeave(zone);
			}
		},
		onHasTask: (delegate, current, target, hasTaskState) => {
			delegate.hasTask(target, hasTaskState);
			if (current === target) {
				if (hasTaskState.change == "microTask") {
					zone._hasPendingMicrotasks = hasTaskState.microTask;
					updateMicroTaskStatus(zone);
					checkStable(zone);
				} else if (hasTaskState.change == "macroTask") zone.hasPendingMacrotasks = hasTaskState.macroTask;
			}
		},
		onHandleError: (delegate, current, target, error) => {
			delegate.handleError(target, error);
			zone.runOutsideAngular(() => zone.onError.emit(error));
			return false;
		}
	});
}
function updateMicroTaskStatus(zone) {
	if (zone._hasPendingMicrotasks || (zone.shouldCoalesceEventChangeDetection || zone.shouldCoalesceRunChangeDetection) && zone.callbackScheduled === true) zone.hasPendingMicrotasks = true;
	else zone.hasPendingMicrotasks = false;
}
function onEnter(zone) {
	zone._nesting++;
	if (zone.isStable) {
		zone.isStable = false;
		zone.onUnstable.emit(null);
	}
}
function onLeave(zone) {
	zone._nesting--;
	checkStable(zone);
}
var NoopNgZone = class {
	hasPendingMicrotasks = false;
	hasPendingMacrotasks = false;
	isStable = true;
	onUnstable = new EventEmitter();
	onMicrotaskEmpty = new EventEmitter();
	onStable = new EventEmitter();
	onError = new EventEmitter();
	run(fn, applyThis, applyArgs) {
		return fn.apply(applyThis, applyArgs);
	}
	runGuarded(fn, applyThis, applyArgs) {
		return fn.apply(applyThis, applyArgs);
	}
	runOutsideAngular(fn) {
		return fn();
	}
	runTask(fn, applyThis, applyArgs, name) {
		return fn.apply(applyThis, applyArgs);
	}
};
function shouldBeIgnoredByZone(applyArgs) {
	return hasApplyArgsData(applyArgs, "__ignore_ng_zone__");
}
function isSchedulerTick(applyArgs) {
	return hasApplyArgsData(applyArgs, "__scheduler_tick__");
}
function hasApplyArgsData(applyArgs, key) {
	if (!Array.isArray(applyArgs)) return false;
	if (applyArgs.length !== 1) return false;
	return applyArgs[0]?.data?.[key] === true;
}
var ErrorHandler = class {
	_console = console;
	handleError(error) {
		this._console.error("ERROR", error);
	}
};
function encapsulateBoundaryError(error) {
	if (isErrorLike(error)) return error;
	return new ErrorBoundaryWrappedError(error);
}
function isErrorLike(error) {
	return error instanceof Error || typeof error === "object" && error !== null && typeof error.name === "string" && typeof error.message === "string";
}
var ErrorBoundaryWrappedError = class extends Error {
	constructor(error) {
		super(typeof ngDevMode !== "undefined" && ngDevMode ? `Error boundary caught an error that's not an Error instance: ${String(error)}. Check this error's .cause for the actual error.` : String(error), { cause: error });
		this.name = "ErrorBoundaryWrappedError";
	}
};
var INTERNAL_APPLICATION_ERROR_HANDLER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "internal error handler" : "", { factory: () => {
	const zone = inject(NgZone);
	const injector = inject(EnvironmentInjector);
	let userErrorHandler;
	return (e) => {
		zone.runOutsideAngular(() => {
			if (injector.destroyed && !userErrorHandler) setTimeout(() => {
				throw e;
			});
			else {
				userErrorHandler ??= injector.get(ErrorHandler);
				userErrorHandler.handleError(e);
			}
		});
	};
} });
var errorHandlerEnvironmentInitializer = {
	provide: ENVIRONMENT_INITIALIZER,
	useValue: () => {
		const handler = inject(ErrorHandler, { optional: true });
		if ((typeof ngDevMode === "undefined" || ngDevMode) && handler === null) throw new RuntimeError(402, "A required Injectable was not found in the dependency injection tree. If you are bootstrapping an NgModule, make sure that the `BrowserModule` is imported.");
	},
	multi: true
};
var globalErrorListeners = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "GlobalErrorListeners" : "", { factory: () => {} });
function provideBrowserGlobalErrorListeners() {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => void inject(globalErrorListeners))]);
}
function ɵunwrapWritableSignal(value) {
	return null;
}
function signal(initialValue, options) {
	const [get, set, update] = createSignal(initialValue, options?.equal);
	const signalFn = get;
	const node = signalFn[SIGNAL];
	signalFn.set = set;
	signalFn.update = update;
	signalFn.asReadonly = signalAsReadonlyFn.bind(signalFn);
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		const debugName = options?.debugName;
		node.debugName = debugName;
		signalFn.toString = () => `[Signal${debugName ? " (" + debugName + ")" : ""}: ${signalFn()}]`;
	}
	return signalFn;
}
function signalAsReadonlyFn() {
	const node = this[SIGNAL];
	if (node.readonlyFn === void 0) {
		const readonlyFn = () => this();
		readonlyFn[SIGNAL] = node;
		node.readonlyFn = readonlyFn;
	}
	return node.readonlyFn;
}
var APP_ID = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "AppId" : "", { factory: () => DEFAULT_APP_ID });
var DEFAULT_APP_ID = "ng";
var validAppIdInitializer = {
	provide: ENVIRONMENT_INITIALIZER,
	multi: true,
	useValue: () => {
		const appId = inject(APP_ID);
		if (!/^[a-zA-Z0-9\-_]+$/.test(appId)) throw new RuntimeError(211, `APP_ID value "${appId}" is not alphanumeric. The APP_ID must be a string of alphanumeric characters. (a-zA-Z0-9), hyphens (-) and underscores (_) are allowed.`);
	}
};
var PLATFORM_INITIALIZER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Platform Initializer" : "");
var PLATFORM_ID = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Platform ID" : "", {
	providedIn: "platform",
	factory: () => "unknown"
});
var ANIMATION_MODULE_TYPE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "AnimationModuleType" : "");
var CSP_NONCE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "CSP nonce" : "", { factory: () => {
	return inject(DOCUMENT$1).body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null;
} });
var IMAGE_CONFIG_DEFAULTS = {
	breakpoints: [
		16,
		32,
		48,
		64,
		96,
		128,
		256,
		384,
		640,
		750,
		828,
		1080,
		1200,
		1920,
		2048,
		3840
	],
	placeholderResolution: 30,
	disableImageSizeWarning: false,
	disableImageLazyLoadWarning: false
};
var IMAGE_CONFIG = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ImageConfig" : "", { factory: () => IMAGE_CONFIG_DEFAULTS });
function makeStateKey(key) {
	return key;
}
function createDictionary() {
	return Object.create(null);
}
var TransferState = class TransferState {
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: TransferState,
		providedIn: "root",
		factory: () => {
			return new TransferState();
		}
	});
	store = createDictionary();
	onSerializeCallbacks = createDictionary();
	get(key, defaultValue) {
		if (!Object.hasOwn(this.store, key)) return defaultValue;
		const value = this.store[key];
		return value !== void 0 ? value : defaultValue;
	}
	set(key, value) {
		this.store[key] = value;
	}
	remove(key) {
		delete this.store[key];
	}
	hasKey(key) {
		return Object.hasOwn(this.store, key);
	}
	get isEmpty() {
		return Object.keys(this.store).length === 0;
	}
	onSerialize(key, callback) {
		this.onSerializeCallbacks[key] = callback;
	}
	toJson() {
		for (const key in this.onSerializeCallbacks) if (Object.hasOwn(this.onSerializeCallbacks, key)) try {
			this.store[key] = this.onSerializeCallbacks[key]();
		} catch (e) {
			console.warn("Exception in onSerialize callback: ", e);
		}
		return JSON.stringify(this.store).replace(/</g, "\\u003C").replace(/\//g, "\\u002F");
	}
};
function retrieveTransferredState(doc, appId) {
	const script = doc.getElementById(appId + "-state");
	if (script?.tagName === "SCRIPT" && script.textContent) try {
		return Object.assign(createDictionary(), JSON.parse(script.textContent));
	} catch (e) {
		console.warn("Exception while restoring TransferState for app " + appId, e);
	}
	return createDictionary();
}
function assertNotInReactiveContext(debugFn, extraContext) {
	if (getActiveConsumer() !== null) throw new RuntimeError(-602, ngDevMode && `${debugFn.name}() cannot be called from within a reactive context.${extraContext ? ` ${extraContext}` : ""}`);
}
var ViewContext = class {
	view;
	node;
	constructor(view, node) {
		this.view = view;
		this.node = node;
	}
	static __NG_ELEMENT_ID__ = injectViewContext;
};
function injectViewContext() {
	return new ViewContext(getLView(), getCurrentTNode());
}
var ChangeDetectionScheduler = class {};
var ZONELESS_ENABLED = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "Zoneless enabled" : "", { factory: () => true });
var PROVIDED_ZONELESS = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "Zoneless provided" : "", { factory: () => false });
var SCHEDULE_IN_ROOT_ZONE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "run changes outside zone in root" : "");
var EffectScheduler = class EffectScheduler {
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: EffectScheduler,
		providedIn: "root",
		factory: () => new ZoneAwareEffectScheduler()
	});
};
var ZoneAwareEffectScheduler = class {
	dirtyEffectCount = 0;
	queues = /* @__PURE__ */ new Map();
	add(handle) {
		this.enqueue(handle);
		this.schedule(handle);
	}
	schedule(handle) {
		if (!handle.dirty) return;
		this.dirtyEffectCount++;
	}
	remove(handle) {
		const zone = handle.zone;
		const queue = this.queues.get(zone);
		if (!queue.has(handle)) return;
		queue.delete(handle);
		if (handle.dirty) this.dirtyEffectCount--;
	}
	enqueue(handle) {
		const zone = handle.zone;
		if (!this.queues.has(zone)) this.queues.set(zone, /* @__PURE__ */ new Set());
		const queue = this.queues.get(zone);
		if (queue.has(handle)) return;
		queue.add(handle);
	}
	flush() {
		while (this.dirtyEffectCount > 0) {
			let ranOneEffect = false;
			for (const [zone, queue] of this.queues) if (zone === null) ranOneEffect ||= this.flushQueue(queue);
			else ranOneEffect ||= zone.run(() => this.flushQueue(queue));
			if (!ranOneEffect) this.dirtyEffectCount = 0;
		}
	}
	flushQueue(queue) {
		let ranOneEffect = false;
		for (const handle of queue) {
			if (!handle.dirty) continue;
			this.dirtyEffectCount--;
			ranOneEffect = true;
			handle.run();
		}
		return ranOneEffect;
	}
};
var EffectRefImpl = class {
	[SIGNAL];
	constructor(node) {
		this[SIGNAL] = node;
	}
	destroy() {
		this[SIGNAL].destroy();
	}
};
function effect(effectFn, options) {
	ngDevMode && assertNotInReactiveContext(effect, "Call `effect` outside of a reactive context. For example, schedule the effect inside the component constructor.");
	if (ngDevMode && !options?.injector) assertInInjectionContext(effect);
	if (ngDevMode && options?.allowSignalWrites !== void 0) console.warn(`The 'allowSignalWrites' flag is deprecated and no longer impacts effect() (writes are always allowed)`);
	const injector = options?.injector ?? inject(Injector);
	let destroyRef = options?.manualCleanup !== true ? injector.get(DestroyRef) : null;
	let node;
	const viewContext = injector.get(ViewContext, null, { optional: true });
	const notifier = injector.get(ChangeDetectionScheduler);
	if (viewContext !== null) {
		node = createViewEffect(viewContext.view, notifier, effectFn);
		if (destroyRef instanceof NodeInjectorDestroyRef && destroyRef._lView === viewContext.view) destroyRef = null;
	} else node = createRootEffect(effectFn, injector.get(EffectScheduler), notifier);
	node.injector = injector;
	if (destroyRef !== null) node.onDestroyFns = [destroyRef.onDestroy(() => node.destroy())];
	const effectRef = new EffectRefImpl(node);
	if (ngDevMode) {
		node.debugName = options?.debugName ?? "";
		const prevInjectorProfilerContext = setInjectorProfilerContext({
			injector,
			token: null
		});
		try {
			emitEffectCreatedEvent(effectRef);
		} finally {
			setInjectorProfilerContext(prevInjectorProfilerContext);
		}
	}
	return effectRef;
}
var EFFECT_NODE = /* @__PURE__ */ (() => ({
	...BASE_EFFECT_NODE,
	cleanupFns: void 0,
	zone: null,
	onDestroyFns: null,
	run() {
		if (ngDevMode && isInNotificationPhase()) throw new Error(`Schedulers cannot synchronously execute watches while scheduling.`);
		const prevRefreshingViews = setIsRefreshingViews(false);
		try {
			runEffect(this);
		} finally {
			setIsRefreshingViews(prevRefreshingViews);
		}
	},
	cleanup() {
		if (!this.cleanupFns?.length) return;
		const prevConsumer = setActiveConsumer(null);
		try {
			while (this.cleanupFns.length) this.cleanupFns.pop()();
		} finally {
			this.cleanupFns = [];
			setActiveConsumer(prevConsumer);
		}
	}
}))();
var ROOT_EFFECT_NODE = /* @__PURE__ */ (() => ({
	...EFFECT_NODE,
	consumerMarkedDirty() {
		this.scheduler.schedule(this);
		this.notifier.notify(12);
	},
	destroy() {
		consumerDestroy(this);
		if (this.onDestroyFns !== null) for (const fn of this.onDestroyFns) fn();
		this.cleanup();
		this.scheduler.remove(this);
	}
}))();
var VIEW_EFFECT_NODE = /* @__PURE__ */ (() => ({
	...EFFECT_NODE,
	consumerMarkedDirty() {
		this.view[2] |= 8192;
		markAncestorsForTraversal(this.view);
		this.notifier.notify(13);
	},
	destroy() {
		consumerDestroy(this);
		if (this.onDestroyFns !== null) for (const fn of this.onDestroyFns) fn();
		this.cleanup();
		this.view[23]?.delete(this);
	}
}))();
function createViewEffect(view, notifier, fn) {
	const node = Object.create(VIEW_EFFECT_NODE);
	node.view = view;
	node.zone = typeof Zone !== "undefined" ? Zone.current : null;
	node.notifier = notifier;
	node.userFn = fn;
	node.fn = createEffectFn(node, fn);
	view[23] ??= /* @__PURE__ */ new Set();
	view[23].add(node);
	node.consumerMarkedDirty(node);
	return node;
}
function createRootEffect(fn, scheduler, notifier) {
	const node = Object.create(ROOT_EFFECT_NODE);
	node.userFn = fn;
	node.fn = createEffectFn(node, fn);
	node.scheduler = scheduler;
	node.notifier = notifier;
	node.zone = typeof Zone !== "undefined" ? Zone.current : null;
	node.scheduler.add(node);
	node.notifier.notify(12);
	return node;
}
function createEffectFn(node, fn) {
	return () => {
		fn((cleanupFn) => (node.cleanupFns ??= []).push(cleanupFn));
	};
}
function isSignal(value) {
	return typeof value === "function" && value[SIGNAL] !== void 0;
}
function isWritableSignal(value) {
	return isSignal(value) && typeof value.set === "function";
}
var PendingTasks = class PendingTasks {
	internalPendingTasks = inject(PendingTasksInternal);
	scheduler = inject(ChangeDetectionScheduler);
	errorHandler = inject(INTERNAL_APPLICATION_ERROR_HANDLER);
	add() {
		const taskId = this.internalPendingTasks.add();
		return () => {
			if (!this.internalPendingTasks.has(taskId)) return;
			this.scheduler.notify(11);
			this.internalPendingTasks.remove(taskId);
		};
	}
	run(fn) {
		const removeTask = this.add();
		try {
			fn().catch(this.errorHandler).finally(removeTask);
		} catch (err) {
			this.errorHandler(err);
			removeTask();
		}
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: PendingTasks,
		providedIn: "root",
		factory: () => new PendingTasks()
	});
};
//#endregion
//#region node_modules/rxjs/dist/cjs/internal/operators/partition.js
var require_partition = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.partition = void 0;
	var not_1 = require_not();
	var filter_1 = require_filter();
	function partition(predicate, thisArg) {
		return function(source) {
			return [filter_1.filter(predicate, thisArg)(source), filter_1.filter(not_1.not(predicate, thisArg))(source)];
		};
	}
	exports.partition = partition;
}));
//#endregion
//#region node_modules/rxjs/dist/cjs/internal/operators/race.js
var require_race = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __read = exports && exports.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = exports && exports.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.race = void 0;
	var argsOrArgArray_1 = require_argsOrArgArray();
	var raceWith_1 = require_raceWith();
	function race() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		return raceWith_1.raceWith.apply(void 0, __spreadArray([], __read(argsOrArgArray_1.argsOrArgArray(args))));
	}
	exports.race = race;
}));
//#endregion
//#region node_modules/rxjs/dist/cjs/operators/index.js
var require_operators = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeAll = exports.merge = exports.max = exports.materialize = exports.mapTo = exports.map = exports.last = exports.isEmpty = exports.ignoreElements = exports.groupBy = exports.first = exports.findIndex = exports.find = exports.finalize = exports.filter = exports.expand = exports.exhaustMap = exports.exhaustAll = exports.exhaust = exports.every = exports.endWith = exports.elementAt = exports.distinctUntilKeyChanged = exports.distinctUntilChanged = exports.distinct = exports.dematerialize = exports.delayWhen = exports.delay = exports.defaultIfEmpty = exports.debounceTime = exports.debounce = exports.count = exports.connect = exports.concatWith = exports.concatMapTo = exports.concatMap = exports.concatAll = exports.concat = exports.combineLatestWith = exports.combineLatest = exports.combineLatestAll = exports.combineAll = exports.catchError = exports.bufferWhen = exports.bufferToggle = exports.bufferTime = exports.bufferCount = exports.buffer = exports.auditTime = exports.audit = void 0;
	exports.timeInterval = exports.throwIfEmpty = exports.throttleTime = exports.throttle = exports.tap = exports.takeWhile = exports.takeUntil = exports.takeLast = exports.take = exports.switchScan = exports.switchMapTo = exports.switchMap = exports.switchAll = exports.subscribeOn = exports.startWith = exports.skipWhile = exports.skipUntil = exports.skipLast = exports.skip = exports.single = exports.shareReplay = exports.share = exports.sequenceEqual = exports.scan = exports.sampleTime = exports.sample = exports.refCount = exports.retryWhen = exports.retry = exports.repeatWhen = exports.repeat = exports.reduce = exports.raceWith = exports.race = exports.publishReplay = exports.publishLast = exports.publishBehavior = exports.publish = exports.pluck = exports.partition = exports.pairwise = exports.onErrorResumeNext = exports.observeOn = exports.multicast = exports.min = exports.mergeWith = exports.mergeScan = exports.mergeMapTo = exports.mergeMap = exports.flatMap = void 0;
	exports.zipWith = exports.zipAll = exports.zip = exports.withLatestFrom = exports.windowWhen = exports.windowToggle = exports.windowTime = exports.windowCount = exports.window = exports.toArray = exports.timestamp = exports.timeoutWith = exports.timeout = void 0;
	var audit_1 = require_audit();
	Object.defineProperty(exports, "audit", {
		enumerable: true,
		get: function() {
			return audit_1.audit;
		}
	});
	var auditTime_1 = require_auditTime();
	Object.defineProperty(exports, "auditTime", {
		enumerable: true,
		get: function() {
			return auditTime_1.auditTime;
		}
	});
	var buffer_1 = require_buffer();
	Object.defineProperty(exports, "buffer", {
		enumerable: true,
		get: function() {
			return buffer_1.buffer;
		}
	});
	var bufferCount_1 = require_bufferCount();
	Object.defineProperty(exports, "bufferCount", {
		enumerable: true,
		get: function() {
			return bufferCount_1.bufferCount;
		}
	});
	var bufferTime_1 = require_bufferTime();
	Object.defineProperty(exports, "bufferTime", {
		enumerable: true,
		get: function() {
			return bufferTime_1.bufferTime;
		}
	});
	var bufferToggle_1 = require_bufferToggle();
	Object.defineProperty(exports, "bufferToggle", {
		enumerable: true,
		get: function() {
			return bufferToggle_1.bufferToggle;
		}
	});
	var bufferWhen_1 = require_bufferWhen();
	Object.defineProperty(exports, "bufferWhen", {
		enumerable: true,
		get: function() {
			return bufferWhen_1.bufferWhen;
		}
	});
	var catchError_1 = require_catchError();
	Object.defineProperty(exports, "catchError", {
		enumerable: true,
		get: function() {
			return catchError_1.catchError;
		}
	});
	var combineAll_1 = require_combineAll();
	Object.defineProperty(exports, "combineAll", {
		enumerable: true,
		get: function() {
			return combineAll_1.combineAll;
		}
	});
	var combineLatestAll_1 = require_combineLatestAll();
	Object.defineProperty(exports, "combineLatestAll", {
		enumerable: true,
		get: function() {
			return combineLatestAll_1.combineLatestAll;
		}
	});
	var combineLatest_1 = require_combineLatest();
	Object.defineProperty(exports, "combineLatest", {
		enumerable: true,
		get: function() {
			return combineLatest_1.combineLatest;
		}
	});
	var combineLatestWith_1 = require_combineLatestWith();
	Object.defineProperty(exports, "combineLatestWith", {
		enumerable: true,
		get: function() {
			return combineLatestWith_1.combineLatestWith;
		}
	});
	var concat_1 = require_concat();
	Object.defineProperty(exports, "concat", {
		enumerable: true,
		get: function() {
			return concat_1.concat;
		}
	});
	var concatAll_1 = require_concatAll();
	Object.defineProperty(exports, "concatAll", {
		enumerable: true,
		get: function() {
			return concatAll_1.concatAll;
		}
	});
	var concatMap_1 = require_concatMap();
	Object.defineProperty(exports, "concatMap", {
		enumerable: true,
		get: function() {
			return concatMap_1.concatMap;
		}
	});
	var concatMapTo_1 = require_concatMapTo();
	Object.defineProperty(exports, "concatMapTo", {
		enumerable: true,
		get: function() {
			return concatMapTo_1.concatMapTo;
		}
	});
	var concatWith_1 = require_concatWith();
	Object.defineProperty(exports, "concatWith", {
		enumerable: true,
		get: function() {
			return concatWith_1.concatWith;
		}
	});
	var connect_1 = require_connect();
	Object.defineProperty(exports, "connect", {
		enumerable: true,
		get: function() {
			return connect_1.connect;
		}
	});
	var count_1 = require_count();
	Object.defineProperty(exports, "count", {
		enumerable: true,
		get: function() {
			return count_1.count;
		}
	});
	var debounce_1 = require_debounce();
	Object.defineProperty(exports, "debounce", {
		enumerable: true,
		get: function() {
			return debounce_1.debounce;
		}
	});
	var debounceTime_1 = require_debounceTime();
	Object.defineProperty(exports, "debounceTime", {
		enumerable: true,
		get: function() {
			return debounceTime_1.debounceTime;
		}
	});
	var defaultIfEmpty_1 = require_defaultIfEmpty();
	Object.defineProperty(exports, "defaultIfEmpty", {
		enumerable: true,
		get: function() {
			return defaultIfEmpty_1.defaultIfEmpty;
		}
	});
	var delay_1 = require_delay();
	Object.defineProperty(exports, "delay", {
		enumerable: true,
		get: function() {
			return delay_1.delay;
		}
	});
	var delayWhen_1 = require_delayWhen();
	Object.defineProperty(exports, "delayWhen", {
		enumerable: true,
		get: function() {
			return delayWhen_1.delayWhen;
		}
	});
	var dematerialize_1 = require_dematerialize();
	Object.defineProperty(exports, "dematerialize", {
		enumerable: true,
		get: function() {
			return dematerialize_1.dematerialize;
		}
	});
	var distinct_1 = require_distinct();
	Object.defineProperty(exports, "distinct", {
		enumerable: true,
		get: function() {
			return distinct_1.distinct;
		}
	});
	var distinctUntilChanged_1 = require_distinctUntilChanged();
	Object.defineProperty(exports, "distinctUntilChanged", {
		enumerable: true,
		get: function() {
			return distinctUntilChanged_1.distinctUntilChanged;
		}
	});
	var distinctUntilKeyChanged_1 = require_distinctUntilKeyChanged();
	Object.defineProperty(exports, "distinctUntilKeyChanged", {
		enumerable: true,
		get: function() {
			return distinctUntilKeyChanged_1.distinctUntilKeyChanged;
		}
	});
	var elementAt_1 = require_elementAt();
	Object.defineProperty(exports, "elementAt", {
		enumerable: true,
		get: function() {
			return elementAt_1.elementAt;
		}
	});
	var endWith_1 = require_endWith();
	Object.defineProperty(exports, "endWith", {
		enumerable: true,
		get: function() {
			return endWith_1.endWith;
		}
	});
	var every_1 = require_every();
	Object.defineProperty(exports, "every", {
		enumerable: true,
		get: function() {
			return every_1.every;
		}
	});
	var exhaust_1 = require_exhaust();
	Object.defineProperty(exports, "exhaust", {
		enumerable: true,
		get: function() {
			return exhaust_1.exhaust;
		}
	});
	var exhaustAll_1 = require_exhaustAll();
	Object.defineProperty(exports, "exhaustAll", {
		enumerable: true,
		get: function() {
			return exhaustAll_1.exhaustAll;
		}
	});
	var exhaustMap_1 = require_exhaustMap();
	Object.defineProperty(exports, "exhaustMap", {
		enumerable: true,
		get: function() {
			return exhaustMap_1.exhaustMap;
		}
	});
	var expand_1 = require_expand();
	Object.defineProperty(exports, "expand", {
		enumerable: true,
		get: function() {
			return expand_1.expand;
		}
	});
	var filter_1 = require_filter();
	Object.defineProperty(exports, "filter", {
		enumerable: true,
		get: function() {
			return filter_1.filter;
		}
	});
	var finalize_1 = require_finalize();
	Object.defineProperty(exports, "finalize", {
		enumerable: true,
		get: function() {
			return finalize_1.finalize;
		}
	});
	var find_1 = require_find();
	Object.defineProperty(exports, "find", {
		enumerable: true,
		get: function() {
			return find_1.find;
		}
	});
	var findIndex_1 = require_findIndex();
	Object.defineProperty(exports, "findIndex", {
		enumerable: true,
		get: function() {
			return findIndex_1.findIndex;
		}
	});
	var first_1 = require_first();
	Object.defineProperty(exports, "first", {
		enumerable: true,
		get: function() {
			return first_1.first;
		}
	});
	var groupBy_1 = require_groupBy();
	Object.defineProperty(exports, "groupBy", {
		enumerable: true,
		get: function() {
			return groupBy_1.groupBy;
		}
	});
	var ignoreElements_1 = require_ignoreElements();
	Object.defineProperty(exports, "ignoreElements", {
		enumerable: true,
		get: function() {
			return ignoreElements_1.ignoreElements;
		}
	});
	var isEmpty_1 = require_isEmpty();
	Object.defineProperty(exports, "isEmpty", {
		enumerable: true,
		get: function() {
			return isEmpty_1.isEmpty;
		}
	});
	var last_1 = require_last();
	Object.defineProperty(exports, "last", {
		enumerable: true,
		get: function() {
			return last_1.last;
		}
	});
	var map_1 = require_map();
	Object.defineProperty(exports, "map", {
		enumerable: true,
		get: function() {
			return map_1.map;
		}
	});
	var mapTo_1 = require_mapTo();
	Object.defineProperty(exports, "mapTo", {
		enumerable: true,
		get: function() {
			return mapTo_1.mapTo;
		}
	});
	var materialize_1 = require_materialize();
	Object.defineProperty(exports, "materialize", {
		enumerable: true,
		get: function() {
			return materialize_1.materialize;
		}
	});
	var max_1 = require_max();
	Object.defineProperty(exports, "max", {
		enumerable: true,
		get: function() {
			return max_1.max;
		}
	});
	var merge_1 = require_merge();
	Object.defineProperty(exports, "merge", {
		enumerable: true,
		get: function() {
			return merge_1.merge;
		}
	});
	var mergeAll_1 = require_mergeAll();
	Object.defineProperty(exports, "mergeAll", {
		enumerable: true,
		get: function() {
			return mergeAll_1.mergeAll;
		}
	});
	var flatMap_1 = require_flatMap();
	Object.defineProperty(exports, "flatMap", {
		enumerable: true,
		get: function() {
			return flatMap_1.flatMap;
		}
	});
	var mergeMap_1 = require_mergeMap();
	Object.defineProperty(exports, "mergeMap", {
		enumerable: true,
		get: function() {
			return mergeMap_1.mergeMap;
		}
	});
	var mergeMapTo_1 = require_mergeMapTo();
	Object.defineProperty(exports, "mergeMapTo", {
		enumerable: true,
		get: function() {
			return mergeMapTo_1.mergeMapTo;
		}
	});
	var mergeScan_1 = require_mergeScan();
	Object.defineProperty(exports, "mergeScan", {
		enumerable: true,
		get: function() {
			return mergeScan_1.mergeScan;
		}
	});
	var mergeWith_1 = require_mergeWith();
	Object.defineProperty(exports, "mergeWith", {
		enumerable: true,
		get: function() {
			return mergeWith_1.mergeWith;
		}
	});
	var min_1 = require_min();
	Object.defineProperty(exports, "min", {
		enumerable: true,
		get: function() {
			return min_1.min;
		}
	});
	var multicast_1 = require_multicast();
	Object.defineProperty(exports, "multicast", {
		enumerable: true,
		get: function() {
			return multicast_1.multicast;
		}
	});
	var observeOn_1 = require_observeOn();
	Object.defineProperty(exports, "observeOn", {
		enumerable: true,
		get: function() {
			return observeOn_1.observeOn;
		}
	});
	var onErrorResumeNextWith_1 = require_onErrorResumeNextWith();
	Object.defineProperty(exports, "onErrorResumeNext", {
		enumerable: true,
		get: function() {
			return onErrorResumeNextWith_1.onErrorResumeNext;
		}
	});
	var pairwise_1 = require_pairwise();
	Object.defineProperty(exports, "pairwise", {
		enumerable: true,
		get: function() {
			return pairwise_1.pairwise;
		}
	});
	var partition_1 = require_partition();
	Object.defineProperty(exports, "partition", {
		enumerable: true,
		get: function() {
			return partition_1.partition;
		}
	});
	var pluck_1 = require_pluck();
	Object.defineProperty(exports, "pluck", {
		enumerable: true,
		get: function() {
			return pluck_1.pluck;
		}
	});
	var publish_1 = require_publish();
	Object.defineProperty(exports, "publish", {
		enumerable: true,
		get: function() {
			return publish_1.publish;
		}
	});
	var publishBehavior_1 = require_publishBehavior();
	Object.defineProperty(exports, "publishBehavior", {
		enumerable: true,
		get: function() {
			return publishBehavior_1.publishBehavior;
		}
	});
	var publishLast_1 = require_publishLast();
	Object.defineProperty(exports, "publishLast", {
		enumerable: true,
		get: function() {
			return publishLast_1.publishLast;
		}
	});
	var publishReplay_1 = require_publishReplay();
	Object.defineProperty(exports, "publishReplay", {
		enumerable: true,
		get: function() {
			return publishReplay_1.publishReplay;
		}
	});
	var race_1 = require_race();
	Object.defineProperty(exports, "race", {
		enumerable: true,
		get: function() {
			return race_1.race;
		}
	});
	var raceWith_1 = require_raceWith();
	Object.defineProperty(exports, "raceWith", {
		enumerable: true,
		get: function() {
			return raceWith_1.raceWith;
		}
	});
	var reduce_1 = require_reduce();
	Object.defineProperty(exports, "reduce", {
		enumerable: true,
		get: function() {
			return reduce_1.reduce;
		}
	});
	var repeat_1 = require_repeat();
	Object.defineProperty(exports, "repeat", {
		enumerable: true,
		get: function() {
			return repeat_1.repeat;
		}
	});
	var repeatWhen_1 = require_repeatWhen();
	Object.defineProperty(exports, "repeatWhen", {
		enumerable: true,
		get: function() {
			return repeatWhen_1.repeatWhen;
		}
	});
	var retry_1 = require_retry();
	Object.defineProperty(exports, "retry", {
		enumerable: true,
		get: function() {
			return retry_1.retry;
		}
	});
	var retryWhen_1 = require_retryWhen();
	Object.defineProperty(exports, "retryWhen", {
		enumerable: true,
		get: function() {
			return retryWhen_1.retryWhen;
		}
	});
	var refCount_1 = require_refCount();
	Object.defineProperty(exports, "refCount", {
		enumerable: true,
		get: function() {
			return refCount_1.refCount;
		}
	});
	var sample_1 = require_sample();
	Object.defineProperty(exports, "sample", {
		enumerable: true,
		get: function() {
			return sample_1.sample;
		}
	});
	var sampleTime_1 = require_sampleTime();
	Object.defineProperty(exports, "sampleTime", {
		enumerable: true,
		get: function() {
			return sampleTime_1.sampleTime;
		}
	});
	var scan_1 = require_scan();
	Object.defineProperty(exports, "scan", {
		enumerable: true,
		get: function() {
			return scan_1.scan;
		}
	});
	var sequenceEqual_1 = require_sequenceEqual();
	Object.defineProperty(exports, "sequenceEqual", {
		enumerable: true,
		get: function() {
			return sequenceEqual_1.sequenceEqual;
		}
	});
	var share_1 = require_share();
	Object.defineProperty(exports, "share", {
		enumerable: true,
		get: function() {
			return share_1.share;
		}
	});
	var shareReplay_1 = require_shareReplay();
	Object.defineProperty(exports, "shareReplay", {
		enumerable: true,
		get: function() {
			return shareReplay_1.shareReplay;
		}
	});
	var single_1 = require_single();
	Object.defineProperty(exports, "single", {
		enumerable: true,
		get: function() {
			return single_1.single;
		}
	});
	var skip_1 = require_skip();
	Object.defineProperty(exports, "skip", {
		enumerable: true,
		get: function() {
			return skip_1.skip;
		}
	});
	var skipLast_1 = require_skipLast();
	Object.defineProperty(exports, "skipLast", {
		enumerable: true,
		get: function() {
			return skipLast_1.skipLast;
		}
	});
	var skipUntil_1 = require_skipUntil();
	Object.defineProperty(exports, "skipUntil", {
		enumerable: true,
		get: function() {
			return skipUntil_1.skipUntil;
		}
	});
	var skipWhile_1 = require_skipWhile();
	Object.defineProperty(exports, "skipWhile", {
		enumerable: true,
		get: function() {
			return skipWhile_1.skipWhile;
		}
	});
	var startWith_1 = require_startWith();
	Object.defineProperty(exports, "startWith", {
		enumerable: true,
		get: function() {
			return startWith_1.startWith;
		}
	});
	var subscribeOn_1 = require_subscribeOn();
	Object.defineProperty(exports, "subscribeOn", {
		enumerable: true,
		get: function() {
			return subscribeOn_1.subscribeOn;
		}
	});
	var switchAll_1 = require_switchAll();
	Object.defineProperty(exports, "switchAll", {
		enumerable: true,
		get: function() {
			return switchAll_1.switchAll;
		}
	});
	var switchMap_1 = require_switchMap();
	Object.defineProperty(exports, "switchMap", {
		enumerable: true,
		get: function() {
			return switchMap_1.switchMap;
		}
	});
	var switchMapTo_1 = require_switchMapTo();
	Object.defineProperty(exports, "switchMapTo", {
		enumerable: true,
		get: function() {
			return switchMapTo_1.switchMapTo;
		}
	});
	var switchScan_1 = require_switchScan();
	Object.defineProperty(exports, "switchScan", {
		enumerable: true,
		get: function() {
			return switchScan_1.switchScan;
		}
	});
	var take_1 = require_take();
	Object.defineProperty(exports, "take", {
		enumerable: true,
		get: function() {
			return take_1.take;
		}
	});
	var takeLast_1 = require_takeLast();
	Object.defineProperty(exports, "takeLast", {
		enumerable: true,
		get: function() {
			return takeLast_1.takeLast;
		}
	});
	var takeUntil_1 = require_takeUntil();
	Object.defineProperty(exports, "takeUntil", {
		enumerable: true,
		get: function() {
			return takeUntil_1.takeUntil;
		}
	});
	var takeWhile_1 = require_takeWhile();
	Object.defineProperty(exports, "takeWhile", {
		enumerable: true,
		get: function() {
			return takeWhile_1.takeWhile;
		}
	});
	var tap_1 = require_tap();
	Object.defineProperty(exports, "tap", {
		enumerable: true,
		get: function() {
			return tap_1.tap;
		}
	});
	var throttle_1 = require_throttle();
	Object.defineProperty(exports, "throttle", {
		enumerable: true,
		get: function() {
			return throttle_1.throttle;
		}
	});
	var throttleTime_1 = require_throttleTime();
	Object.defineProperty(exports, "throttleTime", {
		enumerable: true,
		get: function() {
			return throttleTime_1.throttleTime;
		}
	});
	var throwIfEmpty_1 = require_throwIfEmpty();
	Object.defineProperty(exports, "throwIfEmpty", {
		enumerable: true,
		get: function() {
			return throwIfEmpty_1.throwIfEmpty;
		}
	});
	var timeInterval_1 = require_timeInterval();
	Object.defineProperty(exports, "timeInterval", {
		enumerable: true,
		get: function() {
			return timeInterval_1.timeInterval;
		}
	});
	var timeout_1 = require_timeout();
	Object.defineProperty(exports, "timeout", {
		enumerable: true,
		get: function() {
			return timeout_1.timeout;
		}
	});
	var timeoutWith_1 = require_timeoutWith();
	Object.defineProperty(exports, "timeoutWith", {
		enumerable: true,
		get: function() {
			return timeoutWith_1.timeoutWith;
		}
	});
	var timestamp_1 = require_timestamp();
	Object.defineProperty(exports, "timestamp", {
		enumerable: true,
		get: function() {
			return timestamp_1.timestamp;
		}
	});
	var toArray_1 = require_toArray();
	Object.defineProperty(exports, "toArray", {
		enumerable: true,
		get: function() {
			return toArray_1.toArray;
		}
	});
	var window_1 = require_window();
	Object.defineProperty(exports, "window", {
		enumerable: true,
		get: function() {
			return window_1.window;
		}
	});
	var windowCount_1 = require_windowCount();
	Object.defineProperty(exports, "windowCount", {
		enumerable: true,
		get: function() {
			return windowCount_1.windowCount;
		}
	});
	var windowTime_1 = require_windowTime();
	Object.defineProperty(exports, "windowTime", {
		enumerable: true,
		get: function() {
			return windowTime_1.windowTime;
		}
	});
	var windowToggle_1 = require_windowToggle();
	Object.defineProperty(exports, "windowToggle", {
		enumerable: true,
		get: function() {
			return windowToggle_1.windowToggle;
		}
	});
	var windowWhen_1 = require_windowWhen();
	Object.defineProperty(exports, "windowWhen", {
		enumerable: true,
		get: function() {
			return windowWhen_1.windowWhen;
		}
	});
	var withLatestFrom_1 = require_withLatestFrom();
	Object.defineProperty(exports, "withLatestFrom", {
		enumerable: true,
		get: function() {
			return withLatestFrom_1.withLatestFrom;
		}
	});
	var zip_1 = require_zip();
	Object.defineProperty(exports, "zip", {
		enumerable: true,
		get: function() {
			return zip_1.zip;
		}
	});
	var zipAll_1 = require_zipAll();
	Object.defineProperty(exports, "zipAll", {
		enumerable: true,
		get: function() {
			return zipAll_1.zipAll;
		}
	});
	var zipWith_1 = require_zipWith();
	Object.defineProperty(exports, "zipWith", {
		enumerable: true,
		get: function() {
			return zipWith_1.zipWith;
		}
	});
}));
//#endregion
//#region node_modules/@angular/core/fesm2022/_attribute-chunk.mjs
var import_operators = require_operators();
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var Attribute$1 = { JSACTION: "jsaction" };
//#endregion
//#region node_modules/@angular/core/fesm2022/_debug_node-chunk.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var REQUIRED_UNSET_VALUE = /* @__PURE__ */ Symbol("InputSignalNode#UNSET");
var INPUT_SIGNAL_NODE = /* @__PURE__ */ (() => {
	return {
		...SIGNAL_NODE,
		transformFn: void 0,
		applyValueToInputSignal(node, value) {
			signalSetFn(node, value);
		}
	};
})();
function noSideEffects(fn) {
	return { toString: fn }.toString();
}
var ProfilerEvent;
(function(ProfilerEvent) {
	ProfilerEvent[ProfilerEvent["TemplateCreateStart"] = 0] = "TemplateCreateStart";
	ProfilerEvent[ProfilerEvent["TemplateCreateEnd"] = 1] = "TemplateCreateEnd";
	ProfilerEvent[ProfilerEvent["TemplateUpdateStart"] = 2] = "TemplateUpdateStart";
	ProfilerEvent[ProfilerEvent["TemplateUpdateEnd"] = 3] = "TemplateUpdateEnd";
	ProfilerEvent[ProfilerEvent["LifecycleHookStart"] = 4] = "LifecycleHookStart";
	ProfilerEvent[ProfilerEvent["LifecycleHookEnd"] = 5] = "LifecycleHookEnd";
	ProfilerEvent[ProfilerEvent["OutputStart"] = 6] = "OutputStart";
	ProfilerEvent[ProfilerEvent["OutputEnd"] = 7] = "OutputEnd";
	ProfilerEvent[ProfilerEvent["BootstrapApplicationStart"] = 8] = "BootstrapApplicationStart";
	ProfilerEvent[ProfilerEvent["BootstrapApplicationEnd"] = 9] = "BootstrapApplicationEnd";
	ProfilerEvent[ProfilerEvent["BootstrapComponentStart"] = 10] = "BootstrapComponentStart";
	ProfilerEvent[ProfilerEvent["BootstrapComponentEnd"] = 11] = "BootstrapComponentEnd";
	ProfilerEvent[ProfilerEvent["ChangeDetectionStart"] = 12] = "ChangeDetectionStart";
	ProfilerEvent[ProfilerEvent["ChangeDetectionEnd"] = 13] = "ChangeDetectionEnd";
	ProfilerEvent[ProfilerEvent["ChangeDetectionSyncStart"] = 14] = "ChangeDetectionSyncStart";
	ProfilerEvent[ProfilerEvent["ChangeDetectionSyncEnd"] = 15] = "ChangeDetectionSyncEnd";
	ProfilerEvent[ProfilerEvent["AfterRenderHooksStart"] = 16] = "AfterRenderHooksStart";
	ProfilerEvent[ProfilerEvent["AfterRenderHooksEnd"] = 17] = "AfterRenderHooksEnd";
	ProfilerEvent[ProfilerEvent["ComponentStart"] = 18] = "ComponentStart";
	ProfilerEvent[ProfilerEvent["ComponentEnd"] = 19] = "ComponentEnd";
	ProfilerEvent[ProfilerEvent["DeferBlockStateStart"] = 20] = "DeferBlockStateStart";
	ProfilerEvent[ProfilerEvent["DeferBlockStateEnd"] = 21] = "DeferBlockStateEnd";
	ProfilerEvent[ProfilerEvent["DynamicComponentStart"] = 22] = "DynamicComponentStart";
	ProfilerEvent[ProfilerEvent["DynamicComponentEnd"] = 23] = "DynamicComponentEnd";
	ProfilerEvent[ProfilerEvent["HostBindingsUpdateStart"] = 24] = "HostBindingsUpdateStart";
	ProfilerEvent[ProfilerEvent["HostBindingsUpdateEnd"] = 25] = "HostBindingsUpdateEnd";
})(ProfilerEvent || (ProfilerEvent = {}));
var SimpleChange = class {
	previousValue;
	currentValue;
	firstChange;
	constructor(previousValue, currentValue, firstChange) {
		this.previousValue = previousValue;
		this.currentValue = currentValue;
		this.firstChange = firstChange;
	}
	isFirstChange() {
		return this.firstChange;
	}
};
function applyValueToInputField(instance, inputSignalNode, privateName, value) {
	if (inputSignalNode !== null) inputSignalNode.applyValueToInputSignal(inputSignalNode, value);
	else instance[privateName] = value;
}
var _ngOnChangesFeatureImpl = null;
var ɵɵNgOnChangesFeature = /* @__PURE__ */ (() => {
	_ngOnChangesFeatureImpl = NgOnChangesFeatureImpl;
	const ɵɵNgOnChangesFeatureImpl = () => NgOnChangesFeatureImpl;
	ɵɵNgOnChangesFeatureImpl.ngInherit = true;
	return ɵɵNgOnChangesFeatureImpl;
})();
function getNgOnChangesFeatureImpl() {
	return _ngOnChangesFeatureImpl;
}
function NgOnChangesFeatureImpl(definition) {
	if (definition.type.prototype.ngOnChanges) definition.setInput = ngOnChangesSetInput;
	return rememberChangeHistoryAndInvokeOnChangesHook;
}
function rememberChangeHistoryAndInvokeOnChangesHook() {
	const simpleChangesStore = getSimpleChangesStore(this);
	const current = simpleChangesStore?.current;
	if (current) {
		const previous = simpleChangesStore.previous;
		if (previous === EMPTY_OBJ) simpleChangesStore.previous = current;
		else for (let key in current) previous[key] = current[key];
		simpleChangesStore.current = null;
		this.ngOnChanges(current);
	}
}
function ngOnChangesSetInput(instance, inputSignalNode, value, publicName, privateName) {
	const declaredName = this.declaredInputs[publicName];
	ngDevMode && assertString(declaredName, "Name of input in ngOnChanges has to be a string");
	const simpleChangesStore = getSimpleChangesStore(instance) || setSimpleChangesStore(instance, {
		previous: EMPTY_OBJ,
		current: null
	});
	const current = simpleChangesStore.current || (simpleChangesStore.current = {});
	const previous = simpleChangesStore.previous;
	const previousChange = previous[declaredName];
	current[declaredName] = new SimpleChange(previousChange && previousChange.currentValue, value, previous === EMPTY_OBJ);
	applyValueToInputField(instance, inputSignalNode, privateName, value);
}
var SIMPLE_CHANGES_STORE = "__ngSimpleChanges__";
function getSimpleChangesStore(instance) {
	return Object.hasOwn(instance, SIMPLE_CHANGES_STORE) ? instance[SIMPLE_CHANGES_STORE] || null : null;
}
function setSimpleChangesStore(instance, store) {
	return instance[SIMPLE_CHANGES_STORE] = store;
}
var profilerCallbacks = [];
var NOOP_PROFILER_REMOVAL = () => {};
function removeProfiler(profiler) {
	const profilerIdx = profilerCallbacks.indexOf(profiler);
	if (profilerIdx !== -1) profilerCallbacks.splice(profilerIdx, 1);
}
function setProfiler(profiler) {
	if (profiler !== null) {
		if (!profilerCallbacks.includes(profiler)) profilerCallbacks.push(profiler);
		return () => removeProfiler(profiler);
	} else {
		profilerCallbacks.length = 0;
		return NOOP_PROFILER_REMOVAL;
	}
}
var profiler = function(event, instance = null, eventFn) {
	for (let i = 0; i < profilerCallbacks.length; i++) {
		const profilerCallback = profilerCallbacks[i];
		profilerCallback(event, instance, eventFn);
	}
};
function registerPreOrderHooks(directiveIndex, directiveDef, tView) {
	ngDevMode && assertFirstCreatePass(tView);
	const { ngOnChanges, ngOnInit, ngDoCheck } = directiveDef.type.prototype;
	if (ngOnChanges) {
		const wrappedOnChanges = getNgOnChangesFeatureImpl()(directiveDef);
		(tView.preOrderHooks ??= []).push(directiveIndex, wrappedOnChanges);
		(tView.preOrderCheckHooks ??= []).push(directiveIndex, wrappedOnChanges);
	}
	if (ngOnInit) (tView.preOrderHooks ??= []).push(0 - directiveIndex, ngOnInit);
	if (ngDoCheck) {
		(tView.preOrderHooks ??= []).push(directiveIndex, ngDoCheck);
		(tView.preOrderCheckHooks ??= []).push(directiveIndex, ngDoCheck);
	}
}
function registerPostOrderHooks(tView, tNode) {
	ngDevMode && assertFirstCreatePass(tView);
	for (let i = tNode.directiveStart, end = tNode.directiveEnd; i < end; i++) {
		const directiveDef = tView.data[i];
		ngDevMode && assertDefined(directiveDef, "Expecting DirectiveDef");
		const { ngAfterContentInit, ngAfterContentChecked, ngAfterViewInit, ngAfterViewChecked, ngOnDestroy } = directiveDef.type.prototype;
		if (ngAfterContentInit) (tView.contentHooks ??= []).push(-i, ngAfterContentInit);
		if (ngAfterContentChecked) {
			(tView.contentHooks ??= []).push(i, ngAfterContentChecked);
			(tView.contentCheckHooks ??= []).push(i, ngAfterContentChecked);
		}
		if (ngAfterViewInit) (tView.viewHooks ??= []).push(-i, ngAfterViewInit);
		if (ngAfterViewChecked) {
			(tView.viewHooks ??= []).push(i, ngAfterViewChecked);
			(tView.viewCheckHooks ??= []).push(i, ngAfterViewChecked);
		}
		if (ngOnDestroy != null) (tView.destroyHooks ??= []).push(i, ngOnDestroy);
	}
}
function executeCheckHooks(lView, hooks, nodeIndex) {
	callHooks(lView, hooks, 3, nodeIndex);
}
function executeInitAndCheckHooks(lView, hooks, initPhase, nodeIndex) {
	ngDevMode && assertNotEqual(initPhase, 3, "Init pre-order hooks should not be called more than once");
	if ((lView[2] & 3) === initPhase) callHooks(lView, hooks, initPhase, nodeIndex);
}
function incrementInitPhaseFlags(lView, initPhase) {
	ngDevMode && assertNotEqual(initPhase, 3, "Init hooks phase should not be incremented after all init hooks have been run.");
	let flags = lView[2];
	if ((flags & 3) === initPhase) {
		flags &= 16383;
		flags += 1;
		lView[2] = flags;
	}
}
function callHooks(currentView, arr, initPhase, currentNodeIndex) {
	ngDevMode && assertEqual(isInCheckNoChangesMode(), false, "Hooks should never be run when in check no changes mode.");
	const startIndex = currentNodeIndex !== void 0 ? currentView[17] & 65535 : 0;
	const nodeIndexLimit = currentNodeIndex != null ? currentNodeIndex : -1;
	const max = arr.length - 1;
	let lastNodeIndexFound = 0;
	for (let i = startIndex; i < max; i++) if (typeof arr[i + 1] === "number") {
		lastNodeIndexFound = arr[i];
		if (currentNodeIndex != null && lastNodeIndexFound >= currentNodeIndex) break;
	} else {
		if (arr[i] < 0) currentView[17] += 65536;
		if (lastNodeIndexFound < nodeIndexLimit || nodeIndexLimit == -1) {
			callHook(currentView, initPhase, arr, i);
			currentView[17] = (currentView[17] & 4294901760) + i + 2;
		}
		i++;
	}
}
function callHookInternal(directive, hook) {
	profiler(ProfilerEvent.LifecycleHookStart, directive, hook);
	const prevConsumer = setActiveConsumer(null);
	try {
		hook.call(directive);
	} finally {
		setActiveConsumer(prevConsumer);
		profiler(ProfilerEvent.LifecycleHookEnd, directive, hook);
	}
}
function callHook(currentView, initPhase, arr, i) {
	const isInitHook = arr[i] < 0;
	const hook = arr[i + 1];
	const directive = currentView[isInitHook ? -arr[i] : arr[i]];
	if (isInitHook) {
		if (currentView[2] >> 14 < currentView[17] >> 16 && (currentView[2] & 3) === initPhase) {
			currentView[2] += 16384;
			callHookInternal(directive, hook);
		}
	} else callHookInternal(directive, hook);
}
var NO_PARENT_INJECTOR = -1;
var NodeInjectorFactory = class {
	factory;
	name;
	injectImpl;
	resolving = false;
	canSeeViewProviders;
	multi;
	componentProviders;
	index;
	providerFactory;
	constructor(factory, isViewProvider, injectImplementation, name) {
		this.factory = factory;
		this.name = name;
		ngDevMode && assertDefined(factory, "Factory not specified");
		ngDevMode && assertEqual(typeof factory, "function", "Expected factory function.");
		this.canSeeViewProviders = isViewProvider;
		this.injectImpl = injectImplementation;
	}
};
function toTNodeTypeAsString(tNodeType) {
	let text = "";
	tNodeType & 1 && (text += "|Text");
	tNodeType & 2 && (text += "|Element");
	tNodeType & 4 && (text += "|Container");
	tNodeType & 8 && (text += "|ElementContainer");
	tNodeType & 16 && (text += "|Projection");
	tNodeType & 32 && (text += "|IcuContainer");
	tNodeType & 64 && (text += "|Placeholder");
	tNodeType & 128 && (text += "|LetDeclaration");
	return text.length > 0 ? text.substring(1) : text;
}
function isTNodeShape(value) {
	return value != null && typeof value === "object" && (value.insertBeforeIndex === null || typeof value.insertBeforeIndex === "number" || Array.isArray(value.insertBeforeIndex));
}
function isLetDeclaration(tNode) {
	return !!(tNode.type & 128);
}
function hasClassInput(tNode) {
	return (tNode.flags & 8) !== 0;
}
function hasStyleInput(tNode) {
	return (tNode.flags & 16) !== 0;
}
function assertTNodeType(tNode, expectedTypes, message) {
	assertDefined(tNode, "should be called with a TNode");
	if ((tNode.type & expectedTypes) === 0) throwError(message || `Expected [${toTNodeTypeAsString(expectedTypes)}] but got ${toTNodeTypeAsString(tNode.type)}.`);
}
function assertPureTNodeType(type) {
	if (!(type === 2 || type === 1 || type === 4 || type === 8 || type === 32 || type === 16 || type === 64 || type === 128)) throwError(`Expected TNodeType to have only a single type selected, but got ${toTNodeTypeAsString(type)}.`);
}
function setUpAttributes(renderer, native, attrs) {
	let i = 0;
	while (i < attrs.length) {
		const value = attrs[i];
		if (typeof value === "number") {
			if (value !== 0) break;
			i++;
			const namespaceURI = attrs[i++];
			const attrName = attrs[i++];
			const attrVal = attrs[i++];
			renderer.setAttribute(native, attrName, attrVal, namespaceURI);
		} else {
			const attrName = value;
			const attrVal = attrs[++i];
			if (isAnimationProp(attrName)) renderer.setProperty(native, attrName, attrVal);
			else renderer.setAttribute(native, attrName, attrVal);
			i++;
		}
	}
	return i;
}
function isNameOnlyAttributeMarker(marker) {
	return marker === 3 || marker === 4 || marker === 6;
}
function isAnimationProp(name) {
	return name.charCodeAt(0) === 64;
}
function mergeHostAttrs(dst, src) {
	if (src === null || src.length === 0);
	else if (dst === null || dst.length === 0) dst = src.slice();
	else {
		let srcMarker = -1;
		for (let i = 0; i < src.length; i++) {
			const item = src[i];
			if (typeof item === "number") srcMarker = item;
			else if (srcMarker === 0);
			else if (srcMarker === -1 || srcMarker === 2) mergeHostAttribute(dst, srcMarker, item, null, src[++i]);
			else mergeHostAttribute(dst, srcMarker, item, null, null);
		}
	}
	return dst;
}
function mergeHostAttribute(dst, marker, key1, key2, value) {
	let i = 0;
	let markerInsertPosition = dst.length;
	if (marker === -1) markerInsertPosition = -1;
	else while (i < dst.length) {
		const dstValue = dst[i++];
		if (typeof dstValue === "number") {
			if (dstValue === marker) {
				markerInsertPosition = -1;
				break;
			} else if (dstValue > marker) {
				markerInsertPosition = i - 1;
				break;
			}
		}
	}
	while (i < dst.length) {
		const item = dst[i];
		if (typeof item === "number") break;
		else if (item === key1) {
			if (value !== null) dst[i + 1] = value;
			return;
		}
		i++;
		if (value !== null) i++;
	}
	if (markerInsertPosition !== -1) {
		dst.splice(markerInsertPosition, 0, marker);
		i = markerInsertPosition + 1;
	}
	dst.splice(i++, 0, key1);
	if (value !== null) dst.splice(i++, 0, value);
}
function hasParentInjector(parentLocation) {
	return parentLocation !== NO_PARENT_INJECTOR;
}
function getParentInjectorIndex(parentLocation) {
	if (ngDevMode) {
		assertNumber(parentLocation, "Number expected");
		assertNotEqual(parentLocation, -1, "Not a valid state.");
		assertGreaterThan(parentLocation & 32767, 28, "Parent injector must be pointing past HEADER_OFFSET.");
	}
	return parentLocation & 32767;
}
function getParentInjectorViewOffset(parentLocation) {
	return parentLocation >> 16;
}
function getParentInjectorView(location, startView) {
	let viewOffset = getParentInjectorViewOffset(location);
	let parentView = startView;
	while (viewOffset > 0) {
		parentView = parentView[14];
		viewOffset--;
	}
	return parentView;
}
var includeViewProviders = true;
function setIncludeViewProviders(v) {
	const oldValue = includeViewProviders;
	includeViewProviders = v;
	return oldValue;
}
var BLOOM_MASK = 255;
var BLOOM_BUCKET_BITS = 5;
var nextNgElementId = 0;
var NOT_FOUND = {};
function bloomAdd(injectorIndex, tView, type) {
	ngDevMode && assertEqual(tView.firstCreatePass, true, "expected firstCreatePass to be true");
	let id;
	if (typeof type === "string") id = type.charCodeAt(0) || 0;
	else if (Object.hasOwn(type, NG_ELEMENT_ID)) id = type[NG_ELEMENT_ID];
	if (id == null) id = type[NG_ELEMENT_ID] = nextNgElementId++;
	const bloomHash = id & BLOOM_MASK;
	const mask = 1 << bloomHash;
	tView.data[injectorIndex + (bloomHash >> BLOOM_BUCKET_BITS)] |= mask;
}
function getOrCreateNodeInjectorForNode(tNode, lView) {
	const existingInjectorIndex = getInjectorIndex(tNode, lView);
	if (existingInjectorIndex !== -1) return existingInjectorIndex;
	const tView = lView[1];
	if (tView.firstCreatePass) {
		tNode.injectorIndex = lView.length;
		insertBloom(tView.data, tNode);
		insertBloom(lView, null);
		insertBloom(tView.blueprint, null);
	}
	const parentLoc = getParentInjectorLocation(tNode, lView);
	const injectorIndex = tNode.injectorIndex;
	if (hasParentInjector(parentLoc)) {
		const parentIndex = getParentInjectorIndex(parentLoc);
		const parentLView = getParentInjectorView(parentLoc, lView);
		const parentData = parentLView[1].data;
		for (let i = 0; i < 8; i++) lView[injectorIndex + i] = parentLView[parentIndex + i] | parentData[parentIndex + i];
	}
	lView[injectorIndex + 8] = parentLoc;
	return injectorIndex;
}
function insertBloom(arr, footer) {
	arr.push(0, 0, 0, 0, 0, 0, 0, 0, footer);
}
function getInjectorIndex(tNode, lView) {
	if (tNode.injectorIndex === -1 || tNode.parent && tNode.parent.injectorIndex === tNode.injectorIndex || lView[tNode.injectorIndex + 8] === null) return -1;
	else {
		ngDevMode && assertIndexInRange(lView, tNode.injectorIndex);
		return tNode.injectorIndex;
	}
}
function getParentInjectorLocation(tNode, lView) {
	if (tNode.parent && tNode.parent.injectorIndex !== -1) return tNode.parent.injectorIndex;
	let declarationViewOffset = 0;
	let parentTNode = null;
	let lViewCursor = lView;
	while (lViewCursor !== null) {
		parentTNode = getTNodeFromLView(lViewCursor);
		if (parentTNode === null) return NO_PARENT_INJECTOR;
		ngDevMode && parentTNode && assertTNodeForLView(parentTNode, lViewCursor[14]);
		declarationViewOffset++;
		lViewCursor = lViewCursor[14];
		if (parentTNode.injectorIndex !== -1) return parentTNode.injectorIndex | declarationViewOffset << 16;
	}
	return NO_PARENT_INJECTOR;
}
function diPublicInInjector(injectorIndex, tView, token) {
	bloomAdd(injectorIndex, tView, token);
}
function injectAttributeImpl(tNode, attrNameToInject) {
	ngDevMode && assertTNodeType(tNode, 15);
	ngDevMode && assertDefined(tNode, "expecting tNode");
	if (attrNameToInject === "class") return tNode.classes;
	if (attrNameToInject === "style") return tNode.styles;
	const attrs = tNode.attrs;
	if (attrs) {
		const attrsLength = attrs.length;
		let i = 0;
		while (i < attrsLength) {
			const value = attrs[i];
			if (isNameOnlyAttributeMarker(value)) break;
			if (value === 0) i = i + 2;
			else if (typeof value === "number") {
				i++;
				while (i < attrsLength && typeof attrs[i] === "string") i++;
			} else if (value === attrNameToInject) return attrs[i + 1];
			else i = i + 2;
		}
	}
	return null;
}
function notFoundValueOrThrow(notFoundValue, token, flags) {
	if (flags & 8 || notFoundValue !== void 0) return notFoundValue;
	else throwProviderNotFoundError(token, "NodeInjector");
}
function lookupTokenUsingModuleInjector(lView, token, flags, notFoundValue) {
	if (flags & 8 && notFoundValue === void 0) notFoundValue = null;
	if ((flags & 3) === 0) {
		const moduleInjector = lView[9];
		const previousInjectImplementation = setInjectImplementation(void 0);
		try {
			if (moduleInjector) return moduleInjector.get(token, notFoundValue, flags & 8);
			else return injectRootLimpMode(token, notFoundValue, flags & 8);
		} finally {
			setInjectImplementation(previousInjectImplementation);
		}
	}
	return notFoundValueOrThrow(notFoundValue, token, flags);
}
function getOrCreateInjectable(tNode, lView, token, flags = 0, notFoundValue) {
	if (tNode !== null) {
		if (lView[2] & 2048 && !(flags & 2)) {
			const embeddedInjectorValue = lookupTokenUsingEmbeddedInjector(tNode, lView, token, flags, NOT_FOUND);
			if (embeddedInjectorValue !== NOT_FOUND) return embeddedInjectorValue;
		}
		const value = lookupTokenUsingNodeInjector(tNode, lView, token, flags, NOT_FOUND);
		if (value !== NOT_FOUND) return value;
	}
	return lookupTokenUsingModuleInjector(lView, token, flags, notFoundValue);
}
function lookupTokenUsingNodeInjector(tNode, lView, token, flags, notFoundValue) {
	const bloomHash = bloomHashBitOrFactory(token);
	if (typeof bloomHash === "function") {
		if (!enterDI(lView, tNode, flags)) return flags & 1 ? notFoundValueOrThrow(notFoundValue, token, flags) : lookupTokenUsingModuleInjector(lView, token, flags, notFoundValue);
		try {
			let value;
			if (ngDevMode) runInInjectorProfilerContext(new NodeInjector(getCurrentTNode(), getLView()), token, () => {
				emitInjectorToCreateInstanceEvent(token);
				value = bloomHash(flags);
				emitInstanceCreatedByInjectorEvent(value);
			});
			else value = bloomHash(flags);
			if (value == null && !(flags & 8)) throwProviderNotFoundError(token);
			else return value;
		} finally {
			leaveDI();
		}
	} else if (typeof bloomHash === "number") {
		let previousTView = null;
		let injectorIndex = getInjectorIndex(tNode, lView);
		let parentLocation = NO_PARENT_INJECTOR;
		let hostTElementNode = flags & 1 ? lView[15][5] : null;
		if (injectorIndex === -1 || flags & 4) {
			parentLocation = injectorIndex === -1 ? getParentInjectorLocation(tNode, lView) : lView[injectorIndex + 8];
			if (parentLocation === NO_PARENT_INJECTOR || !shouldSearchParent(flags, false)) injectorIndex = -1;
			else {
				previousTView = lView[1];
				injectorIndex = getParentInjectorIndex(parentLocation);
				lView = getParentInjectorView(parentLocation, lView);
			}
		}
		while (injectorIndex !== -1) {
			ngDevMode && assertNodeInjector(lView, injectorIndex);
			const tView = lView[1];
			ngDevMode && assertTNodeForLView(tView.data[injectorIndex + 8], lView);
			if (bloomHasToken(bloomHash, injectorIndex, tView.data)) {
				const instance = searchTokensOnInjector(injectorIndex, lView, token, previousTView, flags, hostTElementNode);
				if (instance !== NOT_FOUND) return instance;
			}
			parentLocation = lView[injectorIndex + 8];
			if (parentLocation !== NO_PARENT_INJECTOR && shouldSearchParent(flags, lView[1].data[injectorIndex + 8] === hostTElementNode) && bloomHasToken(bloomHash, injectorIndex, lView)) {
				previousTView = tView;
				injectorIndex = getParentInjectorIndex(parentLocation);
				lView = getParentInjectorView(parentLocation, lView);
			} else injectorIndex = -1;
		}
	}
	return notFoundValue;
}
function searchTokensOnInjector(injectorIndex, lView, token, previousTView, flags, hostTElementNode) {
	const currentTView = lView[1];
	const tNode = currentTView.data[injectorIndex + 8];
	const injectableIdx = locateDirectiveOrProvider(tNode, currentTView, token, previousTView == null ? isComponentHost(tNode) && includeViewProviders : previousTView != currentTView && (tNode.type & 3) !== 0, flags & 1 && hostTElementNode === tNode);
	if (injectableIdx !== null) return getNodeInjectable(lView, currentTView, injectableIdx, tNode, flags);
	else return NOT_FOUND;
}
function locateDirectiveOrProvider(tNode, tView, token, canAccessViewProviders, isHostSpecialCase) {
	const nodeProviderIndexes = tNode.providerIndexes;
	const tInjectables = tView.data;
	const injectablesStart = nodeProviderIndexes & 1048575;
	const directivesStart = tNode.directiveStart;
	const directiveEnd = tNode.directiveEnd;
	const cptViewProvidersCount = nodeProviderIndexes >> 20;
	const startingIndex = canAccessViewProviders ? injectablesStart : injectablesStart + cptViewProvidersCount;
	const endIndex = isHostSpecialCase ? injectablesStart + cptViewProvidersCount : directiveEnd;
	for (let i = startingIndex; i < endIndex; i++) {
		const providerTokenOrDef = tInjectables[i];
		if (i < directivesStart && token === providerTokenOrDef || i >= directivesStart && providerTokenOrDef.type === token) return i;
	}
	if (isHostSpecialCase) {
		const dirDef = tInjectables[directivesStart];
		if (dirDef && isComponentDef(dirDef) && dirDef.type === token) return directivesStart;
	}
	return null;
}
var injectionPath = [];
function getNodeInjectable(lView, tView, index, tNode, flags) {
	let value = lView[index];
	const tData = tView.data;
	if (value instanceof NodeInjectorFactory) {
		const factory = value;
		ngDevMode && injectionPath.push(factory.name ?? "unknown");
		if (factory.resolving) {
			let token = "";
			if (ngDevMode) {
				token = stringifyForError(tData[index]);
				throw cyclicDependencyErrorWithDetails(token, injectionPath);
			} else throw cyclicDependencyError(token);
		}
		const previousIncludeViewProviders = setIncludeViewProviders(factory.canSeeViewProviders);
		factory.resolving = true;
		const token = tData[index].type || tData[index];
		let prevInjectContext;
		if (ngDevMode) prevInjectContext = setInjectorProfilerContext({
			injector: new NodeInjector(tNode, lView),
			token
		});
		const previousInjectImplementation = factory.injectImpl ? setInjectImplementation(factory.injectImpl) : null;
		const success = enterDI(lView, tNode, 0);
		ngDevMode && assertEqual(success, true, "Because flags do not contain `SkipSelf' we expect this to always succeed.");
		try {
			ngDevMode && emitInjectorToCreateInstanceEvent(token);
			value = lView[index] = factory.factory(void 0, flags, tData, lView, tNode);
			ngDevMode && emitInstanceCreatedByInjectorEvent(value);
			if (tView.firstCreatePass && index >= tNode.directiveStart) {
				ngDevMode && assertDirectiveDef(tData[index]);
				registerPreOrderHooks(index, tData[index], tView);
			}
		} finally {
			ngDevMode && setInjectorProfilerContext(prevInjectContext);
			previousInjectImplementation !== null && setInjectImplementation(previousInjectImplementation);
			setIncludeViewProviders(previousIncludeViewProviders);
			factory.resolving = false;
			leaveDI();
			ngDevMode && (injectionPath = []);
		}
	}
	return value;
}
function bloomHashBitOrFactory(token) {
	ngDevMode && assertDefined(token, "token must be defined");
	if (typeof token === "string") return token.charCodeAt(0) || 0;
	const tokenId = Object.hasOwn(token, NG_ELEMENT_ID) ? token[NG_ELEMENT_ID] : void 0;
	if (typeof tokenId === "number") {
		if (tokenId >= 0) return tokenId & BLOOM_MASK;
		else {
			ngDevMode && assertEqual(tokenId, -1, "Expecting to get Special Injector Id");
			return createNodeInjector;
		}
	} else return tokenId;
}
function bloomHasToken(bloomHash, injectorIndex, injectorView) {
	const mask = 1 << bloomHash;
	return !!(injectorView[injectorIndex + (bloomHash >> BLOOM_BUCKET_BITS)] & mask);
}
function shouldSearchParent(flags, isFirstHostTNode) {
	return !(flags & 2) && !(flags & 1 && isFirstHostTNode);
}
function getNodeInjectorLView(nodeInjector) {
	return nodeInjector._lView;
}
function getNodeInjectorTNode(nodeInjector) {
	return nodeInjector._tNode;
}
var NodeInjector = class {
	_tNode;
	_lView;
	constructor(_tNode, _lView) {
		this._tNode = _tNode;
		this._lView = _lView;
	}
	get(token, notFoundValue, flags) {
		return getOrCreateInjectable(this._tNode, this._lView, token, convertToBitFlags(flags), notFoundValue);
	}
};
function createNodeInjector() {
	return new NodeInjector(getCurrentTNode(), getLView());
}
function ɵɵgetInheritedFactory(type) {
	return noSideEffects(() => {
		const ownConstructor = type.prototype.constructor;
		const ownFactory = ownConstructor[NG_FACTORY_DEF] || getFactoryOf(ownConstructor);
		const objectPrototype = Object.prototype;
		let parent = Object.getPrototypeOf(type.prototype).constructor;
		while (parent && parent !== objectPrototype) {
			const factory = parent[NG_FACTORY_DEF] || getFactoryOf(parent);
			if (factory && factory !== ownFactory) return factory;
			parent = Object.getPrototypeOf(parent);
		}
		return (t) => new t();
	});
}
function getFactoryOf(type) {
	if (isForwardRef(type)) return () => {
		const factory = getFactoryOf(resolveForwardRef(type));
		return factory && factory();
	};
	return getFactoryDef(type);
}
function lookupTokenUsingEmbeddedInjector(tNode, lView, token, flags, notFoundValue) {
	let currentTNode = tNode;
	let currentLView = lView;
	while (currentTNode !== null && currentLView !== null && currentLView[2] & 2048 && !isRootView(currentLView)) {
		ngDevMode && assertTNodeForLView(currentTNode, currentLView);
		const nodeInjectorValue = lookupTokenUsingNodeInjector(currentTNode, currentLView, token, flags | 2, NOT_FOUND);
		if (nodeInjectorValue !== NOT_FOUND) return nodeInjectorValue;
		flags &= -5;
		let parentTNode = currentTNode.parent;
		if (!parentTNode) {
			const embeddedViewInjector = currentLView[20];
			if (embeddedViewInjector) {
				const embeddedViewInjectorValue = embeddedViewInjector.get(token, NOT_FOUND, flags);
				if (embeddedViewInjectorValue !== NOT_FOUND) return embeddedViewInjectorValue;
			}
			parentTNode = getTNodeFromLView(currentLView);
			currentLView = currentLView[14];
		}
		currentTNode = parentTNode;
	}
	return notFoundValue;
}
function getTNodeFromLView(lView) {
	const tView = lView[1];
	const tViewType = tView.type;
	if (tViewType === 2) {
		ngDevMode && assertDefined(tView.declTNode, "Embedded TNodes should have declaration parents.");
		return tView.declTNode;
	} else if (tViewType === 1) return lView[5];
	return null;
}
function ɵɵinjectAttribute(attrNameToInject) {
	return injectAttributeImpl(getCurrentTNode(), attrNameToInject);
}
var _requestIdleCallback = () => (typeof requestIdleCallback !== "undefined" ? requestIdleCallback : (cb) => setTimeout(cb)).bind(globalThis);
var _cancelIdleCallback = () => (typeof requestIdleCallback !== "undefined" ? cancelIdleCallback : clearTimeout).bind(globalThis);
var IDLE_SERVICE = new InjectionToken(ngDevMode ? "IDLE_SERVICE" : "", { factory: () => new RequestIdleCallbackService() });
function provideIdleServiceWith(useExisting) {
	return makeEnvironmentProviders([{
		provide: IDLE_SERVICE,
		useExisting
	}]);
}
var RequestIdleCallbackService = class {
	requestIdleCallback = _requestIdleCallback();
	cancelIdleCallback = _cancelIdleCallback();
	requestOnIdle(callback, options) {
		return this.requestIdleCallback(callback, options);
	}
	cancelOnIdle(id) {
		return this.cancelIdleCallback(id);
	}
};
var ANNOTATIONS = "__annotations__";
var PARAMETERS = "__parameters__";
var PROP_METADATA = "__prop__metadata__";
function makeDecorator(name, props, parentClass, additionalProcessing, typeFn) {
	return noSideEffects(() => {
		const metaCtor = makeMetadataCtor(props);
		function DecoratorFactory(...args) {
			if (this instanceof DecoratorFactory) {
				metaCtor.call(this, ...args);
				return this;
			}
			const annotationInstance = new DecoratorFactory(...args);
			return function TypeDecorator(cls) {
				if (typeFn) typeFn(cls, ...args);
				(Object.hasOwn(cls, ANNOTATIONS) ? cls[ANNOTATIONS] : Object.defineProperty(cls, ANNOTATIONS, { value: [] })[ANNOTATIONS]).push(annotationInstance);
				return cls;
			};
		}
		if (parentClass) DecoratorFactory.prototype = Object.create(parentClass.prototype);
		DecoratorFactory.prototype.ngMetadataName = name;
		DecoratorFactory.annotationCls = DecoratorFactory;
		return DecoratorFactory;
	});
}
function makeMetadataCtor(props) {
	return function ctor(...args) {
		if (props) {
			const values = props(...args);
			for (const propName in values) this[propName] = values[propName];
		}
	};
}
function makeParamDecorator(name, props, parentClass) {
	return noSideEffects(() => {
		const metaCtor = makeMetadataCtor(props);
		function ParamDecoratorFactory(...args) {
			if (this instanceof ParamDecoratorFactory) {
				metaCtor.apply(this, args);
				return this;
			}
			const annotationInstance = new ParamDecoratorFactory(...args);
			ParamDecorator.annotation = annotationInstance;
			return ParamDecorator;
			function ParamDecorator(cls, unusedKey, index) {
				const parameters = Object.hasOwn(cls, PARAMETERS) ? cls[PARAMETERS] : Object.defineProperty(cls, PARAMETERS, { value: [] })[PARAMETERS];
				while (parameters.length <= index) parameters.push(null);
				(parameters[index] = parameters[index] || []).push(annotationInstance);
				return cls;
			}
		}
		ParamDecoratorFactory.prototype.ngMetadataName = name;
		ParamDecoratorFactory.annotationCls = ParamDecoratorFactory;
		return ParamDecoratorFactory;
	});
}
function makePropDecorator(name, props, parentClass, additionalProcessing) {
	return noSideEffects(() => {
		const metaCtor = makeMetadataCtor(props);
		function PropDecoratorFactory(...args) {
			if (this instanceof PropDecoratorFactory) {
				metaCtor.apply(this, args);
				return this;
			}
			const decoratorInstance = new PropDecoratorFactory(...args);
			function PropDecorator(target, name) {
				if (target === void 0) throw new Error("Standard Angular field decorators are not supported in JIT mode.");
				const constructor = target.constructor;
				const meta = Object.hasOwn(constructor, PROP_METADATA) ? constructor[PROP_METADATA] : Object.defineProperty(constructor, PROP_METADATA, { value: {} })[PROP_METADATA];
				meta[name] = Object.hasOwn(meta, name) && meta[name] || [];
				meta[name].unshift(decoratorInstance);
			}
			return PropDecorator;
		}
		if (parentClass) PropDecoratorFactory.prototype = Object.create(parentClass.prototype);
		PropDecoratorFactory.prototype.ngMetadataName = name;
		PropDecoratorFactory.annotationCls = PropDecoratorFactory;
		return PropDecoratorFactory;
	});
}
function getCompilerFacade(request) {
	const globalNg = _global["ng"];
	if (globalNg && globalNg.ɵcompilerFacade) return globalNg.ɵcompilerFacade;
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		console.error(`JIT compilation failed for ${request.kind}`, request.type);
		let message = `The ${request.kind} '${request.type.name}' needs to be compiled using the JIT compiler, but '@angular/compiler' is not available.\n\n`;
		if (request.usage === 1) {
			message += `The ${request.kind} is part of a library that has been partially compiled.\n`;
			message += `However, the Angular Linker has not processed the library such that JIT compilation is used as fallback.\n`;
			message += "\n";
			message += `Ideally, the library is processed using the Angular Linker to become fully AOT compiled.\n`;
		} else message += `JIT compilation is discouraged for production use-cases! Consider using AOT mode instead.\n`;
		message += `Alternatively, the JIT compiler should be loaded by bootstrapping using '@angular/platform-browser-dynamic' or '@angular/platform-server',\n`;
		message += `or manually provide the compiler with 'import "@angular/compiler";' before bootstrapping.`;
		throw new Error(message);
	} else throw new Error("JIT compiler unavailable");
}
function ɵɵdefineService(opts) {
	return {
		token: opts.token,
		providedIn: opts.autoProvided === false ? null : "root",
		factory: opts.factory,
		value: void 0
	};
}
var angularCoreDiEnv = {
	"ɵɵdefineInjectable": ɵɵdefineInjectable,
	"ɵɵdefineInjector": ɵɵdefineInjector,
	"ɵɵdefineService": ɵɵdefineService,
	"ɵɵinject": ɵɵinject,
	"ɵɵinvalidFactoryDep": ɵɵinvalidFactoryDep,
	"resolveForwardRef": resolveForwardRef
};
var Type = Function;
function isType(v) {
	return typeof v === "function";
}
var ES5_DELEGATE_CTOR = /^function\s+\S+\(\)\s*{[\s\S]+\.apply\(this,\s*(arguments|(?:[^()]+\(\[\],)?[^()]+\(arguments\).*)\)/;
var ES2015_INHERITED_CLASS = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{/;
var ES2015_INHERITED_CLASS_WITH_CTOR = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(/;
var ES2015_INHERITED_CLASS_WITH_DELEGATE_CTOR = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(\)\s*{[^}]*super\(\.\.\.arguments\)/;
function isDelegateCtor(typeStr) {
	return ES5_DELEGATE_CTOR.test(typeStr) || ES2015_INHERITED_CLASS_WITH_DELEGATE_CTOR.test(typeStr) || ES2015_INHERITED_CLASS.test(typeStr) && !ES2015_INHERITED_CLASS_WITH_CTOR.test(typeStr);
}
var ReflectionCapabilities = class {
	_reflect;
	constructor(reflect) {
		this._reflect = reflect || _global["Reflect"];
	}
	factory(t) {
		return (...args) => new t(...args);
	}
	_zipTypesAndAnnotations(paramTypes, paramAnnotations) {
		let result;
		if (typeof paramTypes === "undefined") result = newArray(paramAnnotations.length);
		else result = newArray(paramTypes.length);
		for (let i = 0; i < result.length; i++) {
			if (typeof paramTypes === "undefined") result[i] = [];
			else if (paramTypes[i] && paramTypes[i] != Object) result[i] = [paramTypes[i]];
			else result[i] = [];
			if (paramAnnotations && paramAnnotations[i] != null) result[i] = result[i].concat(paramAnnotations[i]);
		}
		return result;
	}
	_ownParameters(type, parentCtor) {
		if (isDelegateCtor(type.toString())) return null;
		if (type.parameters && type.parameters !== parentCtor.parameters) return type.parameters;
		const tsickleCtorParams = type.ctorParameters;
		if (tsickleCtorParams && tsickleCtorParams !== parentCtor.ctorParameters) {
			const ctorParameters = typeof tsickleCtorParams === "function" ? tsickleCtorParams() : tsickleCtorParams;
			const paramTypes = ctorParameters.map((ctorParam) => ctorParam && ctorParam.type);
			const paramAnnotations = ctorParameters.map((ctorParam) => ctorParam && convertTsickleDecoratorIntoMetadata(ctorParam.decorators));
			return this._zipTypesAndAnnotations(paramTypes, paramAnnotations);
		}
		const paramAnnotations = Object.hasOwn(type, PARAMETERS) && type[PARAMETERS];
		const paramTypes = this._reflect && this._reflect.getOwnMetadata && this._reflect.getOwnMetadata("design:paramtypes", type);
		if (paramTypes || paramAnnotations) return this._zipTypesAndAnnotations(paramTypes, paramAnnotations);
		return newArray(type.length);
	}
	parameters(type) {
		if (!isType(type)) return [];
		const parentCtor = getParentCtor(type);
		let parameters = this._ownParameters(type, parentCtor);
		if (!parameters && parentCtor !== Object) parameters = this.parameters(parentCtor);
		return parameters || [];
	}
	_ownAnnotations(typeOrFunc, parentCtor) {
		if (typeOrFunc.annotations && typeOrFunc.annotations !== parentCtor.annotations) {
			let annotations = typeOrFunc.annotations;
			if (typeof annotations === "function" && annotations.annotations) annotations = annotations.annotations;
			return annotations;
		}
		if (typeOrFunc.decorators && typeOrFunc.decorators !== parentCtor.decorators) return convertTsickleDecoratorIntoMetadata(typeOrFunc.decorators);
		if (Object.hasOwn(typeOrFunc, ANNOTATIONS)) return typeOrFunc[ANNOTATIONS];
		return null;
	}
	annotations(typeOrFunc) {
		if (!isType(typeOrFunc)) return [];
		const parentCtor = getParentCtor(typeOrFunc);
		const ownAnnotations = this._ownAnnotations(typeOrFunc, parentCtor) || [];
		return (parentCtor !== Object ? this.annotations(parentCtor) : []).concat(ownAnnotations);
	}
	_ownPropMetadata(typeOrFunc, parentCtor) {
		if (typeOrFunc.propMetadata && typeOrFunc.propMetadata !== parentCtor.propMetadata) {
			let propMetadata = typeOrFunc.propMetadata;
			if (typeof propMetadata === "function" && propMetadata.propMetadata) propMetadata = propMetadata.propMetadata;
			return propMetadata;
		}
		if (typeOrFunc.propDecorators && typeOrFunc.propDecorators !== parentCtor.propDecorators) {
			const propDecorators = typeOrFunc.propDecorators;
			const propMetadata = {};
			Object.keys(propDecorators).forEach((prop) => {
				propMetadata[prop] = convertTsickleDecoratorIntoMetadata(propDecorators[prop]);
			});
			return propMetadata;
		}
		if (Object.hasOwn(typeOrFunc, PROP_METADATA)) return typeOrFunc[PROP_METADATA];
		return null;
	}
	propMetadata(typeOrFunc) {
		if (!isType(typeOrFunc)) return {};
		const parentCtor = getParentCtor(typeOrFunc);
		const propMetadata = {};
		if (parentCtor !== Object) {
			const parentPropMetadata = this.propMetadata(parentCtor);
			Object.keys(parentPropMetadata).forEach((propName) => {
				propMetadata[propName] = parentPropMetadata[propName];
			});
		}
		const ownPropMetadata = this._ownPropMetadata(typeOrFunc, parentCtor);
		if (ownPropMetadata) Object.keys(ownPropMetadata).forEach((propName) => {
			const decorators = [];
			if (Object.hasOwn(propMetadata, propName)) decorators.push(...propMetadata[propName]);
			decorators.push(...ownPropMetadata[propName]);
			propMetadata[propName] = decorators;
		});
		return propMetadata;
	}
	ownPropMetadata(typeOrFunc) {
		if (!isType(typeOrFunc)) return {};
		return this._ownPropMetadata(typeOrFunc, getParentCtor(typeOrFunc)) || {};
	}
	hasLifecycleHook(type, lcProperty) {
		return type instanceof Type && lcProperty in type.prototype;
	}
};
function convertTsickleDecoratorIntoMetadata(decoratorInvocations) {
	if (!decoratorInvocations) return [];
	return decoratorInvocations.map((decoratorInvocation) => {
		const annotationCls = decoratorInvocation.type.annotationCls;
		return new annotationCls(...decoratorInvocation.args ? decoratorInvocation.args : []);
	});
}
function getParentCtor(ctor) {
	const parentProto = ctor.prototype ? Object.getPrototypeOf(ctor.prototype) : null;
	return (parentProto ? parentProto.constructor : null) || Object;
}
var Inject = attachInjectFlag(makeParamDecorator("Inject", (token) => ({ token })), -1);
var Optional = attachInjectFlag(makeParamDecorator("Optional"), 8);
var Self = attachInjectFlag(makeParamDecorator("Self"), 2);
var SkipSelf = attachInjectFlag(makeParamDecorator("SkipSelf"), 4);
var Host = attachInjectFlag(makeParamDecorator("Host"), 1);
var Attribute = makeParamDecorator("Attribute", (attributeName) => ({
	attributeName,
	__NG_ELEMENT_ID__: () => ɵɵinjectAttribute(attributeName)
}));
var _reflect = null;
function getReflect() {
	return _reflect = _reflect || new ReflectionCapabilities();
}
function reflectDependencies(type) {
	return convertDependencies(getReflect().parameters(type));
}
function convertDependencies(deps) {
	return deps.map((dep) => reflectDependency(dep));
}
function reflectDependency(dep) {
	const meta = {
		token: null,
		attribute: null,
		host: false,
		optional: false,
		self: false,
		skipSelf: false
	};
	if (Array.isArray(dep) && dep.length > 0) for (let j = 0; j < dep.length; j++) {
		const param = dep[j];
		if (param === void 0) continue;
		const proto = Object.getPrototypeOf(param);
		if (param instanceof Optional || proto.ngMetadataName === "Optional") meta.optional = true;
		else if (param instanceof SkipSelf || proto.ngMetadataName === "SkipSelf") meta.skipSelf = true;
		else if (param instanceof Self || proto.ngMetadataName === "Self") meta.self = true;
		else if (param instanceof Host || proto.ngMetadataName === "Host") meta.host = true;
		else if (param instanceof Inject) meta.token = param.token;
		else if (param instanceof Attribute) {
			if (param.attributeName === void 0) throw new RuntimeError(-204, ngDevMode && `Attribute name must be defined.`);
			meta.attribute = param.attributeName;
		} else meta.token = param;
	}
	else if (dep === void 0 || Array.isArray(dep) && dep.length === 0) meta.token = null;
	else meta.token = dep;
	return meta;
}
function compileInjectable(type, meta) {
	let ngInjectableDef = null;
	let ngFactoryDef = null;
	if (!Object.hasOwn(type, NG_PROV_DEF)) Object.defineProperty(type, NG_PROV_DEF, { get: () => {
		if (ngInjectableDef === null) ngInjectableDef = getCompilerFacade({
			usage: 0,
			kind: "injectable",
			type
		}).compileInjectable(angularCoreDiEnv, `ng:///${type.name}/ɵprov.js`, getInjectableMetadata(type, meta));
		return ngInjectableDef;
	} });
	if (!Object.hasOwn(type, NG_FACTORY_DEF)) Object.defineProperty(type, NG_FACTORY_DEF, {
		get: () => {
			if (ngFactoryDef === null) {
				const compiler = getCompilerFacade({
					usage: 0,
					kind: "injectable",
					type
				});
				ngFactoryDef = compiler.compileFactory(angularCoreDiEnv, `ng:///${type.name}/ɵfac.js`, {
					name: type.name,
					type,
					typeArgumentCount: 0,
					deps: reflectDependencies(type),
					target: compiler.FactoryTarget.Injectable
				});
			}
			return ngFactoryDef;
		},
		configurable: true
	});
}
var USE_VALUE = getClosureSafeProperty({
	provide: String,
	useValue: getClosureSafeProperty
});
function isUseClassProvider(meta) {
	return meta.useClass !== void 0;
}
function isUseValueProvider(meta) {
	return USE_VALUE in meta;
}
function isUseFactoryProvider(meta) {
	return meta.useFactory !== void 0;
}
function isUseExistingProvider(meta) {
	return meta.useExisting !== void 0;
}
function getInjectableMetadata(type, srcMeta) {
	const meta = srcMeta || { providedIn: null };
	const compilerMeta = {
		name: type.name,
		type,
		typeArgumentCount: 0,
		providedIn: meta.providedIn
	};
	if ((isUseClassProvider(meta) || isUseFactoryProvider(meta)) && meta.deps !== void 0) compilerMeta.deps = convertDependencies(meta.deps);
	if (isUseClassProvider(meta)) compilerMeta.useClass = meta.useClass;
	else if (isUseValueProvider(meta)) compilerMeta.useValue = meta.useValue;
	else if (isUseFactoryProvider(meta)) compilerMeta.useFactory = meta.useFactory;
	else if (isUseExistingProvider(meta)) compilerMeta.useExisting = meta.useExisting;
	return compilerMeta;
}
var Injectable = makeDecorator("Injectable", void 0, void 0, void 0, (type, meta) => compileInjectable(type, meta));
function compileService(type, meta) {
	let def = null;
	let factoryDef = null;
	if (!Object.hasOwn(type, NG_PROV_DEF)) Object.defineProperty(type, NG_PROV_DEF, { get: () => {
		if (def === null) def = getCompilerFacade({
			usage: 0,
			kind: "service",
			type
		}).compileService(angularCoreDiEnv, `ng:///${type.name}/ɵprov.js`, getServiceMetadata(type, meta));
		return def;
	} });
	if (!Object.hasOwn(type, NG_FACTORY_DEF)) Object.defineProperty(type, NG_FACTORY_DEF, {
		get: () => {
			if (factoryDef === null) {
				const compiler = getCompilerFacade({
					usage: 0,
					kind: "service",
					type
				});
				factoryDef = compiler.compileFactory(angularCoreDiEnv, `ng:///${type.name}/ɵfac.js`, {
					name: type.name,
					type,
					typeArgumentCount: 0,
					deps: reflectDependencies(type),
					target: compiler.FactoryTarget.Service
				});
			}
			return factoryDef;
		},
		configurable: true
	});
}
function getServiceMetadata(type, srcMeta) {
	return {
		name: type.name,
		type,
		typeArgumentCount: 0,
		autoProvided: srcMeta?.autoProvided,
		factory: srcMeta?.factory
	};
}
var Service = makeDecorator("Service", void 0, void 0, void 0, (type, meta) => compileService(type, meta));
function injectElementRef() {
	return createElementRef(getCurrentTNode(), getLView());
}
function createElementRef(tNode, lView) {
	return new ElementRef(getNativeByTNode(tNode, lView));
}
var ElementRef = class {
	nativeElement;
	constructor(nativeElement) {
		this.nativeElement = nativeElement;
	}
	static __NG_ELEMENT_ID__ = injectElementRef;
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(ElementRef);
function unwrapElementRef(value) {
	return value instanceof ElementRef ? value.nativeElement : value;
}
function symbolIterator() {
	return this._results[Symbol.iterator]();
}
var QueryList = class {
	_emitDistinctChangesOnly;
	dirty = true;
	_onDirty = void 0;
	_results = [];
	_changesDetected = false;
	_changes = void 0;
	length = 0;
	first = void 0;
	last = void 0;
	get changes() {
		return this._changes ??= new import_cjs.Subject();
	}
	constructor(_emitDistinctChangesOnly = false) {
		this._emitDistinctChangesOnly = _emitDistinctChangesOnly;
	}
	get(index) {
		return this._results[index];
	}
	map(fn) {
		return this._results.map(fn);
	}
	filter(fn) {
		return this._results.filter(fn);
	}
	find(fn) {
		return this._results.find(fn);
	}
	reduce(fn, init) {
		return this._results.reduce(fn, init);
	}
	forEach(fn) {
		this._results.forEach(fn);
	}
	some(fn) {
		return this._results.some(fn);
	}
	toArray() {
		return this._results.slice();
	}
	toString() {
		return this._results.toString();
	}
	reset(resultsTree, identityAccessor) {
		this.dirty = false;
		const newResultFlat = flatten(resultsTree);
		if (this._changesDetected = !arrayEquals(this._results, newResultFlat, identityAccessor)) {
			this._results = newResultFlat;
			this.length = newResultFlat.length;
			this.last = newResultFlat[this.length - 1];
			this.first = newResultFlat[0];
		}
	}
	notifyOnChanges() {
		if (this._changes !== void 0 && (this._changesDetected || !this._emitDistinctChangesOnly)) this._changes.next(this);
	}
	onDirty(cb) {
		this._onDirty = cb;
	}
	setDirty() {
		this.dirty = true;
		this._onDirty?.();
	}
	destroy() {
		if (this._changes !== void 0) {
			this._changes.complete();
			this._changes.unsubscribe();
		}
	}
	[Symbol.iterator] = (() => symbolIterator)();
};
var SKIP_HYDRATION_ATTR_NAME = "ngSkipHydration";
var SKIP_HYDRATION_ATTR_NAME_LOWER_CASE = "ngskiphydration";
function hasSkipHydrationAttrOnTNode(tNode) {
	const attrs = tNode.mergedAttrs;
	if (attrs === null) return false;
	for (let i = 0; i < attrs.length; i += 2) {
		const value = attrs[i];
		if (typeof value === "number") return false;
		if (typeof value === "string" && value.toLowerCase() === SKIP_HYDRATION_ATTR_NAME_LOWER_CASE) return true;
	}
	return false;
}
function hasInSkipHydrationBlockFlag(tNode) {
	return (tNode.flags & 128) === 128;
}
function isInSkipHydrationBlock(tNode) {
	if (hasInSkipHydrationBlockFlag(tNode)) return true;
	let currentTNode = tNode.parent;
	while (currentTNode) {
		if (hasInSkipHydrationBlockFlag(tNode) || hasSkipHydrationAttrOnTNode(currentTNode)) return true;
		currentTNode = currentTNode.parent;
	}
	return false;
}
function isI18nInSkipHydrationBlock(parentTNode) {
	return hasInSkipHydrationBlockFlag(parentTNode) || hasSkipHydrationAttrOnTNode(parentTNode) || isInSkipHydrationBlock(parentTNode);
}
var ChangeDetectionStrategy;
(function(ChangeDetectionStrategy) {
	ChangeDetectionStrategy[ChangeDetectionStrategy["OnPush"] = 0] = "OnPush";
	ChangeDetectionStrategy[ChangeDetectionStrategy["Eager"] = 1] = "Eager";
	ChangeDetectionStrategy[ChangeDetectionStrategy["Default"] = 1] = "Default";
})(ChangeDetectionStrategy || (ChangeDetectionStrategy = {}));
var TRACKED_LVIEWS = /* @__PURE__ */ new Map();
var uniqueIdCounter = 0;
function getUniqueLViewId() {
	return uniqueIdCounter++;
}
function registerLView(lView) {
	ngDevMode && assertNumber(lView[19], "LView must have an ID in order to be registered");
	TRACKED_LVIEWS.set(lView[19], lView);
}
function getLViewById(id) {
	ngDevMode && assertNumber(id, "ID used for LView lookup must be a number");
	return TRACKED_LVIEWS.get(id) || null;
}
function unregisterLView(lView) {
	ngDevMode && assertNumber(lView[19], "Cannot stop tracking an LView that does not have an ID");
	TRACKED_LVIEWS.delete(lView[19]);
}
function getTrackedLViews() {
	return TRACKED_LVIEWS;
}
var LContext = class {
	lViewId;
	nodeIndex;
	native;
	component;
	directives;
	localRefs;
	get lView() {
		return getLViewById(this.lViewId);
	}
	constructor(lViewId, nodeIndex, native) {
		this.lViewId = lViewId;
		this.nodeIndex = nodeIndex;
		this.native = native;
	}
};
function getLContext(target) {
	let mpValue = readPatchedData(target);
	if (mpValue) {
		if (isLView(mpValue)) {
			const lView = mpValue;
			let nodeIndex;
			let component = void 0;
			let directives = void 0;
			if (isComponentInstance(target)) {
				nodeIndex = findViaComponent(lView, target);
				if (nodeIndex == -1) throw new Error("The provided component was not found in the application");
				component = target;
			} else if (isDirectiveInstance(target)) {
				nodeIndex = findViaDirective(lView, target);
				if (nodeIndex == -1) throw new Error("The provided directive was not found in the application");
				directives = getDirectivesAtNodeIndex(nodeIndex, lView);
			} else {
				nodeIndex = findViaNativeElement(lView, target);
				if (nodeIndex == -1) return null;
			}
			const native = unwrapRNode(lView[nodeIndex]);
			const existingCtx = readPatchedData(native);
			const context = existingCtx && !Array.isArray(existingCtx) ? existingCtx : createLContext(lView, nodeIndex, native);
			if (component && context.component === void 0) {
				context.component = component;
				attachPatchData(context.component, context);
			}
			if (directives && context.directives === void 0) {
				context.directives = directives;
				for (let i = 0; i < directives.length; i++) attachPatchData(directives[i], context);
			}
			attachPatchData(context.native, context);
			mpValue = context;
		}
	} else {
		const rElement = target;
		ngDevMode && assertDomNode(rElement);
		let parent = rElement;
		while (parent = parent.parentNode) {
			const parentContext = readPatchedData(parent);
			if (parentContext) {
				const lView = Array.isArray(parentContext) ? parentContext : parentContext.lView;
				if (!lView) return null;
				const index = findViaNativeElement(lView, rElement);
				if (index >= 0) {
					const native = unwrapRNode(lView[index]);
					const context = createLContext(lView, index, native);
					attachPatchData(native, context);
					mpValue = context;
					break;
				}
			}
		}
	}
	return mpValue || null;
}
function createLContext(lView, nodeIndex, native) {
	return new LContext(lView[19], nodeIndex, native);
}
function getComponentViewByInstance(componentInstance) {
	let patchedData = readPatchedData(componentInstance);
	let lView;
	if (isLView(patchedData)) {
		const contextLView = patchedData;
		const nodeIndex = findViaComponent(contextLView, componentInstance);
		lView = getComponentLViewByIndex(nodeIndex, contextLView);
		const context = createLContext(contextLView, nodeIndex, lView[0]);
		context.component = componentInstance;
		attachPatchData(componentInstance, context);
		attachPatchData(context.native, context);
	} else {
		const context = patchedData;
		const contextLView = context.lView;
		ngDevMode && assertLView(contextLView);
		lView = getComponentLViewByIndex(context.nodeIndex, contextLView);
	}
	return lView;
}
var MONKEY_PATCH_KEY_NAME = "__ngContext__";
function attachPatchData(target, data) {
	ngDevMode && assertDefined(target, "Target expected");
	if (isLView(data)) {
		target[MONKEY_PATCH_KEY_NAME] = data[19];
		registerLView(data);
	} else target[MONKEY_PATCH_KEY_NAME] = data;
}
function readPatchedData(target) {
	ngDevMode && assertDefined(target, "Target expected");
	const data = target[MONKEY_PATCH_KEY_NAME];
	return typeof data === "number" ? getLViewById(data) : data || null;
}
function readPatchedLView(target) {
	const value = readPatchedData(target);
	if (value) return isLView(value) ? value : value.lView;
	return null;
}
function isComponentInstance(instance) {
	return instance && instance.constructor && instance.constructor.ɵcmp;
}
function isDirectiveInstance(instance) {
	return instance && instance.constructor && instance.constructor.ɵdir;
}
function findViaNativeElement(lView, target) {
	const tView = lView[1];
	for (let i = 28; i < tView.bindingStartIndex; i++) if (unwrapRNode(lView[i]) === target) return i;
	return -1;
}
function traverseNextElement(tNode) {
	if (tNode.child) return tNode.child;
	else if (tNode.next) return tNode.next;
	else {
		while (tNode.parent && !tNode.parent.next) tNode = tNode.parent;
		return tNode.parent && tNode.parent.next;
	}
}
function findViaComponent(lView, componentInstance) {
	const componentIndices = lView[1].components;
	if (componentIndices) for (let i = 0; i < componentIndices.length; i++) {
		const elementComponentIndex = componentIndices[i];
		if (getComponentLViewByIndex(elementComponentIndex, lView)[8] === componentInstance) return elementComponentIndex;
	}
	else if (getComponentLViewByIndex(28, lView)[8] === componentInstance) return 28;
	return -1;
}
function findViaDirective(lView, directiveInstance) {
	let tNode = lView[1].firstChild;
	while (tNode) {
		const directiveIndexStart = tNode.directiveStart;
		const directiveIndexEnd = tNode.directiveEnd;
		for (let i = directiveIndexStart; i < directiveIndexEnd; i++) if (lView[i] === directiveInstance) return tNode.index;
		tNode = traverseNextElement(tNode);
	}
	return -1;
}
function getDirectivesAtNodeIndex(nodeIndex, lView) {
	const tNode = lView[1].data[nodeIndex];
	if (tNode.directiveStart === 0) return EMPTY_ARRAY;
	const results = [];
	for (let i = tNode.directiveStart; i < tNode.directiveEnd; i++) {
		const directiveInstance = lView[i];
		if (!isComponentInstance(directiveInstance)) results.push(directiveInstance);
	}
	return results;
}
function getComponentAtNodeIndex(nodeIndex, lView) {
	const tNode = lView[1].data[nodeIndex];
	return isComponentHost(tNode) ? lView[tNode.directiveStart + tNode.componentOffset] : null;
}
function discoverLocalRefs(lView, nodeIndex) {
	const tNode = lView[1].data[nodeIndex];
	if (tNode && tNode.localNames) {
		const result = {};
		let localIndex = tNode.index + 1;
		for (let i = 0; i < tNode.localNames.length; i += 2) {
			result[tNode.localNames[i]] = lView[localIndex];
			localIndex++;
		}
		return result;
	}
	return null;
}
function getRootView(componentOrLView) {
	ngDevMode && assertDefined(componentOrLView, "component");
	let lView = isLView(componentOrLView) ? componentOrLView : readPatchedLView(componentOrLView);
	while (lView && !isRootView(lView)) lView = getLViewParent(lView);
	ngDevMode && assertLView(lView);
	return lView;
}
function getRootContext(viewOrComponent) {
	const rootView = getRootView(viewOrComponent);
	ngDevMode && assertDefined(rootView[8], "Root view has no context. Perhaps it is disconnected?");
	return rootView[8];
}
function getFirstLContainer(lView) {
	return getNearestLContainer(lView[12]);
}
function getNextLContainer(container) {
	return getNearestLContainer(container[4]);
}
function getNearestLContainer(viewOrContainer) {
	while (viewOrContainer !== null && !isLContainer(viewOrContainer)) viewOrContainer = viewOrContainer[4];
	return viewOrContainer;
}
function* walkLViewChildren(tNode, lView) {
	let child = tNode.child;
	while (child) {
		yield [child, lView];
		child = child.next;
	}
	if (tNode.componentOffset > -1) {
		const componentLView = getComponentLViewByIndex(tNode.index, lView);
		if (isLView(componentLView)) {
			let componentChild = componentLView[1].firstChild;
			while (componentChild) {
				yield [componentChild, componentLView];
				componentChild = componentChild.next;
			}
		}
	}
	const slot = lView[tNode.index];
	if (isLContainer(slot)) for (let i = 10; i < slot.length; i++) {
		const embeddedLView = slot[i];
		let embeddedChild = embeddedLView[1].firstChild;
		while (embeddedChild) {
			yield [embeddedChild, embeddedLView];
			embeddedChild = embeddedChild.next;
		}
	}
}
function* walkLViewDescendants(lView) {
	let child = lView[1].firstChild;
	while (child) {
		yield* walkTNodeDescendants(child, lView);
		child = child.next;
	}
}
function* walkTNodeDescendants(tNode, lView) {
	yield [tNode, lView];
	for (const [childTNode, childLView] of walkLViewChildren(tNode, lView)) yield* walkTNodeDescendants(childTNode, childLView);
}
function* walkLViewDirectives(lView) {
	for (const [tNode, currentLView] of walkLViewDescendants(lView)) if (tNode.directiveEnd > tNode.directiveStart) yield [tNode, currentLView];
}
function getComponent(element) {
	ngDevMode && assertDomElement(element);
	const context = getLContext(element);
	if (context === null) return null;
	if (context.component === void 0) {
		const lView = context.lView;
		if (lView === null) return null;
		context.component = getComponentAtNodeIndex(context.nodeIndex, lView);
	}
	return context.component;
}
function getContext(element) {
	assertDomElement(element);
	const context = getLContext(element);
	const lView = context ? context.lView : null;
	return lView === null ? null : lView[8];
}
function getOwningComponent(elementOrDir) {
	const context = getLContext(elementOrDir);
	let lView = context ? context.lView : null;
	if (lView === null) return null;
	let parent;
	while (lView[1].type === 2 && (parent = getLViewParent(lView))) lView = parent;
	return isRootView(lView) ? null : lView[8];
}
function getRootComponents(elementOrDir) {
	const lView = readPatchedLView(elementOrDir);
	return lView !== null ? [getRootContext(lView)] : [];
}
function getInjector(elementOrDir) {
	const context = getLContext(elementOrDir);
	const lView = context ? context.lView : null;
	if (lView === null) return Injector.NULL;
	const tNode = lView[1].data[context.nodeIndex];
	return new NodeInjector(tNode, lView);
}
function getInjectionTokens(element) {
	const context = getLContext(element);
	const lView = context ? context.lView : null;
	if (lView === null) return [];
	const tView = lView[1];
	const tNode = tView.data[context.nodeIndex];
	const providerTokens = [];
	const startIndex = tNode.providerIndexes & 1048575;
	const endIndex = tNode.directiveEnd;
	for (let i = startIndex; i < endIndex; i++) {
		let value = tView.data[i];
		if (isDirectiveDefHack(value)) value = value.type;
		providerTokens.push(value);
	}
	return providerTokens;
}
function getDirectives(node) {
	if (node instanceof Text) return [];
	const context = getLContext(node);
	const lView = context ? context.lView : null;
	if (lView === null) return [];
	const tView = lView[1];
	const nodeIndex = context.nodeIndex;
	if (!tView?.data[nodeIndex]) return [];
	if (context.directives === void 0) context.directives = getDirectivesAtNodeIndex(nodeIndex, lView);
	return context.directives === null ? [] : [...context.directives];
}
var AcxChangeDetectionStrategy;
(function(AcxChangeDetectionStrategy) {
	AcxChangeDetectionStrategy[AcxChangeDetectionStrategy["Default"] = 0] = "Default";
	AcxChangeDetectionStrategy[AcxChangeDetectionStrategy["OnPush"] = 1] = "OnPush";
})(AcxChangeDetectionStrategy || (AcxChangeDetectionStrategy = {}));
var AcxViewEncapsulation;
(function(AcxViewEncapsulation) {
	AcxViewEncapsulation[AcxViewEncapsulation["Emulated"] = 0] = "Emulated";
	AcxViewEncapsulation[AcxViewEncapsulation["None"] = 1] = "None";
})(AcxViewEncapsulation || (AcxViewEncapsulation = {}));
function getDirectiveMetadata$1(directiveOrComponentInstance) {
	if (!directiveOrComponentInstance) return null;
	const { constructor } = directiveOrComponentInstance;
	if (!constructor) throw new Error("Unable to find the instance constructor");
	const componentDef = getComponentDef(constructor);
	if (componentDef) return {
		inputs: extractInputDebugMetadata(componentDef.inputs),
		outputs: componentDef.outputs,
		encapsulation: componentDef.encapsulation,
		changeDetection: componentDef.onPush ? ChangeDetectionStrategy.OnPush : ChangeDetectionStrategy.Eager
	};
	const directiveDef = getDirectiveDef(constructor);
	if (directiveDef) return {
		inputs: extractInputDebugMetadata(directiveDef.inputs),
		outputs: directiveDef.outputs
	};
	return null;
}
function getLocalRefs(target) {
	const context = getLContext(target);
	if (context === null) return {};
	if (context.localRefs === void 0) {
		const lView = context.lView;
		if (lView === null) return {};
		context.localRefs = discoverLocalRefs(lView, context.nodeIndex);
	}
	return context.localRefs || {};
}
function getHostElement(componentOrDirective) {
	return getLContext(componentOrDirective).native;
}
function getListeners(element) {
	ngDevMode && assertDomElement(element);
	const lContext = getLContext(element);
	const lView = lContext === null ? null : lContext.lView;
	if (lView === null) return [];
	const tView = lView[1];
	const lCleanup = lView[7];
	const tCleanup = tView.cleanup;
	const listeners = [];
	if (tCleanup && lCleanup) for (let i = 0; i < tCleanup.length;) {
		const firstParam = tCleanup[i++];
		const secondParam = tCleanup[i++];
		if (typeof firstParam === "string") {
			const name = firstParam;
			const listenerElement = unwrapRNode(lView[secondParam]);
			const callback = lCleanup[tCleanup[i++]];
			const useCaptureOrIndx = tCleanup[i++];
			const type = typeof useCaptureOrIndx === "boolean" || useCaptureOrIndx >= 0 ? "dom" : "output";
			const useCapture = typeof useCaptureOrIndx === "boolean" ? useCaptureOrIndx : false;
			if (element == listenerElement) listeners.push({
				element,
				name,
				callback,
				useCapture,
				type
			});
		}
	}
	listeners.sort(sortListeners);
	return listeners;
}
function sortListeners(a, b) {
	if (a.name == b.name) return 0;
	return a.name < b.name ? -1 : 1;
}
function isDirectiveDefHack(obj) {
	return obj.type !== void 0 && obj.declaredInputs !== void 0 && obj.resolveHostDirectives !== void 0;
}
function assertDomElement(value) {
	if (typeof Element !== "undefined" && !(value instanceof Element)) throw new Error("Expecting instance of DOM Element");
}
function extractInputDebugMetadata(inputs) {
	const res = {};
	for (const key in inputs) if (Object.hasOwn(inputs, key)) {
		const value = inputs[key];
		if (value !== void 0) res[key] = value[0];
	}
	return res;
}
var DOCUMENT = void 0;
function setDocument(document) {
	DOCUMENT = document;
}
function getDocument() {
	if (DOCUMENT !== void 0) return DOCUMENT;
	else if (typeof document !== "undefined") return document;
	throw new RuntimeError(210, (typeof ngDevMode === "undefined" || ngDevMode) && `The document object is not available in this context. Make sure the DOCUMENT injection token is provided.`);
}
var REFERENCE_NODE_HOST = "h";
var REFERENCE_NODE_BODY = "b";
var NODE_NAVIGATION_STEP_FIRST_CHILD = "f";
var NODE_NAVIGATION_STEP_NEXT_SIBLING = "n";
var IS_HYDRATION_DOM_REUSE_ENABLED = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "IS_HYDRATION_DOM_REUSE_ENABLED" : "");
var PRESERVE_HOST_CONTENT_DEFAULT = false;
var PRESERVE_HOST_CONTENT = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "PRESERVE_HOST_CONTENT" : "", { factory: () => PRESERVE_HOST_CONTENT_DEFAULT });
var IS_I18N_HYDRATION_ENABLED = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "IS_I18N_HYDRATION_ENABLED" : "");
var IS_EVENT_REPLAY_ENABLED = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "IS_EVENT_REPLAY_ENABLED" : "");
var EVENT_REPLAY_QUEUE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "EVENT_REPLAY_QUEUE" : "", { factory: () => [] });
var IS_INCREMENTAL_HYDRATION_ENABLED = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "IS_INCREMENTAL_HYDRATION_ENABLED" : "");
var JSACTION_BLOCK_ELEMENT_MAP = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "JSACTION_BLOCK_ELEMENT_MAP" : "", { factory: () => /* @__PURE__ */ new Map() });
var IS_ENABLED_BLOCKING_INITIAL_NAVIGATION = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "IS_ENABLED_BLOCKING_INITIAL_NAVIGATION" : "");
var eventListenerOptions = {
	passive: true,
	capture: true
};
var hoverTriggers = /* @__PURE__ */ new WeakMap();
var interactionTriggers = /* @__PURE__ */ new WeakMap();
var viewportTriggers = /* @__PURE__ */ new WeakMap();
var interactionEventNames = ["click", "keydown"];
var hoverEventNames = [
	"mouseenter",
	"mouseover",
	"focusin"
];
var intersectionObservers = /* @__PURE__ */ new Map();
var DeferEventEntry = class {
	callbacks = /* @__PURE__ */ new Set();
	listener = () => {
		for (const callback of this.callbacks) callback();
	};
};
function onInteraction(trigger, callback) {
	let entry = interactionTriggers.get(trigger);
	if (!entry) {
		entry = new DeferEventEntry();
		interactionTriggers.set(trigger, entry);
		for (const name of interactionEventNames) trigger.addEventListener(name, entry.listener, eventListenerOptions);
	}
	entry.callbacks.add(callback);
	return () => {
		const { callbacks, listener } = entry;
		callbacks.delete(callback);
		if (callbacks.size === 0) {
			interactionTriggers.delete(trigger);
			for (const name of interactionEventNames) trigger.removeEventListener(name, listener, eventListenerOptions);
		}
	};
}
function onHover(trigger, callback) {
	let entry = hoverTriggers.get(trigger);
	if (!entry) {
		entry = new DeferEventEntry();
		hoverTriggers.set(trigger, entry);
		for (const name of hoverEventNames) trigger.addEventListener(name, entry.listener, eventListenerOptions);
	}
	entry.callbacks.add(callback);
	return () => {
		const { callbacks, listener } = entry;
		callbacks.delete(callback);
		if (callbacks.size === 0) {
			for (const name of hoverEventNames) trigger.removeEventListener(name, listener, eventListenerOptions);
			hoverTriggers.delete(trigger);
		}
	};
}
function createIntersectionObserver(options) {
	const key = getIntersectionObserverKey(options);
	return new IntersectionObserver((entries) => {
		for (const current of entries) if (current.isIntersecting && viewportTriggers.has(current.target)) viewportTriggers.get(current.target)?.get(key)?.listener();
	}, options);
}
function onViewport(trigger, callback, observerFactoryFn, options) {
	const key = getIntersectionObserverKey(options);
	let entry = viewportTriggers.get(trigger)?.get(key);
	if (!intersectionObservers.has(key)) intersectionObservers.set(key, {
		observer: observerFactoryFn(options),
		count: 0
	});
	const config = intersectionObservers.get(key);
	if (!entry) {
		entry = new DeferEventEntry();
		config.observer.observe(trigger);
		let triggerConfig = viewportTriggers.get(trigger);
		if (triggerConfig) triggerConfig.set(key, entry);
		else {
			triggerConfig = /* @__PURE__ */ new Map();
			viewportTriggers.set(trigger, triggerConfig);
		}
		triggerConfig.set(key, entry);
		config.count++;
	}
	entry.callbacks.add(callback);
	return () => {
		if (!viewportTriggers.get(trigger)?.has(key)) return;
		entry.callbacks.delete(callback);
		if (entry.callbacks.size === 0) {
			config.observer.unobserve(trigger);
			config.count--;
			const triggerConfig = viewportTriggers.get(trigger);
			if (triggerConfig) {
				triggerConfig.delete(key);
				if (triggerConfig.size === 0) viewportTriggers.delete(trigger);
			}
		}
		if (config.count === 0) {
			config.observer.disconnect();
			intersectionObservers.delete(key);
		}
	};
}
function getIntersectionObserverKey(options) {
	if (!options) return "";
	return `${options.rootMargin}/${typeof options.threshold === "number" ? options.threshold : options.threshold?.join("\n")}`;
}
function setJSActionAttributes(nativeElement, eventTypes, parentDeferBlockId = null) {
	if (eventTypes.length === 0 || nativeElement.nodeType !== Node.ELEMENT_NODE) return;
	const existingAttr = nativeElement.getAttribute(Attribute$1.JSACTION);
	const parts = eventTypes.reduce((prev, curr) => {
		return (existingAttr?.indexOf(curr) ?? -1) === -1 ? prev + curr + ":;" : prev;
	}, "");
	nativeElement.setAttribute(Attribute$1.JSACTION, `${existingAttr ?? ""}${parts}`);
	const blockName = parentDeferBlockId ?? "";
	if (blockName !== "" && parts.length > 0) nativeElement.setAttribute("ngb", blockName);
}
function removeListenersFromBlocks(blockNames, jsActionMap) {
	if (blockNames.length > 0) {
		let blockList = [];
		for (let blockName of blockNames) if (jsActionMap.has(blockName)) blockList = [...blockList, ...jsActionMap.get(blockName)];
		new Set(blockList).forEach(removeListeners);
	}
}
var removeListeners = (el) => {
	el.removeAttribute(Attribute$1.JSACTION);
	el.removeAttribute("ngb");
	el.__jsaction_fns = void 0;
};
var JSACTION_EVENT_CONTRACT = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "EVENT_CONTRACT_DETAILS" : "", { factory: () => ({}) });
var handledEventElements = /* @__PURE__ */ new WeakMap();
function markEventHandledForElement(event, element) {
	if (event == null || typeof event !== "object") return;
	let elements = handledEventElements.get(event);
	if (!elements) {
		elements = /* @__PURE__ */ new WeakSet();
		handledEventElements.set(event, elements);
	}
	elements.add(element);
}
var DEHYDRATED_BLOCK_REGISTRY = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DEHYDRATED_BLOCK_REGISTRY" : "");
var DehydratedBlockRegistry = class DehydratedBlockRegistry {
	registry = /* @__PURE__ */ new Map();
	cleanupFns = /* @__PURE__ */ new Map();
	jsActionMap = inject(JSACTION_BLOCK_ELEMENT_MAP);
	contract = inject(JSACTION_EVENT_CONTRACT);
	add(blockId, info) {
		this.registry.set(blockId, info);
		if (this.awaitingCallbacks.has(blockId)) {
			const awaitingCallbacks = this.awaitingCallbacks.get(blockId);
			for (const cb of awaitingCallbacks) cb();
		}
	}
	get(blockId) {
		return this.registry.get(blockId) ?? null;
	}
	has(blockId) {
		return this.registry.has(blockId);
	}
	cleanup(hydratedBlocks) {
		removeListenersFromBlocks(hydratedBlocks, this.jsActionMap);
		for (let blockId of hydratedBlocks) {
			this.registry.delete(blockId);
			this.jsActionMap.delete(blockId);
			this.invokeTriggerCleanupFns(blockId);
			this.hydrating.delete(blockId);
			this.awaitingCallbacks.delete(blockId);
		}
		if (this.size === 0) this.contract.instance?.cleanUp();
	}
	get size() {
		return this.registry.size;
	}
	addCleanupFn(blockId, fn) {
		let cleanupFunctions = [];
		if (this.cleanupFns.has(blockId)) cleanupFunctions = this.cleanupFns.get(blockId);
		cleanupFunctions.push(fn);
		this.cleanupFns.set(blockId, cleanupFunctions);
	}
	invokeTriggerCleanupFns(blockId) {
		const fns = this.cleanupFns.get(blockId) ?? [];
		for (let fn of fns) fn();
		this.cleanupFns.delete(blockId);
	}
	hydrating = /* @__PURE__ */ new Map();
	awaitingCallbacks = /* @__PURE__ */ new Map();
	awaitParentBlock(topmostParentBlock, callback) {
		const parentBlockAwaitCallbacks = this.awaitingCallbacks.get(topmostParentBlock) ?? [];
		parentBlockAwaitCallbacks.push(callback);
		this.awaitingCallbacks.set(topmostParentBlock, parentBlockAwaitCallbacks);
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: DehydratedBlockRegistry,
		providedIn: null,
		factory: () => new DehydratedBlockRegistry()
	});
};
function isDetachedByI18n(tNode) {
	return (tNode.flags & 32) === 32;
}
var TRANSFER_STATE_TOKEN_ID = "__nghData__";
var NGH_DATA_KEY = makeStateKey(TRANSFER_STATE_TOKEN_ID);
var TRANSFER_STATE_DEFER_BLOCKS_INFO = "__nghDeferData__";
var NGH_DEFER_BLOCKS_KEY = makeStateKey(TRANSFER_STATE_DEFER_BLOCKS_INFO);
function isInternalHydrationTransferStateKey(key) {
	return key === TRANSFER_STATE_TOKEN_ID || key === TRANSFER_STATE_DEFER_BLOCKS_INFO;
}
var SSR_CONTENT_INTEGRITY_MARKER = "nghm";
var _retrieveHydrationInfoImpl = () => null;
function retrieveHydrationInfo(rNode, injector, isRootView = false) {
	return _retrieveHydrationInfoImpl(rNode, injector, isRootView);
}
function getLNodeForHydration(viewRef) {
	let lView = viewRef._lView;
	if (lView[1].type === 2) return null;
	if (isRootView(lView)) lView = lView[28];
	return lView;
}
var HydrationStatus;
(function(HydrationStatus) {
	HydrationStatus["Hydrated"] = "hydrated";
	HydrationStatus["Skipped"] = "skipped";
	HydrationStatus["Mismatched"] = "mismatched";
})(HydrationStatus || (HydrationStatus = {}));
var HYDRATION_INFO_KEY = "__ngDebugHydrationInfo__";
function patchHydrationInfo(node, info) {
	node[HYDRATION_INFO_KEY] = info;
}
function readHydrationInfo(node) {
	return node[HYDRATION_INFO_KEY] ?? null;
}
function markRNodeAsClaimedByHydration(node, checkIfAlreadyClaimed = true) {
	if (!ngDevMode) throw new Error("Calling `markRNodeAsClaimedByHydration` in prod mode is not supported and likely a mistake.");
	if (checkIfAlreadyClaimed && isRNodeClaimedForHydration(node)) throw new Error("Trying to claim a node, which was claimed already.");
	patchHydrationInfo(node, { status: HydrationStatus.Hydrated });
	ngDevMode.hydratedNodes++;
}
function markRNodeAsHavingHydrationMismatch(node, expectedNodeDetails = null, actualNodeDetails = null) {
	if (!ngDevMode) throw new Error("Calling `markRNodeAsMismatchedByHydration` in prod mode is not supported and likely a mistake.");
	while (node && !getComponent(node)) node = node?.parentNode;
	if (node) patchHydrationInfo(node, {
		status: HydrationStatus.Mismatched,
		expectedNodeDetails,
		actualNodeDetails
	});
}
function isRNodeClaimedForHydration(node) {
	return readHydrationInfo(node)?.status === HydrationStatus.Hydrated;
}
function getSegmentHead(hydrationInfo, index) {
	return hydrationInfo.segmentHeads?.[index] ?? null;
}
function isIncrementalHydrationEnabled(injector) {
	return injector.get(IS_INCREMENTAL_HYDRATION_ENABLED, false, { optional: true });
}
var incrementalHydrationEnabledWarned = false;
function resetIncrementalHydrationEnabledWarnedForTests() {
	incrementalHydrationEnabledWarned = false;
}
function warnIncrementalHydrationNotConfigured() {
	if (!incrementalHydrationEnabledWarned) {
		incrementalHydrationEnabledWarned = true;
		console.warn(formatRuntimeError(508, "Angular has detected that some `@defer` blocks use `hydrate` triggers, but incremental hydration was not enabled. Incremental hydration is enabled by default with `provideClientHydration()`. Make sure `provideClientHydration()` is included in your application config and that you have not opted out using `withNoIncrementalHydration()`."));
	}
}
function getNgContainerSize(hydrationInfo, index) {
	const data = hydrationInfo.data;
	let size = data["e"]?.[index] ?? null;
	if (size === null && data["c"]?.[index]) size = calcSerializedContainerSize(hydrationInfo, index);
	return size;
}
function isSerializedElementContainer(hydrationInfo, index) {
	return hydrationInfo.data["e"]?.[index] !== void 0;
}
function getSerializedContainerViews(hydrationInfo, index) {
	return hydrationInfo.data["c"]?.[index] ?? null;
}
function calcSerializedContainerSize(hydrationInfo, index) {
	const views = getSerializedContainerViews(hydrationInfo, index) ?? [];
	let numNodes = 0;
	for (let view of views) numNodes += view["r"] * (view["x"] ?? 1);
	return numNodes;
}
function initDisconnectedNodes(hydrationInfo) {
	if (typeof hydrationInfo.disconnectedNodes === "undefined") {
		const nodeIds = hydrationInfo.data["d"];
		hydrationInfo.disconnectedNodes = nodeIds ? new Set(nodeIds) : null;
	}
	return hydrationInfo.disconnectedNodes;
}
function isDisconnectedNode$1(hydrationInfo, index) {
	if (typeof hydrationInfo.disconnectedNodes === "undefined") {
		const nodeIds = hydrationInfo.data["d"];
		hydrationInfo.disconnectedNodes = nodeIds ? new Set(nodeIds) : null;
	}
	return !!initDisconnectedNodes(hydrationInfo)?.has(index);
}
function processTextNodeBeforeSerialization(context, node) {
	const el = node;
	const corruptedTextNodes = context.corruptedTextNodes;
	if (el.textContent === "") corruptedTextNodes.set(el, "ngetn");
	else if (el.nextSibling?.nodeType === Node.TEXT_NODE) corruptedTextNodes.set(el, "ngtns");
}
function convertHydrateTriggersToJsAction(triggers) {
	let actionList = [];
	if (triggers !== null) {
		if (triggers.has(4)) actionList.push(...hoverEventNames);
		if (triggers.has(3)) actionList.push(...interactionEventNames);
	}
	return actionList;
}
function refreshContentQueries(tView, lView) {
	const contentQueries = tView.contentQueries;
	if (contentQueries !== null) {
		const prevConsumer = setActiveConsumer(null);
		try {
			for (let i = 0; i < contentQueries.length; i += 2) {
				const queryStartIdx = contentQueries[i];
				const directiveDefIdx = contentQueries[i + 1];
				if (directiveDefIdx !== -1) {
					const directiveDef = tView.data[directiveDefIdx];
					ngDevMode && assertDefined(directiveDef, "DirectiveDef not found.");
					ngDevMode && assertDefined(directiveDef.contentQueries, "contentQueries function should be defined");
					setCurrentQueryIndex(queryStartIdx);
					directiveDef.contentQueries(2, lView[directiveDefIdx], directiveDefIdx);
				}
			}
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
}
function executeViewQueryFn(flags, viewQueryFn, component) {
	ngDevMode && assertDefined(viewQueryFn, "View queries function to execute must be defined.");
	setCurrentQueryIndex(0);
	const prevConsumer = setActiveConsumer(null);
	try {
		viewQueryFn(flags, component);
	} finally {
		setActiveConsumer(prevConsumer);
	}
}
function executeContentQueries(tView, tNode, lView) {
	if (isContentQueryHost(tNode)) {
		const prevConsumer = setActiveConsumer(null);
		try {
			const start = tNode.directiveStart;
			const end = tNode.directiveEnd;
			for (let directiveIndex = start; directiveIndex < end; directiveIndex++) {
				const def = tView.data[directiveIndex];
				if (def.contentQueries) {
					const directiveInstance = lView[directiveIndex];
					ngDevMode && assertDefined(directiveIndex, "Incorrect reference to a directive defining a content query");
					def.contentQueries(1, directiveInstance, directiveIndex);
				}
			}
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
}
var ViewEncapsulation$1;
(function(ViewEncapsulation) {
	ViewEncapsulation[ViewEncapsulation["Emulated"] = 0] = "Emulated";
	ViewEncapsulation[ViewEncapsulation["None"] = 2] = "None";
	ViewEncapsulation[ViewEncapsulation["ShadowDom"] = 3] = "ShadowDom";
	ViewEncapsulation[ViewEncapsulation["ExperimentalIsolatedShadowDom"] = 4] = "ExperimentalIsolatedShadowDom";
})(ViewEncapsulation$1 || (ViewEncapsulation$1 = {}));
var CUSTOM_ELEMENTS_SCHEMA = { name: "custom-elements" };
var NO_ERRORS_SCHEMA = { name: "no-errors-schema" };
var shouldThrowErrorOnUnknownElement = false;
function ɵsetUnknownElementStrictMode(shouldThrow) {
	shouldThrowErrorOnUnknownElement = shouldThrow;
}
function ɵgetUnknownElementStrictMode() {
	return shouldThrowErrorOnUnknownElement;
}
var shouldThrowErrorOnUnknownProperty = false;
function ɵsetUnknownPropertyStrictMode(shouldThrow) {
	shouldThrowErrorOnUnknownProperty = shouldThrow;
}
function ɵgetUnknownPropertyStrictMode() {
	return shouldThrowErrorOnUnknownProperty;
}
function validateElementIsKnown(lView, tNode) {
	const tView = lView[1];
	if (tView.schemas === null) return;
	const tagName = tNode.value;
	if (!isDirectiveHost(tNode) && tagName !== null) {
		if ((typeof HTMLUnknownElement !== "undefined" && HTMLUnknownElement && getNativeByTNode(tNode, lView) instanceof HTMLUnknownElement || typeof customElements !== "undefined" && tagName.indexOf("-") > -1 && !customElements.get(tagName)) && !matchingSchemas(tView.schemas, tagName)) {
			const isHostStandalone = isHostComponentStandalone(lView);
			const templateLocation = getTemplateLocationDetails(lView);
			const schemas = `'${isHostStandalone ? "@Component" : "@NgModule"}.schemas'`;
			let message = `'${tagName}' is not a known element${templateLocation}:\n`;
			message += `1. If '${tagName}' is an Angular component, then verify that it is ${isHostStandalone ? "included in the '@Component.imports' of this component" : "a part of an @NgModule where this component is declared"}.\n`;
			if (tagName && tagName.indexOf("-") > -1) message += `2. If '${tagName}' is a Web Component then add 'CUSTOM_ELEMENTS_SCHEMA' to the ${schemas} of this component to suppress this message.`;
			else message += `2. To allow any element add 'NO_ERRORS_SCHEMA' to the ${schemas} of this component.`;
			if (shouldThrowErrorOnUnknownElement) throw new RuntimeError(304, message);
			else console.error(formatRuntimeError(304, message));
		}
	}
}
function isPropertyValid(element, propName, tagName, schemas) {
	if (schemas === null) return true;
	if (matchingSchemas(schemas, tagName) || propName in element || isAnimationProp(propName)) return true;
	return typeof Node === "undefined" || Node === null || !(element instanceof Node);
}
function handleUnknownPropertyError(propName, tagName, nodeType, lView) {
	if (!tagName && nodeType === 4) tagName = "ng-template";
	const isHostStandalone = isHostComponentStandalone(lView);
	const templateLocation = getTemplateLocationDetails(lView);
	let message = `Can't bind to '${propName}' since it isn't a known property of '${tagName}'${templateLocation}.`;
	const schemas = `'${isHostStandalone ? "@Component" : "@NgModule"}.schemas'`;
	const importLocation = isHostStandalone ? "included in the '@Component.imports' of this component" : "a part of an @NgModule where this component is declared";
	if (KNOWN_CONTROL_FLOW_DIRECTIVES.has(propName)) {
		const correspondingImport = KNOWN_CONTROL_FLOW_DIRECTIVES.get(propName);
		message += `\nIf the '${propName}' is an Angular control flow directive, please make sure that either the '${correspondingImport}' directive or the 'CommonModule' is ${importLocation}.`;
	} else {
		message += `\n1. If '${tagName}' is an Angular component and it has the '${propName}' input, then verify that it is ${importLocation}.`;
		if (tagName && tagName.indexOf("-") > -1) {
			message += `\n2. If '${tagName}' is a Web Component then add 'CUSTOM_ELEMENTS_SCHEMA' to the ${schemas} of this component to suppress this message.`;
			message += `\n3. To allow any property add 'NO_ERRORS_SCHEMA' to the ${schemas} of this component.`;
		} else message += `\n2. To allow any property add 'NO_ERRORS_SCHEMA' to the ${schemas} of this component.`;
	}
	reportUnknownPropertyError(message);
}
function reportUnknownPropertyError(message) {
	if (shouldThrowErrorOnUnknownProperty) throw new RuntimeError(303, message);
	else console.error(formatRuntimeError(303, message));
}
function getDeclarationComponentDef(lView) {
	!ngDevMode && throwError("Must never be called in production mode");
	const context = lView[15][8];
	if (!context) return null;
	return context.constructor ? getComponentDef(context.constructor) : null;
}
function isHostComponentStandalone(lView) {
	!ngDevMode && throwError("Must never be called in production mode");
	return !!getDeclarationComponentDef(lView)?.standalone;
}
function getTemplateLocationDetails(lView) {
	!ngDevMode && throwError("Must never be called in production mode");
	const componentClassName = getDeclarationComponentDef(lView)?.type?.name;
	return componentClassName ? ` (used in the '${componentClassName}' component template)` : "";
}
var KNOWN_CONTROL_FLOW_DIRECTIVES = /* @__PURE__ */ new Map([
	["ngIf", "NgIf"],
	["ngFor", "NgFor"],
	["ngSwitchCase", "NgSwitchCase"],
	["ngSwitchDefault", "NgSwitchDefault"]
]);
function matchingSchemas(schemas, tagName) {
	if (schemas !== null) for (let i = 0; i < schemas.length; i++) {
		const schema = schemas[i];
		if (schema === NO_ERRORS_SCHEMA || schema === CUSTOM_ELEMENTS_SCHEMA && tagName && tagName.indexOf("-") > -1) return true;
	}
	return false;
}
var NAMESPACE_URIS = {
	"http://www.w3.org/2000/svg": "svg",
	"http://www.w3.org/1998/Math/MathML": MATH_ML_NAMESPACE
};
var policy$1;
function getPolicy$1() {
	if (policy$1 === void 0) {
		policy$1 = null;
		if (_global.trustedTypes) try {
			policy$1 = _global.trustedTypes.createPolicy("angular", {
				createHTML: (s) => s,
				createScript: (s) => s,
				createScriptURL: (s) => s
			});
		} catch {}
	}
	return policy$1;
}
function trustedHTMLFromString(html) {
	return getPolicy$1()?.createHTML(html) || html;
}
function trustedScriptURLFromString(url) {
	return getPolicy$1()?.createScriptURL(url) || url;
}
var policy;
function getPolicy() {
	if (policy === void 0) {
		policy = null;
		if (_global.trustedTypes) try {
			policy = _global.trustedTypes.createPolicy("angular#unsafe-bypass", {
				createHTML: (s) => s,
				createScript: (s) => s,
				createScriptURL: (s) => s
			});
		} catch {}
	}
	return policy;
}
function trustedHTMLFromStringBypass(html) {
	return getPolicy()?.createHTML(html) || html;
}
function trustedScriptFromStringBypass(script) {
	return getPolicy()?.createScript(script) || script;
}
function trustedScriptURLFromStringBypass(url) {
	return getPolicy()?.createScriptURL(url) || url;
}
var SafeValueImpl = class {
	changingThisBreaksApplicationSecurity;
	constructor(changingThisBreaksApplicationSecurity) {
		this.changingThisBreaksApplicationSecurity = changingThisBreaksApplicationSecurity;
	}
	toString() {
		return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${XSS_SECURITY_URL})`;
	}
};
var SafeHtmlImpl = class extends SafeValueImpl {
	getTypeName() {
		return "HTML";
	}
};
var SafeStyleImpl = class extends SafeValueImpl {
	getTypeName() {
		return "Style";
	}
};
var SafeScriptImpl = class extends SafeValueImpl {
	getTypeName() {
		return "Script";
	}
};
var SafeUrlImpl = class extends SafeValueImpl {
	getTypeName() {
		return "URL";
	}
};
var SafeResourceUrlImpl = class extends SafeValueImpl {
	getTypeName() {
		return "ResourceURL";
	}
};
function unwrapSafeValue(value) {
	return value instanceof SafeValueImpl ? value.changingThisBreaksApplicationSecurity : value;
}
function allowSanitizationBypassAndThrow(value, type) {
	const actualType = getSanitizationBypassType(value);
	if (actualType != null && actualType !== type) {
		if (actualType === "ResourceURL" && type === "URL") return true;
		throw new Error(`Required a safe ${type}, got a ${actualType} (see ${XSS_SECURITY_URL})`);
	}
	return actualType === type;
}
function getSanitizationBypassType(value) {
	return value instanceof SafeValueImpl && value.getTypeName() || null;
}
function bypassSanitizationTrustHtml(trustedHtml) {
	return new SafeHtmlImpl(trustedHtml);
}
function bypassSanitizationTrustStyle(trustedStyle) {
	return new SafeStyleImpl(trustedStyle);
}
function bypassSanitizationTrustScript(trustedScript) {
	return new SafeScriptImpl(trustedScript);
}
function bypassSanitizationTrustUrl(trustedUrl) {
	return new SafeUrlImpl(trustedUrl);
}
function bypassSanitizationTrustResourceUrl(trustedResourceUrl) {
	return new SafeResourceUrlImpl(trustedResourceUrl);
}
function getInertBodyHelper(defaultDoc) {
	const inertDocumentHelper = new InertDocumentHelper(defaultDoc);
	return isDOMParserAvailable() ? new DOMParserHelper(inertDocumentHelper) : inertDocumentHelper;
}
var DOMParserHelper = class {
	inertDocumentHelper;
	constructor(inertDocumentHelper) {
		this.inertDocumentHelper = inertDocumentHelper;
	}
	getInertBodyElement(html) {
		html = "<body><remove></remove>" + html;
		try {
			const body = new window.DOMParser().parseFromString(trustedHTMLFromString(html), "text/html").body;
			if (body === null) return this.inertDocumentHelper.getInertBodyElement(html);
			body.firstChild?.remove();
			return body;
		} catch {
			return null;
		}
	}
};
var InertDocumentHelper = class {
	defaultDoc;
	inertDocument;
	constructor(defaultDoc) {
		this.defaultDoc = defaultDoc;
		this.inertDocument = this.defaultDoc.implementation.createHTMLDocument("sanitization-inert");
	}
	getInertBodyElement(html) {
		const templateEl = this.inertDocument.createElement("template");
		templateEl.innerHTML = trustedHTMLFromString(html);
		return templateEl;
	}
};
function isDOMParserAvailable() {
	try {
		return !!new window.DOMParser().parseFromString(trustedHTMLFromString(""), "text/html");
	} catch {
		return false;
	}
}
var SAFE_URL_PATTERN = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;
function _sanitizeUrl(url) {
	url = String(url);
	if (url.match(SAFE_URL_PATTERN)) return url;
	if (typeof ngDevMode === "undefined" || ngDevMode) console.warn(`WARNING: sanitizing unsafe URL value ${url} (see ${XSS_SECURITY_URL})`);
	return "unsafe:" + url;
}
function tagSet(tags) {
	const res = Object.create(null);
	for (const t of tags.split(",")) res[t] = true;
	return res;
}
function merge(...sets) {
	const res = Object.create(null);
	for (const s of sets) for (const v in s) if (Object.hasOwn(s, v)) res[v] = true;
	return res;
}
var VOID_ELEMENTS = tagSet("area,br,col,hr,img,wbr");
var OPTIONAL_END_TAG_BLOCK_ELEMENTS = tagSet("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr");
var OPTIONAL_END_TAG_INLINE_ELEMENTS = tagSet("rp,rt");
var OPTIONAL_END_TAG_ELEMENTS = merge(OPTIONAL_END_TAG_INLINE_ELEMENTS, OPTIONAL_END_TAG_BLOCK_ELEMENTS);
var VALID_ELEMENTS = merge(VOID_ELEMENTS, merge(OPTIONAL_END_TAG_BLOCK_ELEMENTS, tagSet("address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul")), merge(OPTIONAL_END_TAG_INLINE_ELEMENTS, tagSet("a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video")), OPTIONAL_END_TAG_ELEMENTS);
var URI_ATTRS = tagSet("background,cite,href,itemtype,longdesc,poster,src,xlink:href");
var VALID_ATTRS = merge(URI_ATTRS, tagSet("abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,srcset,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"), tagSet("aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"));
var SKIP_TRAVERSING_CONTENT_IF_INVALID_ELEMENTS = tagSet("script,style,template");
var SanitizingHtmlSerializer = class {
	sanitizedSomething = false;
	buf = [];
	sanitizeChildren(el) {
		let current = el.firstChild;
		let traverseContent = true;
		let parentNodes = [];
		while (current) {
			if (current.nodeType === Node.ELEMENT_NODE) traverseContent = this.startElement(current);
			else if (current.nodeType === Node.TEXT_NODE) this.chars(current.nodeValue);
			else this.sanitizedSomething = true;
			if (traverseContent && current.firstChild) {
				parentNodes.push(current);
				current = getFirstChild(current);
				continue;
			}
			while (current) {
				if (current.nodeType === Node.ELEMENT_NODE) this.endElement(current);
				let next = getNextSibling(current);
				if (next) {
					current = next;
					break;
				}
				current = parentNodes.pop();
			}
		}
		return this.buf.join("");
	}
	startElement(element) {
		const tagName = getNodeName(element).toLowerCase();
		if (!Object.hasOwn(VALID_ELEMENTS, tagName)) {
			this.sanitizedSomething = true;
			return !Object.hasOwn(SKIP_TRAVERSING_CONTENT_IF_INVALID_ELEMENTS, tagName);
		}
		this.buf.push("<");
		this.buf.push(tagName);
		const elAttrs = element.attributes;
		for (let i = 0; i < elAttrs.length; i++) {
			const elAttr = elAttrs.item(i);
			const attrName = elAttr.name;
			const lower = attrName.toLowerCase();
			if (!Object.hasOwn(VALID_ATTRS, lower)) {
				this.sanitizedSomething = true;
				continue;
			}
			let value = elAttr.value;
			if (URI_ATTRS[lower]) value = _sanitizeUrl(value);
			this.buf.push(" ", attrName, "=\"", encodeEntities(value), "\"");
		}
		this.buf.push(">");
		return true;
	}
	endElement(current) {
		const tagName = getNodeName(current).toLowerCase();
		if (Object.hasOwn(VALID_ELEMENTS, tagName) && !Object.hasOwn(VOID_ELEMENTS, tagName)) {
			this.buf.push("</");
			this.buf.push(tagName);
			this.buf.push(">");
		}
	}
	chars(chars) {
		this.buf.push(encodeEntities(chars));
	}
};
function isClobberedElement(parentNode, childNode) {
	return (parentNode.compareDocumentPosition(childNode) & Node.DOCUMENT_POSITION_CONTAINED_BY) !== Node.DOCUMENT_POSITION_CONTAINED_BY;
}
function getNextSibling(node) {
	const nextSibling = node.nextSibling;
	if (nextSibling && node !== nextSibling.previousSibling) throw clobberedElementError(nextSibling);
	return nextSibling;
}
function getFirstChild(node) {
	const firstChild = node.firstChild;
	if (firstChild && isClobberedElement(node, firstChild)) throw clobberedElementError(firstChild);
	return firstChild;
}
function getNodeName(node) {
	const nodeName = node.nodeName;
	return typeof nodeName === "string" ? nodeName : "FORM";
}
function clobberedElementError(node) {
	return /* @__PURE__ */ new Error(`Failed to sanitize html because the element is clobbered: ${node.outerHTML}`);
}
var SURROGATE_PAIR_REGEXP = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g;
var NON_ALPHANUMERIC_REGEXP = /([^\#-~ |!])/g;
function encodeEntities(value) {
	return value.replace(/&/g, "&amp;").replace(SURROGATE_PAIR_REGEXP, function(match) {
		const hi = match.charCodeAt(0);
		const low = match.charCodeAt(1);
		return "&#" + ((hi - 55296) * 1024 + (low - 56320) + 65536) + ";";
	}).replace(NON_ALPHANUMERIC_REGEXP, function(match) {
		return "&#" + match.charCodeAt(0) + ";";
	}).replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
var inertBodyHelper;
function _sanitizeHtml(defaultDoc, unsafeHtmlInput) {
	let inertBodyElement = null;
	try {
		inertBodyHelper = inertBodyHelper || getInertBodyHelper(defaultDoc);
		let unsafeHtml = unsafeHtmlInput ? String(unsafeHtmlInput) : "";
		inertBodyElement = inertBodyHelper.getInertBodyElement(unsafeHtml);
		let mXSSAttempts = 5;
		let parsedHtml = unsafeHtml;
		do {
			if (mXSSAttempts === 0) throw new Error("Failed to sanitize html because the input is unstable");
			mXSSAttempts--;
			unsafeHtml = parsedHtml;
			parsedHtml = inertBodyElement.innerHTML;
			inertBodyElement = inertBodyHelper.getInertBodyElement(unsafeHtml);
		} while (unsafeHtml !== parsedHtml);
		const sanitizer = new SanitizingHtmlSerializer();
		const safeHtml = sanitizer.sanitizeChildren(getTemplateContent(inertBodyElement) || inertBodyElement);
		if ((typeof ngDevMode === "undefined" || ngDevMode) && sanitizer.sanitizedSomething) console.warn(`WARNING: sanitizing HTML stripped some content, see ${XSS_SECURITY_URL}`);
		return trustedHTMLFromString(safeHtml);
	} finally {
		if (inertBodyElement) {
			const parent = getTemplateContent(inertBodyElement) || inertBodyElement;
			while (parent.firstChild) parent.firstChild.remove();
		}
	}
}
function getTemplateContent(el) {
	return "content" in el && isTemplateElement(el) ? el.content : null;
}
function isTemplateElement(el) {
	return el.nodeType === Node.ELEMENT_NODE && el.nodeName === "TEMPLATE";
}
var COMMENT_DISALLOWED = /^>|^->|<!--|-->|--!>|<!-$/g;
var COMMENT_DELIMITER = /(<|>)/g;
var COMMENT_DELIMITER_ESCAPED = "​$1​";
function escapeCommentText(value) {
	return value.replace(COMMENT_DISALLOWED, (text) => text.replace(COMMENT_DELIMITER, COMMENT_DELIMITER_ESCAPED));
}
function createTextNode(renderer, value) {
	return renderer.createText(value);
}
function updateTextNode(renderer, rNode, value) {
	renderer.setValue(rNode, value);
}
function createCommentNode(renderer, value) {
	return renderer.createComment(escapeCommentText(value));
}
function createElementNode(renderer, name, namespace) {
	return renderer.createElement(name, namespace);
}
function nativeInsertBefore(renderer, parent, child, beforeNode, isMove) {
	renderer.insertBefore(parent, child, beforeNode, isMove);
}
function nativeAppendChild(renderer, parent, child) {
	ngDevMode && assertDefined(parent, "parent node must be defined");
	renderer.appendChild(parent, child);
}
function nativeAppendOrInsertBefore(renderer, parent, child, beforeNode, isMove) {
	if (beforeNode !== null) nativeInsertBefore(renderer, parent, child, beforeNode, isMove);
	else nativeAppendChild(renderer, parent, child);
}
function nativeRemoveNode(renderer, rNode, isHostElement, requireSynchronousElementRemoval) {
	renderer.removeChild(null, rNode, isHostElement, requireSynchronousElementRemoval);
}
function writeDirectStyle(renderer, element, newValue) {
	ngDevMode && assertString(newValue, "'newValue' should be a string");
	renderer.setAttribute(element, "style", newValue);
}
function writeDirectClass(renderer, element, newValue) {
	ngDevMode && assertString(newValue, "'newValue' should be a string");
	if (newValue === "") renderer.removeAttribute(element, "class");
	else renderer.setAttribute(element, "class", newValue);
}
function setupStaticAttributes(renderer, element, tNode) {
	const { mergedAttrs, classes, styles } = tNode;
	if (mergedAttrs !== null) setUpAttributes(renderer, element, mergedAttrs);
	if (classes !== null) writeDirectClass(renderer, element, classes);
	if (styles !== null) writeDirectStyle(renderer, element, styles);
}
function enforceIframeSecurity(iframe) {
	const lView = getLView();
	iframe.src = "";
	iframe.srcdoc = trustedHTMLFromString("");
	nativeRemoveNode(lView[11], iframe);
}
function splitNsName(elementName, fatal = true) {
	if (elementName[0] != ":") return [null, elementName];
	const colonIndex = elementName.indexOf(":", 1);
	if (colonIndex === -1) {
		if (fatal) throw new Error(`Unsupported format "${elementName}" expecting ":namespace:name"`);
		else return [null, elementName];
	}
	return [elementName.slice(1, colonIndex), elementName.slice(colonIndex + 1)];
}
function ɵɵsanitizeHtml(unsafeHtml, tagName, propName) {
	if (tagName !== void 0 && propName !== void 0 && getSecurityContext(tagName, propName) !== SecurityContext.HTML) return unsafeHtml;
	const sanitizer = getSanitizer();
	if (sanitizer) return trustedHTMLFromStringBypass(sanitizer.sanitize(SecurityContext.HTML, unsafeHtml) || "");
	if (allowSanitizationBypassAndThrow(unsafeHtml, "HTML")) return trustedHTMLFromStringBypass(unwrapSafeValue(unsafeHtml));
	return _sanitizeHtml(getDocument(), renderStringify(unsafeHtml));
}
function ɵɵsanitizeStyle(unsafeStyle) {
	const sanitizer = getSanitizer();
	if (sanitizer) return sanitizer.sanitize(SecurityContext.STYLE, unsafeStyle) || "";
	if (allowSanitizationBypassAndThrow(unsafeStyle, "Style")) return unwrapSafeValue(unsafeStyle);
	return renderStringify(unsafeStyle);
}
function ɵɵsanitizeUrl(unsafeUrl) {
	const sanitizer = getSanitizer();
	if (sanitizer) return sanitizer.sanitize(SecurityContext.URL, unsafeUrl) || "";
	if (allowSanitizationBypassAndThrow(unsafeUrl, "URL")) return unwrapSafeValue(unsafeUrl);
	return _sanitizeUrl(renderStringify(unsafeUrl));
}
function ɵɵsanitizeResourceUrl(unsafeResourceUrl) {
	const sanitizer = getSanitizer();
	if (sanitizer) return trustedScriptURLFromStringBypass(sanitizer.sanitize(SecurityContext.RESOURCE_URL, unsafeResourceUrl) || "");
	if (allowSanitizationBypassAndThrow(unsafeResourceUrl, "ResourceURL")) return trustedScriptURLFromStringBypass(unwrapSafeValue(unsafeResourceUrl));
	throw new RuntimeError(904, ngDevMode && `unsafe value used in a resource URL context (see https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss)`);
}
function ɵɵsanitizeScript(unsafeScript) {
	const sanitizer = getSanitizer();
	if (sanitizer) return trustedScriptFromStringBypass(sanitizer.sanitize(SecurityContext.SCRIPT, unsafeScript) || "");
	if (allowSanitizationBypassAndThrow(unsafeScript, "Script")) return trustedScriptFromStringBypass(unwrapSafeValue(unsafeScript));
	throw new RuntimeError(905, ngDevMode && "unsafe value used in a script context");
}
function ɵɵtrustConstantHtml(html) {
	if (ngDevMode && (!Array.isArray(html) || !Array.isArray(html.raw) || html.length !== 1)) throw new Error(`Unexpected interpolation in trusted HTML constant: ${html.join("?")}`);
	return trustedHTMLFromString(html[0]);
}
function ɵɵtrustConstantResourceUrl(url) {
	if (ngDevMode && (!Array.isArray(url) || !Array.isArray(url.raw) || url.length !== 1)) throw new Error(`Unexpected interpolation in trusted URL constant: ${url.join("?")}`);
	return trustedScriptURLFromString(url[0]);
}
function getUrlSanitizer(tag, prop) {
	switch (getSecurityContext(tag, prop)) {
		case SecurityContext.RESOURCE_URL: return ɵɵsanitizeResourceUrl;
		case SecurityContext.URL: return ɵɵsanitizeUrl;
		default: return null;
	}
}
function ɵɵsanitizeUrlOrResourceUrl(unsafeUrl, tag, prop) {
	return getUrlSanitizer(tag, prop)?.(unsafeUrl) ?? unsafeUrl;
}
function validateAgainstEventProperties(name) {
	if (name.toLowerCase().startsWith("on")) throw new RuntimeError(306, `Binding to event property '${name}' is disallowed for security reasons, please use (${name.slice(2)})=...\nIf '${name}' is a directive input, make sure the directive is imported by the current module.`);
}
function getSanitizer() {
	const lView = getLView();
	return lView && lView[10].sanitizer;
}
function getSecurityContext(tagName, propName) {
	const [namespace, resolvedTagName] = resolveElement(tagName);
	return checkSecurityContext(resolvedTagName, propName, namespace);
}
function resolveElement(tagName) {
	tagName = tagName.toLowerCase();
	const splitResult = splitNsName(tagName, false);
	if (splitResult[0]) return splitResult;
	const tNode = getSelectedIndex() === -1 ? null : getSelectedTNode();
	let namespace = tNode?.namespace;
	if (tagName === "#host" && tNode?.type === 2) {
		const element = getNativeByTNode(tNode, getLView());
		if (element.tagName) tagName = element.tagName.toLowerCase();
		if (namespace == null) {
			const namespaceURI = element.namespaceURI;
			namespace = namespaceURI && NAMESPACE_URIS[namespaceURI];
		}
	}
	return [namespace, tagName];
}
var SECURITY_SENSITIVE_ATTRIBUTE_NAMES = /* @__PURE__ */ new Set(["href", "xlink:href"]);
var SVG_ANIMATION_SENSITIVE_STATIC_VALUES = {
	"animate": {
		"to": SECURITY_SENSITIVE_ATTRIBUTE_NAMES,
		"values": SECURITY_SENSITIVE_ATTRIBUTE_NAMES,
		"from": SECURITY_SENSITIVE_ATTRIBUTE_NAMES
	},
	"set": { "to": SECURITY_SENSITIVE_ATTRIBUTE_NAMES }
};
function ɵɵvalidateAttribute(value, tagName, attributeName) {
	const tNode = getSelectedIndex() === -1 ? null : getSelectedTNode();
	if (tNode && tNode.type !== 2) return value;
	const [namespace, resolvedTagName] = resolveElement(tagName);
	if (checkSecurityContext(resolvedTagName, attributeName, namespace) !== SecurityContext.ATTRIBUTE_NO_BINDING) return value;
	const lView = getLView();
	if (tNode) {
		if (resolvedTagName === "iframe") enforceIframeSecurity(getNativeByTNode(tNode, lView));
		else if (namespace === "svg" || !namespace) {
			const config = SVG_ANIMATION_SENSITIVE_STATIC_VALUES[resolvedTagName]?.[attributeName.toLowerCase()];
			if (config) {
				const attributeNameValue = getSecuritySensitiveSVGAnimationAttributeName(getNativeByTNode(tNode, lView), config);
				if (attributeNameValue) throw new RuntimeError(-910, ngDevMode && `Angular has detected that the \`${attributeName}\` was applied as a binding to the <${resolvedTagName}> element${getTemplateLocationDetails(lView)}. For security reasons, the \`${attributeName}\` can be set on the <${resolvedTagName}> element as a static attribute only when the "attributeName" is set to \'${attributeNameValue}\'. \nTo fix this, switch the \`${attributeNameValue}\` binding to a static attribute in a template or in host bindings section.`);
				return value;
			}
		}
	}
	throw new RuntimeError(-910, ngDevMode && `Angular has detected that the \`${attributeName}\` was applied as a binding to the <${resolvedTagName}> element${tNode ? getTemplateLocationDetails(lView) : ""}. For security reasons, the \`${attributeName}\` can be set on the <${resolvedTagName}> element as a static attribute only. \nTo fix this, switch the \`${attributeName}\` binding to a static attribute in a template or in host bindings section.`);
}
function getSecuritySensitiveSVGAnimationAttributeName(element, validationConfig) {
	for (const attributeName of element.getAttributeNames()) {
		if (attributeName.toLowerCase() !== "attributename") continue;
		const attributeNameValue = element.getAttribute(attributeName);
		if (attributeNameValue !== null && validationConfig.has(attributeNameValue.toLowerCase())) return attributeNameValue;
	}
	return null;
}
var NG_REFLECT_ATTRS_FLAG_DEFAULT = false;
var NG_REFLECT_ATTRS_FLAG = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "NG_REFLECT_FLAG" : "", { factory: () => NG_REFLECT_ATTRS_FLAG_DEFAULT });
function provideNgReflectAttributes() {
	return makeEnvironmentProviders(typeof ngDevMode === "undefined" || ngDevMode ? [{
		provide: NG_REFLECT_ATTRS_FLAG,
		useValue: true
	}] : []);
}
function normalizeDebugBindingName(name) {
	name = camelCaseToDashCase(name.replace(/[$@]/g, "_"));
	return `ng-reflect-${name}`;
}
var CAMEL_CASE_REGEXP = /([A-Z])/g;
function camelCaseToDashCase(input) {
	return input.replace(CAMEL_CASE_REGEXP, (...m) => "-" + m[1].toLowerCase());
}
function normalizeDebugBindingValue(value) {
	try {
		return value != null ? value.toString().slice(0, 30) : value;
	} catch (e) {
		return "[ERROR] Exception while trying to serialize the value";
	}
}
function ɵɵresolveWindow(element) {
	return element.ownerDocument.defaultView;
}
function ɵɵresolveDocument(element) {
	return element.ownerDocument;
}
function ɵɵresolveBody(element) {
	return element.ownerDocument.body;
}
var INTERPOLATION_DELIMITER = `�`;
function maybeUnwrapFn(value) {
	if (value instanceof Function) return value();
	else return value;
}
var VALUE_STRING_LENGTH_LIMIT = 200;
function assertStandaloneComponentType(type) {
	assertComponentDef(type);
	if (!getComponentDef(type).standalone) throw new RuntimeError(907, `The ${stringifyForError(type)} component is not marked as standalone, but Angular expects to have a standalone component here. Please make sure the ${stringifyForError(type)} component does not have the \`standalone: false\` flag in the decorator.`);
}
function assertComponentDef(type) {
	if (!getComponentDef(type)) throw new RuntimeError(906, `The ${stringifyForError(type)} is not an Angular component, make sure it has the \`@Component\` decorator.`);
}
function throwMultipleComponentError(tNode, first, second) {
	throw new RuntimeError(-300, `Multiple components match node with tagname ${tNode.value}: ${stringifyForError(first)} and ${stringifyForError(second)}`);
}
function throwErrorIfNoChangesMode(creationMode, oldValue, currValue, propName, lView) {
	const componentClassName = getDeclarationComponentDef(lView)?.type?.name;
	let msg = `ExpressionChangedAfterItHasBeenCheckedError: Expression has changed after it was checked. Previous value${propName ? ` for '${propName}'` : ""}: '${formatValue(oldValue)}'. Current value: '${formatValue(currValue)}'.${componentClassName ? ` Expression location: ${componentClassName} component` : ""}`;
	if (creationMode) msg += " It seems like the view has been created after its parent and its children have been dirty checked. Has it been created in a change detection hook?";
	throw new RuntimeError(-100, msg);
}
function formatValue(value) {
	let strValue = String(value);
	try {
		if (Array.isArray(value) || strValue === "[object Object]") strValue = JSON.stringify(value);
	} catch (error) {}
	return strValue.length > VALUE_STRING_LENGTH_LIMIT ? strValue.substring(0, VALUE_STRING_LENGTH_LIMIT) + "…" : strValue;
}
function constructDetailsForInterpolation(lView, rootIndex, expressionIndex, meta, changedValue) {
	const [propName, prefix, ...chunks] = meta.split(INTERPOLATION_DELIMITER);
	let oldValue = prefix, newValue = prefix;
	for (let i = 0; i < chunks.length; i++) {
		const slotIdx = rootIndex + i;
		oldValue += `${lView[slotIdx]}${chunks[i]}`;
		newValue += `${slotIdx === expressionIndex ? changedValue : lView[slotIdx]}${chunks[i]}`;
	}
	return {
		propName,
		oldValue,
		newValue
	};
}
function getExpressionChangedErrorDetails(lView, bindingIndex, oldValue, newValue) {
	const tData = lView[1].data;
	const metadata = tData[bindingIndex];
	if (typeof metadata === "string") {
		if (metadata.indexOf(INTERPOLATION_DELIMITER) > -1) return constructDetailsForInterpolation(lView, bindingIndex, bindingIndex, metadata, newValue);
		return {
			propName: metadata,
			oldValue,
			newValue
		};
	}
	if (metadata === null) {
		let idx = bindingIndex - 1;
		while (typeof tData[idx] !== "string" && tData[idx + 1] === null) idx--;
		const meta = tData[idx];
		if (typeof meta === "string") {
			const matches = meta.match(new RegExp(INTERPOLATION_DELIMITER, "g"));
			if (matches && matches.length - 1 > bindingIndex - idx) return constructDetailsForInterpolation(lView, idx, bindingIndex, meta, newValue);
		}
	}
	return {
		propName: void 0,
		oldValue,
		newValue
	};
}
function classIndexOf(className, classToSearch, startingIndex) {
	ngDevMode && assertNotEqual(classToSearch, "", "can not look for \"\" string.");
	let end = className.length;
	while (true) {
		const foundIndex = className.indexOf(classToSearch, startingIndex);
		if (foundIndex === -1) return foundIndex;
		if (foundIndex === 0 || className.charCodeAt(foundIndex - 1) <= 32) {
			const length = classToSearch.length;
			if (foundIndex + length === end || className.charCodeAt(foundIndex + length) <= 32) return foundIndex;
		}
		startingIndex = foundIndex + 1;
	}
}
var NG_TEMPLATE_SELECTOR = "ng-template";
function isCssClassMatching(tNode, attrs, cssClassToMatch, isProjectionMode) {
	ngDevMode && assertEqual(cssClassToMatch, cssClassToMatch.toLowerCase(), "Class name expected to be lowercase.");
	let i = 0;
	if (isProjectionMode) {
		for (; i < attrs.length && typeof attrs[i] === "string"; i += 2) if (attrs[i] === "class" && classIndexOf(attrs[i + 1].toLowerCase(), cssClassToMatch, 0) !== -1) return true;
	} else if (isInlineTemplate(tNode)) return false;
	i = attrs.indexOf(1, i);
	if (i > -1) {
		let item;
		while (++i < attrs.length && typeof (item = attrs[i]) === "string") if (item.toLowerCase() === cssClassToMatch) return true;
	}
	return false;
}
function isInlineTemplate(tNode) {
	return tNode.type === 4 && tNode.value !== NG_TEMPLATE_SELECTOR;
}
function hasTagAndTypeMatch(tNode, currentSelector, isProjectionMode) {
	return currentSelector === (tNode.type === 4 && !isProjectionMode ? NG_TEMPLATE_SELECTOR : tNode.value);
}
function isNodeMatchingSelector(tNode, selector, isProjectionMode) {
	ngDevMode && assertDefined(selector[0], "Selector should have a tag name");
	let mode = 4;
	const nodeAttrs = tNode.attrs;
	const nameOnlyMarkerIdx = nodeAttrs !== null ? getNameOnlyMarkerIndex(nodeAttrs) : 0;
	let skipToNextSelector = false;
	for (let i = 0; i < selector.length; i++) {
		const current = selector[i];
		if (typeof current === "number") {
			if (!skipToNextSelector && !isPositive(mode) && !isPositive(current)) return false;
			if (skipToNextSelector && isPositive(current)) continue;
			skipToNextSelector = false;
			mode = current | mode & 1;
			continue;
		}
		if (skipToNextSelector) continue;
		if (mode & 4) {
			mode = 2 | mode & 1;
			if (current !== "" && !hasTagAndTypeMatch(tNode, current, isProjectionMode) || current === "" && selector.length === 1) {
				if (isPositive(mode)) return false;
				skipToNextSelector = true;
			}
		} else if (mode & 8) {
			if (nodeAttrs === null || !isCssClassMatching(tNode, nodeAttrs, current, isProjectionMode)) {
				if (isPositive(mode)) return false;
				skipToNextSelector = true;
			}
		} else {
			const selectorAttrValue = selector[++i];
			const attrIndexInNode = findAttrIndexInNode(current, nodeAttrs, isInlineTemplate(tNode), isProjectionMode);
			if (attrIndexInNode === -1) {
				if (isPositive(mode)) return false;
				skipToNextSelector = true;
				continue;
			}
			if (selectorAttrValue !== "") {
				let nodeAttrValue;
				if (attrIndexInNode > nameOnlyMarkerIdx) nodeAttrValue = "";
				else {
					ngDevMode && assertNotEqual(nodeAttrs[attrIndexInNode], 0, "We do not match directives on namespaced attributes");
					nodeAttrValue = nodeAttrs[attrIndexInNode + 1].toLowerCase();
				}
				if (mode & 2 && selectorAttrValue !== nodeAttrValue) {
					if (isPositive(mode)) return false;
					skipToNextSelector = true;
				}
			}
		}
	}
	return isPositive(mode) || skipToNextSelector;
}
function isPositive(mode) {
	return (mode & 1) === 0;
}
function findAttrIndexInNode(name, attrs, isInlineTemplate, isProjectionMode) {
	if (attrs === null) return -1;
	let i = 0;
	if (isProjectionMode || !isInlineTemplate) {
		let bindingsMode = false;
		while (i < attrs.length) {
			const maybeAttrName = attrs[i];
			if (maybeAttrName === name) return i;
			else if (maybeAttrName === 3 || maybeAttrName === 6) bindingsMode = true;
			else if (maybeAttrName === 1 || maybeAttrName === 2) {
				let value = attrs[++i];
				while (typeof value === "string") value = attrs[++i];
				continue;
			} else if (maybeAttrName === 4) break;
			else if (maybeAttrName === 0) {
				i += 4;
				continue;
			}
			i += bindingsMode ? 1 : 2;
		}
		return -1;
	} else return matchTemplateAttribute(attrs, name);
}
function isNodeMatchingSelectorList(tNode, selector, isProjectionMode = false) {
	for (let i = 0; i < selector.length; i++) if (isNodeMatchingSelector(tNode, selector[i], isProjectionMode)) return true;
	return false;
}
function getProjectAsAttrValue(tNode) {
	const nodeAttrs = tNode.attrs;
	if (nodeAttrs != null) {
		const ngProjectAsAttrIdx = nodeAttrs.indexOf(5);
		if ((ngProjectAsAttrIdx & 1) === 0) return nodeAttrs[ngProjectAsAttrIdx + 1];
	}
	return null;
}
function getNameOnlyMarkerIndex(nodeAttrs) {
	for (let i = 0; i < nodeAttrs.length; i++) {
		const nodeAttr = nodeAttrs[i];
		if (isNameOnlyAttributeMarker(nodeAttr)) return i;
	}
	return nodeAttrs.length;
}
function matchTemplateAttribute(attrs, name) {
	let i = attrs.indexOf(4);
	if (i > -1) {
		i++;
		while (i < attrs.length) {
			const attr = attrs[i];
			if (typeof attr === "number") return -1;
			if (attr === name) return i;
			i++;
		}
	}
	return -1;
}
function isSelectorInSelectorList(selector, list) {
	selectorListLoop: for (let i = 0; i < list.length; i++) {
		const currentSelectorInList = list[i];
		if (selector.length !== currentSelectorInList.length) continue;
		for (let j = 0; j < selector.length; j++) if (selector[j] !== currentSelectorInList[j]) continue selectorListLoop;
		return true;
	}
	return false;
}
function maybeWrapInNotSelector(isNegativeMode, chunk) {
	return isNegativeMode ? ":not(" + chunk.trim() + ")" : chunk;
}
function stringifyCSSSelector(selector) {
	let result = selector[0];
	let i = 1;
	let mode = 2;
	let currentChunk = "";
	let isNegativeMode = false;
	while (i < selector.length) {
		let valueOrMarker = selector[i];
		if (typeof valueOrMarker === "string") {
			if (mode & 2) {
				const attrValue = selector[++i];
				currentChunk += "[" + valueOrMarker + (attrValue.length > 0 ? "=\"" + attrValue + "\"" : "") + "]";
			} else if (mode & 8) currentChunk += "." + valueOrMarker;
			else if (mode & 4) currentChunk += " " + valueOrMarker;
		} else {
			if (currentChunk !== "" && !isPositive(valueOrMarker)) {
				result += maybeWrapInNotSelector(isNegativeMode, currentChunk);
				currentChunk = "";
			}
			mode = valueOrMarker;
			isNegativeMode = isNegativeMode || !isPositive(mode);
		}
		i++;
	}
	if (currentChunk !== "") result += maybeWrapInNotSelector(isNegativeMode, currentChunk);
	return result;
}
function stringifyCSSSelectorList(selectorList) {
	return selectorList.map(stringifyCSSSelector).join(",");
}
function extractAttrsAndClassesFromSelector(selector) {
	const attrs = [];
	const classes = [];
	let i = 1;
	let mode = 2;
	while (i < selector.length) {
		let valueOrMarker = selector[i];
		if (typeof valueOrMarker === "string") {
			if (mode === 2) {
				if (valueOrMarker !== "") attrs.push(valueOrMarker, selector[++i]);
			} else if (mode === 8) classes.push(valueOrMarker);
		} else {
			if (!isPositive(mode)) break;
			mode = valueOrMarker;
		}
		i++;
	}
	if (classes.length) attrs.push(1, ...classes);
	return attrs;
}
var NO_CHANGE = typeof ngDevMode === "undefined" || ngDevMode ? { __brand__: "NO_CHANGE" } : {};
var RendererStyleFlags2;
(function(RendererStyleFlags2) {
	RendererStyleFlags2[RendererStyleFlags2["Important"] = 1] = "Important";
	RendererStyleFlags2[RendererStyleFlags2["DashCase"] = 2] = "DashCase";
})(RendererStyleFlags2 || (RendererStyleFlags2 = {}));
var _icuContainerIterate;
function icuContainerIterate(tIcuContainerNode, lView) {
	return _icuContainerIterate(tIcuContainerNode, lView);
}
function ensureIcuContainerVisitorLoaded(loader) {
	if (_icuContainerIterate === void 0) _icuContainerIterate = loader();
}
var ANIMATIONS_DISABLED = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "AnimationsDisabled" : "", { factory: () => false });
var MAX_ANIMATION_TIMEOUT = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "MaxAnimationTimeout" : "", { factory: () => MAX_ANIMATION_TIMEOUT_DEFAULT });
var MAX_ANIMATION_TIMEOUT_DEFAULT = 4e3;
var allLeavingAnimations = /* @__PURE__ */ new Set();
var leavingNodes = /* @__PURE__ */ new WeakMap();
function getDeclarationView(lView) {
	if (!lView) return null;
	return lView[14] ?? lView;
}
var reusedNodes = /* @__PURE__ */ new WeakSet();
function cancelLeavingNodes(tNode, newElement, newLView) {
	const nodes = leavingNodes.get(tNode);
	if (!nodes || nodes.length === 0) return;
	const newParent = newElement.parentNode;
	const prevSibling = newElement.previousSibling;
	const newDeclarationView = getDeclarationView(newLView);
	for (let i = nodes.length - 1; i >= 0; i--) {
		const { el: leavingEl, declarationView: leavingDeclarationView } = nodes[i];
		const leavingParent = leavingEl.parentNode;
		if (leavingEl === newElement) {
			nodes.splice(i, 1);
			reusedNodes.add(leavingEl);
			leavingEl.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: true } }));
		} else if (prevSibling && leavingEl === prevSibling) {
			nodes.splice(i, 1);
			leavingEl.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: true } }));
			leavingEl.parentNode?.removeChild(leavingEl);
		} else if (leavingParent && newParent && leavingParent !== newParent) {
			if (newDeclarationView === null || leavingDeclarationView === null || newDeclarationView === leavingDeclarationView) {
				nodes.splice(i, 1);
				leavingEl.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: true } }));
				leavingEl.parentNode?.removeChild(leavingEl);
			}
		}
	}
}
function trackLeavingNodes(tNode, el, lView) {
	const declarationView = getDeclarationView(lView);
	const nodes = leavingNodes.get(tNode);
	if (nodes) {
		if (!nodes.some((node) => node.el === el)) nodes.push({
			el,
			declarationView
		});
	} else leavingNodes.set(tNode, [{
		el,
		declarationView
	}]);
}
var TracingAction;
(function(TracingAction) {
	TracingAction[TracingAction["CHANGE_DETECTION"] = 0] = "CHANGE_DETECTION";
	TracingAction[TracingAction["AFTER_NEXT_RENDER"] = 1] = "AFTER_NEXT_RENDER";
})(TracingAction || (TracingAction = {}));
var TracingService = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "TracingService" : "");
var markedFeatures = /* @__PURE__ */ new Set();
function performanceMarkFeature(feature) {
	if (markedFeatures.has(feature)) return;
	markedFeatures.add(feature);
	performance?.mark?.("mark_feature_usage", { detail: { feature } });
}
var AfterRenderManager = class AfterRenderManager {
	impl = null;
	execute() {
		this.impl?.execute();
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: AfterRenderManager,
		providedIn: "root",
		factory: () => new AfterRenderManager()
	});
};
function afterEveryRender(callbackOrSpec, options) {
	ngDevMode && assertNotInReactiveContext(afterEveryRender, "Call `afterEveryRender` outside of a reactive context. For example, schedule the render callback inside the component constructor`.");
	if (ngDevMode && !options?.injector) assertInInjectionContext(afterEveryRender);
	options?.injector ?? inject(Injector);
	return NOOP_AFTER_RENDER_REF;
}
function afterNextRender(callbackOrSpec, options) {
	if (ngDevMode && !options?.injector) assertInInjectionContext(afterNextRender);
	options?.injector ?? inject(Injector);
	return NOOP_AFTER_RENDER_REF;
}
var NOOP_AFTER_RENDER_REF = { destroy() {} };
new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "AnimationQueue" : "", { factory: () => {
	const injector = inject(EnvironmentInjector);
	const queue = /* @__PURE__ */ new Set();
	injector.onDestroy(() => queue.clear());
	return {
		queue,
		isScheduled: false,
		scheduler: null,
		injector
	};
} });
function runLeaveAnimationsWithCallback(lView, tNode, injector, callback) {
	callback(false);
}
function applyToElementOrContainer(action, renderer, injector, parent, lNodeToHandle, tNode, beforeNode, parentLView) {
	if (lNodeToHandle != null) {
		let lContainer;
		let isComponent = false;
		if (isLContainer(lNodeToHandle)) lContainer = lNodeToHandle;
		else if (isLView(lNodeToHandle)) {
			isComponent = true;
			ngDevMode && assertDefined(lNodeToHandle[0], "HOST must be defined for a component LView");
			lNodeToHandle = lNodeToHandle[0];
		}
		const rNode = unwrapRNode(lNodeToHandle);
		if (action === 0 && parent !== null) {
			if (beforeNode == null) nativeAppendChild(renderer, parent, rNode);
			else nativeInsertBefore(renderer, parent, rNode, beforeNode || null, true);
		} else if (action === 1 && parent !== null) {
			nativeInsertBefore(renderer, parent, rNode, beforeNode || null, true);
			cancelLeavingNodes(tNode, rNode, parentLView);
			if (!reusedNodes.has(rNode));
		} else if (action === 2) {
			if (parentLView?.[26]?.leave?.has(tNode.index)) trackLeavingNodes(tNode, rNode, parentLView);
			reusedNodes.delete(rNode);
			runLeaveAnimationsWithCallback(parentLView, tNode, injector, (nodeHasLeaveAnimations) => {
				if (reusedNodes.has(rNode)) {
					reusedNodes.delete(rNode);
					return;
				}
				nativeRemoveNode(renderer, rNode, isComponent, nodeHasLeaveAnimations);
			});
		} else if (action === 3) {
			reusedNodes.delete(rNode);
			runLeaveAnimationsWithCallback(parentLView, tNode, injector, () => {
				renderer.destroyNode(rNode);
			});
		}
		if (lContainer != null) applyContainer(renderer, action, injector, lContainer, tNode, parent, beforeNode);
	}
}
function removeViewFromDOM(tView, lView) {
	detachViewFromDOM(tView, lView);
	lView[0] = null;
	lView[5] = null;
}
function addViewToDOM(tView, parentTNode, renderer, lView, parentNativeNode, beforeNode) {
	lView[0] = parentNativeNode;
	lView[5] = parentTNode;
	applyView(tView, lView, renderer, 1, parentNativeNode, beforeNode);
}
function detachViewFromDOM(tView, lView) {
	lView[10].changeDetectionScheduler?.notify(9);
	applyView(tView, lView, lView[11], 2, null, null);
}
function destroyViewTree(rootView) {
	let lViewOrLContainer = rootView[12];
	if (!lViewOrLContainer) return cleanUpView(rootView[1], rootView);
	while (lViewOrLContainer) {
		let next = null;
		if (isLView(lViewOrLContainer)) next = lViewOrLContainer[12];
		else {
			ngDevMode && assertLContainer(lViewOrLContainer);
			const firstView = lViewOrLContainer[10];
			if (firstView) next = firstView;
		}
		if (!next) {
			while (lViewOrLContainer && !lViewOrLContainer[4] && lViewOrLContainer !== rootView) {
				if (isLView(lViewOrLContainer)) cleanUpView(lViewOrLContainer[1], lViewOrLContainer);
				lViewOrLContainer = lViewOrLContainer[3];
			}
			if (lViewOrLContainer === null) lViewOrLContainer = rootView;
			if (isLView(lViewOrLContainer)) cleanUpView(lViewOrLContainer[1], lViewOrLContainer);
			next = lViewOrLContainer && lViewOrLContainer[4];
		}
		lViewOrLContainer = next;
	}
}
function detachMovedView(declarationContainer, lView) {
	ngDevMode && assertLContainer(declarationContainer);
	ngDevMode && assertDefined(declarationContainer[9], "A projected view should belong to a non-empty projected views collection");
	const movedViews = declarationContainer[9];
	const declarationViewIndex = movedViews.indexOf(lView);
	movedViews.splice(declarationViewIndex, 1);
}
function destroyLView(tView, lView) {
	if (isDestroyed(lView)) return;
	const renderer = lView[11];
	if (renderer.destroyNode) applyView(tView, lView, renderer, 3, null, null);
	destroyViewTree(lView);
}
function cleanUpView(tView, lView) {
	if (isDestroyed(lView)) return;
	const prevConsumer = setActiveConsumer(null);
	try {
		lView[2] &= -129;
		lView[2] |= 256;
		lView[24] && consumerDestroy(lView[24]);
		executeOnDestroys(tView, lView);
		processCleanups(tView, lView);
		if (lView[1].type === 1) lView[11].destroy();
		const declarationContainer = lView[16];
		if (declarationContainer !== null && isLContainer(lView[3])) {
			if (declarationContainer !== lView[3]) detachMovedView(declarationContainer, lView);
			const lQueries = lView[18];
			if (lQueries !== null) lQueries.detachView(tView);
		}
		unregisterLView(lView);
	} finally {
		setActiveConsumer(prevConsumer);
	}
}
function processCleanups(tView, lView) {
	ngDevMode && assertNotReactive(processCleanups.name);
	const tCleanup = tView.cleanup;
	const lCleanup = lView[7];
	if (tCleanup !== null) for (let i = 0; i < tCleanup.length - 1; i += 2) if (typeof tCleanup[i] === "string") {
		const targetIdx = tCleanup[i + 3];
		ngDevMode && assertNumber(targetIdx, "cleanup target must be a number");
		if (targetIdx >= 0) lCleanup[targetIdx]();
		else lCleanup[-targetIdx].unsubscribe();
		i += 2;
	} else {
		const context = lCleanup[tCleanup[i + 1]];
		tCleanup[i].call(context);
	}
	if (lCleanup !== null) lView[7] = null;
	const destroyHooks = lView[21];
	if (destroyHooks !== null) {
		lView[21] = null;
		for (let i = 0; i < destroyHooks.length; i++) {
			const destroyHooksFn = destroyHooks[i];
			ngDevMode && assertFunction(destroyHooksFn, "Expecting destroy hook to be a function.");
			destroyHooksFn();
		}
	}
	const effects = lView[23];
	if (effects !== null) {
		lView[23] = null;
		for (const effect of effects) effect.destroy();
	}
}
function executeOnDestroys(tView, lView) {
	ngDevMode && assertNotReactive(executeOnDestroys.name);
	let destroyHooks;
	if (tView != null && (destroyHooks = tView.destroyHooks) != null) for (let i = 0; i < destroyHooks.length; i += 2) {
		const context = lView[destroyHooks[i]];
		if (!(context instanceof NodeInjectorFactory)) {
			const toCall = destroyHooks[i + 1];
			if (Array.isArray(toCall)) for (let j = 0; j < toCall.length; j += 2) {
				const callContext = context[toCall[j]];
				const hook = toCall[j + 1];
				profiler(ProfilerEvent.LifecycleHookStart, callContext, hook);
				try {
					hook.call(callContext);
				} finally {
					profiler(ProfilerEvent.LifecycleHookEnd, callContext, hook);
				}
			}
			else {
				profiler(ProfilerEvent.LifecycleHookStart, context, toCall);
				try {
					toCall.call(context);
				} finally {
					profiler(ProfilerEvent.LifecycleHookEnd, context, toCall);
				}
			}
		}
	}
}
function getParentRElement(tView, tNode, lView) {
	if (tNode === null) throw new RuntimeError(510, ngDevMode && "getParentRElement() was called with a null TNode, so no parent element could be resolved. This usually means a TNode was never created for this node, or was already destroyed.");
	return getClosestRElement(tView, tNode.parent, lView);
}
function getClosestRElement(tView, tNode, lView) {
	let parentTNode = tNode;
	while (parentTNode !== null && parentTNode.type & 168) {
		tNode = parentTNode;
		parentTNode = tNode.parent;
	}
	if (parentTNode === null) return lView[0];
	else {
		ngDevMode && assertTNodeType(parentTNode, 7);
		if (isComponentHost(parentTNode)) {
			ngDevMode && assertTNodeForLView(parentTNode, lView);
			const { encapsulation } = tView.data[parentTNode.directiveStart + parentTNode.componentOffset];
			if (encapsulation === ViewEncapsulation$1.None || encapsulation === ViewEncapsulation$1.Emulated) return null;
		}
		return getNativeByTNode(parentTNode, lView);
	}
}
function getInsertInFrontOfRNode(parentTNode, currentTNode, lView) {
	return _getInsertInFrontOfRNodeWithI18n(parentTNode, currentTNode, lView);
}
function getInsertInFrontOfRNodeWithNoI18n(parentTNode, currentTNode, lView) {
	if (parentTNode.type & 40) return getNativeByTNode(parentTNode, lView);
	return null;
}
var _getInsertInFrontOfRNodeWithI18n = getInsertInFrontOfRNodeWithNoI18n;
var _processI18nInsertBefore;
function setI18nHandling(getInsertInFrontOfRNodeWithI18n, processI18nInsertBefore) {
	_getInsertInFrontOfRNodeWithI18n = getInsertInFrontOfRNodeWithI18n;
	_processI18nInsertBefore = processI18nInsertBefore;
}
function appendChild(tView, lView, childRNode, childTNode) {
	const parentRNode = getParentRElement(tView, childTNode, lView);
	const renderer = lView[11];
	const anchorNode = getInsertInFrontOfRNode(childTNode.parent || lView[5], childTNode, lView);
	if (parentRNode != null) {
		if (Array.isArray(childRNode)) for (let i = 0; i < childRNode.length; i++) nativeAppendOrInsertBefore(renderer, parentRNode, childRNode[i], anchorNode, false);
		else nativeAppendOrInsertBefore(renderer, parentRNode, childRNode, anchorNode, false);
	}
	_processI18nInsertBefore !== void 0 && _processI18nInsertBefore(renderer, childTNode, lView, childRNode, parentRNode);
}
function getFirstNativeNode(lView, tNode) {
	if (tNode !== null) {
		ngDevMode && assertTNodeType(tNode, 191);
		const tNodeType = tNode.type;
		if (tNodeType & 3) return getNativeByTNode(tNode, lView);
		else if (tNodeType & 4) return getBeforeNodeForView(-1, lView[tNode.index]);
		else if (tNodeType & 8) {
			const elIcuContainerChild = tNode.child;
			if (elIcuContainerChild !== null) return getFirstNativeNode(lView, elIcuContainerChild);
			else {
				const rNodeOrLContainer = lView[tNode.index];
				if (isLContainer(rNodeOrLContainer)) return getBeforeNodeForView(-1, rNodeOrLContainer);
				else return unwrapRNode(rNodeOrLContainer);
			}
		} else if (tNodeType & 128) return getFirstNativeNode(lView, tNode.next);
		else if (tNodeType & 32) return icuContainerIterate(tNode, lView)() || unwrapRNode(lView[tNode.index]);
		else {
			const projectionNodes = getProjectionNodes(lView, tNode);
			if (projectionNodes !== null) {
				if (Array.isArray(projectionNodes)) return projectionNodes[0];
				const parentView = getLViewParent(lView[15]);
				ngDevMode && assertParentView(parentView);
				return getFirstNativeNode(parentView, projectionNodes);
			} else return getFirstNativeNode(lView, tNode.next);
		}
	}
	return null;
}
function getProjectionNodes(lView, tNode) {
	if (tNode !== null) {
		const componentHost = lView[15][5];
		const slotIdx = tNode.projection;
		ngDevMode && assertProjectionSlots(lView);
		return componentHost.projection[slotIdx];
	}
	return null;
}
function getBeforeNodeForView(viewIndexInContainer, lContainer) {
	const nextViewIndex = 10 + viewIndexInContainer + 1;
	if (nextViewIndex < lContainer.length) {
		const lView = lContainer[nextViewIndex];
		const firstTNodeOfView = lView[1].firstChild;
		if (firstTNodeOfView !== null) return getFirstNativeNode(lView, firstTNodeOfView);
	}
	return lContainer[7];
}
function applyNodes(renderer, action, tNode, lView, parentRElement, beforeNode, isProjection) {
	while (tNode != null) {
		ngDevMode && assertTNodeForLView(tNode, lView);
		const injector = lView[9];
		if (tNode.type === 128) {
			tNode = tNode.next;
			continue;
		}
		ngDevMode && assertTNodeType(tNode, 63);
		const rawSlotValue = lView[tNode.index];
		const tNodeType = tNode.type;
		if (isProjection) {
			if (action === 0) {
				rawSlotValue && attachPatchData(unwrapRNode(rawSlotValue), lView);
				tNode.flags |= 2;
			}
		}
		if (!isDetachedByI18n(tNode)) {
			if (tNodeType & 8) {
				applyNodes(renderer, action, tNode.child, lView, parentRElement, beforeNode, false);
				applyToElementOrContainer(action, renderer, injector, parentRElement, rawSlotValue, tNode, beforeNode, lView);
			} else if (tNodeType & 32) {
				const nextRNode = icuContainerIterate(tNode, lView);
				let rNode;
				while (rNode = nextRNode()) applyToElementOrContainer(action, renderer, injector, parentRElement, rNode, tNode, beforeNode, lView);
				applyToElementOrContainer(action, renderer, injector, parentRElement, rawSlotValue, tNode, beforeNode, lView);
			} else if (tNodeType & 16) applyProjectionRecursive(renderer, action, lView, tNode, parentRElement, beforeNode);
			else {
				ngDevMode && assertTNodeType(tNode, 7);
				applyToElementOrContainer(action, renderer, injector, parentRElement, rawSlotValue, tNode, beforeNode, lView);
			}
		}
		tNode = isProjection ? tNode.projectionNext : tNode.next;
	}
}
function applyView(tView, lView, renderer, action, parentRElement, beforeNode) {
	if (tView.type === 3) applyForeignNodes(renderer, action, lView, parentRElement, beforeNode);
	else applyNodes(renderer, action, tView.firstChild, lView, parentRElement, beforeNode, false);
}
function applyForeignNodes(renderer, action, lView, parent, beforeNode) {
	const headTNode = lView[1].firstChild;
	const tailTNode = headTNode.next;
	const head = unwrapRNode(lView[headTNode.index]);
	const tail = unwrapRNode(lView[tailTNode.index]);
	const fragmentSlotIndex = tailTNode.index + 1;
	let fragment = lView[fragmentSlotIndex];
	if (action === 1 || action === 0) {
		if (parent !== null) {
			if (fragment && fragment.hasChildNodes()) nativeInsertBefore(renderer, parent, fragment, beforeNode, true);
			else {
				nativeInsertBefore(renderer, parent, head, beforeNode, true);
				nativeInsertBefore(renderer, parent, tail, beforeNode, true);
			}
		}
	} else if (action === 2) {
		if (!fragment) {
			fragment = document.createDocumentFragment();
			lView[fragmentSlotIndex] = fragment;
		}
		if (head && head.parentNode === fragment) return;
		let current = head;
		while (current !== null) {
			const next = current.nextSibling;
			fragment.appendChild(current);
			if (current === tail) break;
			current = next;
		}
	}
}
function applyProjection(tView, lView, tProjectionNode) {
	const renderer = lView[11];
	applyProjectionRecursive(renderer, 0, lView, tProjectionNode, getParentRElement(tView, tProjectionNode, lView), getInsertInFrontOfRNode(tProjectionNode.parent || lView[5], tProjectionNode, lView));
}
function applyProjectionRecursive(renderer, action, lView, tProjectionNode, parentRElement, beforeNode) {
	const componentLView = lView[15];
	const componentNode = componentLView[5];
	ngDevMode && assertEqual(typeof tProjectionNode.projection, "number", "expecting projection index");
	const nodeToProjectOrRNodes = componentNode.projection[tProjectionNode.projection];
	if (Array.isArray(nodeToProjectOrRNodes)) for (let i = 0; i < nodeToProjectOrRNodes.length; i++) {
		const rNode = nodeToProjectOrRNodes[i];
		applyToElementOrContainer(action, renderer, lView[9], parentRElement, rNode, tProjectionNode, beforeNode, lView);
	}
	else {
		let nodeToProject = nodeToProjectOrRNodes;
		const projectedComponentLView = componentLView[3];
		if (hasInSkipHydrationBlockFlag(tProjectionNode)) nodeToProject.flags |= 128;
		applyNodes(renderer, action, nodeToProject, projectedComponentLView, parentRElement, beforeNode, true);
	}
}
function applyContainer(renderer, action, injector, lContainer, tNode, parentRElement, beforeNode) {
	ngDevMode && assertLContainer(lContainer);
	const anchor = lContainer[7];
	if (anchor !== unwrapRNode(lContainer)) applyToElementOrContainer(action, renderer, injector, parentRElement, anchor, tNode, beforeNode);
	if ((lContainer[2] & 4) !== 0) return;
	for (let i = 10; i < lContainer.length; i++) {
		const lView = lContainer[i];
		applyView(lView[1], lView, renderer, action, parentRElement, anchor);
	}
}
function applyStyling(renderer, isClassBased, rNode, prop, value) {
	if (isClassBased) {
		if (!value) renderer.removeClass(rNode, prop);
		else renderer.addClass(rNode, prop);
	} else {
		let flags = prop.indexOf("-") === -1 ? void 0 : RendererStyleFlags2.DashCase;
		if (value == null) renderer.removeStyle(rNode, prop, flags);
		else {
			if (typeof value === "string" ? value.endsWith("!important") : false) {
				value = value.slice(0, -10);
				flags |= RendererStyleFlags2.Important;
			}
			renderer.setStyle(rNode, prop, value, flags);
		}
	}
}
function createTView(type, declTNode, templateFn, decls, vars, directives, pipes, viewQuery, schemas, constsOrFactory, ssrId) {
	const bindingStartIndex = 28 + decls;
	const initialViewLength = bindingStartIndex + vars;
	const blueprint = createViewBlueprint(bindingStartIndex, initialViewLength);
	const consts = typeof constsOrFactory === "function" ? constsOrFactory() : constsOrFactory;
	const tView = blueprint[1] = {
		type,
		blueprint,
		template: templateFn,
		queries: null,
		viewQuery,
		declTNode,
		data: blueprint.slice().fill(null, bindingStartIndex),
		bindingStartIndex,
		expandoStartIndex: initialViewLength,
		hostBindingOpCodes: null,
		firstCreatePass: true,
		firstUpdatePass: true,
		staticViewQueries: false,
		staticContentQueries: false,
		preOrderHooks: null,
		preOrderCheckHooks: null,
		contentHooks: null,
		contentCheckHooks: null,
		viewHooks: null,
		viewCheckHooks: null,
		destroyHooks: null,
		cleanup: null,
		contentQueries: null,
		components: null,
		directiveRegistry: typeof directives === "function" ? directives() : directives,
		pipeRegistry: typeof pipes === "function" ? pipes() : pipes,
		firstChild: null,
		schemas,
		consts,
		incompleteFirstPass: false,
		ssrId
	};
	if (ngDevMode) Object.seal(tView);
	return tView;
}
function createViewBlueprint(bindingStartIndex, initialViewLength) {
	const blueprint = [];
	for (let i = 0; i < initialViewLength; i++) blueprint.push(i < bindingStartIndex ? null : NO_CHANGE);
	return blueprint;
}
function getOrCreateComponentTView(def) {
	const tView = def.tView;
	if (tView === null || tView.incompleteFirstPass) return def.tView = createTView(1, null, def.template, def.decls, def.vars, def.directiveDefs, def.pipeDefs, def.viewQuery, def.schemas, def.consts, def.id);
	return tView;
}
function createLView(parentLView, tView, context, flags, host, tHostNode, environment, renderer, injector, embeddedViewInjector, hydrationInfo) {
	const lView = tView.blueprint.slice();
	lView[0] = host;
	lView[2] = flags | 1228;
	if (embeddedViewInjector !== null || parentLView && parentLView[2] & 2048) lView[2] |= 2048;
	resetPreOrderHookFlags(lView);
	ngDevMode && tView.declTNode && parentLView && assertTNodeForLView(tView.declTNode, parentLView);
	lView[3] = lView[14] = parentLView;
	lView[8] = context;
	lView[10] = environment || parentLView && parentLView[10];
	ngDevMode && assertDefined(lView[10], "LViewEnvironment is required");
	lView[11] = renderer || parentLView && parentLView[11];
	ngDevMode && assertDefined(lView[11], "Renderer is required");
	lView[9] = injector || parentLView && parentLView[9] || null;
	lView[5] = tHostNode;
	lView[19] = getUniqueLViewId();
	lView[6] = hydrationInfo;
	lView[20] = embeddedViewInjector;
	ngDevMode && assertEqual(tView.type == 2 ? parentLView !== null : true, true, "Embedded views must have parentLView");
	lView[15] = tView.type == 2 ? parentLView[15] : lView;
	return lView;
}
function createComponentLView(lView, hostTNode, def) {
	const native = getNativeByTNode(hostTNode, lView);
	const tView = getOrCreateComponentTView(def);
	const rendererFactory = lView[10].rendererFactory;
	const componentView = addToEndOfViewTree(lView, createLView(lView, tView, null, getInitialLViewFlagsFromDef(def), native, hostTNode, null, rendererFactory.createRenderer(native, def), null, null, null));
	return lView[hostTNode.index] = componentView;
}
function getInitialLViewFlagsFromDef(def) {
	let flags = 16;
	if (def.signals) flags = 4096;
	else if (def.onPush) flags = 64;
	return flags;
}
function allocExpando(tView, lView, numSlotsToAlloc, initialValue) {
	if (numSlotsToAlloc === 0) return -1;
	if (ngDevMode) {
		assertFirstCreatePass(tView);
		assertSame(tView, lView[1], "`LView` must be associated with `TView`!");
		assertEqual(tView.data.length, lView.length, "Expecting LView to be same size as TView");
		assertEqual(tView.data.length, tView.blueprint.length, "Expecting Blueprint to be same size as TView");
		assertFirstUpdatePass(tView);
	}
	const allocIdx = lView.length;
	for (let i = 0; i < numSlotsToAlloc; i++) {
		lView.push(initialValue);
		tView.blueprint.push(initialValue);
		tView.data.push(null);
	}
	return allocIdx;
}
function addToEndOfViewTree(lView, lViewOrLContainer) {
	if (lView[12]) lView[13][4] = lViewOrLContainer;
	else lView[12] = lViewOrLContainer;
	lView[13] = lViewOrLContainer;
	return lViewOrLContainer;
}
function ɵɵadvance(delta = 1) {
	ngDevMode && assertGreaterThan(delta, 0, "Can only advance forward");
	selectIndexInternal(getTView(), getLView(), getSelectedIndex() + delta, !!ngDevMode && isInCheckNoChangesMode());
}
function selectIndexInternal(tView, lView, index, checkNoChangesMode) {
	ngDevMode && assertIndexInDeclRange(lView[1], index);
	if (!checkNoChangesMode) {
		if ((lView[2] & 3) === 3) {
			const preOrderCheckHooks = tView.preOrderCheckHooks;
			if (preOrderCheckHooks !== null) executeCheckHooks(lView, preOrderCheckHooks, index);
		} else {
			const preOrderHooks = tView.preOrderHooks;
			if (preOrderHooks !== null) executeInitAndCheckHooks(lView, preOrderHooks, 0, index);
		}
	}
	setSelectedIndex(index);
}
var InputFlags;
(function(InputFlags) {
	InputFlags[InputFlags["None"] = 0] = "None";
	InputFlags[InputFlags["SignalBased"] = 1] = "SignalBased";
	InputFlags[InputFlags["HasDecoratorInputTransform"] = 2] = "HasDecoratorInputTransform";
})(InputFlags || (InputFlags = {}));
function writeToDirectiveInput(def, instance, publicName, value) {
	const prevConsumer = setActiveConsumer(null);
	try {
		if (ngDevMode) {
			if (!Object.hasOwn(def.inputs, publicName)) throw new Error(`ASSERTION ERROR: Directive ${def.type.name} does not have an input with a public name of "${publicName}"`);
			if (instance instanceof NodeInjectorFactory) throw new Error(`ASSERTION ERROR: Cannot write input to factory for type ${def.type.name}. Directive has not been created yet.`);
		}
		const [privateName, flags, transform] = def.inputs[publicName];
		let inputSignalNode = null;
		if ((flags & InputFlags.SignalBased) !== 0) inputSignalNode = instance[privateName][SIGNAL];
		if (inputSignalNode !== null && inputSignalNode.transformFn !== void 0) value = inputSignalNode.transformFn(value);
		else if (transform !== null) value = transform.call(instance, value);
		if (def.setInput !== null) def.setInput(instance, inputSignalNode, value, publicName, privateName);
		else applyValueToInputField(instance, inputSignalNode, privateName, value);
	} finally {
		setActiveConsumer(prevConsumer);
	}
}
function executeTemplate(tView, lView, templateFn, rf, context) {
	const prevSelectedIndex = getSelectedIndex();
	const isUpdatePhase = rf & 2;
	try {
		setSelectedIndex(-1);
		if (isUpdatePhase && lView.length > 28) selectIndexInternal(tView, lView, 28, !!ngDevMode && isInCheckNoChangesMode());
		profiler(isUpdatePhase ? ProfilerEvent.TemplateUpdateStart : ProfilerEvent.TemplateCreateStart, context, templateFn);
		templateFn(rf, context);
	} finally {
		setSelectedIndex(prevSelectedIndex);
		profiler(isUpdatePhase ? ProfilerEvent.TemplateUpdateEnd : ProfilerEvent.TemplateCreateEnd, context, templateFn);
	}
}
function createDirectivesInstances(tView, lView, tNode) {
	instantiateAllDirectives(tView, lView, tNode);
	if ((tNode.flags & 64) === 64) invokeDirectivesHostBindings(tView, lView, tNode);
}
function saveResolvedLocalsInData(viewData, tNode, localRefExtractor = getNativeByTNode) {
	const localNames = tNode.localNames;
	if (localNames !== null) {
		let localIndex = tNode.index + 1;
		for (let i = 0; i < localNames.length; i += 2) {
			const index = localNames[i + 1];
			const value = index === -1 ? localRefExtractor(tNode, viewData) : viewData[index];
			viewData[localIndex++] = value;
		}
	}
}
function locateHostElement(renderer, elementOrSelector, encapsulation, injector) {
	const preserveContent = injector.get(PRESERVE_HOST_CONTENT, PRESERVE_HOST_CONTENT_DEFAULT) || encapsulation === ViewEncapsulation$1.ShadowDom || encapsulation === ViewEncapsulation$1.ExperimentalIsolatedShadowDom;
	return renderer.selectRootElement(elementOrSelector, preserveContent);
}
function mapPropName(name) {
	if (name === "class") return "className";
	if (name === "for") return "htmlFor";
	if (name === "formaction") return "formAction";
	if (name === "innerHtml") return "innerHTML";
	if (name === "readonly") return "readOnly";
	if (name === "tabindex") return "tabIndex";
	return name;
}
function setPropertyAndInputs(tNode, lView, propName, value, renderer, sanitizer) {
	ngDevMode && assertNotSame(value, NO_CHANGE, "Incoming value should never be NO_CHANGE.");
	const tView = lView[1];
	if (setAllInputsForProperty(tNode, tView, lView, propName, value)) {
		isComponentHost(tNode) && markDirtyIfOnPush(lView, tNode.index);
		ngDevMode && setNgReflectProperties(lView, tView, tNode, propName, value);
		return;
	}
	if (tNode.type & 3) propName = mapPropName(propName);
	setDomProperty(tNode, lView, propName, value, renderer, sanitizer);
}
function setDomProperty(tNode, lView, propName, value, renderer, sanitizer) {
	if (tNode.type & 3) {
		const element = getNativeByTNode(tNode, lView);
		if (ngDevMode) {
			if (lView[1].firstUpdatePass) validateAgainstEventProperties(propName);
			if (!isPropertyValid(element, propName, tNode.value, lView[1].schemas)) handleUnknownPropertyError(propName, tNode.value, tNode.type, lView);
		}
		value = sanitizer != null ? sanitizer(value, tNode.value || "", propName) : value;
		renderer.setProperty(element, propName, value);
	} else if (tNode.type & 12) {
		if (ngDevMode && !matchingSchemas(lView[1].schemas, tNode.value)) handleUnknownPropertyError(propName, tNode.value, tNode.type, lView);
	}
}
function markDirtyIfOnPush(lView, viewIndex) {
	ngDevMode && assertLView(lView);
	const childComponentLView = getComponentLViewByIndex(viewIndex, lView);
	if (!(childComponentLView[2] & 16)) childComponentLView[2] |= 64;
}
function setNgReflectProperty(lView, tNode, attrName, value) {
	if (!lView[10].ngReflect) return;
	const element = getNativeByTNode(tNode, lView);
	const renderer = lView[11];
	attrName = normalizeDebugBindingName(attrName);
	const debugValue = normalizeDebugBindingValue(value);
	if (tNode.type & 3) {
		if (value == null) renderer.removeAttribute(element, attrName);
		else renderer.setAttribute(element, attrName, debugValue);
	} else {
		const textContent = escapeCommentText(`bindings=${JSON.stringify({ [attrName]: debugValue }, null, 2)}`);
		renderer.setValue(element, textContent);
	}
}
function setNgReflectProperties(lView, tView, tNode, publicName, value) {
	if (!lView[10].ngReflect || !(tNode.type & 7)) return;
	const inputConfig = tNode.inputs?.[publicName];
	const hostInputConfig = tNode.hostDirectiveInputs?.[publicName];
	if (hostInputConfig) for (let i = 0; i < hostInputConfig.length; i += 2) {
		const index = hostInputConfig[i];
		const publicName = hostInputConfig[i + 1];
		const def = tView.data[index];
		setNgReflectProperty(lView, tNode, def.inputs[publicName][0], value);
	}
	if (inputConfig) for (const index of inputConfig) {
		const def = tView.data[index];
		setNgReflectProperty(lView, tNode, def.inputs[publicName][0], value);
	}
}
function instantiateAllDirectives(tView, lView, tNode) {
	const start = tNode.directiveStart;
	const end = tNode.directiveEnd;
	if (isComponentHost(tNode)) {
		ngDevMode && assertTNodeType(tNode, 3);
		createComponentLView(lView, tNode, tView.data[start + tNode.componentOffset]);
	}
	if (!tView.firstCreatePass) getOrCreateNodeInjectorForNode(tNode, lView);
	const initialInputs = tNode.initialInputs;
	for (let i = start; i < end; i++) {
		const def = tView.data[i];
		const directive = getNodeInjectable(lView, tView, i, tNode);
		attachPatchData(directive, lView);
		if (initialInputs !== null) setInputsFromAttrs(lView, i - start, directive, def, tNode, initialInputs);
		if (isComponentDef(def)) {
			const componentView = getComponentLViewByIndex(tNode.index, lView);
			componentView[8] = getNodeInjectable(lView, tView, i, tNode);
		}
	}
}
function invokeDirectivesHostBindings(tView, lView, tNode) {
	const start = tNode.directiveStart;
	const end = tNode.directiveEnd;
	const elementIndex = tNode.index;
	const currentDirectiveIndex = getCurrentDirectiveIndex();
	try {
		setSelectedIndex(elementIndex);
		for (let dirIndex = start; dirIndex < end; dirIndex++) {
			const def = tView.data[dirIndex];
			const directive = lView[dirIndex];
			setCurrentDirectiveIndex(dirIndex);
			if (def.hostBindings !== null || def.hostVars !== 0 || def.hostAttrs !== null) invokeHostBindingsInCreationMode(def, directive);
		}
	} finally {
		setSelectedIndex(-1);
		setCurrentDirectiveIndex(currentDirectiveIndex);
	}
}
function invokeHostBindingsInCreationMode(def, directive) {
	if (def.hostBindings !== null) def.hostBindings(1, directive);
}
function findDirectiveDefMatches(tView, tNode) {
	ngDevMode && assertFirstCreatePass(tView);
	ngDevMode && assertTNodeType(tNode, 15);
	const registry = tView.directiveRegistry;
	let matches = null;
	if (registry) for (let i = 0; i < registry.length; i++) {
		const def = registry[i];
		if (isNodeMatchingSelectorList(tNode, def.selectors, false)) {
			matches ??= [];
			if (isComponentDef(def)) {
				if (ngDevMode) {
					assertTNodeType(tNode, 2, `"${tNode.value}" tags cannot be used as component hosts. Please use a different tag to activate the ${stringify(def.type)} component.`);
					if (matches.length && isComponentDef(matches[0])) throwMultipleComponentError(tNode, matches.find(isComponentDef).type, def.type);
				}
				matches.unshift(def);
			} else matches.push(def);
		}
	}
	return matches;
}
function elementAttributeInternal(tNode, lView, name, value, sanitizer, namespace) {
	if (ngDevMode) {
		assertNotSame(value, NO_CHANGE, "Incoming value should never be NO_CHANGE.");
		assertTNodeType(tNode, 2, `Attempted to set attribute \`${name}\` on a container node. Host bindings are not valid on ng-container or ng-template.`);
	}
	const element = getNativeByTNode(tNode, lView);
	setElementAttribute(lView[11], element, namespace, tNode.value, name, value, sanitizer);
}
function setElementAttribute(renderer, element, namespace, tagName, name, value, sanitizer) {
	if (value == null) {
		if (sanitizer != null) sanitizer(value, tagName || "", name);
		renderer.removeAttribute(element, name, namespace);
	} else {
		const strValue = sanitizer == null ? renderStringify(value) : sanitizer(value, tagName || "", name);
		renderer.setAttribute(element, name, strValue, namespace);
	}
}
function setInputsFromAttrs(lView, directiveIndex, instance, def, tNode, initialInputData) {
	const initialInputs = initialInputData[directiveIndex];
	if (initialInputs !== null) for (let i = 0; i < initialInputs.length; i += 2) {
		const lookupName = initialInputs[i];
		const value = initialInputs[i + 1];
		writeToDirectiveInput(def, instance, lookupName, value);
		if (ngDevMode) setNgReflectProperty(lView, tNode, def.inputs[lookupName][0], value);
	}
}
function elementLikeStartShared(tNode, lView, index, name, locateOrCreateNativeNode) {
	const adjustedIndex = 28 + index;
	const tView = lView[1];
	const native = locateOrCreateNativeNode(tView, lView, tNode, name, index);
	lView[adjustedIndex] = native;
	setCurrentTNode(tNode, true);
	const isElement = tNode.type === 2;
	if (isElement) {
		setupStaticAttributes(lView[11], native, tNode);
		if (getElementDepthCount() === 0 || isDirectiveHost(tNode)) attachPatchData(native, lView);
		increaseElementDepthCount();
	} else attachPatchData(native, lView);
	if (wasLastNodeCreated() && (!isElement || !isDetachedByI18n(tNode))) appendChild(tView, lView, native, tNode);
	return tNode;
}
function elementLikeEndShared(tNode) {
	let currentTNode = tNode;
	if (isCurrentTNodeParent()) setCurrentTNodeAsNotParent();
	else {
		ngDevMode && assertHasParent(getCurrentTNode());
		currentTNode = currentTNode.parent;
		setCurrentTNode(currentTNode, false);
	}
	return currentTNode;
}
function storePropertyBindingMetadata(tData, tNode, propertyName, bindingIndex, ...interpolationParts) {
	if (tData[bindingIndex] === null) {
		if (!tNode.inputs?.[propertyName] && !tNode.hostDirectiveInputs?.[propertyName]) {
			(tNode.propertyBindings || (tNode.propertyBindings = [])).push(bindingIndex);
			let bindingMetadata = propertyName;
			if (interpolationParts.length > 0) bindingMetadata += INTERPOLATION_DELIMITER + interpolationParts.join(INTERPOLATION_DELIMITER);
			tData[bindingIndex] = bindingMetadata;
		}
	}
}
function loadComponentRenderer(currentDef, tNode, lView) {
	if (currentDef === null || isComponentDef(currentDef)) lView = unwrapLView(lView[tNode.index]);
	return lView[11];
}
function handleUncaughtError(lView, error) {
	const injector = lView[9];
	if (!injector) return;
	let errorHandler;
	try {
		errorHandler = injector.get(INTERNAL_APPLICATION_ERROR_HANDLER, null);
	} catch {
		errorHandler = null;
	}
	errorHandler?.(error);
}
function setAllInputsForProperty(tNode, tView, lView, publicName, value) {
	const inputs = tNode.inputs?.[publicName];
	const hostDirectiveInputs = tNode.hostDirectiveInputs?.[publicName];
	let hasMatch = false;
	if (hostDirectiveInputs) for (let i = 0; i < hostDirectiveInputs.length; i += 2) {
		const index = hostDirectiveInputs[i];
		ngDevMode && assertIndexInRange(lView, index);
		const publicName = hostDirectiveInputs[i + 1];
		const def = tView.data[index];
		writeToDirectiveInput(def, lView[index], publicName, value);
		hasMatch = true;
	}
	if (inputs) for (const index of inputs) {
		ngDevMode && assertIndexInRange(lView, index);
		const instance = lView[index];
		const def = tView.data[index];
		writeToDirectiveInput(def, instance, publicName, value);
		hasMatch = true;
	}
	return hasMatch;
}
function setDirectiveInput(tNode, tView, lView, target, publicName, value) {
	let hostIndex = null;
	let hostDirectivesStart = null;
	let hostDirectivesEnd = null;
	let hasSet = false;
	if (ngDevMode && !tNode.directiveToIndex?.has(target.type)) throw new Error(`Node does not have a directive with type ${target.type.name}`);
	const data = tNode.directiveToIndex.get(target.type);
	if (typeof data === "number") hostIndex = data;
	else [hostIndex, hostDirectivesStart, hostDirectivesEnd] = data;
	if (hostDirectivesStart !== null && hostDirectivesEnd !== null && tNode.hostDirectiveInputs && Object.hasOwn(tNode.hostDirectiveInputs, publicName)) {
		const hostDirectiveInputs = tNode.hostDirectiveInputs[publicName];
		for (let i = 0; i < hostDirectiveInputs.length; i += 2) {
			const index = hostDirectiveInputs[i];
			if (index >= hostDirectivesStart && index <= hostDirectivesEnd) {
				ngDevMode && assertIndexInRange(lView, index);
				const def = tView.data[index];
				const hostDirectivePublicName = hostDirectiveInputs[i + 1];
				writeToDirectiveInput(def, lView[index], hostDirectivePublicName, value);
				hasSet = true;
			} else if (index > hostDirectivesEnd) break;
		}
	}
	if (hostIndex !== null && Object.hasOwn(target.inputs, publicName)) {
		ngDevMode && assertIndexInRange(lView, hostIndex);
		writeToDirectiveInput(target, lView[hostIndex], publicName, value);
		hasSet = true;
	}
	return hasSet;
}
function renderComponent(hostLView, componentHostIdx) {
	ngDevMode && assertEqual(isCreationMode(hostLView), true, "Should be run in creation mode");
	const componentView = getComponentLViewByIndex(componentHostIdx, hostLView);
	const componentTView = componentView[1];
	syncViewWithBlueprint(componentTView, componentView);
	const hostRNode = componentView[0];
	if (hostRNode !== null && componentView[6] === null) componentView[6] = retrieveHydrationInfo(hostRNode, componentView[9]);
	profiler(ProfilerEvent.ComponentStart);
	try {
		renderView(componentTView, componentView, componentView[8]);
	} finally {
		profiler(ProfilerEvent.ComponentEnd, componentView[8]);
	}
}
function syncViewWithBlueprint(tView, lView) {
	for (let i = lView.length; i < tView.blueprint.length; i++) lView.push(tView.blueprint[i]);
}
function renderView(tView, lView, context) {
	ngDevMode && assertEqual(isCreationMode(lView), true, "Should be run in creation mode");
	ngDevMode && assertNotReactive(renderView.name);
	enterView(lView);
	try {
		const viewQuery = tView.viewQuery;
		if (viewQuery !== null) executeViewQueryFn(1, viewQuery, context);
		const templateFn = tView.template;
		if (templateFn !== null) executeTemplate(tView, lView, templateFn, 1, context);
		if (tView.firstCreatePass) tView.firstCreatePass = false;
		lView[18]?.finishViewCreation(tView);
		if (tView.staticContentQueries) refreshContentQueries(tView, lView);
		if (tView.staticViewQueries) executeViewQueryFn(2, tView.viewQuery, context);
		const components = tView.components;
		if (components !== null) renderChildComponents(lView, components);
	} catch (error) {
		if (tView.firstCreatePass) {
			tView.incompleteFirstPass = true;
			tView.firstCreatePass = false;
		}
		throw error;
	} finally {
		lView[2] &= -5;
		leaveView();
	}
}
function renderChildComponents(hostLView, components) {
	for (let i = 0; i < components.length; i++) renderComponent(hostLView, components[i]);
}
function createAndRenderEmbeddedLView(declarationLView, templateTNode, context, options) {
	const prevConsumer = setActiveConsumer(null);
	try {
		const embeddedTView = templateTNode.tView;
		ngDevMode && assertDefined(embeddedTView, "TView must be defined for a template node.");
		ngDevMode && assertTNodeForLView(templateTNode, declarationLView);
		const embeddedLView = createLView(declarationLView, embeddedTView, context, declarationLView[2] & 4096 ? 4096 : 16, null, templateTNode, null, null, options?.injector ?? null, options?.embeddedViewInjector ?? null, options?.dehydratedView ?? null);
		const declarationLContainer = declarationLView[templateTNode.index];
		ngDevMode && assertLContainer(declarationLContainer);
		embeddedLView[16] = declarationLContainer;
		const declarationViewLQueries = declarationLView[18];
		if (declarationViewLQueries !== null) embeddedLView[18] = declarationViewLQueries.createEmbeddedView(embeddedTView);
		renderView(embeddedTView, embeddedLView, context);
		return embeddedLView;
	} finally {
		setActiveConsumer(prevConsumer);
	}
}
function shouldAddViewToDom(tNode, dehydratedView) {
	return !dehydratedView || dehydratedView.firstChild === null || hasInSkipHydrationBlockFlag(tNode);
}
var USE_EXHAUSTIVE_CHECK_NO_CHANGES_DEFAULT = false;
var UseExhaustiveCheckNoChanges = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "exhaustive checkNoChanges" : "");
function collectNativeNodes(tView, lView, tNode, result, isProjection = false) {
	if (tView.type === 3) {
		const headTNode = tView.firstChild;
		const tailTNode = headTNode.next;
		const head = unwrapRNode(lView[headTNode.index]);
		const tail = unwrapRNode(lView[tailTNode.index]);
		let current = head;
		while (current !== null) {
			result.push(current);
			if (current === tail) break;
			current = current.nextSibling;
		}
		return result;
	}
	while (tNode !== null) {
		if (tNode.type === 128) {
			tNode = isProjection ? tNode.projectionNext : tNode.next;
			continue;
		}
		ngDevMode && assertTNodeType(tNode, 63);
		const lNode = lView[tNode.index];
		if (lNode !== null) {
			if (isLContainer(lNode)) {
				const anchor = lNode[7];
				if (anchor !== lNode[0]) result.push(unwrapRNode(lNode));
				if (!(lNode[2] & 4)) collectNativeNodesInLContainer(lNode, result);
				result.push(anchor);
			} else result.push(unwrapRNode(lNode));
		}
		const tNodeType = tNode.type;
		if (tNodeType & 8) collectNativeNodes(tView, lView, tNode.child, result);
		else if (tNodeType & 32) {
			const nextRNode = icuContainerIterate(tNode, lView);
			let rNode;
			while (rNode = nextRNode()) result.push(rNode);
		} else if (tNodeType & 16) {
			const nodesInSlot = getProjectionNodes(lView, tNode);
			if (Array.isArray(nodesInSlot)) result.push(...nodesInSlot);
			else {
				const parentView = getLViewParent(lView[15]);
				ngDevMode && assertParentView(parentView);
				collectNativeNodes(parentView[1], parentView, nodesInSlot, result, true);
			}
		}
		tNode = isProjection ? tNode.projectionNext : tNode.next;
	}
	return result;
}
function collectNativeNodesInLContainer(lContainer, result) {
	for (let i = 10; i < lContainer.length; i++) {
		const lViewInAContainer = lContainer[i];
		const lViewFirstChildTNode = lViewInAContainer[1].firstChild;
		if (lViewFirstChildTNode !== null) collectNativeNodes(lViewInAContainer[1], lViewInAContainer, lViewFirstChildTNode, result);
	}
}
function addAfterRenderSequencesForView(lView) {
	if (lView[25] !== null) {
		for (const sequence of lView[25]) sequence.impl.addSequence(sequence);
		lView[25].length = 0;
	}
}
var freeConsumers = [];
function getOrBorrowReactiveLViewConsumer(lView) {
	return lView[24] ?? borrowReactiveLViewConsumer(lView);
}
function borrowReactiveLViewConsumer(lView) {
	const consumer = freeConsumers.pop() ?? Object.create(REACTIVE_LVIEW_CONSUMER_NODE);
	consumer.lView = lView;
	return consumer;
}
function maybeReturnReactiveLViewConsumer(consumer) {
	if (consumer.lView[24] === consumer) return;
	consumer.lView = null;
	freeConsumers.push(consumer);
}
var REACTIVE_LVIEW_CONSUMER_NODE = {
	...REACTIVE_NODE,
	consumerIsAlwaysLive: true,
	kind: "template",
	consumerMarkedDirty: (node) => {
		markAncestorsForTraversal(node.lView);
	},
	consumerOnSignalRead() {
		this.lView[24] = this;
	}
};
function getOrCreateTemporaryConsumer(lView) {
	const consumer = lView[24] ?? Object.create(TEMPORARY_CONSUMER_NODE);
	consumer.lView = lView;
	return consumer;
}
var TEMPORARY_CONSUMER_NODE = {
	...REACTIVE_NODE,
	consumerIsAlwaysLive: true,
	kind: "template",
	consumerMarkedDirty: (node) => {
		let parent = getLViewParent(node.lView);
		while (parent && !viewShouldHaveReactiveConsumer(parent[1])) parent = getLViewParent(parent);
		if (!parent) return;
		markViewForRefresh(parent);
	},
	consumerOnSignalRead() {
		this.lView[24] = this;
	}
};
function viewShouldHaveReactiveConsumer(tView) {
	return tView.type !== 2;
}
function isReactiveLViewConsumer(node) {
	return node.kind === "template";
}
function runEffectsInView(view) {
	if (view[23] === null) return;
	let tryFlushEffects = true;
	while (tryFlushEffects) {
		let foundDirtyEffect = false;
		for (const effect of view[23]) {
			if (!effect.dirty) continue;
			foundDirtyEffect = true;
			if (effect.zone === null || Zone.current === effect.zone) effect.run();
			else effect.zone.run(() => effect.run());
			if (view[23] === null) return;
		}
		tryFlushEffects = foundDirtyEffect && !!(view[2] & 8192);
	}
}
var MAXIMUM_REFRESH_RERUNS$1 = 100;
function detectChangesInternal(lView, mode = 0) {
	const rendererFactory = lView[10].rendererFactory;
	const checkNoChangesMode = !!ngDevMode && isInCheckNoChangesMode();
	if (!checkNoChangesMode) rendererFactory.begin?.();
	try {
		detectChangesInViewWhileDirty(lView, mode);
	} finally {
		if (!checkNoChangesMode) rendererFactory.end?.();
	}
}
function detectChangesInViewWhileDirty(lView, mode) {
	const lastIsRefreshingViewsValue = isRefreshingViews();
	try {
		setIsRefreshingViews(true);
		detectChangesInView(lView, mode);
		if (ngDevMode && isExhaustiveCheckNoChanges()) return;
		let retries = 0;
		while (requiresRefreshOrTraversal(lView)) {
			if (retries === MAXIMUM_REFRESH_RERUNS$1) throw new RuntimeError(103, ngDevMode && "Infinite change detection while trying to refresh views. There may be components which each cause the other to require a refresh, causing an infinite loop.");
			retries++;
			detectChangesInView(lView, 1);
		}
	} finally {
		setIsRefreshingViews(lastIsRefreshingViewsValue);
	}
}
function checkNoChangesInternal(lView, exhaustive) {
	setIsInCheckNoChangesMode(exhaustive ? CheckNoChangesMode.Exhaustive : CheckNoChangesMode.OnlyDirtyViews);
	try {
		detectChangesInternal(lView);
	} finally {
		setIsInCheckNoChangesMode(CheckNoChangesMode.Off);
	}
}
function refreshView(tView, lView, templateFn, context) {
	ngDevMode && assertEqual(isCreationMode(lView), false, "Should be run in update mode");
	if (isDestroyed(lView)) return;
	const flags = lView[2];
	const isInCheckNoChangesPass = ngDevMode && isInCheckNoChangesMode();
	const isInExhaustiveCheckNoChangesPass = ngDevMode && isExhaustiveCheckNoChanges();
	enterView(lView);
	let returnConsumerToPool = true;
	let prevConsumer = null;
	let currentConsumer = null;
	if (!isInCheckNoChangesPass) {
		if (viewShouldHaveReactiveConsumer(tView)) {
			currentConsumer = getOrBorrowReactiveLViewConsumer(lView);
			prevConsumer = consumerBeforeComputation(currentConsumer);
		} else if (getActiveConsumer() === null) {
			returnConsumerToPool = false;
			currentConsumer = getOrCreateTemporaryConsumer(lView);
			prevConsumer = consumerBeforeComputation(currentConsumer);
		} else if (lView[24]) {
			consumerDestroy(lView[24]);
			lView[24] = null;
		}
	}
	try {
		resetPreOrderHookFlags(lView);
		setBindingIndex(tView.bindingStartIndex);
		if (templateFn !== null) executeTemplate(tView, lView, templateFn, 2, context);
		const hooksInitPhaseCompleted = (flags & 3) === 3;
		if (!isInCheckNoChangesPass) {
			if (hooksInitPhaseCompleted) {
				const preOrderCheckHooks = tView.preOrderCheckHooks;
				if (preOrderCheckHooks !== null) executeCheckHooks(lView, preOrderCheckHooks, null);
			} else {
				const preOrderHooks = tView.preOrderHooks;
				if (preOrderHooks !== null) executeInitAndCheckHooks(lView, preOrderHooks, 0, null);
				incrementInitPhaseFlags(lView, 0);
			}
		}
		if (!isInExhaustiveCheckNoChangesPass) markTransplantedViewsForRefresh(lView);
		runEffectsInView(lView);
		detectChangesInEmbeddedViews(lView, 0);
		if (tView.contentQueries !== null) refreshContentQueries(tView, lView);
		if (!isInCheckNoChangesPass) {
			if (hooksInitPhaseCompleted) {
				const contentCheckHooks = tView.contentCheckHooks;
				if (contentCheckHooks !== null) executeCheckHooks(lView, contentCheckHooks);
			} else {
				const contentHooks = tView.contentHooks;
				if (contentHooks !== null) executeInitAndCheckHooks(lView, contentHooks, 1);
				incrementInitPhaseFlags(lView, 1);
			}
		}
		processHostBindingOpCodes(tView, lView);
		const components = tView.components;
		if (components !== null) detectChangesInChildComponents(lView, components, 0);
		const viewQuery = tView.viewQuery;
		if (viewQuery !== null) executeViewQueryFn(2, viewQuery, context);
		if (!isInCheckNoChangesPass) {
			if (hooksInitPhaseCompleted) {
				const viewCheckHooks = tView.viewCheckHooks;
				if (viewCheckHooks !== null) executeCheckHooks(lView, viewCheckHooks);
			} else {
				const viewHooks = tView.viewHooks;
				if (viewHooks !== null) executeInitAndCheckHooks(lView, viewHooks, 2);
				incrementInitPhaseFlags(lView, 2);
			}
		}
		if (tView.firstUpdatePass === true) tView.firstUpdatePass = false;
		if (lView[22]) {
			for (const notifyEffect of lView[22]) notifyEffect();
			lView[22] = null;
		}
		if (!isInCheckNoChangesPass) {
			addAfterRenderSequencesForView(lView);
			lView[2] &= -73;
		}
	} catch (e) {
		let handled = false;
		let errorToHandle = e;
		let currentLView = lView;
		while (currentLView !== null) {
			if (isLContainer(currentLView)) {
				currentLView = currentLView[3];
				continue;
			}
			const onError = currentLView[27];
			if (onError) try {
				const declarationInstance = lView[15][8];
				const details = {
					declarationInstance,
					declarationType: declarationInstance?.constructor,
					caughtBy: onError
				};
				onError(encapsulateBoundaryError(errorToHandle), details);
				handled = true;
				break;
			} catch (boundaryError) {
				errorToHandle = boundaryError;
			}
			currentLView = currentLView[3];
		}
		if (!handled) {
			if (!isInCheckNoChangesPass) markAncestorsForTraversal(lView);
			throw errorToHandle;
		}
	} finally {
		if (currentConsumer !== null) {
			consumerAfterComputation(currentConsumer, prevConsumer);
			if (returnConsumerToPool) maybeReturnReactiveLViewConsumer(currentConsumer);
		}
		leaveView();
	}
}
function detectChangesInEmbeddedViews(lView, mode) {
	for (let lContainer = getFirstLContainer(lView); lContainer !== null; lContainer = getNextLContainer(lContainer)) for (let i = 10; i < lContainer.length; i++) {
		const embeddedLView = lContainer[i];
		detectChangesInViewIfAttached(embeddedLView, mode);
	}
}
function markTransplantedViewsForRefresh(lView) {
	for (let lContainer = getFirstLContainer(lView); lContainer !== null; lContainer = getNextLContainer(lContainer)) {
		if (!(lContainer[2] & 2)) continue;
		const movedViews = lContainer[9];
		ngDevMode && assertDefined(movedViews, "Transplanted View flags set but missing MOVED_VIEWS");
		for (let i = 0; i < movedViews.length; i++) {
			const movedLView = movedViews[i];
			markViewForRefresh(movedLView);
		}
	}
}
function detectChangesInComponent(hostLView, componentHostIdx, mode) {
	ngDevMode && assertEqual(isCreationMode(hostLView), false, "Should be run in update mode");
	profiler(ProfilerEvent.ComponentStart);
	const componentView = getComponentLViewByIndex(componentHostIdx, hostLView);
	try {
		detectChangesInViewIfAttached(componentView, mode);
	} finally {
		profiler(ProfilerEvent.ComponentEnd, componentView[8]);
	}
}
function detectChangesInViewIfAttached(lView, mode) {
	if (!viewAttachedToChangeDetector(lView)) return;
	detectChangesInView(lView, mode);
}
function detectChangesInView(lView, mode) {
	const isInCheckNoChangesPass = ngDevMode && isInCheckNoChangesMode();
	const tView = lView[1];
	const flags = lView[2];
	const consumer = lView[24];
	let shouldRefreshView = !!(mode === 0 && flags & 16);
	shouldRefreshView ||= !!(flags & 64 && mode === 0 && !isInCheckNoChangesPass);
	shouldRefreshView ||= !!(flags & 1024);
	shouldRefreshView ||= !!(consumer?.dirty && consumerPollProducersForChange(consumer));
	shouldRefreshView ||= !!(ngDevMode && isExhaustiveCheckNoChanges());
	if (consumer) consumer.dirty = false;
	lView[2] &= -9217;
	if (shouldRefreshView) refreshView(tView, lView, tView.template, lView[8]);
	else if (flags & 8192) {
		const prevConsumer = setActiveConsumer(null);
		try {
			if (!isInCheckNoChangesPass) runEffectsInView(lView);
			detectChangesInEmbeddedViews(lView, 1);
			const components = tView.components;
			if (components !== null) detectChangesInChildComponents(lView, components, 1);
			if (!isInCheckNoChangesPass) addAfterRenderSequencesForView(lView);
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
}
function detectChangesInChildComponents(hostLView, components, mode) {
	for (let i = 0; i < components.length; i++) detectChangesInComponent(hostLView, components[i], mode);
}
function processHostBindingOpCodes(tView, lView) {
	const hostBindingOpCodes = tView.hostBindingOpCodes;
	if (hostBindingOpCodes === null) return;
	try {
		for (let i = 0; i < hostBindingOpCodes.length; i++) {
			const opCode = hostBindingOpCodes[i];
			if (opCode < 0) setSelectedIndex(~opCode);
			else {
				const directiveIdx = opCode;
				const bindingRootIndx = hostBindingOpCodes[++i];
				const hostBindingFn = hostBindingOpCodes[++i];
				setBindingRootForHostBindings(bindingRootIndx, directiveIdx);
				const context = lView[directiveIdx];
				profiler(ProfilerEvent.HostBindingsUpdateStart, context);
				try {
					hostBindingFn(2, context);
				} finally {
					profiler(ProfilerEvent.HostBindingsUpdateEnd, context);
				}
			}
		}
	} finally {
		setSelectedIndex(-1);
	}
}
function markViewDirty(lView, source) {
	const dirtyBitsToUse = isRefreshingViews() ? 64 : 1088;
	lView[10].changeDetectionScheduler?.notify(source);
	while (lView) {
		lView[2] |= dirtyBitsToUse;
		const parent = getLViewParent(lView);
		if (isRootView(lView) && !parent) return lView;
		lView = parent;
	}
	return null;
}
function createLContainer(hostNative, currentView, native, tNode) {
	ngDevMode && assertLView(currentView);
	const lContainer = [
		hostNative,
		true,
		0,
		currentView,
		null,
		tNode,
		null,
		native,
		null,
		null
	];
	ngDevMode && assertEqual(lContainer.length, 10, "Should allocate correct number of slots for LContainer header.");
	return lContainer;
}
function getLViewFromLContainer(lContainer, index) {
	const adjustedIndex = 10 + index;
	if (adjustedIndex < lContainer.length) {
		const lView = lContainer[adjustedIndex];
		ngDevMode && assertLView(lView);
		return lView;
	}
}
function addLViewToLContainer(lContainer, lView, index, addToDOM = true) {
	const tView = lView[1];
	insertView(tView, lView, lContainer, index);
	if (addToDOM) {
		const beforeNode = getBeforeNodeForView(index, lContainer);
		const renderer = lView[11];
		const parentRNode = renderer.parentNode(lContainer[7]);
		if (parentRNode !== null) addViewToDOM(tView, lContainer[5], renderer, lView, parentRNode, beforeNode);
	}
	const hydrationInfo = lView[6];
	if (hydrationInfo !== null && hydrationInfo.firstChild !== null) hydrationInfo.firstChild = null;
}
function removeLViewFromLContainer(lContainer, index) {
	const lView = detachView(lContainer, index);
	if (lView !== void 0) destroyLView(lView[1], lView);
	return lView;
}
function detachView(lContainer, removeIndex) {
	if (lContainer.length <= 10) return;
	const indexInContainer = 10 + removeIndex;
	const viewToDetach = lContainer[indexInContainer];
	if (viewToDetach) {
		const declarationLContainer = viewToDetach[16];
		if (declarationLContainer !== null && declarationLContainer !== lContainer) detachMovedView(declarationLContainer, viewToDetach);
		if (removeIndex > 0) lContainer[indexInContainer - 1][4] = viewToDetach[4];
		const removedLView = removeFromArray(lContainer, 10 + removeIndex);
		removeViewFromDOM(viewToDetach[1], viewToDetach);
		const lQueries = removedLView[18];
		if (lQueries !== null) lQueries.detachView(removedLView[1]);
		viewToDetach[3] = null;
		viewToDetach[4] = null;
		viewToDetach[2] &= -129;
	}
	return viewToDetach;
}
function insertView(tView, lView, lContainer, index) {
	ngDevMode && assertLView(lView);
	ngDevMode && assertLContainer(lContainer);
	const indexInContainer = 10 + index;
	const containerLength = lContainer.length;
	if (index > 0) lContainer[indexInContainer - 1][4] = lView;
	if (index < containerLength - 10) {
		lView[4] = lContainer[indexInContainer];
		addToArray(lContainer, 10 + index, lView);
	} else {
		lContainer.push(lView);
		lView[4] = null;
	}
	lView[3] = lContainer;
	const declarationLContainer = lView[16];
	if (declarationLContainer !== null && lContainer !== declarationLContainer) trackMovedView(declarationLContainer, lView);
	const lQueries = lView[18];
	if (lQueries !== null) lQueries.insertView(tView);
	updateAncestorTraversalFlagsOnAttach(lView);
	lView[2] |= 128;
}
function trackMovedView(declarationContainer, lView) {
	ngDevMode && assertDefined(lView, "LView required");
	ngDevMode && assertLContainer(declarationContainer);
	const movedViews = declarationContainer[9];
	const parent = lView[3];
	ngDevMode && assertDefined(parent, "missing parent");
	if (isLView(parent)) declarationContainer[2] |= 2;
	else {
		const insertedComponentLView = parent[3][15];
		ngDevMode && assertDefined(insertedComponentLView, "Missing insertedComponentLView");
		const declaredComponentLView = lView[15];
		ngDevMode && assertDefined(declaredComponentLView, "Missing declaredComponentLView");
		if (declaredComponentLView !== insertedComponentLView) declarationContainer[2] |= 2;
	}
	if (movedViews === null) declarationContainer[9] = [lView];
	else movedViews.push(lView);
}
var ViewRef$1 = class {
	_lView;
	_cdRefInjectingView;
	_appRef = null;
	_attachedToViewContainer = false;
	exhaustive;
	get rootNodes() {
		const lView = this._lView;
		const tView = lView[1];
		return collectNativeNodes(tView, lView, tView.firstChild, []);
	}
	constructor(_lView, _cdRefInjectingView) {
		this._lView = _lView;
		this._cdRefInjectingView = _cdRefInjectingView;
	}
	get context() {
		return this._lView[8];
	}
	set context(value) {
		if (ngDevMode) console.warn("Angular: Replacing the `context` object of an `EmbeddedViewRef` is deprecated.");
		this._lView[8] = value;
	}
	get destroyed() {
		return isDestroyed(this._lView);
	}
	destroy() {
		if (this._appRef) this._appRef.detachView(this);
		else if (this._attachedToViewContainer) {
			const parent = this._lView[3];
			if (isLContainer(parent)) {
				const viewRefs = parent[8];
				const index = viewRefs ? viewRefs.indexOf(this) : -1;
				if (index > -1) {
					ngDevMode && assertEqual(index, parent.indexOf(this._lView) - 10, "An attached view should be in the same position within its container as its ViewRef in the VIEW_REFS array.");
					detachView(parent, index);
					removeFromArray(viewRefs, index);
				}
			}
			this._attachedToViewContainer = false;
		}
		destroyLView(this._lView[1], this._lView);
	}
	onDestroy(callback) {
		storeLViewOnDestroy(this._lView, callback);
	}
	markForCheck() {
		markViewDirty(this._cdRefInjectingView || this._lView, 4);
	}
	detach() {
		this._lView[2] &= -129;
	}
	reattach() {
		updateAncestorTraversalFlagsOnAttach(this._lView);
		this._lView[2] |= 128;
	}
	detectChanges() {
		this._lView[2] |= 1024;
		detectChangesInternal(this._lView);
	}
	checkNoChanges() {
		if (ngDevMode) {
			try {
				this.exhaustive ??= this._lView[9].get(UseExhaustiveCheckNoChanges, USE_EXHAUSTIVE_CHECK_NO_CHANGES_DEFAULT);
			} catch {
				this.exhaustive = USE_EXHAUSTIVE_CHECK_NO_CHANGES_DEFAULT;
			}
			checkNoChangesInternal(this._lView, this.exhaustive);
		}
	}
	attachToViewContainerRef() {
		if (this._appRef) throw new RuntimeError(902, ngDevMode && "This view is already attached directly to the ApplicationRef!");
		this._attachedToViewContainer = true;
	}
	detachFromAppRef() {
		this._appRef = null;
		const isRoot = isRootView(this._lView);
		const declarationContainer = this._lView[16];
		if (declarationContainer !== null && !isRoot) detachMovedView(declarationContainer, this._lView);
		detachViewFromDOM(this._lView[1], this._lView);
	}
	attachToAppRef(appRef) {
		if (this._attachedToViewContainer) throw new RuntimeError(902, ngDevMode && "This view is already attached to a ViewContainer!");
		this._appRef = appRef;
		const isRoot = isRootView(this._lView);
		const declarationContainer = this._lView[16];
		if (declarationContainer !== null && !isRoot) trackMovedView(declarationContainer, this._lView);
		updateAncestorTraversalFlagsOnAttach(this._lView);
	}
};
function isViewDirty(view) {
	return requiresRefreshOrTraversal(view._lView) || !!(view._lView[2] & 64);
}
function markForRefresh(view) {
	markViewForRefresh(view._lView);
}
var TemplateRef = class {
	_declarationLView;
	_declarationTContainer;
	elementRef;
	static __NG_ELEMENT_ID__ = injectTemplateRef;
	constructor(_declarationLView, _declarationTContainer, elementRef) {
		this._declarationLView = _declarationLView;
		this._declarationTContainer = _declarationTContainer;
		this.elementRef = elementRef;
	}
	get ssrId() {
		return this._declarationTContainer.tView?.ssrId || null;
	}
	createEmbeddedView(context, injector) {
		return this.createEmbeddedViewImpl(context, injector);
	}
	createEmbeddedViewImpl(context, injector, dehydratedView) {
		return new ViewRef$1(createAndRenderEmbeddedLView(this._declarationLView, this._declarationTContainer, context, {
			embeddedViewInjector: injector,
			dehydratedView
		}));
	}
};
function injectTemplateRef() {
	return createTemplateRef(getCurrentTNode(), getLView());
}
function createTemplateRef(hostTNode, hostLView) {
	if (hostTNode.type & 4) {
		ngDevMode && assertDefined(hostTNode.tView, "TView must be allocated");
		return new TemplateRef(hostLView, hostTNode, createElementRef(hostTNode, hostLView));
	}
	return null;
}
var AT_THIS_LOCATION = "<-- AT THIS LOCATION";
var THIRD_PARTY_SCRIPTS_URL = `/guide/hydration#third-party-scripts-with-dom-manipulation`;
function getFriendlyStringFromTNodeType(tNodeType) {
	switch (tNodeType) {
		case 4: return "view container";
		case 2: return "element";
		case 8: return "ng-container";
		case 32: return "icu";
		case 64: return "i18n";
		case 16: return "projection";
		case 1: return "text";
		case 128: return "@let";
		default: return "<unknown>";
	}
}
function validateMatchingNode(node, nodeType, tagName, lView, tNode, isViewContainerAnchor = false) {
	if (!node || node.nodeType !== nodeType || node.nodeType === Node.ELEMENT_NODE && node.tagName.toLowerCase() !== tagName?.toLowerCase()) {
		let header = `During hydration Angular expected ${shortRNodeDescription(nodeType, tagName, null)} but `;
		const componentClassName = getDeclarationComponentDef(lView)?.type?.name;
		const expectedDom = describeExpectedDom(lView, tNode, isViewContainerAnchor);
		const expected = `Angular expected this DOM:\n\n${expectedDom}\n\n`;
		let actual = "";
		const componentHostElement = unwrapRNode(lView[0]);
		if (!node) {
			header += `the node was not found.\n\n`;
			markRNodeAsHavingHydrationMismatch(componentHostElement, expectedDom);
		} else {
			const actualNode = shortRNodeDescription(node.nodeType, node.tagName ?? null, node.textContent ?? null);
			header += `found ${actualNode}.\n\n`;
			const actualDom = describeDomFromNode(node);
			actual = `Actual DOM is:\n\n${actualDom}\n\n`;
			markRNodeAsHavingHydrationMismatch(componentHostElement, expectedDom, actualDom);
		}
		const footer = getHydrationErrorFooter(componentClassName);
		let message = header + expected + actual + getHydrationAttributeNote() + footer;
		if (!node || node && isLikelyExternalSourceNode(node)) message += "Note: It looks like this mismatch may have been caused by a third-party script or browser extension that modified the DOM outside of Angular's control. Angular hydration does not support nodes injected or removed outside of the Angular-managed DOM. Note: If you know which element in the DOM this will be inserted, consider adding ngSkipHydration to prevent this error. \n\n";
		throw new RuntimeError(-500, message);
	}
}
function validateSiblingNodeExists(node) {
	validateNodeExists(node);
	if (!node.nextSibling) {
		const header = "During hydration Angular expected more sibling nodes to be present.\n\n";
		const actual = `Actual DOM is:\n\n${describeDomFromNode(node)}\n\n`;
		const footer = getHydrationErrorFooter();
		const message = header + actual + footer;
		markRNodeAsHavingHydrationMismatch(node, "", actual);
		throw new RuntimeError(-501, message);
	}
}
function validateNodeExists(node, lView = null, tNode = null) {
	if (!node) {
		const header = "During hydration, Angular expected an element to be present at this location.\n\n";
		let expected = "";
		let footer = "";
		if (lView !== null && tNode !== null) {
			expected = describeExpectedDom(lView, tNode, false);
			footer = getHydrationErrorFooter();
			markRNodeAsHavingHydrationMismatch(unwrapRNode(lView[0]), expected, "");
		}
		throw new RuntimeError(-502, `${header}${expected}\n\n${footer}`);
	}
}
function nodeNotFoundError(lView, tNode) {
	const header = "During serialization, Angular was unable to find an element in the DOM:\n\n";
	const expected = `${describeExpectedDom(lView, tNode, false)}\n\n`;
	const footer = getHydrationErrorFooter();
	throw new RuntimeError(-502, header + expected + footer);
}
function nodeNotFoundAtPathError(host, path) {
	const header = `During hydration Angular was unable to locate a node using the "${path}" path, starting from the ${describeRNode(host)} node.\n\n`;
	const footer = getHydrationErrorFooter();
	markRNodeAsHavingHydrationMismatch(host);
	throw new RuntimeError(-502, header + footer);
}
function unsupportedProjectionOfDomNodes(rNode) {
	return new RuntimeError(-503, `During serialization, Angular detected DOM nodes that were created outside of Angular context and provided as projectable nodes (likely via \`ViewContainerRef.createComponent\` or \`createComponent\` APIs). Hydration is not supported for such cases, consider refactoring the code to avoid this pattern or using \`ngSkipHydration\` on the host element of the component.

${describeDomFromNode(rNode)}\n\n` + getHydrationAttributeNote());
}
function stringifyTNodeAttrs(tNode) {
	const results = [];
	if (tNode.attrs) for (let i = 0; i < tNode.attrs.length;) {
		const attrName = tNode.attrs[i++];
		if (typeof attrName == "number") break;
		const attrValue = tNode.attrs[i++];
		results.push(`${attrName}="${shorten(attrValue)}"`);
	}
	return results.join(" ");
}
var internalAttrs = /* @__PURE__ */ new Set([
	"ngh",
	"ng-version",
	"ng-server-context"
]);
function stringifyRNodeAttrs(rNode) {
	const results = [];
	for (let i = 0; i < rNode.attributes.length; i++) {
		const attr = rNode.attributes[i];
		if (internalAttrs.has(attr.name)) continue;
		results.push(`${attr.name}="${shorten(attr.value)}"`);
	}
	return results.join(" ");
}
function describeTNode(tNode, innerContent = "…") {
	switch (tNode.type) {
		case 1: return `#text${tNode.value ? `(${tNode.value})` : ""}`;
		case 2:
			const attrs = stringifyTNodeAttrs(tNode);
			const tag = tNode.value.toLowerCase();
			return `<${tag}${attrs ? " " + attrs : ""}>${innerContent}</${tag}>`;
		case 8: return "<!-- ng-container -->";
		case 4: return "<!-- container -->";
		default: return `#node(${getFriendlyStringFromTNodeType(tNode.type)})`;
	}
}
function describeRNode(rNode, innerContent = "…") {
	const node = rNode;
	switch (node.nodeType) {
		case Node.ELEMENT_NODE:
			const tag = node.tagName.toLowerCase();
			const attrs = stringifyRNodeAttrs(node);
			return `<${tag}${attrs ? " " + attrs : ""}>${innerContent}</${tag}>`;
		case Node.TEXT_NODE:
			const content = node.textContent ? shorten(node.textContent) : "";
			return `#text${content ? `(${content})` : ""}`;
		case Node.COMMENT_NODE: return `<!-- ${shorten(node.textContent ?? "")} -->`;
		default: return `#node(${node.nodeType})`;
	}
}
function describeExpectedDom(lView, tNode, isViewContainerAnchor) {
	const spacer = "  ";
	let content = "";
	if (tNode.prev) {
		content += "  …\n";
		content += spacer + describeTNode(tNode.prev) + "\n";
	} else if (tNode.type && tNode.type & 12) content += "  …\n";
	if (isViewContainerAnchor) {
		content += spacer + describeTNode(tNode) + "\n";
		content += `  <!-- container -->  ${AT_THIS_LOCATION}\n`;
	} else content += spacer + describeTNode(tNode) + `  ${AT_THIS_LOCATION}\n`;
	content += "  …\n";
	const parentRNode = tNode.type ? getParentRElement(lView[1], tNode, lView) : null;
	if (parentRNode) content = describeRNode(parentRNode, "\n" + content);
	return content;
}
function describeDomFromNode(node) {
	const spacer = "  ";
	let content = "";
	const currentNode = node;
	if (currentNode.previousSibling) {
		content += "  …\n";
		content += spacer + describeRNode(currentNode.previousSibling) + "\n";
	}
	content += spacer + describeRNode(currentNode) + `  ${AT_THIS_LOCATION}\n`;
	if (node.nextSibling) content += "  …\n";
	if (node.parentNode) content = describeRNode(currentNode.parentNode, "\n" + content);
	return content;
}
function shortRNodeDescription(nodeType, tagName, textContent) {
	switch (nodeType) {
		case Node.ELEMENT_NODE: return `<${tagName.toLowerCase()}>`;
		case Node.TEXT_NODE: return `a text node${textContent ? ` (with the "${shorten(textContent)}" content)` : ""}`;
		case Node.COMMENT_NODE: return "a comment node";
		default: return `#node(nodeType=${nodeType})`;
	}
}
function getHydrationErrorFooter(componentClassName) {
	return `To fix this problem:\n  * check ${componentClassName ? `the "${componentClassName}"` : "corresponding"} component for hydration-related issues\n  * check to see if your template has valid HTML structure\n  * check if there are any third-party scripts that manipulate the DOM. More info: ${DOC_PAGE_BASE_URL}${THIRD_PARTY_SCRIPTS_URL}\n  * or skip hydration by adding the \`ngSkipHydration\` attribute to its host node in a template\n\n`;
}
function isLikelyExternalSourceNode(rNode) {
	const node = rNode;
	if (node.nodeType !== Node.ELEMENT_NODE) return false;
	if (readPatchedData(node)) return false;
	return true;
}
function getHydrationAttributeNote() {
	return "Note: attributes are only displayed to better represent the DOM but have no effect on hydration mismatches.\n\n";
}
function stripNewlines(input) {
	return input.replace(/\s+/gm, "");
}
function shorten(input, maxLength = 50) {
	if (!input) return "";
	input = stripNewlines(input);
	return input.length > maxLength ? `${input.substring(0, maxLength - 1)}…` : input;
}
function describeDomNode(node) {
	const textContent = node.textContent?.slice(0, 50);
	return textContent ? `${node.nodeName} ("${textContent}")` : node.nodeName;
}
function getInsertInFrontOfRNodeWithI18n(parentTNode, currentTNode, lView) {
	const tNodeInsertBeforeIndex = currentTNode.insertBeforeIndex;
	const insertBeforeIndex = Array.isArray(tNodeInsertBeforeIndex) ? tNodeInsertBeforeIndex[0] : tNodeInsertBeforeIndex;
	if (insertBeforeIndex === null) return getInsertInFrontOfRNodeWithNoI18n(parentTNode, currentTNode, lView);
	else {
		ngDevMode && assertIndexInRange(lView, insertBeforeIndex);
		return unwrapRNode(lView[insertBeforeIndex]);
	}
}
function processI18nInsertBefore(renderer, childTNode, lView, childRNode, parentRElement) {
	const tNodeInsertBeforeIndex = childTNode.insertBeforeIndex;
	if (Array.isArray(tNodeInsertBeforeIndex)) {
		ngDevMode && assertDomNode(childRNode);
		let i18nParent = childRNode;
		let anchorRNode = null;
		if (!(childTNode.type & 3)) {
			anchorRNode = i18nParent;
			i18nParent = parentRElement;
		}
		if (i18nParent !== null && childTNode.componentOffset === -1) for (let i = 1; i < tNodeInsertBeforeIndex.length; i++) {
			const i18nChild = lView[tNodeInsertBeforeIndex[i]];
			nativeInsertBefore(renderer, i18nParent, i18nChild, anchorRNode, false);
		}
	}
}
function getOrCreateTNode(tView, index, type, name, attrs) {
	ngDevMode && index !== 0 && assertGreaterThanOrEqual(index, 28, "TNodes can't be in the LView header.");
	ngDevMode && assertPureTNodeType(type);
	let tNode = tView.data[index];
	if (tNode === null) {
		tNode = createTNodeAtIndex(tView, index, type, name, attrs);
		if (isInI18nBlock()) tNode.flags |= 32;
	} else if (tNode.type & 64) {
		tNode.type = type;
		tNode.value = name;
		tNode.attrs = attrs;
		const parent = getCurrentParentTNode();
		tNode.injectorIndex = parent === null ? -1 : parent.injectorIndex;
		ngDevMode && assertTNodeForTView(tNode, tView);
		ngDevMode && assertEqual(index, tNode.index, "Expecting same index");
	}
	setCurrentTNode(tNode, true);
	return tNode;
}
function createTNodeAtIndex(tView, index, type, name, attrs) {
	const currentTNode = getCurrentTNodePlaceholderOk();
	const isParent = isCurrentTNodeParent();
	const parent = isParent ? currentTNode : currentTNode && currentTNode.parent;
	const tNode = tView.data[index] = createTNode(tView, parent, type, index, name, attrs);
	linkTNodeInTView(tView, tNode, currentTNode, isParent);
	return tNode;
}
function linkTNodeInTView(tView, tNode, currentTNode, isParent) {
	if (tView.firstChild === null) tView.firstChild = tNode;
	if (currentTNode !== null) {
		if (isParent) {
			if (currentTNode.child == null && tNode.parent !== null) currentTNode.child = tNode;
		} else if (currentTNode.next === null) {
			currentTNode.next = tNode;
			tNode.prev = currentTNode;
		}
	}
}
function createTNode(tView, tParent, type, index, value, attrs) {
	ngDevMode && index !== 0 && assertGreaterThanOrEqual(index, 28, "TNodes can't be in the LView header.");
	ngDevMode && assertNotSame(attrs, void 0, "'undefined' is not valid value for 'attrs'");
	ngDevMode && tParent && assertTNodeForTView(tParent, tView);
	let injectorIndex = tParent ? tParent.injectorIndex : -1;
	let flags = 0;
	if (isInSkipHydrationBlock$1()) flags |= 128;
	const tNode = {
		type,
		index,
		insertBeforeIndex: null,
		injectorIndex,
		directiveStart: -1,
		directiveEnd: -1,
		directiveStylingLast: -1,
		componentOffset: -1,
		controlDirectiveIndex: -1,
		customControlIndex: -1,
		propertyBindings: null,
		flags,
		providerIndexes: 0,
		value,
		namespace: getNamespace(),
		attrs,
		mergedAttrs: null,
		localNames: null,
		initialInputs: null,
		inputs: null,
		hostDirectiveInputs: null,
		outputs: null,
		hostDirectiveOutputs: null,
		directiveToIndex: null,
		tView: null,
		next: null,
		prev: null,
		projectionNext: null,
		child: null,
		parent: tParent,
		projection: null,
		styles: null,
		stylesWithoutHost: null,
		residualStyles: void 0,
		classes: null,
		classesWithoutHost: null,
		residualClasses: void 0,
		classBindings: 0,
		styleBindings: 0
	};
	if (ngDevMode) Object.seal(tNode);
	return tNode;
}
function addTNodeAndUpdateInsertBeforeIndex(previousTNodes, newTNode) {
	ngDevMode && assertEqual(newTNode.insertBeforeIndex, null, "We expect that insertBeforeIndex is not set");
	previousTNodes.push(newTNode);
	if (previousTNodes.length > 1) for (let i = previousTNodes.length - 2; i >= 0; i--) {
		const existingTNode = previousTNodes[i];
		if (!isI18nText(existingTNode)) {
			if (isNewTNodeCreatedBefore(existingTNode, newTNode) && getInsertBeforeIndex(existingTNode) === null) setInsertBeforeIndex(existingTNode, newTNode.index);
		}
	}
}
function isI18nText(tNode) {
	return !(tNode.type & 64);
}
function isNewTNodeCreatedBefore(existingTNode, newTNode) {
	return isI18nText(newTNode) || existingTNode.index > newTNode.index;
}
function getInsertBeforeIndex(tNode) {
	const index = tNode.insertBeforeIndex;
	return Array.isArray(index) ? index[0] : index;
}
function setInsertBeforeIndex(tNode, value) {
	const index = tNode.insertBeforeIndex;
	if (Array.isArray(index)) index[0] = value;
	else {
		setI18nHandling(getInsertInFrontOfRNodeWithI18n, processI18nInsertBefore);
		tNode.insertBeforeIndex = value;
	}
}
var CURRENT_CASE_LVIEW_INDEX = getClosureSafeProperty({ currentCaseLViewIndex: getClosureSafeProperty });
var TVIEW = getClosureSafeProperty({ tView: getClosureSafeProperty });
function getTIcu(tView, index) {
	const value = tView.data[index];
	if (value === null || typeof value === "string") return null;
	if (ngDevMode && !(Object.hasOwn(value, TVIEW) || Object.hasOwn(value, CURRENT_CASE_LVIEW_INDEX))) throwError("We expect to get 'null'|'TIcu'|'TIcuContainer', but got: " + value);
	const tIcu = Object.hasOwn(value, CURRENT_CASE_LVIEW_INDEX) ? value : value.value;
	ngDevMode && assertTIcu(tIcu);
	return tIcu;
}
function setTIcu(tView, index, tIcu) {
	const tNode = tView.data[index];
	ngDevMode && assertEqual(tNode === null || Object.hasOwn(tNode, TVIEW), true, "We expect to get 'null'|'TIcuContainer'");
	if (tNode === null) tView.data[index] = tIcu;
	else {
		ngDevMode && assertTNodeType(tNode, 32);
		tNode.value = tIcu;
	}
}
function setTNodeInsertBeforeIndex(tNode, index) {
	ngDevMode && assertTNode(tNode);
	let insertBeforeIndex = tNode.insertBeforeIndex;
	if (insertBeforeIndex === null) {
		setI18nHandling(getInsertInFrontOfRNodeWithI18n, processI18nInsertBefore);
		insertBeforeIndex = tNode.insertBeforeIndex = [null, index];
	} else {
		assertEqual(Array.isArray(insertBeforeIndex), true, "Expecting array here");
		insertBeforeIndex.push(index);
	}
}
function createTNodePlaceholder(tView, previousTNodes, index) {
	const tNode = createTNodeAtIndex(tView, index, 64, null, null);
	addTNodeAndUpdateInsertBeforeIndex(previousTNodes, tNode);
	return tNode;
}
function getCurrentICUCaseIndex(tIcu, lView) {
	const currentCase = lView[tIcu.currentCaseLViewIndex];
	return currentCase === null ? currentCase : currentCase < 0 ? ~currentCase : currentCase;
}
function getParentFromIcuCreateOpCode(mergedCode) {
	return mergedCode >>> 17;
}
function getRefFromIcuCreateOpCode(mergedCode) {
	return (mergedCode & 131070) >>> 1;
}
function getInstructionFromIcuCreateOpCode(mergedCode) {
	return mergedCode & 1;
}
function icuCreateOpCode(opCode, parentIdx, refIdx) {
	ngDevMode && assertGreaterThanOrEqual(parentIdx, 0, "Missing parent index");
	ngDevMode && assertGreaterThan(refIdx, 0, "Missing ref index");
	return opCode | parentIdx << 17 | refIdx << 1;
}
function isRootTemplateMessage(subTemplateIndex) {
	return subTemplateIndex === -1;
}
function enterIcu(state, tIcu, lView) {
	state.index = 0;
	const currentCase = getCurrentICUCaseIndex(tIcu, lView);
	if (currentCase !== null) {
		ngDevMode && assertNumberInRange(currentCase, 0, tIcu.cases.length - 1);
		state.removes = tIcu.remove[currentCase];
	} else state.removes = EMPTY_ARRAY;
}
function icuContainerIteratorNext(state) {
	if (state.index < state.removes.length) {
		const removeOpCode = state.removes[state.index++];
		ngDevMode && assertNumber(removeOpCode, "Expecting OpCode number");
		if (removeOpCode > 0) {
			const rNode = state.lView[removeOpCode];
			ngDevMode && assertDomNode(rNode);
			return rNode;
		} else {
			state.stack.push(state.index, state.removes);
			const tIcuIndex = ~removeOpCode;
			const tIcu = state.lView[1].data[tIcuIndex];
			ngDevMode && assertTIcu(tIcu);
			enterIcu(state, tIcu, state.lView);
			return icuContainerIteratorNext(state);
		}
	} else if (state.stack.length === 0) {
		state.lView = void 0;
		return null;
	} else {
		state.removes = state.stack.pop();
		state.index = state.stack.pop();
		return icuContainerIteratorNext(state);
	}
}
function loadIcuContainerVisitor() {
	const _state = {
		stack: [],
		index: -1
	};
	function icuContainerIteratorStart(tIcuContainerNode, lView) {
		_state.lView = lView;
		while (_state.stack.length) _state.stack.pop();
		ngDevMode && assertTNodeForLView(tIcuContainerNode, lView);
		enterIcu(_state, tIcuContainerNode.value, lView);
		return icuContainerIteratorNext.bind(null, _state);
	}
	return icuContainerIteratorStart;
}
function createIcuIterator(tIcu, lView) {
	const state = {
		stack: [],
		index: -1,
		lView
	};
	ngDevMode && assertTIcu(tIcu);
	enterIcu(state, tIcu, lView);
	return icuContainerIteratorNext.bind(null, state);
}
var REF_EXTRACTOR_REGEXP = /* @__PURE__ */ (() => {
	return new RegExp(`^(\\d+)*(${REFERENCE_NODE_BODY}|${REFERENCE_NODE_HOST})*(.*)`);
})();
function compressNodeLocation(referenceNode, path) {
	const result = [referenceNode];
	for (const segment of path) {
		const lastIdx = result.length - 1;
		if (lastIdx > 0 && result[lastIdx - 1] === segment) result[lastIdx] = (result[lastIdx] || 1) + 1;
		else result.push(segment, "");
	}
	return result.join("");
}
function decompressNodeLocation(path) {
	const [_, refNodeId, refNodeName, rest] = path.match(REF_EXTRACTOR_REGEXP);
	const ref = refNodeId ? parseInt(refNodeId, 10) : refNodeName;
	const steps = [];
	for (const [_, step, count] of rest.matchAll(/(f|n)(\d*)/g)) {
		const repeat = parseInt(count, 10) || 1;
		steps.push(step, repeat);
	}
	return [ref, ...steps];
}
function isFirstElementInNgContainer(tNode) {
	return !tNode.prev && tNode.parent?.type === 8;
}
function getNoOffsetIndex(tNode) {
	return tNode.index - 28;
}
function isDisconnectedNode(tNode, lView) {
	return !(tNode.type & 144) && !!lView[tNode.index] && isDisconnectedRNode(unwrapRNode(lView[tNode.index]));
}
function isDisconnectedRNode(rNode) {
	return !!rNode && !rNode.isConnected;
}
function locateI18nRNodeByIndex(hydrationInfo, noOffsetIndex) {
	const i18nNodes = hydrationInfo.i18nNodes;
	if (i18nNodes) return i18nNodes.get(noOffsetIndex);
}
function tryLocateRNodeByPath(hydrationInfo, lView, noOffsetIndex) {
	const path = hydrationInfo.data["n"]?.[noOffsetIndex];
	return path ? locateRNodeByPath(path, lView) : null;
}
function locateNextRNode(hydrationInfo, tView, lView, tNode) {
	const noOffsetIndex = getNoOffsetIndex(tNode);
	let native = locateI18nRNodeByIndex(hydrationInfo, noOffsetIndex);
	if (native === void 0) {
		const nodes = hydrationInfo.data["n"];
		if (nodes?.[noOffsetIndex]) native = locateRNodeByPath(nodes[noOffsetIndex], lView);
		else if (tView.firstChild === tNode) native = hydrationInfo.firstChild;
		else {
			const previousTNodeParent = tNode.prev === null;
			const previousTNode = tNode.prev ?? tNode.parent;
			ngDevMode && assertDefined(previousTNode, "Unexpected state: current TNode does not have a connection to the previous node or a parent node.");
			if (isFirstElementInNgContainer(tNode)) native = getSegmentHead(hydrationInfo, getNoOffsetIndex(tNode.parent));
			else {
				let previousRElement = getNativeByTNode(previousTNode, lView);
				if (previousTNodeParent) native = previousRElement.firstChild;
				else {
					const noOffsetPrevSiblingIndex = getNoOffsetIndex(previousTNode);
					const segmentHead = getSegmentHead(hydrationInfo, noOffsetPrevSiblingIndex);
					if (previousTNode.type === 2 && segmentHead) native = siblingAfter(calcSerializedContainerSize(hydrationInfo, noOffsetPrevSiblingIndex) + 1, segmentHead);
					else native = previousRElement.nextSibling;
				}
			}
		}
	}
	return native;
}
function siblingAfter(skip, from) {
	let currentNode = from;
	for (let i = 0; i < skip; i++) {
		ngDevMode && validateSiblingNodeExists(currentNode);
		if (currentNode == null) throw new RuntimeError(-501, ngDevMode && "During hydration Angular expected more sibling nodes to be present. This usually means the client-rendered DOM no longer matches the server-rendered HTML.");
		currentNode = currentNode.nextSibling;
	}
	return currentNode;
}
function stringifyNavigationInstructions(instructions) {
	const container = [];
	for (let i = 0; i < instructions.length; i += 2) {
		const step = instructions[i];
		const repeat = instructions[i + 1];
		for (let r = 0; r < repeat; r++) container.push(step === NODE_NAVIGATION_STEP_FIRST_CHILD ? "firstChild" : "nextSibling");
	}
	return container.join(".");
}
function navigateToNode(from, instructions) {
	let node = from;
	for (let i = 0; i < instructions.length; i += 2) {
		const step = instructions[i];
		const repeat = instructions[i + 1];
		for (let r = 0; r < repeat; r++) {
			if (ngDevMode && !node) throw nodeNotFoundAtPathError(from, stringifyNavigationInstructions(instructions));
			if (!node) throw new RuntimeError(509, ngDevMode && "During hydration Angular was unable to locate a node using a recorded navigation path. This usually means the client-rendered DOM no longer matches the server-rendered HTML.");
			switch (step) {
				case NODE_NAVIGATION_STEP_FIRST_CHILD:
					node = node.firstChild;
					break;
				case NODE_NAVIGATION_STEP_NEXT_SIBLING: node = node.nextSibling;
			}
		}
	}
	if (ngDevMode && !node) throw nodeNotFoundAtPathError(from, stringifyNavigationInstructions(instructions));
	if (!node) throw new RuntimeError(509, ngDevMode && "During hydration Angular was unable to locate a node using a recorded navigation path. This usually means the client-rendered DOM no longer matches the server-rendered HTML.");
	return node;
}
function locateRNodeByPath(path, lView) {
	const [referenceNode, ...navigationInstructions] = decompressNodeLocation(path);
	let ref;
	if (referenceNode === REFERENCE_NODE_HOST) ref = lView[15][0];
	else if (referenceNode === REFERENCE_NODE_BODY) ref = ɵɵresolveBody(lView[15][0]);
	else ref = unwrapRNode(lView[Number(referenceNode) + 28]);
	return navigateToNode(ref, navigationInstructions);
}
function navigateBetween(start, finish) {
	if (start === finish) return [];
	else if (start.parentElement == null || finish.parentElement == null) return null;
	else if (start.parentElement === finish.parentElement) return navigateBetweenSiblings(start, finish);
	else {
		const parent = finish.parentElement;
		const parentPath = navigateBetween(start, parent);
		const childPath = navigateBetween(parent.firstChild, finish);
		if (!parentPath || !childPath) return null;
		return [
			...parentPath,
			NODE_NAVIGATION_STEP_FIRST_CHILD,
			...childPath
		];
	}
}
function navigateBetweenSiblings(start, finish) {
	const nav = [];
	let node = null;
	for (node = start; node != null && node !== finish; node = node.nextSibling) nav.push(NODE_NAVIGATION_STEP_NEXT_SIBLING);
	return node == null ? null : nav;
}
function calcPathBetween(from, to, fromNodeName) {
	const path = navigateBetween(from, to);
	return path === null ? null : compressNodeLocation(fromNodeName, path);
}
function calcPathForNode(tNode, lView, excludedParentNodes) {
	let parentTNode = tNode.parent;
	let parentIndex;
	let parentRNode;
	let referenceNodeName;
	while (parentTNode !== null && (isDisconnectedNode(parentTNode, lView) || excludedParentNodes?.has(parentTNode.index))) parentTNode = parentTNode.parent;
	if (parentTNode === null || !(parentTNode.type & 3)) {
		parentIndex = referenceNodeName = REFERENCE_NODE_HOST;
		parentRNode = lView[15][0];
	} else {
		parentIndex = parentTNode.index;
		parentRNode = unwrapRNode(lView[parentIndex]);
		referenceNodeName = renderStringify(parentIndex - 28);
	}
	let rNode = unwrapRNode(lView[tNode.index]);
	if (tNode.type & 44) {
		const firstRNode = getFirstNativeNode(lView, tNode);
		if (firstRNode) rNode = firstRNode;
	}
	let path = calcPathBetween(parentRNode, rNode, referenceNodeName);
	if (path === null && parentRNode !== rNode) {
		const body = parentRNode.ownerDocument.body;
		path = calcPathBetween(body, rNode, REFERENCE_NODE_BODY);
		if (path === null) throw nodeNotFoundError(lView, tNode);
	}
	return path;
}
var _isI18nHydrationSupportEnabled = false;
var _prepareI18nBlockForHydrationImpl = () => {};
function setIsI18nHydrationSupportEnabled(enabled) {
	_isI18nHydrationSupportEnabled = enabled;
}
function isI18nHydrationSupportEnabled() {
	return _isI18nHydrationSupportEnabled;
}
function prepareI18nBlockForHydration(lView, index, parentTNode, subTemplateIndex) {
	_prepareI18nBlockForHydrationImpl(lView, index, parentTNode, subTemplateIndex);
}
function enablePrepareI18nBlockForHydrationImpl() {
	_prepareI18nBlockForHydrationImpl = prepareI18nBlockForHydrationImpl;
}
function isI18nHydrationEnabled(injector) {
	injector = injector ?? inject(Injector);
	return injector.get(IS_I18N_HYDRATION_ENABLED, false);
}
function getOrComputeI18nChildren(tView, context) {
	let i18nChildren = context.i18nChildren.get(tView);
	if (i18nChildren === void 0) {
		i18nChildren = collectI18nChildren(tView);
		context.i18nChildren.set(tView, i18nChildren);
	}
	return i18nChildren;
}
function collectI18nChildren(tView) {
	const children = /* @__PURE__ */ new Set();
	function collectI18nViews(node) {
		children.add(node.index);
		switch (node.kind) {
			case 1:
			case 2:
				for (const childNode of node.children) collectI18nViews(childNode);
				break;
			case 3: for (const caseNodes of node.cases) for (const caseNode of caseNodes) collectI18nViews(caseNode);
		}
	}
	for (let i = 28; i < tView.bindingStartIndex; i++) {
		const tI18n = tView.data[i];
		if (!tI18n || !tI18n.ast) continue;
		for (const node of tI18n.ast) collectI18nViews(node);
	}
	return children.size === 0 ? null : children;
}
function trySerializeI18nBlock(lView, index, context) {
	if (!context.isI18nHydrationEnabled) return null;
	const tView = lView[1];
	const tI18n = tView.data[index];
	if (!tI18n || !tI18n.ast) return null;
	const parentTNode = tView.data[tI18n.parentTNodeIndex];
	if (parentTNode && isI18nInSkipHydrationBlock(parentTNode)) return null;
	const serializedI18nBlock = {
		caseQueue: [],
		disconnectedNodes: /* @__PURE__ */ new Set(),
		disjointNodes: /* @__PURE__ */ new Set()
	};
	serializeI18nBlock(lView, serializedI18nBlock, context, tI18n.ast);
	return serializedI18nBlock.caseQueue.length === 0 && serializedI18nBlock.disconnectedNodes.size === 0 && serializedI18nBlock.disjointNodes.size === 0 ? null : serializedI18nBlock;
}
function serializeI18nBlock(lView, serializedI18nBlock, context, nodes) {
	let prevRNode = null;
	for (const node of nodes) {
		const nextRNode = serializeI18nNode(lView, serializedI18nBlock, context, node);
		if (nextRNode) {
			if (isDisjointNode(prevRNode, nextRNode)) serializedI18nBlock.disjointNodes.add(node.index - 28);
			prevRNode = nextRNode;
		}
	}
	return prevRNode;
}
function isDisjointNode(prevNode, nextNode) {
	return prevNode && prevNode.nextSibling !== nextNode;
}
function serializeI18nNode(lView, serializedI18nBlock, context, node) {
	const maybeRNode = unwrapRNode(lView[node.index]);
	if (!maybeRNode || isDisconnectedRNode(maybeRNode)) {
		serializedI18nBlock.disconnectedNodes.add(node.index - 28);
		return null;
	}
	const rNode = maybeRNode;
	switch (node.kind) {
		case 0:
			processTextNodeBeforeSerialization(context, rNode);
			break;
		case 1:
		case 2:
			serializeI18nBlock(lView, serializedI18nBlock, context, node.children);
			break;
		case 3: {
			const currentCase = lView[node.currentCaseLViewIndex];
			if (currentCase != null) {
				const caseIdx = currentCase < 0 ? ~currentCase : currentCase;
				serializedI18nBlock.caseQueue.push(caseIdx);
				serializeI18nBlock(lView, serializedI18nBlock, context, node.cases[caseIdx]);
			}
			break;
		}
	}
	return getFirstNativeNodeForI18nNode(lView, node);
}
function getFirstNativeNodeForI18nNode(lView, node) {
	const maybeTNode = lView[1].data[node.index];
	if (isTNodeShape(maybeTNode)) return getFirstNativeNode(lView, maybeTNode);
	else if (node.kind === 3) return createIcuIterator(maybeTNode, lView)() ?? unwrapRNode(lView[node.index]);
	else return unwrapRNode(lView[node.index]) ?? null;
}
function setCurrentNode(state, node) {
	state.currentNode = node;
}
function appendI18nNodeToCollection(context, state, astNode) {
	const noOffsetIndex = astNode.index - 28;
	const { disconnectedNodes } = context;
	const currentNode = state.currentNode;
	if (state.isConnected) {
		context.i18nNodes.set(noOffsetIndex, currentNode);
		disconnectedNodes.delete(noOffsetIndex);
	} else disconnectedNodes.add(noOffsetIndex);
	return currentNode;
}
function skipSiblingNodes(state, skip) {
	let currentNode = state.currentNode;
	for (let i = 0; i < skip; i++) {
		if (!currentNode) break;
		currentNode = currentNode?.nextSibling ?? null;
	}
	return currentNode;
}
function forkHydrationState(state, nextNode) {
	return {
		currentNode: nextNode,
		isConnected: state.isConnected
	};
}
function prepareI18nBlockForHydrationImpl(lView, index, parentTNode, subTemplateIndex) {
	const hydrationInfo = lView[6];
	if (!hydrationInfo) return;
	if (!isI18nHydrationSupportEnabled() || parentTNode && (isI18nInSkipHydrationBlock(parentTNode) || isDisconnectedNode$1(hydrationInfo, parentTNode.index - 28))) return;
	const tView = lView[1];
	const tI18n = tView.data[index];
	ngDevMode && assertDefined(tI18n, "Expected i18n data to be present in a given TView slot during hydration");
	function findHydrationRoot() {
		if (isRootTemplateMessage(subTemplateIndex)) {
			ngDevMode && assertDefined(parentTNode, "Expected parent TNode while hydrating i18n root");
			const rootNode = locateNextRNode(hydrationInfo, tView, lView, parentTNode);
			return parentTNode.type & 8 ? rootNode : rootNode.firstChild;
		}
		return hydrationInfo?.firstChild;
	}
	const currentNode = findHydrationRoot();
	ngDevMode && assertDefined(currentNode, "Expected root i18n node during hydration");
	const disconnectedNodes = initDisconnectedNodes(hydrationInfo) ?? /* @__PURE__ */ new Set();
	collectI18nNodesFromDom({
		hydrationInfo,
		lView,
		i18nNodes: hydrationInfo.i18nNodes ??= /* @__PURE__ */ new Map(),
		disconnectedNodes,
		caseQueue: hydrationInfo.data["l"]?.[index - 28] ?? [],
		dehydratedIcuData: hydrationInfo.dehydratedIcuData ??= /* @__PURE__ */ new Map()
	}, {
		currentNode,
		isConnected: true
	}, tI18n.ast);
	hydrationInfo.disconnectedNodes = disconnectedNodes.size === 0 ? null : disconnectedNodes;
}
function collectI18nNodesFromDom(context, state, nodeOrNodes) {
	if (Array.isArray(nodeOrNodes)) {
		let nextState = state;
		for (const node of nodeOrNodes) {
			const targetNode = tryLocateRNodeByPath(context.hydrationInfo, context.lView, node.index - 28);
			if (targetNode) nextState = forkHydrationState(state, targetNode);
			collectI18nNodesFromDom(context, nextState, node);
		}
	} else {
		if (context.disconnectedNodes.has(nodeOrNodes.index - 28)) return;
		switch (nodeOrNodes.kind) {
			case 0:
				setCurrentNode(state, appendI18nNodeToCollection(context, state, nodeOrNodes)?.nextSibling ?? null);
				break;
			case 1:
				collectI18nNodesFromDom(context, forkHydrationState(state, state.currentNode?.firstChild ?? null), nodeOrNodes.children);
				setCurrentNode(state, appendI18nNodeToCollection(context, state, nodeOrNodes)?.nextSibling ?? null);
				break;
			case 2: {
				const noOffsetIndex = nodeOrNodes.index - 28;
				const { hydrationInfo } = context;
				const containerSize = getNgContainerSize(hydrationInfo, noOffsetIndex);
				switch (nodeOrNodes.type) {
					case 0: {
						const currentNode = appendI18nNodeToCollection(context, state, nodeOrNodes);
						if (isSerializedElementContainer(hydrationInfo, noOffsetIndex)) {
							collectI18nNodesFromDom(context, state, nodeOrNodes.children);
							setCurrentNode(state, skipSiblingNodes(state, 1));
						} else {
							collectI18nNodesFromDom(context, forkHydrationState(state, state.currentNode?.firstChild ?? null), nodeOrNodes.children);
							setCurrentNode(state, currentNode?.nextSibling ?? null);
							if (containerSize !== null) setCurrentNode(state, skipSiblingNodes(state, containerSize + 1));
						}
						break;
					}
					case 1:
						ngDevMode && assertNotEqual(containerSize, null, "Expected a container size while hydrating i18n subtemplate");
						appendI18nNodeToCollection(context, state, nodeOrNodes);
						setCurrentNode(state, skipSiblingNodes(state, containerSize + 1));
				}
				break;
			}
			case 3: {
				const selectedCase = state.isConnected ? context.caseQueue.shift() : null;
				const childState = {
					currentNode: null,
					isConnected: false
				};
				for (let i = 0; i < nodeOrNodes.cases.length; i++) collectI18nNodesFromDom(context, i === selectedCase ? state : childState, nodeOrNodes.cases[i]);
				if (selectedCase !== null) context.dehydratedIcuData.set(nodeOrNodes.index, {
					case: selectedCase,
					node: nodeOrNodes
				});
				setCurrentNode(state, appendI18nNodeToCollection(context, state, nodeOrNodes)?.nextSibling ?? null);
				break;
			}
		}
	}
}
var _claimDehydratedIcuCaseImpl = () => {};
function claimDehydratedIcuCase(lView, icuIndex, caseIndex) {
	_claimDehydratedIcuCaseImpl(lView, icuIndex, caseIndex);
}
function enableClaimDehydratedIcuCaseImpl() {
	_claimDehydratedIcuCaseImpl = claimDehydratedIcuCaseImpl;
}
function claimDehydratedIcuCaseImpl(lView, icuIndex, caseIndex) {
	const dehydratedIcuDataMap = lView[6]?.dehydratedIcuData;
	if (dehydratedIcuDataMap) {
		if (dehydratedIcuDataMap.get(icuIndex)?.case === caseIndex) dehydratedIcuDataMap.delete(icuIndex);
	}
}
function cleanupI18nHydrationData(lView) {
	const hydrationInfo = lView[6];
	if (hydrationInfo) {
		const { i18nNodes, dehydratedIcuData: dehydratedIcuDataMap } = hydrationInfo;
		if (i18nNodes && dehydratedIcuDataMap) {
			const renderer = lView[11];
			for (const dehydratedIcuData of dehydratedIcuDataMap.values()) cleanupDehydratedIcuData(renderer, i18nNodes, dehydratedIcuData);
		}
		hydrationInfo.i18nNodes = void 0;
		hydrationInfo.dehydratedIcuData = void 0;
	}
}
function cleanupDehydratedIcuData(renderer, i18nNodes, dehydratedIcuData) {
	for (const node of dehydratedIcuData.node.cases[dehydratedIcuData.case]) {
		const rNode = i18nNodes.get(node.index - 28);
		if (rNode) nativeRemoveNode(renderer, rNode, false);
	}
}
function removeDehydratedViews(lContainer) {
	const views = lContainer[6] ?? [];
	const renderer = lContainer[3][11];
	const retainedViews = [];
	for (const view of views) if (view.data["di"] !== void 0) retainedViews.push(view);
	else {
		removeDehydratedView(view, renderer);
		ngDevMode && ngDevMode.dehydratedViewsRemoved++;
	}
	lContainer[6] = retainedViews;
}
function removeDehydratedView(dehydratedView, renderer) {
	let nodesRemoved = 0;
	let currentRNode = dehydratedView.firstChild;
	if (currentRNode) {
		const numNodes = dehydratedView.data["r"];
		while (nodesRemoved < numNodes) {
			ngDevMode && validateSiblingNodeExists(currentRNode);
			const nextSibling = currentRNode.nextSibling;
			nativeRemoveNode(renderer, currentRNode, false);
			currentRNode = nextSibling;
			nodesRemoved++;
		}
	}
}
function cleanupLContainer(lContainer) {
	removeDehydratedViews(lContainer);
	const hostLView = lContainer[0];
	if (isLView(hostLView)) cleanupLView(hostLView);
	for (let i = 10; i < lContainer.length; i++) cleanupLView(lContainer[i]);
}
function cleanupLView(lView) {
	cleanupI18nHydrationData(lView);
	const tView = lView[1];
	for (let i = 28; i < tView.bindingStartIndex; i++) if (isLContainer(lView[i])) {
		const lContainer = lView[i];
		cleanupLContainer(lContainer);
	} else if (isLView(lView[i])) cleanupLView(lView[i]);
}
var _findMatchingDehydratedViewImpl = () => null;
var _findAndReconcileMatchingDehydratedViewsImpl = () => null;
function findMatchingDehydratedView(lContainer, template) {
	return _findMatchingDehydratedViewImpl(lContainer, template);
}
function findAndReconcileMatchingDehydratedViews(lContainer, templateTNode, hostLView) {
	return _findAndReconcileMatchingDehydratedViewsImpl(lContainer, templateTNode, hostLView);
}
var ComponentRef$1 = class ComponentRef {};
var RendererFactory2 = class {};
var Renderer2 = class {
	destroyNode = null;
	static __NG_ELEMENT_ID__ = () => injectRenderer2();
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(Renderer2);
function injectRenderer2() {
	const lView = getLView();
	const nodeAtIndex = getComponentLViewByIndex(getCurrentTNode().index, lView);
	return (isLView(nodeAtIndex) ? nodeAtIndex : lView)[11];
}
var Sanitizer = class Sanitizer {
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: Sanitizer,
		providedIn: "root",
		factory: () => null
	});
};
var RENDER = Symbol("RENDER");
var ON_DESTROY = Symbol("ON_DESTROY");
var CONTENT_ADAPTER = Symbol("CONTENT_ADAPTER");
var GET_CONTEXT = Symbol("GET_CONTEXT");
function isForeignComponent(value) {
	return typeof value === "object" && value !== null && RENDER in value;
}
function isModuleWithProviders(value) {
	return value.ngModule !== void 0;
}
function isNgModule(value) {
	return !!getNgModuleDef(value);
}
function isPipe(value) {
	return !!getPipeDef$1(value);
}
function isDirective(value) {
	return !!getDirectiveDef(value);
}
function isComponent(value) {
	return !!getComponentDef(value);
}
function getDependencyTypeForError(type) {
	if (getComponentDef(type)) return "component";
	if (getDirectiveDef(type)) return "directive";
	if (getPipeDef$1(type)) return "pipe";
	return "type";
}
function verifyStandaloneImport(depType, importingType) {
	if (isForwardRef(depType)) {
		depType = resolveForwardRef(depType);
		if (!depType) throw new Error(`Expected forwardRef function, imported from "${stringifyForError(importingType)}", to return a standalone entity or NgModule but got "${stringifyForError(depType) || depType}".`);
	}
	if (getNgModuleDef(depType) == null) {
		const def = getComponentDef(depType) || getDirectiveDef(depType) || getPipeDef$1(depType);
		if (def != null) {
			if (!def.standalone) {
				const type = getDependencyTypeForError(depType);
				throw new Error(`The "${stringifyForError(depType)}" ${type}, imported from "${stringifyForError(importingType)}", is not standalone. Does the ${type} have the standalone: false flag?`);
			}
		} else if (isModuleWithProviders(depType)) throw new Error(`A module with providers was imported from "${stringifyForError(importingType)}". Modules with providers are not supported in standalone components imports.`);
		else if (isForeignComponent(depType)) throw new Error(`A foreign component, imported from "${stringifyForError(importingType)}", cannot be imported using 'imports'. Foreign components are only supported in AOT mode and must be registered in 'foreignImports'.`);
		else throw new Error(`The "${stringifyForError(depType)}" type, imported from "${stringifyForError(importingType)}", must be a standalone component / directive / pipe or an NgModule. Did you forget to add the required @Component / @Directive / @Pipe or @NgModule annotation?`);
	}
}
var DepsTracker = class {
	ownerNgModule = /* @__PURE__ */ new WeakMap();
	ngModulesWithSomeUnresolvedDecls = /* @__PURE__ */ new Set();
	ngModulesScopeCache = /* @__PURE__ */ new WeakMap();
	standaloneComponentsScopeCache = /* @__PURE__ */ new WeakMap();
	resolveNgModulesDecls() {
		if (this.ngModulesWithSomeUnresolvedDecls.size === 0) return;
		for (const moduleType of this.ngModulesWithSomeUnresolvedDecls) {
			const def = getNgModuleDef(moduleType);
			if (def?.declarations) {
				for (const decl of maybeUnwrapFn(def.declarations)) if (isComponent(decl)) this.ownerNgModule.set(decl, moduleType);
			}
		}
		this.ngModulesWithSomeUnresolvedDecls.clear();
	}
	getComponentDependencies(type, rawImports) {
		this.resolveNgModulesDecls();
		const def = getComponentDef(type);
		if (def === null) throw new Error(`Attempting to get component dependencies for a type that is not a component: ${type}`);
		if (def.standalone) {
			const scope = this.getStandaloneComponentScope(type, rawImports);
			if (scope.compilation.isPoisoned) return { dependencies: [] };
			return { dependencies: [
				...scope.compilation.directives,
				...scope.compilation.pipes,
				...scope.compilation.ngModules
			] };
		} else {
			if (!this.ownerNgModule.has(type)) return { dependencies: [] };
			const scope = this.getNgModuleScope(this.ownerNgModule.get(type));
			if (scope.compilation.isPoisoned) return { dependencies: [] };
			return { dependencies: [...scope.compilation.directives, ...scope.compilation.pipes] };
		}
	}
	registerNgModule(type, scopeInfo) {
		if (!isNgModule(type)) throw new Error(`Attempting to register a Type which is not NgModule as NgModule: ${type}`);
		this.ngModulesWithSomeUnresolvedDecls.add(type);
	}
	clearScopeCacheFor(type) {
		this.ngModulesScopeCache.delete(type);
		this.standaloneComponentsScopeCache.delete(type);
	}
	getNgModuleScope(type) {
		if (this.ngModulesScopeCache.has(type)) return this.ngModulesScopeCache.get(type);
		const scope = this.computeNgModuleScope(type);
		this.ngModulesScopeCache.set(type, scope);
		return scope;
	}
	computeNgModuleScope(type) {
		const def = getNgModuleDefOrThrow(type);
		const scope = {
			exported: {
				directives: /* @__PURE__ */ new Set(),
				pipes: /* @__PURE__ */ new Set()
			},
			compilation: {
				directives: /* @__PURE__ */ new Set(),
				pipes: /* @__PURE__ */ new Set()
			}
		};
		for (const imported of maybeUnwrapFn(def.imports)) if (isNgModule(imported)) {
			const importedScope = this.getNgModuleScope(imported);
			addSet(importedScope.exported.directives, scope.compilation.directives);
			addSet(importedScope.exported.pipes, scope.compilation.pipes);
		} else if (isStandalone(imported)) {
			if (isDirective(imported) || isComponent(imported)) scope.compilation.directives.add(imported);
			else if (isPipe(imported)) scope.compilation.pipes.add(imported);
			else throw new RuntimeError(980, "The standalone imported type is neither a component nor a directive nor a pipe");
		} else {
			scope.compilation.isPoisoned = true;
			break;
		}
		if (!scope.compilation.isPoisoned) for (const decl of maybeUnwrapFn(def.declarations)) {
			if (isNgModule(decl) || isStandalone(decl)) {
				scope.compilation.isPoisoned = true;
				break;
			}
			if (isPipe(decl)) scope.compilation.pipes.add(decl);
			else scope.compilation.directives.add(decl);
		}
		for (const exported of maybeUnwrapFn(def.exports)) if (isNgModule(exported)) {
			const exportedScope = this.getNgModuleScope(exported);
			addSet(exportedScope.exported.directives, scope.exported.directives);
			addSet(exportedScope.exported.pipes, scope.exported.pipes);
			addSet(exportedScope.exported.directives, scope.compilation.directives);
			addSet(exportedScope.exported.pipes, scope.compilation.pipes);
		} else if (isPipe(exported)) scope.exported.pipes.add(exported);
		else scope.exported.directives.add(exported);
		return scope;
	}
	getStandaloneComponentScope(type, rawImports) {
		if (this.standaloneComponentsScopeCache.has(type)) return this.standaloneComponentsScopeCache.get(type);
		const ans = this.computeStandaloneComponentScope(type, rawImports);
		this.standaloneComponentsScopeCache.set(type, ans);
		return ans;
	}
	computeStandaloneComponentScope(type, rawImports) {
		const ans = { compilation: {
			directives: /* @__PURE__ */ new Set([type]),
			pipes: /* @__PURE__ */ new Set(),
			ngModules: /* @__PURE__ */ new Set()
		} };
		for (const rawImport of flatten(rawImports ?? [])) {
			const imported = resolveForwardRef(rawImport);
			try {
				verifyStandaloneImport(imported, type);
			} catch (e) {
				ans.compilation.isPoisoned = true;
				return ans;
			}
			if (isNgModule(imported)) {
				ans.compilation.ngModules.add(imported);
				const importedScope = this.getNgModuleScope(imported);
				if (importedScope.exported.isPoisoned) {
					ans.compilation.isPoisoned = true;
					return ans;
				}
				addSet(importedScope.exported.directives, ans.compilation.directives);
				addSet(importedScope.exported.pipes, ans.compilation.pipes);
			} else if (isPipe(imported)) ans.compilation.pipes.add(imported);
			else if (isDirective(imported) || isComponent(imported)) ans.compilation.directives.add(imported);
			else {
				ans.compilation.isPoisoned = true;
				return ans;
			}
		}
		return ans;
	}
	isOrphanComponent(cmp) {
		const def = getComponentDef(cmp);
		if (!def || def.standalone) return false;
		this.resolveNgModulesDecls();
		return !this.ownerNgModule.has(cmp);
	}
};
function addSet(sourceSet, targetSet) {
	for (const m of sourceSet) targetSet.add(m);
}
var depsTracker = new DepsTracker();
function getClosestComponentName(node, predicate) {
	let currentNode = node;
	while (currentNode) {
		const lView = readPatchedLView(currentNode);
		if (lView !== null) for (let i = 28; i < lView.length; i++) {
			const current = lView[i];
			if (!isLView(current) && !isLContainer(current) || current[0] !== currentNode) continue;
			const tView = lView[1];
			const tNode = getTNode(tView, i);
			if (isComponentHost(tNode)) {
				const def = tView.data[tNode.directiveStart + tNode.componentOffset];
				const name = getComponentName(def);
				if (name !== null && (!predicate || predicate(currentNode, name))) return name;
				else break;
			}
		}
		currentNode = currentNode.parentNode;
	}
	return null;
}
function getComponentName(def) {
	return def.debugInfo?.className || def.type.name || null;
}
var NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR = {};
var ChainedInjector = class {
	injector;
	parentInjector;
	constructor(injector, parentInjector) {
		this.injector = injector;
		this.parentInjector = parentInjector;
	}
	get(token, notFoundValue, options) {
		const value = this.injector.get(token, NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR, options);
		if (value !== NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR || notFoundValue === NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR) return value;
		return this.parentInjector.get(token, notFoundValue, options);
	}
};
function isListLikeIterable(obj) {
	if (!isJsObject(obj)) return false;
	return Array.isArray(obj) || !(obj instanceof Map) && Symbol.iterator in obj;
}
function areIterablesEqual(a, b, comparator) {
	const iterator1 = a[Symbol.iterator]();
	const iterator2 = b[Symbol.iterator]();
	while (true) {
		const item1 = iterator1.next();
		const item2 = iterator2.next();
		if (item1.done && item2.done) return true;
		if (item1.done || item2.done) return false;
		if (!comparator(item1.value, item2.value)) return false;
	}
}
function iterateListLike(obj, fn) {
	if (Array.isArray(obj)) for (let i = 0; i < obj.length; i++) fn(obj[i]);
	else {
		const iterator = obj[Symbol.iterator]();
		let item;
		while (!(item = iterator.next()).done) fn(item.value);
	}
}
function isJsObject(o) {
	return o !== null && (typeof o === "function" || typeof o === "object");
}
function devModeEqual(a, b) {
	const isListLikeIterableA = isListLikeIterable(a);
	const isListLikeIterableB = isListLikeIterable(b);
	if (isListLikeIterableA && isListLikeIterableB) return areIterablesEqual(a, b, devModeEqual);
	else if (!isListLikeIterableA && a && (typeof a === "object" || typeof a === "function") && !isListLikeIterableB && b && (typeof b === "object" || typeof b === "function")) return true;
	else return Object.is(a, b);
}
function updateBinding(lView, bindingIndex, value) {
	return lView[bindingIndex] = value;
}
function getBinding(lView, bindingIndex) {
	ngDevMode && assertIndexInRange(lView, bindingIndex);
	ngDevMode && assertNotSame(lView[bindingIndex], NO_CHANGE, "Stored value should never be NO_CHANGE.");
	return lView[bindingIndex];
}
function bindingUpdated(lView, bindingIndex, value) {
	ngDevMode && assertLessThan(bindingIndex, lView.length, `Slot should have been initialized to NO_CHANGE`);
	if (value === NO_CHANGE) return false;
	const oldValue = lView[bindingIndex];
	if (Object.is(oldValue, value)) return false;
	else {
		if (ngDevMode && isInCheckNoChangesMode()) {
			const oldValueToCompare = oldValue !== NO_CHANGE ? oldValue : void 0;
			if (!devModeEqual(oldValueToCompare, value)) {
				const details = getExpressionChangedErrorDetails(lView, bindingIndex, oldValueToCompare, value);
				throwErrorIfNoChangesMode(oldValue === NO_CHANGE, details.oldValue, details.newValue, details.propName, lView);
			}
			return false;
		}
		lView[bindingIndex] = value;
		return true;
	}
}
function bindingUpdated2(lView, bindingIndex, exp1, exp2) {
	const different = bindingUpdated(lView, bindingIndex, exp1);
	return bindingUpdated(lView, bindingIndex + 1, exp2) || different;
}
function bindingUpdated3(lView, bindingIndex, exp1, exp2, exp3) {
	const different = bindingUpdated2(lView, bindingIndex, exp1, exp2);
	return bindingUpdated(lView, bindingIndex + 2, exp3) || different;
}
function bindingUpdated4(lView, bindingIndex, exp1, exp2, exp3, exp4) {
	const different = bindingUpdated2(lView, bindingIndex, exp1, exp2);
	return bindingUpdated2(lView, bindingIndex + 2, exp3, exp4) || different;
}
function wrapListener(tNode, lView, listenerFn) {
	return function wrapListenerIn_markDirtyAndPreventDefault(event) {
		const nativeEl = wrapListenerIn_markDirtyAndPreventDefault.__ngNativeEl__;
		if (nativeEl !== void 0) markEventHandledForElement(event, nativeEl);
		markViewDirty(isComponentHost(tNode) ? getComponentLViewByIndex(tNode.index, lView) : lView, 5);
		const context = lView[8];
		let result = executeListenerWithErrorHandling(lView, context, listenerFn, event);
		let nextListenerFn = wrapListenerIn_markDirtyAndPreventDefault.__ngNextListenerFn__;
		while (nextListenerFn) {
			result = executeListenerWithErrorHandling(lView, context, nextListenerFn, event) && result;
			nextListenerFn = nextListenerFn.__ngNextListenerFn__;
		}
		return result;
	};
}
function executeListenerWithErrorHandling(lView, context, listenerFn, e) {
	const prevConsumer = setActiveConsumer(null);
	try {
		profiler(ProfilerEvent.OutputStart, context, listenerFn);
		return listenerFn(e) !== false;
	} catch (error) {
		handleUncaughtError(lView, error);
		return false;
	} finally {
		profiler(ProfilerEvent.OutputEnd, context, listenerFn);
		setActiveConsumer(prevConsumer);
	}
}
function listenToDomEvent(tNode, tView, lView, eventTargetResolver, renderer, eventName, originalListener, wrappedListener) {
	ngDevMode && assertNotSame(wrappedListener, originalListener, "Expected wrapped and original listeners to be different.");
	const isTNodeDirectiveHost = isDirectiveHost(tNode);
	let hasCoalesced = false;
	let existingListener = null;
	if (!eventTargetResolver && isTNodeDirectiveHost) existingListener = findExistingListener(tView, lView, eventName, tNode.index);
	if (existingListener !== null) {
		const lastListenerFn = existingListener.__ngLastListenerFn__ || existingListener;
		lastListenerFn.__ngNextListenerFn__ = originalListener;
		existingListener.__ngLastListenerFn__ = originalListener;
		hasCoalesced = true;
	} else {
		const native = getNativeByTNode(tNode, lView);
		const target = eventTargetResolver ? eventTargetResolver(native) : native;
		if (!eventTargetResolver) wrappedListener.__ngNativeEl__ = native;
		const cleanupFn = renderer.listen(target, eventName, wrappedListener);
		if (!isAnimationEventType(eventName)) storeListenerCleanup(eventTargetResolver ? (_lView) => eventTargetResolver(unwrapRNode(_lView[tNode.index])) : tNode.index, tView, lView, eventName, wrappedListener, cleanupFn, false);
	}
	return hasCoalesced;
}
function isAnimationEventType(eventName) {
	return eventName.startsWith("animation") || eventName.startsWith("transition");
}
function findExistingListener(tView, lView, eventName, tNodeIndex) {
	const tCleanup = tView.cleanup;
	if (tCleanup != null) for (let i = 0; i < tCleanup.length - 1; i += 2) {
		const cleanupEventName = tCleanup[i];
		if (cleanupEventName === eventName && tCleanup[i + 1] === tNodeIndex) {
			const lCleanup = lView[7];
			const listenerIdxInLCleanup = tCleanup[i + 2];
			return lCleanup && lCleanup.length > listenerIdxInLCleanup ? lCleanup[listenerIdxInLCleanup] : null;
		}
		if (typeof cleanupEventName === "string") i += 2;
	}
	return null;
}
function storeListenerCleanup(indexOrTargetGetter, tView, lView, eventName, listenerFn, cleanup, isOutput) {
	const tCleanup = tView.firstCreatePass ? getOrCreateTViewCleanup(tView) : null;
	const lCleanup = getOrCreateLViewCleanup(lView);
	const index = lCleanup.length;
	lCleanup.push(listenerFn, cleanup);
	tCleanup && tCleanup.push(eventName, indexOrTargetGetter, index, (index + 1) * (isOutput ? -1 : 1));
}
function createOutputListener(tNode, lView, listenerFn, targetDef, eventName) {
	if (!listenToDirectiveOutput(tNode, lView, targetDef, eventName, wrapListener(tNode, lView, listenerFn)) && ngDevMode) throw new RuntimeError(316, `${stringifyForError(targetDef.type)} does not have an output with a public name of "${eventName}".`);
}
function listenToDirectiveOutput(tNode, lView, target, eventName, listenerFn) {
	let hostIndex = null;
	let hostDirectivesStart = null;
	let hostDirectivesEnd = null;
	let hasOutput = false;
	if (ngDevMode && !tNode.directiveToIndex?.has(target.type)) throw new Error(`Node does not have a directive with type ${target.type.name}`);
	const data = tNode.directiveToIndex.get(target.type);
	if (typeof data === "number") hostIndex = data;
	else [hostIndex, hostDirectivesStart, hostDirectivesEnd] = data;
	if (hostDirectivesStart !== null && hostDirectivesEnd !== null && tNode.hostDirectiveOutputs && Object.hasOwn(tNode.hostDirectiveOutputs, eventName)) {
		const hostDirectiveOutputs = tNode.hostDirectiveOutputs[eventName];
		for (let i = 0; i < hostDirectiveOutputs.length; i += 2) {
			const index = hostDirectiveOutputs[i];
			if (index >= hostDirectivesStart && index <= hostDirectivesEnd) {
				ngDevMode && assertIndexInRange(lView, index);
				hasOutput = true;
				listenToOutput(tNode, lView, index, hostDirectiveOutputs[i + 1], eventName, listenerFn);
			} else if (index > hostDirectivesEnd) break;
		}
	}
	if (Object.hasOwn(target.outputs, eventName)) {
		ngDevMode && assertIndexInRange(lView, hostIndex);
		hasOutput = true;
		listenToOutput(tNode, lView, hostIndex, eventName, eventName, listenerFn);
	}
	return hasOutput;
}
function listenToOutput(tNode, lView, directiveIndex, lookupName, eventName, listenerFn) {
	ngDevMode && assertIndexInRange(lView, directiveIndex);
	const instance = lView[directiveIndex];
	const tView = lView[1];
	const propertyName = tView.data[directiveIndex].outputs[lookupName];
	const output = instance[propertyName];
	if (ngDevMode && !isOutputSubscribable(output)) throw new Error(`@Output ${propertyName} not initialized in '${instance.constructor.name}'.`);
	const subscription = output.subscribe(listenerFn);
	storeListenerCleanup(tNode.index, tView, lView, eventName, listenerFn, subscription, true);
}
function isOutputSubscribable(value) {
	return value != null && typeof value.subscribe === "function";
}
function ɵɵcontrolCreate() {
	controlCreateInternal();
}
function controlCreateInternal() {
	const lView = getLView();
	const tView = getTView();
	const tNode = getCurrentTNode();
	if (tView.firstCreatePass) initializeControlFirstCreatePass(tView, tNode);
	if (tNode.controlDirectiveIndex === -1) return;
	performanceMarkFeature("NgSignalForms");
	const instance = lView[tNode.controlDirectiveIndex];
	tView.data[tNode.controlDirectiveIndex].controlDef.create(instance, new ControlDirectiveHostImpl(lView, tView, tNode));
}
function ɵɵcontrol() {
	controlUpdateInternal();
}
function controlUpdateInternal() {
	if (ngDevMode && isInCheckNoChangesMode()) return;
	const lView = getLView();
	const tView = getTView();
	const tNode = getSelectedTNode();
	if (tNode.controlDirectiveIndex === -1) return;
	const controlDef = tView.data[tNode.controlDirectiveIndex].controlDef;
	const instance = lView[tNode.controlDirectiveIndex];
	controlDef.update(instance, new ControlDirectiveHostImpl(lView, tView, tNode));
}
var ControlDirectiveHostImpl = class {
	lView;
	tView;
	tNode;
	hasPassThrough;
	constructor(lView, tView, tNode) {
		this.lView = lView;
		this.tView = tView;
		this.tNode = tNode;
		this.hasPassThrough = !!(tNode.flags & 4096);
	}
	get customControl() {
		return this.tNode.customControlIndex !== -1 ? this.lView[this.tNode.customControlIndex] : void 0;
	}
	get nativeElement() {
		return getNativeByTNode(this.tNode, this.lView);
	}
	get descriptor() {
		if (ngDevMode && isComponentHost(this.tNode)) {
			const componentIndex = this.tNode.directiveStart + this.tNode.componentOffset;
			const componentDef = this.tView.data[componentIndex];
			return `Component ${debugStringifyTypeForError(componentDef.type)}`;
		}
		return `<${this.tNode.value}>`;
	}
	listenToCustomControlOutput(outputName, callback) {
		const directiveDef = this.tView.data[this.tNode.customControlIndex];
		listenToDirectiveOutput(this.tNode, this.lView, directiveDef, outputName, wrapListener(this.tNode, this.lView, callback));
	}
	listenToCustomControlModel(listener) {
		const modelName = this.tNode.flags & 1024 ? "valueChange" : "checkedChange";
		const directiveDef = this.tView.data[this.tNode.customControlIndex];
		listenToDirectiveOutput(this.tNode, this.lView, directiveDef, modelName, wrapListener(this.tNode, this.lView, listener));
	}
	listenToDom(eventName, listener) {
		listenToDomEvent(this.tNode, this.tView, this.lView, void 0, this.lView[11], eventName, listener, wrapListener(this.tNode, this.lView, listener));
	}
	setInputOnDirectives(inputName, value, writePredicate) {
		const directiveIndices = this.tNode.inputs?.[inputName];
		const hostDirectiveInputs = this.tNode.hostDirectiveInputs?.[inputName];
		if (!directiveIndices && !hostDirectiveInputs) return false;
		let wasSet = false;
		if (directiveIndices) for (const index of directiveIndices) {
			if (index === this.tNode.controlDirectiveIndex) continue;
			const directive = this.lView[index];
			const directiveDef = this.tView.data[index];
			if (!writePredicate || writePredicate(readInputFromDirective(directive, directiveDef, inputName))) {
				writeToDirectiveInput(directiveDef, directive, inputName, value);
				wasSet = true;
			}
		}
		if (hostDirectiveInputs) for (let i = 0; i < hostDirectiveInputs.length; i += 2) {
			const index = hostDirectiveInputs[i];
			if (index === this.tNode.controlDirectiveIndex) continue;
			const directive = this.lView[index];
			const internalName = hostDirectiveInputs[i + 1];
			const directiveDef = this.tView.data[index];
			if (!writePredicate || writePredicate(readInputFromDirective(directive, directiveDef, inputName))) {
				writeToDirectiveInput(directiveDef, directive, internalName, value);
				wasSet = true;
			}
		}
		return wasSet;
	}
	setCustomControlModelInput(value) {
		const directiveDef = this.tView.data[this.tNode.customControlIndex];
		const modelName = this.tNode.flags & 1024 ? "value" : "checked";
		setDirectiveInput(this.tNode, this.tView, this.lView, directiveDef, modelName, value);
	}
	customControlHasInput(inputName) {
		if (this.tNode.customControlIndex === -1) return false;
		const directiveDef = this.tView.data[this.tNode.customControlIndex];
		return (directiveDef.signalFormsInputPresence ??= this._buildCustomControlInputCache(directiveDef))[inputName] === true;
	}
	_buildCustomControlInputCache(directiveDef) {
		const cache = {};
		for (const key in directiveDef.inputs) cache[key] = true;
		if (directiveDef.hostDirectives !== null) {
			const queue = [...directiveDef.hostDirectives];
			while (queue.length > 0) {
				const hostDir = queue.shift();
				if (typeof hostDir !== "function") {
					for (const key in hostDir.inputs) cache[hostDir.inputs[key]] = true;
					const hostDirectives = getHostDirectives(hostDir.directive);
					if (hostDirectives !== null) queue.push(...hostDirectives);
					continue;
				}
				for (const config of hostDir()) {
					if (typeof config === "function") continue;
					if (config.inputs) for (let i = 0; i < config.inputs.length; i += 2) {
						const exposedName = config.inputs[i + 1] || config.inputs[i];
						cache[exposedName] = true;
					}
					const hostDirectives = getHostDirectives(config.directive);
					if (hostDirectives !== null) queue.push(...hostDirectives);
				}
			}
		}
		return cache;
	}
};
function getHostDirectives(directiveType) {
	if (typeof directiveType === "function" && "ɵdir" in directiveType) return directiveType.ɵdir.hostDirectives ?? null;
	return null;
}
function readInputFromDirective(instance, directiveDef, inputName) {
	if (!directiveDef.inputs || !Object.hasOwn(directiveDef.inputs, inputName)) return;
	const [privateName, flags] = directiveDef.inputs[inputName];
	if ((flags & InputFlags.SignalBased) !== 0) {
		const node = instance[privateName][SIGNAL];
		return node.value === REQUIRED_UNSET_VALUE ? void 0 : node.value;
	}
	return instance[privateName];
}
function initializeControlFirstCreatePass(tView, tNode, lView) {
	ngDevMode && assertFirstCreatePass(tView);
	for (let i = tNode.directiveStart; i < tNode.directiveEnd; i++) if (tView.data[i].controlDef) {
		tNode.controlDirectiveIndex = i;
		break;
	}
	if (tNode.controlDirectiveIndex === -1) return;
	const controlDef = tView.data[tNode.controlDirectiveIndex].controlDef;
	if (controlDef.passThroughInput) {
		if ((tNode.inputs?.[controlDef.passThroughInput]?.length ?? 0) > 1) {
			tNode.flags |= 4096;
			return;
		}
	}
	initializeCustomControlStatus(tView, tNode);
}
function initializeCustomControlStatus(tView, tNode) {
	for (let i = tNode.directiveStart; i < tNode.directiveEnd; i++) {
		const directiveDef = tView.data[i];
		if (tNode.directiveToIndex && !tNode.directiveToIndex.has(directiveDef.type)) continue;
		if (hasModelInput(directiveDef, "value")) {
			tNode.flags |= 1024;
			tNode.customControlIndex = i;
			return;
		}
		if (hasModelInput(directiveDef, "checked")) {
			tNode.flags |= 2048;
			tNode.customControlIndex = i;
			return;
		}
	}
	if (tNode.hostDirectiveInputs !== null && tNode.hostDirectiveOutputs !== null && tNode.directiveToIndex !== null) {
		const checkModel = (modelName, flag) => {
			const inputs = tNode.hostDirectiveInputs[modelName];
			const outputs = tNode.hostDirectiveOutputs[modelName + "Change"];
			if (!inputs || !outputs) return false;
			for (let i = 0; i < inputs.length; i += 2) {
				const inputIndex = inputs[i];
				for (let j = 0; j < outputs.length; j += 2) {
					if (inputIndex !== outputs[j]) continue;
					for (const data of tNode.directiveToIndex.values()) {
						if (!Array.isArray(data)) continue;
						const [hostIndex, start, end] = data;
						if (inputIndex >= start && inputIndex <= end) {
							tNode.flags |= flag;
							tNode.customControlIndex = hostIndex;
							return true;
						}
					}
				}
			}
			return false;
		};
		if (checkModel("value", 1024)) return;
		if (checkModel("checked", 2048)) return;
	}
}
function hasModelInput(directiveDef, name) {
	return hasInput(directiveDef, name) && hasOutput(directiveDef, name + "Change");
}
function hasInput(directiveDef, name) {
	return name in directiveDef.inputs;
}
function hasOutput(directiveDef, name) {
	return name in directiveDef.outputs;
}
var BINDING = /* @__PURE__ */ Symbol("BINDING");
var INPUT_BINDING_METADATA = {
	kind: "input",
	requiredVars: 1
};
var OUTPUT_BINDING_METADATA = {
	kind: "output",
	requiredVars: 0
};
function inputBindingUpdate(targetDirectiveIdx, publicName, value) {
	const lView = getLView();
	const bindingIndex = nextBindingIndex();
	if (bindingUpdated(lView, bindingIndex, value)) {
		const tView = lView[1];
		const tNode = getSelectedTNode();
		markViewDirty(getComponentLViewByIndex(tNode.index, lView), 1);
		const targetDef = tView.directiveRegistry[targetDirectiveIdx];
		if (ngDevMode && !targetDef) throw new RuntimeError(315, `Input binding to property "${publicName}" does not have a target.`);
		const hasSet = setDirectiveInput(tNode, tView, lView, targetDef, publicName, value);
		if (ngDevMode) {
			if (!hasSet) throw new RuntimeError(315, `${stringifyForError(targetDef.type)} does not have an input with a public name of "${publicName}".`);
			storePropertyBindingMetadata(tView.data, tNode, publicName, bindingIndex);
		}
	}
}
function inputBinding(publicName, value) {
	if (publicName === "formField") {
		const binding = {
			[BINDING]: INPUT_BINDING_METADATA,
			create: () => {
				controlCreateInternal();
			},
			update: () => {
				inputBindingUpdate(binding.targetIdx, publicName, value());
				controlUpdateInternal();
			}
		};
		return binding;
	}
	const binding = {
		[BINDING]: INPUT_BINDING_METADATA,
		update: () => inputBindingUpdate(binding.targetIdx, publicName, value())
	};
	return binding;
}
function outputBinding(eventName, listener) {
	const binding = {
		[BINDING]: OUTPUT_BINDING_METADATA,
		create: () => {
			const lView = getLView();
			const tNode = getCurrentTNode();
			const targetDef = lView[1].directiveRegistry[binding.targetIdx];
			createOutputListener(tNode, lView, listener, targetDef, eventName);
		}
	};
	return binding;
}
function twoWayBinding(publicName, value) {
	const input = inputBinding(publicName, value);
	const output = outputBinding(publicName + "Change", (eventValue) => value.set(eventValue));
	ngDevMode && assertNotDefined(input.create, "Unexpected `create` callback in inputBinding");
	ngDevMode && assertNotDefined(output.update, "Unexpected `update` callback in outputBinding");
	return {
		[BINDING]: {
			kind: "twoWay",
			requiredVars: input[BINDING].requiredVars + output[BINDING].requiredVars
		},
		set targetIdx(idx) {
			input.targetIdx = idx;
			output.targetIdx = idx;
		},
		create: output.create,
		update: input.update
	};
}
var SHARED_STYLES_HOST = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "SHARED_STYLES_HOST" : "");
function computeStaticStyling(tNode, attrs, writeToHost) {
	ngDevMode && assertFirstCreatePass(getTView(), "Expecting to be called in first template pass only");
	let styles = writeToHost ? tNode.styles : null;
	let classes = writeToHost ? tNode.classes : null;
	let mode = 0;
	if (attrs !== null) for (let i = 0; i < attrs.length; i++) {
		const value = attrs[i];
		if (typeof value === "number") mode = value;
		else if (mode == 1) classes = concatStringsWithSpace(classes, value);
		else if (mode == 2) {
			const style = value;
			const styleValue = attrs[++i];
			styles = concatStringsWithSpace(styles, style + ": " + styleValue + ";");
		}
	}
	writeToHost ? tNode.styles = styles : tNode.stylesWithoutHost = styles;
	writeToHost ? tNode.classes = classes : tNode.classesWithoutHost = classes;
}
function ɵɵdirectiveInject(token, flags = 0) {
	const lView = getLView();
	if (lView === null) {
		ngDevMode && assertInjectImplementationNotEqual(ɵɵdirectiveInject);
		return ɵɵinject(token, flags);
	}
	const value = getOrCreateInjectable(getCurrentTNode(), lView, resolveForwardRef(token), flags);
	ngDevMode && emitInjectEvent(token, value, flags);
	return value;
}
function ɵɵinvalidFactory() {
	const msg = ngDevMode ? `This constructor was not compatible with Dependency Injection.` : "invalid";
	throw new Error(msg);
}
function resolveDirectives(tView, lView, tNode, localRefs, directiveMatcher) {
	ngDevMode && assertFirstCreatePass(tView);
	const exportsMap = localRefs === null ? null : { "": -1 };
	const matchedDirectiveDefs = directiveMatcher(tView, tNode);
	if (matchedDirectiveDefs !== null) {
		let directiveDefs = matchedDirectiveDefs;
		let hostDirectiveDefs = null;
		let hostDirectiveRanges = null;
		for (const def of matchedDirectiveDefs) if (def.resolveHostDirectives !== null) {
			[directiveDefs, hostDirectiveDefs, hostDirectiveRanges] = def.resolveHostDirectives(matchedDirectiveDefs);
			break;
		}
		ngDevMode && assertNoDuplicateDirectives(directiveDefs);
		initializeDirectives(tView, lView, tNode, directiveDefs, exportsMap, hostDirectiveDefs, hostDirectiveRanges);
	}
	if (exportsMap !== null && localRefs !== null) cacheMatchingLocalNames(tNode, localRefs, exportsMap);
}
function cacheMatchingLocalNames(tNode, localRefs, exportsMap) {
	const localNames = tNode.localNames = [];
	for (let i = 0; i < localRefs.length; i += 2) {
		const index = exportsMap[localRefs[i + 1]];
		if (index == null) throw new RuntimeError(-301, ngDevMode && `Export of name '${localRefs[i + 1]}' not found!`);
		localNames.push(localRefs[i], index);
	}
}
function markAsComponentHost(tView, hostTNode, componentOffset) {
	ngDevMode && assertFirstCreatePass(tView);
	ngDevMode && assertGreaterThan(componentOffset, -1, "componentOffset must be great than -1");
	hostTNode.componentOffset = componentOffset;
	(tView.components ??= []).push(hostTNode.index);
}
function initializeDirectives(tView, lView, tNode, directives, exportsMap, hostDirectiveDefs, hostDirectiveRanges) {
	ngDevMode && assertFirstCreatePass(tView);
	const directivesLength = directives.length;
	let componentDef = null;
	for (let i = 0; i < directivesLength; i++) {
		const def = directives[i];
		if (componentDef === null && isComponentDef(def)) {
			componentDef = def;
			markAsComponentHost(tView, tNode, i);
		}
		diPublicInInjector(getOrCreateNodeInjectorForNode(tNode, lView), tView, def.type);
	}
	initTNodeFlags(tNode, tView.data.length, directivesLength);
	if (componentDef?.viewProvidersResolver) componentDef.viewProvidersResolver(componentDef);
	for (let i = 0; i < directivesLength; i++) {
		const def = directives[i];
		if (def.providersResolver) def.providersResolver(def);
	}
	let preOrderHooksFound = false;
	let preOrderCheckHooksFound = false;
	let directiveIdx = allocExpando(tView, lView, directivesLength, null);
	ngDevMode && assertSame(directiveIdx, tNode.directiveStart, "TNode.directiveStart should point to just allocated space");
	if (directivesLength > 0) tNode.directiveToIndex = /* @__PURE__ */ new Map();
	for (let i = 0; i < directivesLength; i++) {
		const def = directives[i];
		tNode.mergedAttrs = mergeHostAttrs(tNode.mergedAttrs, def.hostAttrs);
		configureViewWithDirective(tView, tNode, lView, directiveIdx, def);
		saveNameToExportMap(directiveIdx, def, exportsMap);
		if (hostDirectiveRanges !== null && hostDirectiveRanges.has(def)) {
			const [start, end] = hostDirectiveRanges.get(def);
			tNode.directiveToIndex.set(def.type, [
				directiveIdx,
				start + tNode.directiveStart,
				end + tNode.directiveStart
			]);
		} else if (hostDirectiveDefs === null || !hostDirectiveDefs.has(def)) tNode.directiveToIndex.set(def.type, directiveIdx);
		if (def.contentQueries !== null) tNode.flags |= 4;
		if (def.hostBindings !== null || def.hostAttrs !== null || def.hostVars !== 0) tNode.flags |= 64;
		const lifeCycleHooks = def.type.prototype;
		if (!preOrderHooksFound && (lifeCycleHooks.ngOnChanges || lifeCycleHooks.ngOnInit || lifeCycleHooks.ngDoCheck)) {
			(tView.preOrderHooks ??= []).push(tNode.index);
			preOrderHooksFound = true;
		}
		if (!preOrderCheckHooksFound && (lifeCycleHooks.ngOnChanges || lifeCycleHooks.ngDoCheck)) {
			(tView.preOrderCheckHooks ??= []).push(tNode.index);
			preOrderCheckHooksFound = true;
		}
		directiveIdx++;
	}
	initializeInputAndOutputAliases(tView, tNode, hostDirectiveDefs);
}
function initializeInputAndOutputAliases(tView, tNode, hostDirectiveDefs) {
	ngDevMode && assertFirstCreatePass(tView);
	for (let index = tNode.directiveStart; index < tNode.directiveEnd; index++) {
		const directiveDef = tView.data[index];
		if (hostDirectiveDefs === null || !hostDirectiveDefs.has(directiveDef)) {
			setupSelectorMatchedInputsOrOutputs(0, tNode, directiveDef, index);
			setupSelectorMatchedInputsOrOutputs(1, tNode, directiveDef, index);
			setupInitialInputs(tNode, index, false);
		} else {
			const hostDirectiveDef = hostDirectiveDefs.get(directiveDef);
			setupHostDirectiveInputsOrOutputs(0, tNode, hostDirectiveDef, index);
			setupHostDirectiveInputsOrOutputs(1, tNode, hostDirectiveDef, index);
			setupInitialInputs(tNode, index, true);
		}
	}
}
function setupSelectorMatchedInputsOrOutputs(mode, tNode, def, directiveIndex) {
	const aliasMap = mode === 0 ? def.inputs : def.outputs;
	for (const publicName in aliasMap) if (Object.hasOwn(aliasMap, publicName)) {
		let bindings;
		if (mode === 0) bindings = tNode.inputs ??= {};
		else bindings = tNode.outputs ??= {};
		bindings[publicName] ??= [];
		bindings[publicName].push(directiveIndex);
		setShadowStylingInputFlags(tNode, publicName);
	}
}
function setupHostDirectiveInputsOrOutputs(mode, tNode, config, directiveIndex) {
	const aliasMap = mode === 0 ? config.inputs : config.outputs;
	for (const initialName in aliasMap) if (Object.hasOwn(aliasMap, initialName)) {
		const publicName = aliasMap[initialName];
		let bindings;
		if (mode === 0) bindings = tNode.hostDirectiveInputs ??= {};
		else bindings = tNode.hostDirectiveOutputs ??= {};
		bindings[publicName] ??= [];
		bindings[publicName].push(directiveIndex, initialName);
		setShadowStylingInputFlags(tNode, publicName);
	}
}
function setShadowStylingInputFlags(tNode, publicName) {
	if (publicName === "class") tNode.flags |= 8;
	else if (publicName === "style") tNode.flags |= 16;
}
function setupInitialInputs(tNode, directiveIndex, isHostDirective) {
	const { attrs, inputs, hostDirectiveInputs } = tNode;
	if (attrs === null || !isHostDirective && inputs === null || isHostDirective && hostDirectiveInputs === null || isInlineTemplate(tNode)) {
		tNode.initialInputs ??= [];
		tNode.initialInputs.push(null);
		return;
	}
	let inputsToStore = null;
	let i = 0;
	while (i < attrs.length) {
		const attrName = attrs[i];
		if (attrName === 0) {
			i += 4;
			continue;
		} else if (attrName === 5) {
			i += 2;
			continue;
		} else if (typeof attrName === "number") break;
		if (!isHostDirective && Object.hasOwn(inputs, attrName)) {
			const inputConfig = inputs[attrName];
			for (const index of inputConfig) if (index === directiveIndex) {
				inputsToStore ??= [];
				inputsToStore.push(attrName, attrs[i + 1]);
				break;
			}
		} else if (isHostDirective && Object.hasOwn(hostDirectiveInputs, attrName)) {
			const config = hostDirectiveInputs[attrName];
			for (let j = 0; j < config.length; j += 2) if (config[j] === directiveIndex) {
				inputsToStore ??= [];
				inputsToStore.push(config[j + 1], attrs[i + 1]);
				break;
			}
		}
		i += 2;
	}
	tNode.initialInputs ??= [];
	tNode.initialInputs.push(inputsToStore);
}
function configureViewWithDirective(tView, tNode, lView, directiveIndex, def) {
	ngDevMode && assertGreaterThanOrEqual(directiveIndex, 28, "Must be in Expando section");
	tView.data[directiveIndex] = def;
	const nodeInjectorFactory = new NodeInjectorFactory(def.factory || (def.factory = getFactoryDef(def.type, true)), isComponentDef(def), ɵɵdirectiveInject, ngDevMode ? def.type.name : null);
	tView.blueprint[directiveIndex] = nodeInjectorFactory;
	lView[directiveIndex] = nodeInjectorFactory;
	registerHostBindingOpCodes(tView, tNode, directiveIndex, allocExpando(tView, lView, def.hostVars, NO_CHANGE), def);
}
function registerHostBindingOpCodes(tView, tNode, directiveIdx, directiveVarsIdx, def) {
	ngDevMode && assertFirstCreatePass(tView);
	const hostBindings = def.hostBindings;
	if (hostBindings) {
		let hostBindingOpCodes = tView.hostBindingOpCodes;
		if (hostBindingOpCodes === null) hostBindingOpCodes = tView.hostBindingOpCodes = [];
		const elementIndx = ~tNode.index;
		if (lastSelectedElementIdx(hostBindingOpCodes) != elementIndx) hostBindingOpCodes.push(elementIndx);
		hostBindingOpCodes.push(directiveIdx, directiveVarsIdx, hostBindings);
	}
}
function lastSelectedElementIdx(hostBindingOpCodes) {
	let i = hostBindingOpCodes.length;
	while (i > 0) {
		const value = hostBindingOpCodes[--i];
		if (typeof value === "number" && value < 0) return value;
	}
	return 0;
}
function saveNameToExportMap(directiveIdx, def, exportsMap) {
	if (exportsMap) {
		if (def.exportAs) for (let i = 0; i < def.exportAs.length; i++) exportsMap[def.exportAs[i]] = directiveIdx;
		if (isComponentDef(def)) exportsMap[""] = directiveIdx;
	}
}
function initTNodeFlags(tNode, index, numberOfDirectives) {
	ngDevMode && assertNotEqual(numberOfDirectives, tNode.directiveEnd - tNode.directiveStart, "Reached the max number of directives");
	tNode.flags |= 1;
	tNode.directiveStart = index;
	tNode.directiveEnd = index + numberOfDirectives;
	tNode.providerIndexes = index;
}
function assertNoDuplicateDirectives(directives) {
	if (directives.length < 2) return;
	const seenDirectives = /* @__PURE__ */ new Set();
	for (const current of directives) {
		if (seenDirectives.has(current)) throw new RuntimeError(309, `Directive ${current.type.name} matches multiple times on the same element. Directives can only match an element once.`);
		seenDirectives.add(current);
	}
}
function directiveHostFirstCreatePass(index, lView, type, name, directiveMatcher, bindingsEnabled, attrsIndex, localRefsIndex) {
	const tView = lView[1];
	ngDevMode && assertFirstCreatePass(tView);
	const tViewConsts = tView.consts;
	const tNode = getOrCreateTNode(tView, index, type, name, getConstant(tViewConsts, attrsIndex));
	if (bindingsEnabled) resolveDirectives(tView, lView, tNode, getConstant(tViewConsts, localRefsIndex), directiveMatcher);
	tNode.mergedAttrs = mergeHostAttrs(tNode.mergedAttrs, tNode.attrs);
	if (tNode.attrs !== null) computeStaticStyling(tNode, tNode.attrs, false);
	if (tNode.mergedAttrs !== null) computeStaticStyling(tNode, tNode.mergedAttrs, true);
	if (tView.queries !== null) tView.queries.elementStart(tView, tNode);
	return tNode;
}
function directiveHostEndFirstCreatePass(tView, tNode) {
	ngDevMode && assertFirstCreatePass(tView);
	registerPostOrderHooks(tView, tNode);
	if (isContentQueryHost(tNode)) tView.queries.elementEnd(tNode);
}
function domOnlyFirstCreatePass(index, tView, type, name, attrsIndex, localRefsIndex) {
	ngDevMode && assertFirstCreatePass(tView);
	const tViewConsts = tView.consts;
	const tNode = getOrCreateTNode(tView, index, type, name, getConstant(tViewConsts, attrsIndex));
	tNode.mergedAttrs = mergeHostAttrs(tNode.mergedAttrs, tNode.attrs);
	if (localRefsIndex != null) {
		const refs = getConstant(tViewConsts, localRefsIndex);
		tNode.localNames = [];
		for (let i = 0; i < refs.length; i += 2) tNode.localNames.push(refs[i], -1);
	}
	if (tNode.attrs !== null) computeStaticStyling(tNode, tNode.attrs, false);
	if (tNode.mergedAttrs !== null) computeStaticStyling(tNode, tNode.mergedAttrs, true);
	if (tView.queries !== null) tView.queries.elementStart(tView, tNode);
	return tNode;
}
var shadowRootSupported = typeof ShadowRoot !== "undefined";
var documentSupported = typeof Document !== "undefined";
function toInputRefArray(map) {
	return Object.keys(map).map((name) => {
		const [propName, flags, transform] = map[name];
		const inputData = {
			propName,
			templateName: name,
			isSignal: (flags & InputFlags.SignalBased) !== 0
		};
		if (transform) inputData.transform = transform;
		return inputData;
	});
}
function toOutputRefArray(map) {
	return Object.keys(map).map((name) => ({
		propName: map[name],
		templateName: name
	}));
}
function createRootViewInjector(componentDef, environmentInjector, injector) {
	let realEnvironmentInjector = environmentInjector instanceof EnvironmentInjector ? environmentInjector : environmentInjector?.injector;
	if (realEnvironmentInjector && componentDef.getStandaloneInjector !== null) realEnvironmentInjector = componentDef.getStandaloneInjector(realEnvironmentInjector) || realEnvironmentInjector;
	return realEnvironmentInjector ? new ChainedInjector(injector, realEnvironmentInjector) : injector;
}
function createRootLViewEnvironment(rootLViewInjector) {
	const rendererFactory = rootLViewInjector.get(RendererFactory2, null);
	if (rendererFactory === null) throw new RuntimeError(407, ngDevMode && "Angular was not able to inject a renderer (RendererFactory2). Likely this is due to a broken DI hierarchy. Make sure that any injector used to create this component has a correct parent.");
	const sanitizer = rootLViewInjector.get(Sanitizer, null);
	const changeDetectionScheduler = rootLViewInjector.get(ChangeDetectionScheduler, null);
	const tracingService = rootLViewInjector.get(TracingService, null, { optional: true });
	let ngReflect = false;
	if (typeof ngDevMode === "undefined" || ngDevMode) ngReflect = rootLViewInjector.get(NG_REFLECT_ATTRS_FLAG, NG_REFLECT_ATTRS_FLAG_DEFAULT);
	return {
		rendererFactory,
		sanitizer,
		changeDetectionScheduler,
		ngReflect,
		tracingService
	};
}
function createHostElement(componentDef, renderer, hostElementNamespace) {
	const tagName = inferTagNameFromDefinition(componentDef);
	return createElementNode(renderer, tagName, tagName === "svg" ? "svg" : tagName === "math" ? MATH_ML_NAMESPACE : hostElementNamespace);
}
function assertNotScriptHostElement(element) {
	if ((element && "localName" in element && typeof element.localName === "string" ? element.localName : element?.tagName)?.toLowerCase() === "script") throw new RuntimeError(905, ngDevMode && `"<script>" tag is not allowed as a component host element.`);
}
function inferTagNameFromDefinition(componentDef) {
	return (componentDef.selectors[0][0] || "div").toLowerCase();
}
var ComponentFactory = class {
	componentDef;
	ngModule;
	selector;
	componentType;
	ngContentSelectors;
	isBoundToModule;
	cachedInputs = null;
	cachedOutputs = null;
	get inputs() {
		this.cachedInputs ??= toInputRefArray(this.componentDef.inputs);
		return this.cachedInputs;
	}
	get outputs() {
		this.cachedOutputs ??= toOutputRefArray(this.componentDef.outputs);
		return this.cachedOutputs;
	}
	constructor(componentDef, ngModule) {
		this.componentDef = componentDef;
		this.ngModule = ngModule;
		this.componentType = componentDef.type;
		this.selector = stringifyCSSSelectorList(componentDef.selectors);
		this.ngContentSelectors = componentDef.ngContentSelectors ?? [];
		this.isBoundToModule = !!ngModule;
	}
	create(injector, projectableNodes, rootSelectorOrNode, environmentInjector, directives, componentBindings, hostElementNamespace, allowNonStandaloneDirectives) {
		profiler(ProfilerEvent.DynamicComponentStart);
		const prevConsumer = setActiveConsumer(null);
		try {
			const cmpDef = this.componentDef;
			ngDevMode;
			const rootViewInjector = createRootViewInjector(cmpDef, environmentInjector || this.ngModule, injector);
			const environment = createRootLViewEnvironment(rootViewInjector);
			const tracingService = environment.tracingService;
			if (tracingService && tracingService.componentCreate) return tracingService.componentCreate(getComponentName(cmpDef), () => this.createComponentRef(environment, rootViewInjector, projectableNodes, rootSelectorOrNode, directives, componentBindings, hostElementNamespace, allowNonStandaloneDirectives));
			else return this.createComponentRef(environment, rootViewInjector, projectableNodes, rootSelectorOrNode, directives, componentBindings, hostElementNamespace, allowNonStandaloneDirectives);
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
	createComponentRef(environment, rootViewInjector, projectableNodes, rootSelectorOrNode, directives, componentBindings, hostElementNamespace, allowNonStandaloneDirectives) {
		const cmpDef = this.componentDef;
		const rootTView = createRootTView(rootSelectorOrNode, cmpDef, componentBindings, directives, allowNonStandaloneDirectives);
		const hostRenderer = environment.rendererFactory.createRenderer(null, cmpDef);
		const hostElement = rootSelectorOrNode ? locateHostElement(hostRenderer, rootSelectorOrNode, cmpDef.encapsulation, rootViewInjector) : createHostElement(cmpDef, hostRenderer, hostElementNamespace ?? null);
		assertNotScriptHostElement(hostElement);
		const sharedStylesHost = rootViewInjector.get(SHARED_STYLES_HOST, null);
		const styleHost = getStyleHost(hostElement, () => rootViewInjector.get(DOCUMENT$1, null) ?? getDocument());
		if (sharedStylesHost) sharedStylesHost.addHost(styleHost);
		const hasInputBindings = componentBindings?.some(isInputBinding) || directives?.some((d) => typeof d !== "function" && d.bindings.some(isInputBinding));
		const rootLView = createLView(null, rootTView, null, 512 | getInitialLViewFlagsFromDef(cmpDef), null, null, environment, hostRenderer, rootViewInjector, null, retrieveHydrationInfo(hostElement, rootViewInjector, true));
		if (sharedStylesHost && shadowRootSupported && styleHost instanceof ShadowRoot) storeLViewOnDestroy(rootLView, () => {
			sharedStylesHost.removeHost(styleHost);
		});
		rootLView[28] = hostElement;
		enterView(rootLView);
		let componentView = null;
		try {
			const hostTNode = directiveHostFirstCreatePass(28, rootLView, 2, "#host", () => rootTView.directiveRegistry, true, 0);
			setupStaticAttributes(hostRenderer, hostElement, hostTNode);
			attachPatchData(hostElement, rootLView);
			createDirectivesInstances(rootTView, rootLView, hostTNode);
			executeContentQueries(rootTView, hostTNode, rootLView);
			directiveHostEndFirstCreatePass(rootTView, hostTNode);
			if (projectableNodes !== void 0) projectNodes(hostTNode, this.ngContentSelectors, projectableNodes);
			componentView = getComponentLViewByIndex(hostTNode.index, rootLView);
			rootLView[8] = componentView[8];
			renderView(rootTView, rootLView, null);
		} catch (e) {
			if (componentView !== null) unregisterLView(componentView);
			unregisterLView(rootLView);
			throw e;
		} finally {
			profiler(ProfilerEvent.DynamicComponentEnd);
			leaveView();
		}
		return new ComponentRef(this.componentType, rootLView, !!hasInputBindings);
	}
};
function createRootTView(rootSelectorOrNode, componentDef, componentBindings, directives, allowNonStandaloneDirectives) {
	const tAttributes = rootSelectorOrNode ? ["ng-version", "22.2.1"] : extractAttrsAndClassesFromSelector(componentDef.selectors[0]);
	let creationBindings = null;
	let updateBindings = null;
	let varsToAllocate = 0;
	if (componentBindings) for (const binding of componentBindings) {
		varsToAllocate += binding[BINDING].requiredVars;
		if (binding.create) {
			binding.targetIdx = 0;
			(creationBindings ??= []).push(binding);
		}
		if (binding.update) {
			binding.targetIdx = 0;
			(updateBindings ??= []).push(binding);
		}
	}
	if (directives) for (let i = 0; i < directives.length; i++) {
		const directive = directives[i];
		if (typeof directive !== "function") for (const binding of directive.bindings) {
			varsToAllocate += binding[BINDING].requiredVars;
			const targetDirectiveIdx = i + 1;
			if (binding.create) {
				binding.targetIdx = targetDirectiveIdx;
				(creationBindings ??= []).push(binding);
			}
			if (binding.update) {
				binding.targetIdx = targetDirectiveIdx;
				(updateBindings ??= []).push(binding);
			}
		}
	}
	const directivesToApply = [componentDef];
	if (directives) for (const directive of directives) {
		const directiveType = typeof directive === "function" ? directive : directive.type;
		const directiveDef = ngDevMode ? getDirectiveDefOrThrow(directiveType) : getDirectiveDef(directiveType);
		if (ngDevMode && !allowNonStandaloneDirectives && !directiveDef.standalone) throw new RuntimeError(907, `The ${stringifyForError(directiveType)} directive must be standalone in order to be applied to a dynamically-created component.`);
		directivesToApply.push(directiveDef);
	}
	return createTView(0, null, getRootTViewTemplate(creationBindings, updateBindings), 1, varsToAllocate, directivesToApply, null, null, null, [tAttributes], null);
}
function getStyleHost(node, doc) {
	const rootNode = node.getRootNode?.();
	if (documentSupported && rootNode instanceof Document) return rootNode.head;
	else if (!rootNode) return doc().head;
	else if (shadowRootSupported && rootNode instanceof ShadowRoot) return rootNode;
	else return doc().head;
}
function getRootTViewTemplate(creationBindings, updateBindings) {
	if (!creationBindings && !updateBindings) return null;
	return (flags) => {
		if (flags & 1 && creationBindings) for (const binding of creationBindings) binding.create();
		if (flags & 2 && updateBindings) for (const binding of updateBindings) binding.update();
	};
}
function isInputBinding(binding) {
	const kind = binding[BINDING].kind;
	return kind === "input" || kind === "twoWay";
}
var ComponentRef = class extends ComponentRef$1 {
	_rootLView;
	_hasInputBindings;
	instance;
	hostView;
	changeDetectorRef;
	componentType;
	location;
	previousInputValues = null;
	_tNode;
	constructor(componentType, _rootLView, _hasInputBindings) {
		super();
		this._rootLView = _rootLView;
		this._hasInputBindings = _hasInputBindings;
		this._tNode = getTNode(_rootLView[1], 28);
		this.location = createElementRef(this._tNode, _rootLView);
		this.instance = getComponentLViewByIndex(this._tNode.index, _rootLView)[8];
		this.hostView = this.changeDetectorRef = new ViewRef$1(_rootLView, void 0);
		this.componentType = componentType;
	}
	setInput(name, value) {
		if (this._hasInputBindings && ngDevMode) throw new RuntimeError(317, "Cannot call `setInput` on a component that is using the `inputBinding` or `twoWayBinding` functions.");
		const tNode = this._tNode;
		this.previousInputValues ??= /* @__PURE__ */ new Map();
		if (this.previousInputValues.has(name) && Object.is(this.previousInputValues.get(name), value)) return;
		const lView = this._rootLView;
		const hasSetInput = setAllInputsForProperty(tNode, lView[1], lView, name, value);
		this.previousInputValues.set(name, value);
		markViewDirty(getComponentLViewByIndex(tNode.index, lView), 1);
		if (ngDevMode && !hasSetInput) {
			let message = `Can't set value of the '${name}' input on the '${stringifyForError(this.componentType)}' component. `;
			message += `Make sure that the '${name}' property is declared as an input using the input() or model() function or the @Input() decorator.`;
			reportUnknownPropertyError(message);
		}
	}
	get injector() {
		return new NodeInjector(this._tNode, this._rootLView);
	}
	destroy() {
		this.hostView.destroy();
	}
	onDestroy(callback) {
		this.hostView.onDestroy(callback);
	}
};
function projectNodes(tNode, ngContentSelectors, projectableNodes) {
	const projection = tNode.projection = [];
	for (let i = 0; i < ngContentSelectors.length; i++) {
		const nodesforSlot = projectableNodes[i];
		projection.push(nodesforSlot != null && nodesforSlot.length ? Array.from(nodesforSlot) : null);
	}
}
var ViewContainerRef = class {
	static __NG_ELEMENT_ID__ = injectViewContainerRef;
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(ViewContainerRef);
function injectViewContainerRef() {
	return createContainerRef(getCurrentTNode(), getLView());
}
var R3ViewContainerRef = class R3ViewContainerRef extends ViewContainerRef {
	_lContainer;
	_hostTNode;
	_hostLView;
	constructor(_lContainer, _hostTNode, _hostLView) {
		super();
		this._lContainer = _lContainer;
		this._hostTNode = _hostTNode;
		this._hostLView = _hostLView;
	}
	get element() {
		return createElementRef(this._hostTNode, this._hostLView);
	}
	get injector() {
		return new NodeInjector(this._hostTNode, this._hostLView);
	}
	get parentInjector() {
		const parentLocation = getParentInjectorLocation(this._hostTNode, this._hostLView);
		if (hasParentInjector(parentLocation)) {
			const parentView = getParentInjectorView(parentLocation, this._hostLView);
			const injectorIndex = getParentInjectorIndex(parentLocation);
			ngDevMode && assertNodeInjector(parentView, injectorIndex);
			const parentTNode = parentView[1].data[injectorIndex + 8];
			return new NodeInjector(parentTNode, parentView);
		} else return new NodeInjector(null, this._hostLView);
	}
	clear() {
		while (this.length > 0) this.remove(this.length - 1);
	}
	get(index) {
		const viewRefs = getViewRefs(this._lContainer);
		return viewRefs !== null && viewRefs[index] || null;
	}
	get length() {
		return this._lContainer.length - 10;
	}
	createEmbeddedView(templateRef, context, indexOrOptions) {
		let index;
		let injector;
		let onError;
		if (typeof indexOrOptions === "number") index = indexOrOptions;
		else if (indexOrOptions != null) {
			index = indexOrOptions.index;
			injector = indexOrOptions.injector;
			onError = indexOrOptions.onError;
		}
		const dehydratedView = findMatchingDehydratedView(this._lContainer, templateRef.ssrId);
		const viewRef = templateRef.createEmbeddedViewImpl(context || {}, injector, dehydratedView);
		if (onError) viewRef._lView[27] = onError;
		this.insertImpl(viewRef, index, shouldAddViewToDom(this._hostTNode, dehydratedView));
		return viewRef;
	}
	createComponent(componentType, opts, injector, projectableNodes, environmentInjector, directives, bindings) {
		let index;
		let onError;
		if (ngDevMode) {
			assertDefined(getComponentDef(componentType), "Provided Component class doesn't contain Component definition. Please check whether provided class has @Component decorator.");
			assertEqual(typeof opts !== "number", true, "It looks like Component type was provided as the first argument and a number (representing an index at which to insert the new component's host view into this container as the second argument. This combination of arguments is incompatible. Please use an object as the second argument instead.");
		}
		const options = opts || {};
		if (ngDevMode && options.environmentInjector && options.ngModuleRef) throwError(`Cannot pass both environmentInjector and ngModuleRef options to createComponent().`);
		index = options.index;
		injector = options.injector;
		projectableNodes = options.projectableNodes;
		environmentInjector = options.environmentInjector || options.ngModuleRef;
		directives = options.directives;
		bindings = options.bindings;
		onError = options.onError;
		const componentFactory = new ComponentFactory(getComponentDef(componentType));
		const contextInjector = injector || this.parentInjector;
		if (!environmentInjector && componentFactory.ngModule == null) {
			const result = this.parentInjector.get(EnvironmentInjector, null);
			if (result) environmentInjector = result;
		}
		const componentDef = getComponentDef(componentFactory.componentType ?? {});
		const dehydratedView = findMatchingDehydratedView(this._lContainer, componentDef?.id ?? null);
		const rNode = dehydratedView?.firstChild ?? null;
		const componentRef = componentFactory.create(contextInjector, projectableNodes, rNode, environmentInjector, directives, bindings, this._getHostElementNamespace());
		if (onError) componentRef.hostView._lView[27] = onError;
		this.insertImpl(componentRef.hostView, index, shouldAddViewToDom(this._hostTNode, dehydratedView));
		return componentRef;
	}
	_getHostElementNamespace() {
		if (this._hostTNode.type & 2) {
			const parentTNode = this._hostTNode.parent ?? this._hostLView[5];
			if (parentTNode !== null && parentTNode.type & 2 && typeof parentTNode.value === "string" && parentTNode.value.toLowerCase() === "foreignobject") return null;
			return parentTNode?.namespace ?? null;
		}
		return this._hostTNode.namespace;
	}
	insert(viewRef, index) {
		return this.insertImpl(viewRef, index, true);
	}
	insertImpl(viewRef, index, addToDOM) {
		const lView = viewRef._lView;
		if (ngDevMode && viewRef.destroyed) throw new RuntimeError(922, ngDevMode && "Cannot insert a destroyed View in a ViewContainer!");
		if (viewAttachedToContainer(lView)) {
			const prevIdx = this.indexOf(viewRef);
			if (prevIdx !== -1) this.detach(prevIdx);
			else {
				const prevLContainer = lView[3];
				ngDevMode && assertEqual(isLContainer(prevLContainer), true, "An attached view should have its PARENT point to a container.");
				const prevVCRef = new R3ViewContainerRef(prevLContainer, prevLContainer[5], prevLContainer[3]);
				prevVCRef.detach(prevVCRef.indexOf(viewRef));
			}
		}
		const adjustedIdx = this._adjustIndex(index);
		const lContainer = this._lContainer;
		addLViewToLContainer(lContainer, lView, adjustedIdx, addToDOM);
		viewRef.attachToViewContainerRef();
		addToArray(getOrCreateViewRefs(lContainer), adjustedIdx, viewRef);
		return viewRef;
	}
	move(viewRef, newIndex) {
		if (ngDevMode && viewRef.destroyed) throw new RuntimeError(923, ngDevMode && "Cannot move a destroyed View in a ViewContainer!");
		return this.insert(viewRef, newIndex);
	}
	indexOf(viewRef) {
		const viewRefsArr = getViewRefs(this._lContainer);
		return viewRefsArr !== null ? viewRefsArr.indexOf(viewRef) : -1;
	}
	remove(index) {
		const adjustedIdx = this._adjustIndex(index, -1);
		const detachedView = detachView(this._lContainer, adjustedIdx);
		if (detachedView) {
			removeFromArray(getOrCreateViewRefs(this._lContainer), adjustedIdx);
			destroyLView(detachedView[1], detachedView);
		}
	}
	detach(index) {
		const adjustedIdx = this._adjustIndex(index, -1);
		const view = detachView(this._lContainer, adjustedIdx);
		return view && removeFromArray(getOrCreateViewRefs(this._lContainer), adjustedIdx) != null ? new ViewRef$1(view) : null;
	}
	_adjustIndex(index, shift = 0) {
		if (index == null) return this.length + shift;
		if (ngDevMode) {
			assertGreaterThan(index, -1, `ViewRef index must be positive, got ${index}`);
			assertLessThan(index, this.length + 1 + shift, "index");
		}
		return index;
	}
};
function getViewRefs(lContainer) {
	return lContainer[8];
}
function getOrCreateViewRefs(lContainer) {
	return lContainer[8] || (lContainer[8] = []);
}
function createContainerRef(hostTNode, hostLView) {
	ngDevMode && assertTNodeType(hostTNode, 15);
	let lContainer;
	const slotValue = hostLView[hostTNode.index];
	if (isLContainer(slotValue)) lContainer = slotValue;
	else {
		lContainer = createLContainer(slotValue, hostLView, null, hostTNode);
		hostLView[hostTNode.index] = lContainer;
		addToEndOfViewTree(hostLView, lContainer);
	}
	_locateOrCreateAnchorNode(lContainer, hostLView, hostTNode, slotValue);
	return new R3ViewContainerRef(lContainer, hostTNode, hostLView);
}
function insertAnchorNode(hostLView, hostTNode) {
	const renderer = hostLView[11];
	const commentNode = renderer.createComment(ngDevMode ? "container" : "");
	const hostNative = getNativeByTNode(hostTNode, hostLView);
	nativeInsertBefore(renderer, renderer.parentNode(hostNative), commentNode, renderer.nextSibling(hostNative), false);
	return commentNode;
}
var _locateOrCreateAnchorNode = createAnchorNode;
var _populateDehydratedViewsInLContainer = () => false;
function populateDehydratedViewsInLContainer(lContainer, tNode, hostLView) {
	return _populateDehydratedViewsInLContainer(lContainer, tNode, hostLView);
}
function createAnchorNode(lContainer, hostLView, hostTNode, slotValue) {
	if (lContainer[7]) return;
	let commentNode;
	if (hostTNode.type & 8) commentNode = unwrapRNode(slotValue);
	else commentNode = insertAnchorNode(hostLView, hostTNode);
	lContainer[7] = commentNode;
}
var LQuery_ = class LQuery_ {
	queryList;
	matches = null;
	constructor(queryList) {
		this.queryList = queryList;
	}
	clone() {
		return new LQuery_(this.queryList);
	}
	setDirty() {
		this.queryList.setDirty();
	}
};
var LQueries_ = class LQueries_ {
	queries;
	constructor(queries = []) {
		this.queries = queries;
	}
	createEmbeddedView(tView) {
		const tQueries = tView.queries;
		if (tQueries !== null) {
			const noOfInheritedQueries = tView.contentQueries !== null ? tView.contentQueries[0] : tQueries.length;
			const viewLQueries = [];
			for (let i = 0; i < noOfInheritedQueries; i++) {
				const tQuery = tQueries.getByIndex(i);
				const parentLQuery = this.queries[tQuery.indexInDeclarationView];
				viewLQueries.push(parentLQuery.clone());
			}
			return new LQueries_(viewLQueries);
		}
		return null;
	}
	insertView(tView) {
		this.dirtyQueriesWithMatches(tView);
	}
	detachView(tView) {
		this.dirtyQueriesWithMatches(tView);
	}
	finishViewCreation(tView) {
		this.dirtyQueriesWithMatches(tView);
	}
	dirtyQueriesWithMatches(tView) {
		for (let i = 0; i < this.queries.length; i++) if (getTQuery(tView, i).matches !== null) this.queries[i].setDirty();
	}
};
var TQueryMetadata_ = class {
	flags;
	read;
	predicate;
	constructor(predicate, flags, read = null) {
		this.flags = flags;
		this.read = read;
		if (typeof predicate === "string") this.predicate = splitQueryMultiSelectors(predicate);
		else this.predicate = predicate;
	}
};
var TQueries_ = class TQueries_ {
	queries;
	constructor(queries = []) {
		this.queries = queries;
	}
	elementStart(tView, tNode) {
		ngDevMode && assertFirstCreatePass(tView, "Queries should collect results on the first template pass only");
		for (let i = 0; i < this.queries.length; i++) this.queries[i].elementStart(tView, tNode);
	}
	elementEnd(tNode) {
		for (let i = 0; i < this.queries.length; i++) this.queries[i].elementEnd(tNode);
	}
	embeddedTView(tNode) {
		let queriesForTemplateRef = null;
		for (let i = 0; i < this.length; i++) {
			const childQueryIndex = queriesForTemplateRef !== null ? queriesForTemplateRef.length : 0;
			const tqueryClone = this.getByIndex(i).embeddedTView(tNode, childQueryIndex);
			if (tqueryClone) {
				tqueryClone.indexInDeclarationView = i;
				if (queriesForTemplateRef !== null) queriesForTemplateRef.push(tqueryClone);
				else queriesForTemplateRef = [tqueryClone];
			}
		}
		return queriesForTemplateRef !== null ? new TQueries_(queriesForTemplateRef) : null;
	}
	template(tView, tNode) {
		ngDevMode && assertFirstCreatePass(tView, "Queries should collect results on the first template pass only");
		for (let i = 0; i < this.queries.length; i++) this.queries[i].template(tView, tNode);
	}
	getByIndex(index) {
		ngDevMode && assertIndexInRange(this.queries, index);
		return this.queries[index];
	}
	get length() {
		return this.queries.length;
	}
	track(tquery) {
		this.queries.push(tquery);
	}
};
var TQuery_ = class TQuery_ {
	metadata;
	matches = null;
	indexInDeclarationView = -1;
	crossesNgTemplate = false;
	_declarationNodeIndex;
	_appliesToNextNode = true;
	constructor(metadata, nodeIndex = -1) {
		this.metadata = metadata;
		this._declarationNodeIndex = nodeIndex;
	}
	elementStart(tView, tNode) {
		if (this.isApplyingToNode(tNode)) this.matchTNode(tView, tNode);
	}
	elementEnd(tNode) {
		if (this._declarationNodeIndex === tNode.index) this._appliesToNextNode = false;
	}
	template(tView, tNode) {
		this.elementStart(tView, tNode);
	}
	embeddedTView(tNode, childQueryIndex) {
		if (this.isApplyingToNode(tNode)) {
			this.crossesNgTemplate = true;
			this.addMatch(-tNode.index, childQueryIndex);
			return new TQuery_(this.metadata);
		}
		return null;
	}
	isApplyingToNode(tNode) {
		if (this._appliesToNextNode && (this.metadata.flags & 1) !== 1) {
			const declarationNodeIdx = this._declarationNodeIndex;
			let parent = tNode.parent;
			while (parent !== null && parent.type & 8 && parent.index !== declarationNodeIdx) parent = parent.parent;
			return declarationNodeIdx === (parent !== null ? parent.index : -1);
		}
		return this._appliesToNextNode;
	}
	matchTNode(tView, tNode) {
		const predicate = this.metadata.predicate;
		if (Array.isArray(predicate)) for (let i = 0; i < predicate.length; i++) {
			const name = predicate[i];
			this.matchTNodeWithReadOption(tView, tNode, getIdxOfMatchingSelector(tNode, name));
			this.matchTNodeWithReadOption(tView, tNode, locateDirectiveOrProvider(tNode, tView, name, false, false));
		}
		else if (predicate === TemplateRef) {
			if (tNode.type & 4) this.matchTNodeWithReadOption(tView, tNode, -1);
		} else this.matchTNodeWithReadOption(tView, tNode, locateDirectiveOrProvider(tNode, tView, predicate, false, false));
	}
	matchTNodeWithReadOption(tView, tNode, nodeMatchIdx) {
		if (nodeMatchIdx !== null) {
			const read = this.metadata.read;
			if (read !== null) {
				if (read === ElementRef || read === ViewContainerRef || read === Injector || read === TemplateRef && tNode.type & 4) this.addMatch(tNode.index, -2);
				else {
					const directiveOrProviderIdx = locateDirectiveOrProvider(tNode, tView, read, false, false);
					if (directiveOrProviderIdx !== null) this.addMatch(tNode.index, directiveOrProviderIdx);
				}
			} else this.addMatch(tNode.index, nodeMatchIdx);
		}
	}
	addMatch(tNodeIdx, matchIdx) {
		if (this.matches === null) this.matches = [tNodeIdx, matchIdx];
		else this.matches.push(tNodeIdx, matchIdx);
	}
};
function getIdxOfMatchingSelector(tNode, selector) {
	const localNames = tNode.localNames;
	if (localNames !== null) {
		for (let i = 0; i < localNames.length; i += 2) if (localNames[i] === selector) return localNames[i + 1];
	}
	return null;
}
function createResultByTNodeType(tNode, currentView) {
	if (tNode.type & 11) return createElementRef(tNode, currentView);
	else if (tNode.type & 4) return createTemplateRef(tNode, currentView);
	return null;
}
function createResultForNode(lView, tNode, matchingIdx, read) {
	if (matchingIdx === -1) return createResultByTNodeType(tNode, lView);
	else if (matchingIdx === -2) return createSpecialToken(lView, tNode, read);
	else return getNodeInjectable(lView, lView[1], matchingIdx, tNode);
}
function createSpecialToken(lView, tNode, read) {
	if (read === ElementRef) return createElementRef(tNode, lView);
	else if (read === TemplateRef) return createTemplateRef(tNode, lView);
	else if (read === ViewContainerRef) {
		ngDevMode && assertTNodeType(tNode, 15);
		return createContainerRef(tNode, lView);
	} else if (read === Injector) return new NodeInjector(tNode, lView);
	else ngDevMode && throwError(`Special token to read should be one of ElementRef, TemplateRef, ViewContainerRef or Injector but got ${stringify(read)}.`);
}
function materializeViewResults(tView, lView, tQuery, queryIndex) {
	const lQuery = lView[18].queries[queryIndex];
	if (lQuery.matches === null) {
		const tViewData = tView.data;
		const tQueryMatches = tQuery.matches;
		const result = [];
		for (let i = 0; tQueryMatches !== null && i < tQueryMatches.length; i += 2) {
			const matchedNodeIdx = tQueryMatches[i];
			if (matchedNodeIdx < 0) result.push(null);
			else {
				ngDevMode && assertIndexInRange(tViewData, matchedNodeIdx);
				const tNode = tViewData[matchedNodeIdx];
				result.push(createResultForNode(lView, tNode, tQueryMatches[i + 1], tQuery.metadata.read));
			}
		}
		lQuery.matches = result;
	}
	return lQuery.matches;
}
function collectQueryResults(tView, lView, queryIndex, result) {
	const tQuery = tView.queries.getByIndex(queryIndex);
	const tQueryMatches = tQuery.matches;
	if (tQueryMatches !== null) {
		const lViewResults = materializeViewResults(tView, lView, tQuery, queryIndex);
		for (let i = 0; i < tQueryMatches.length; i += 2) {
			const tNodeIdx = tQueryMatches[i];
			if (tNodeIdx > 0) result.push(lViewResults[i / 2]);
			else {
				const childQueryIndex = tQueryMatches[i + 1];
				const declarationLContainer = lView[-tNodeIdx];
				ngDevMode && assertLContainer(declarationLContainer);
				for (let i = 10; i < declarationLContainer.length; i++) {
					const embeddedLView = declarationLContainer[i];
					if (embeddedLView[16] === embeddedLView[3]) collectQueryResults(embeddedLView[1], embeddedLView, childQueryIndex, result);
				}
				if (declarationLContainer[9] !== null) {
					const embeddedLViews = declarationLContainer[9];
					for (let i = 0; i < embeddedLViews.length; i++) {
						const embeddedLView = embeddedLViews[i];
						collectQueryResults(embeddedLView[1], embeddedLView, childQueryIndex, result);
					}
				}
			}
		}
	}
	return result;
}
function loadQueryInternal(lView, queryIndex) {
	ngDevMode && assertDefined(lView[18], "LQueries should be defined when trying to load a query");
	ngDevMode && assertIndexInRange(lView[18].queries, queryIndex);
	return lView[18].queries[queryIndex].queryList;
}
function createLQuery(tView, lView, flags) {
	const queryList = new QueryList((flags & 4) === 4);
	storeCleanupWithContext(tView, lView, queryList, queryList.destroy);
	return (lView[18] ??= new LQueries_()).queries.push(new LQuery_(queryList)) - 1;
}
function createViewQuery(predicate, flags, read) {
	ngDevMode && assertNumber(flags, "Expecting flags");
	const tView = getTView();
	if (tView.firstCreatePass) {
		createTQuery(tView, new TQueryMetadata_(predicate, flags, read), -1);
		if ((flags & 2) === 2) tView.staticViewQueries = true;
	}
	return createLQuery(tView, getLView(), flags);
}
function createContentQuery(directiveIndex, predicate, flags, read) {
	ngDevMode && assertNumber(flags, "Expecting flags");
	const tView = getTView();
	if (tView.firstCreatePass) {
		const tNode = getCurrentTNode();
		createTQuery(tView, new TQueryMetadata_(predicate, flags, read), tNode.index);
		saveContentQueryAndDirectiveIndex(tView, directiveIndex);
		if ((flags & 2) === 2) tView.staticContentQueries = true;
	}
	return createLQuery(tView, getLView(), flags);
}
function splitQueryMultiSelectors(locator) {
	return locator.split(",").map((s) => s.trim());
}
function createTQuery(tView, metadata, nodeIndex) {
	if (tView.queries === null) tView.queries = new TQueries_();
	tView.queries.track(new TQuery_(metadata, nodeIndex));
}
function saveContentQueryAndDirectiveIndex(tView, directiveIndex) {
	const tViewContentQueries = tView.contentQueries || (tView.contentQueries = []);
	if (directiveIndex !== (tViewContentQueries.length ? tViewContentQueries[tViewContentQueries.length - 1] : -1)) tViewContentQueries.push(tView.queries.length - 1, directiveIndex);
}
function getTQuery(tView, index) {
	ngDevMode && assertDefined(tView.queries, "TQueries must be defined to retrieve a TQuery");
	return tView.queries.getByIndex(index);
}
function getQueryResults(lView, queryIndex) {
	const tView = lView[1];
	const tQuery = getTQuery(tView, queryIndex);
	return tQuery.crossesNgTemplate ? collectQueryResults(tView, lView, queryIndex, []) : materializeViewResults(tView, lView, tQuery, queryIndex);
}
function createQuerySignalFn(firstOnly, required, opts) {
	let node;
	const signalFn = createComputed(() => {
		node._dirtyCounter();
		const value = refreshSignalQuery(node, firstOnly);
		if (required && value === void 0) throw new RuntimeError(-951, ngDevMode && "Child query result is required but no value is available.");
		return value;
	});
	node = signalFn[SIGNAL];
	node._dirtyCounter = signal(0);
	node._flatValue = void 0;
	if (ngDevMode) {
		signalFn.toString = () => `[Query Signal]`;
		node.debugName = opts?.debugName;
	}
	return signalFn;
}
function createSingleResultOptionalQuerySignalFn(opts) {
	return createQuerySignalFn(true, false, opts);
}
function createSingleResultRequiredQuerySignalFn(opts) {
	return createQuerySignalFn(true, true, opts);
}
function createMultiResultQuerySignalFn(opts) {
	return createQuerySignalFn(false, false, opts);
}
function bindQueryToSignal(target, queryIndex) {
	const node = target[SIGNAL];
	node._lView = getLView();
	node._queryIndex = queryIndex;
	node._queryList = loadQueryInternal(node._lView, queryIndex);
	node._queryList.onDirty(() => node._dirtyCounter.update((v) => v + 1));
}
function refreshSignalQuery(node, firstOnly) {
	const lView = node._lView;
	const queryIndex = node._queryIndex;
	if (lView === void 0 || queryIndex === void 0 || lView[2] & 4) return firstOnly ? void 0 : EMPTY_ARRAY;
	const queryList = loadQueryInternal(lView, queryIndex);
	const results = getQueryResults(lView, queryIndex);
	queryList.reset(results, unwrapElementRef);
	if (firstOnly) return queryList.first;
	else {
		if (queryList._changesDetected || node._flatValue === void 0) return node._flatValue = queryList.toArray();
		return node._flatValue;
	}
}
function isPromise(obj) {
	return !!obj && typeof obj.then === "function";
}
function isSubscribable(obj) {
	return !!obj && typeof obj.subscribe === "function";
}
var NgModuleRef$1 = class NgModuleRef {};
var NgModuleFactory$1 = class NgModuleFactory {};
function createNgModule(ngModule, parentInjector) {
	return new NgModuleRef(ngModule, parentInjector ?? null, []);
}
var NgModuleRef = class extends NgModuleRef$1 {
	ngModuleType;
	_parent;
	_bootstrapComponents = [];
	_r3Injector;
	instance;
	destroyCbs = [];
	constructor(ngModuleType, _parent, additionalProviders, runInjectorInitializers = true) {
		super();
		this.ngModuleType = ngModuleType;
		this._parent = _parent;
		const ngModuleDef = getNgModuleDef(ngModuleType);
		ngDevMode && assertDefined(ngModuleDef, `NgModule '${stringify(ngModuleType)}' is not a subtype of 'NgModuleType'.`);
		this._bootstrapComponents = maybeUnwrapFn(ngModuleDef.bootstrap);
		this._r3Injector = createInjectorWithoutInjectorInstances(ngModuleType, _parent, [{
			provide: NgModuleRef$1,
			useValue: this
		}, ...additionalProviders], stringify(ngModuleType), /* @__PURE__ */ new Set(["environment"]));
		if (runInjectorInitializers) this.resolveInjectorInitializers();
	}
	resolveInjectorInitializers() {
		this._r3Injector.resolveInjectorInitializers();
		this.instance = this._r3Injector.get(this.ngModuleType);
	}
	get injector() {
		return this._r3Injector;
	}
	destroy() {
		ngDevMode && assertDefined(this.destroyCbs, "NgModule already destroyed");
		const injector = this._r3Injector;
		!injector.destroyed && injector.destroy();
		this.destroyCbs.forEach((fn) => fn());
		this.destroyCbs = null;
	}
	onDestroy(callback) {
		ngDevMode && assertDefined(this.destroyCbs, "NgModule already destroyed");
		this.destroyCbs.push(callback);
	}
};
var NgModuleFactory = class extends NgModuleFactory$1 {
	moduleType;
	constructor(moduleType) {
		super();
		this.moduleType = moduleType;
	}
	create(parentInjector) {
		return new NgModuleRef(this.moduleType, parentInjector, []);
	}
};
function createNgModuleRefWithProviders(moduleType, parentInjector, additionalProviders) {
	return new NgModuleRef(moduleType, parentInjector, additionalProviders, false);
}
var EnvironmentNgModuleRefAdapter = class extends NgModuleRef$1 {
	injector;
	instance = null;
	constructor(config) {
		super();
		const injector = new R3Injector([...config.providers, {
			provide: NgModuleRef$1,
			useValue: this
		}], config.parent || getNullInjector(), config.debugName, /* @__PURE__ */ new Set(["environment"]));
		this.injector = injector;
		if (config.runEnvironmentInitializers) injector.resolveInjectorInitializers();
	}
	destroy() {
		this.injector.destroy();
	}
	onDestroy(callback) {
		this.injector.onDestroy(callback);
	}
};
function createEnvironmentInjector(providers, parent, debugName = null) {
	return new EnvironmentNgModuleRefAdapter({
		providers,
		parent,
		debugName,
		runEnvironmentInitializers: true
	}).injector;
}
var StandaloneService = class StandaloneService {
	_injector;
	cachedInjectors = /* @__PURE__ */ new Map();
	constructor(_injector) {
		this._injector = _injector;
	}
	getOrCreateStandaloneInjector(componentDef) {
		if (!componentDef.standalone) return null;
		if (!this.cachedInjectors.has(componentDef)) {
			const providers = internalImportProvidersFrom(false, componentDef.type);
			const standaloneInjector = providers.length > 0 ? createEnvironmentInjector([providers], this._injector, typeof ngDevMode !== "undefined" && ngDevMode ? `Standalone[${componentDef.type.name}]` : "") : null;
			this.cachedInjectors.set(componentDef, standaloneInjector);
		}
		return this.cachedInjectors.get(componentDef);
	}
	ngOnDestroy() {
		try {
			for (const injector of this.cachedInjectors.values()) if (injector !== null) injector.destroy();
		} finally {
			this.cachedInjectors.clear();
		}
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: StandaloneService,
		providedIn: "environment",
		factory: () => new StandaloneService(ɵɵinject(EnvironmentInjector))
	});
};
function ɵɵdefineComponent(componentDefinition) {
	return noSideEffects(() => {
		(typeof ngDevMode === "undefined" || ngDevMode) && initNgDevMode();
		const baseDef = getNgDirectiveDef(componentDefinition);
		const def = {
			...baseDef,
			decls: componentDefinition.decls,
			vars: componentDefinition.vars,
			template: componentDefinition.template,
			consts: componentDefinition.consts || null,
			ngContentSelectors: componentDefinition.ngContentSelectors,
			onPush: componentDefinition.changeDetection !== ChangeDetectionStrategy.Eager,
			directiveDefs: null,
			pipeDefs: null,
			dependencies: baseDef.standalone && componentDefinition.dependencies || null,
			getStandaloneInjector: baseDef.standalone ? (parentInjector) => {
				return parentInjector.get(StandaloneService).getOrCreateStandaloneInjector(def);
			} : null,
			getExternalStyles: null,
			signals: componentDefinition.signals ?? false,
			data: componentDefinition.data || {},
			encapsulation: componentDefinition.encapsulation || ViewEncapsulation$1.Emulated,
			styles: componentDefinition.styles || EMPTY_ARRAY,
			_: null,
			schemas: componentDefinition.schemas || null,
			tView: null,
			id: ""
		};
		if (baseDef.standalone) performanceMarkFeature("NgStandalone");
		initFeatures(def);
		const dependencies = componentDefinition.dependencies;
		def.directiveDefs = extractDefListOrFactory(dependencies, extractDirectiveDef);
		def.pipeDefs = extractDefListOrFactory(dependencies, getPipeDef$1);
		def.id = getComponentId(def);
		return def;
	});
}
function extractDirectiveDef(type) {
	return getComponentDef(type) || getDirectiveDef(type);
}
function ɵɵdefineNgModule(def) {
	return noSideEffects(() => {
		return {
			type: def.type,
			bootstrap: def.bootstrap || EMPTY_ARRAY,
			declarations: def.declarations || EMPTY_ARRAY,
			imports: def.imports || EMPTY_ARRAY,
			exports: def.exports || EMPTY_ARRAY,
			transitiveCompileScopes: null,
			schemas: def.schemas || null,
			id: def.id || null
		};
	});
}
function parseAndConvertInputsForDefinition(obj, declaredInputs) {
	if (obj == null) return EMPTY_OBJ;
	const newLookup = {};
	for (const minifiedKey in obj) if (Object.hasOwn(obj, minifiedKey)) {
		const value = obj[minifiedKey];
		let publicName;
		let declaredName;
		let inputFlags;
		let transform;
		if (Array.isArray(value)) {
			inputFlags = value[0];
			publicName = value[1];
			declaredName = value[2] ?? publicName;
			transform = value[3] || null;
		} else {
			publicName = value;
			declaredName = value;
			inputFlags = InputFlags.None;
			transform = null;
		}
		newLookup[publicName] = [
			minifiedKey,
			inputFlags,
			transform
		];
		declaredInputs[publicName] = declaredName;
	}
	return newLookup;
}
function parseAndConvertOutputsForDefinition(obj) {
	if (obj == null) return EMPTY_OBJ;
	const newLookup = {};
	for (const minifiedKey in obj) if (Object.hasOwn(obj, minifiedKey)) newLookup[obj[minifiedKey]] = minifiedKey;
	return newLookup;
}
function ɵɵdefineDirective(directiveDefinition) {
	return noSideEffects(() => {
		const def = getNgDirectiveDef(directiveDefinition);
		initFeatures(def);
		return def;
	});
}
function ɵɵdefinePipe(pipeDef) {
	return {
		type: pipeDef.type,
		name: pipeDef.name,
		factory: null,
		pure: pipeDef.pure !== false,
		standalone: pipeDef.standalone ?? true,
		onDestroy: pipeDef.type.prototype.ngOnDestroy || null
	};
}
function getNgDirectiveDef(directiveDefinition) {
	const declaredInputs = {};
	return {
		type: directiveDefinition.type,
		providersResolver: null,
		viewProvidersResolver: null,
		factory: null,
		hostBindings: directiveDefinition.hostBindings || null,
		hostVars: directiveDefinition.hostVars || 0,
		hostAttrs: directiveDefinition.hostAttrs || null,
		contentQueries: directiveDefinition.contentQueries || null,
		declaredInputs,
		inputConfig: directiveDefinition.inputs || EMPTY_OBJ,
		exportAs: directiveDefinition.exportAs || null,
		standalone: directiveDefinition.standalone ?? true,
		signals: directiveDefinition.signals === true,
		selectors: directiveDefinition.selectors || EMPTY_ARRAY,
		viewQuery: directiveDefinition.viewQuery || null,
		features: directiveDefinition.features || null,
		setInput: null,
		resolveHostDirectives: null,
		hostDirectives: null,
		controlDef: null,
		signalFormsInputPresence: null,
		inputs: parseAndConvertInputsForDefinition(directiveDefinition.inputs, declaredInputs),
		outputs: parseAndConvertOutputsForDefinition(directiveDefinition.outputs),
		debugInfo: null
	};
}
function initFeatures(definition) {
	definition.features?.forEach((fn) => fn(definition));
}
function extractDefListOrFactory(dependencies, defExtractor) {
	if (!dependencies) return null;
	return () => {
		const resolvedDependencies = typeof dependencies === "function" ? dependencies() : dependencies;
		const result = [];
		for (const dep of resolvedDependencies) {
			const definition = defExtractor(dep);
			if (definition !== null) result.push(definition);
		}
		return result;
	};
}
var GENERATED_COMP_IDS = /* @__PURE__ */ new Map();
function getComponentId(componentDef) {
	let hash = 0;
	const componentDefConsts = typeof componentDef.consts === "function" ? "" : componentDef.consts;
	const hashSelectors = [
		componentDef.selectors,
		componentDef.ngContentSelectors,
		componentDef.hostVars,
		componentDef.hostAttrs,
		componentDefConsts,
		componentDef.vars,
		componentDef.decls,
		componentDef.encapsulation,
		componentDef.standalone,
		componentDef.signals,
		componentDef.exportAs,
		JSON.stringify(componentDef.inputs),
		JSON.stringify(componentDef.outputs),
		Object.getOwnPropertyNames(componentDef.type.prototype),
		!!componentDef.contentQueries,
		!!componentDef.viewQuery
	];
	if (typeof ngDevMode === "undefined" || ngDevMode) for (const item of hashSelectors) assertNotEqual(typeof item, "function", "Internal error: attempting to use a function in component id computation logic.");
	for (const char of hashSelectors.join("|")) hash = Math.imul(31, hash) + char.charCodeAt(0) << 0;
	hash += 2147483648;
	return "c" + hash;
}
var ASYNC_COMPONENT_METADATA_FN = "__ngAsyncComponentMetadataFn__";
var ASYNC_METADATA_LOADED = "__ngAsyncMetadataLoaded__";
function getAsyncClassMetadataFn(type) {
	const componentClass = type;
	if (componentClass[ASYNC_COMPONENT_METADATA_FN] === ASYNC_METADATA_LOADED) return null;
	return componentClass[ASYNC_COMPONENT_METADATA_FN] ?? null;
}
function setClassMetadataAsync(type, dependencyLoaderFn, metadataSetterFn) {
	const componentClass = type;
	componentClass[ASYNC_COMPONENT_METADATA_FN] = () => Promise.all(dependencyLoaderFn()).then((dependencies) => {
		metadataSetterFn(...dependencies);
		componentClass[ASYNC_COMPONENT_METADATA_FN] = ASYNC_METADATA_LOADED;
		return dependencies;
	});
	return componentClass[ASYNC_COMPONENT_METADATA_FN];
}
function setClassMetadata(type, decorators, ctorParameters, propDecorators) {
	return noSideEffects(() => {
		const clazz = type;
		if (decorators !== null) {
			if (Object.hasOwn(clazz, "decorators") && clazz.decorators !== void 0) clazz.decorators.push(...decorators);
			else clazz.decorators = decorators;
		}
		if (ctorParameters !== null) clazz.ctorParameters = ctorParameters;
		if (propDecorators !== null) {
			if (Object.hasOwn(clazz, "propDecorators") && clazz.propDecorators !== void 0) clazz.propDecorators = {
				...clazz.propDecorators,
				...propDecorators
			};
			else clazz.propDecorators = propDecorators;
		}
	});
}
var APP_INITIALIZER = new InjectionToken(ngDevMode ? "Application Initializer" : "");
function provideAppInitializer(initializerFn) {
	return makeEnvironmentProviders([{
		provide: APP_INITIALIZER,
		multi: true,
		useValue: initializerFn
	}]);
}
var ApplicationInitStatus = class ApplicationInitStatus {
	resolve;
	reject;
	initialized = false;
	done = false;
	donePromise = new Promise((res, rej) => {
		this.resolve = res;
		this.reject = rej;
	});
	appInits = inject(APP_INITIALIZER, { optional: true }) ?? [];
	injector = inject(Injector);
	constructor() {
		if ((typeof ngDevMode === "undefined" || ngDevMode) && !Array.isArray(this.appInits)) throw new RuntimeError(-209, `Unexpected type of the \`APP_INITIALIZER\` token value (expected an array, but got ${typeof this.appInits}). Please check that the \`APP_INITIALIZER\` token is configured as a \`multi: true\` provider.`);
	}
	runInitializers() {
		if (this.initialized) return;
		const asyncInitPromises = [];
		for (const appInits of this.appInits) {
			const initResult = runInInjectionContext(this.injector, appInits);
			if (isPromise(initResult)) asyncInitPromises.push(initResult);
			else if (isSubscribable(initResult)) {
				const observableAsPromise = new Promise((resolve, reject) => {
					initResult.subscribe({
						complete: resolve,
						error: reject
					});
				});
				asyncInitPromises.push(observableAsPromise);
			}
		}
		const complete = () => {
			this.done = true;
			this.resolve();
		};
		Promise.all(asyncInitPromises).then(() => {
			complete();
		}).catch((e) => {
			this.reject(e);
		});
		if (asyncInitPromises.length === 0) complete();
		this.initialized = true;
	}
	static ɵfac = function ApplicationInitStatus_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ApplicationInitStatus)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: ApplicationInitStatus,
		factory: ApplicationInitStatus.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ApplicationInitStatus, [{ type: Service }], () => [], null);
})();
var componentResourceResolutionQueue = /* @__PURE__ */ new Map();
var componentDefPendingResolution = /* @__PURE__ */ new Set();
async function resolveComponentResources(resourceResolver) {
	const currentQueue = componentResourceResolutionQueue;
	componentResourceResolutionQueue = /* @__PURE__ */ new Map();
	const urlCache = /* @__PURE__ */ new Map();
	function cachedResourceResolve(url) {
		const promiseCached = urlCache.get(url);
		if (promiseCached) return promiseCached;
		const promise = resourceResolver(url).then((response) => unwrapResponse(url, response));
		urlCache.set(url, promise);
		return promise;
	}
	const resolutionPromises = Array.from(currentQueue).map(async ([type, component]) => {
		if (component.styleUrl && component.styleUrls?.length) throw new Error("@Component cannot define both `styleUrl` and `styleUrls`. Use `styleUrl` if the component has one stylesheet, or `styleUrls` if it has multiple");
		const componentTasks = [];
		if (component.templateUrl) componentTasks.push(cachedResourceResolve(component.templateUrl).then((template) => {
			component.template = template;
		}));
		const styles = typeof component.styles === "string" ? [component.styles] : component.styles ?? [];
		component.styles = styles;
		let { styleUrl, styleUrls } = component;
		if (styleUrl) {
			styleUrls = [styleUrl];
			component.styleUrl = void 0;
		}
		if (styleUrls?.length) {
			const allFetched = Promise.all(styleUrls.map((url) => cachedResourceResolve(url))).then((fetchedStyles) => {
				styles.push(...fetchedStyles);
				component.styleUrls = void 0;
			});
			componentTasks.push(allFetched);
		}
		await Promise.all(componentTasks);
		componentDefPendingResolution.delete(type);
	});
	await Promise.all(resolutionPromises);
}
function maybeQueueResolutionOfComponentResources(type, metadata) {
	if (componentNeedsResolution(metadata)) {
		componentResourceResolutionQueue.set(type, metadata);
		componentDefPendingResolution.add(type);
	}
}
function isComponentDefPendingResolution(type) {
	return componentDefPendingResolution.has(type);
}
function componentNeedsResolution(component) {
	return !!(component.templateUrl && !Object.hasOwn(component, "template") || component.styleUrls?.length || component.styleUrl);
}
function clearResolutionOfComponentResourcesQueue() {
	const old = componentResourceResolutionQueue;
	componentResourceResolutionQueue = /* @__PURE__ */ new Map();
	return old;
}
function restoreComponentResolutionQueue(queue) {
	componentDefPendingResolution.clear();
	for (const type of queue.keys()) componentDefPendingResolution.add(type);
	componentResourceResolutionQueue = queue;
}
async function unwrapResponse(url, response) {
	if (typeof response === "string") return response;
	if (response.status !== void 0 && response.status !== 200) throw new RuntimeError(918, ngDevMode && `Could not load resource: ${url}. Response status: ${response.status}`);
	return response.text();
}
var modules = /* @__PURE__ */ new Map();
var checkForDuplicateNgModules = true;
function assertSameOrNotExisting(id, type, incoming) {
	if (type && type !== incoming && checkForDuplicateNgModules) throw new RuntimeError(921, ngDevMode && `Duplicate module registered for ${id} - ${stringify(type)} vs ${stringify(type.name)}`);
}
function registerNgModuleType(ngModuleType, id) {
	assertSameOrNotExisting(id, modules.get(id) || null, ngModuleType);
	modules.set(id, ngModuleType);
}
function getRegisteredNgModuleType(id) {
	return modules.get(id);
}
function setAllowDuplicateNgModuleIdsForTest(allowDuplicates) {
	checkForDuplicateNgModules = !allowDuplicates;
}
function ɵɵControlFeature(passThroughInput) {
	return (definition) => {
		definition.controlDef = {
			create: (inst, host) => {
				inst?.ɵngControlCreate(host);
			},
			update: (inst, host) => {
				inst?.ɵngControlUpdate?.(host);
			},
			passThroughInput
		};
	};
}
function ɵɵHostDirectivesFeature(rawHostDirectives) {
	const feature = (definition) => {
		const isEager = Array.isArray(rawHostDirectives);
		if (definition.hostDirectives === null) {
			definition.resolveHostDirectives = resolveHostDirectives;
			definition.hostDirectives = isEager ? rawHostDirectives.map(createHostDirectiveDef) : [rawHostDirectives];
		} else if (isEager) definition.hostDirectives.unshift(...rawHostDirectives.map(createHostDirectiveDef));
		else definition.hostDirectives.unshift(rawHostDirectives);
	};
	feature.ngInherit = true;
	return feature;
}
function resolveHostDirectives(matches) {
	const allDirectiveDefs = [];
	let hasComponent = false;
	let hostDirectiveDefs = null;
	let hostDirectiveRanges = null;
	for (let i = 0; i < matches.length; i++) {
		const def = matches[i];
		if (def.hostDirectives !== null) {
			const start = allDirectiveDefs.length;
			hostDirectiveDefs ??= /* @__PURE__ */ new Map();
			hostDirectiveRanges ??= /* @__PURE__ */ new Map();
			findHostDirectiveDefs(def, allDirectiveDefs, hostDirectiveDefs, matches);
			hostDirectiveRanges.set(def, [start, allDirectiveDefs.length - 1]);
		}
		if (i === 0 && isComponentDef(def)) {
			hasComponent = true;
			allDirectiveDefs.push(def);
		}
	}
	for (let i = hasComponent ? 1 : 0; i < matches.length; i++) allDirectiveDefs.push(matches[i]);
	if (hostDirectiveDefs !== null) hostDirectiveDefs.forEach((def, hostDirectiveDef) => {
		patchDeclaredInputs(hostDirectiveDef.declaredInputs, def.inputs);
	});
	return [
		allDirectiveDefs,
		hostDirectiveDefs,
		hostDirectiveRanges
	];
}
function findHostDirectiveDefs(currentDef, matchedDefs, hostDirectiveDefs, templateMatches) {
	if (currentDef.hostDirectives !== null) for (const configOrFn of currentDef.hostDirectives) if (typeof configOrFn === "function") {
		const resolved = configOrFn();
		for (const config of resolved) trackHostDirectiveDef(createHostDirectiveDef(config), matchedDefs, hostDirectiveDefs, templateMatches);
	} else trackHostDirectiveDef(configOrFn, matchedDefs, hostDirectiveDefs, templateMatches);
}
function trackHostDirectiveDef(def, finalMatches, hostDirectiveDefs, templateMatches) {
	const hostDirectiveDef = getDirectiveDef(def.directive);
	if (typeof ngDevMode === "undefined" || ngDevMode) validateHostDirective(def, hostDirectiveDef);
	findHostDirectiveDefs(hostDirectiveDef, finalMatches, hostDirectiveDefs, templateMatches);
	if (hostDirectiveDefs.has(hostDirectiveDef)) {
		const existing = hostDirectiveDefs.get(hostDirectiveDef);
		mergeBindingMaps(existing, def.inputs, "input");
		mergeBindingMaps(existing, def.outputs, "output");
	} else if (!templateMatches.includes(hostDirectiveDef)) {
		hostDirectiveDefs.set(hostDirectiveDef, def);
		finalMatches.push(hostDirectiveDef);
	}
}
function mergeBindingMaps(existingDef, newMap, kind) {
	const targetMap = kind === "input" ? existingDef.inputs : existingDef.outputs;
	Object.keys(newMap).forEach((publicName) => {
		const alias = newMap[publicName];
		if (!Object.hasOwn(targetMap, publicName) || targetMap[publicName] === alias) targetMap[publicName] = alias;
		else if (typeof ngDevMode === "undefined" || ngDevMode) throw new RuntimeError(312, `${kind === "input" ? "Input" : "Output"} "${publicName}" from ${existingDef.directive.name} is exposed under the following conflicting names: "${targetMap[publicName]}" and "${alias}". An ${kind} can only be exposed under a single name.`);
	});
}
function createHostDirectiveDef(config) {
	return typeof config === "function" ? {
		directive: resolveForwardRef(config),
		inputs: {},
		outputs: {}
	} : {
		directive: resolveForwardRef(config.directive),
		inputs: bindingArrayToMap(config.inputs),
		outputs: bindingArrayToMap(config.outputs)
	};
}
function bindingArrayToMap(bindings) {
	const result = {};
	if (bindings !== void 0 && bindings.length > 0) for (let i = 0; i < bindings.length; i += 2) result[bindings[i]] = bindings[i + 1];
	return result;
}
function patchDeclaredInputs(declaredInputs, exposedInputs) {
	for (const publicName in exposedInputs) if (Object.hasOwn(exposedInputs, publicName)) {
		const remappedPublicName = exposedInputs[publicName];
		const privateName = declaredInputs[publicName];
		if ((typeof ngDevMode === "undefined" || ngDevMode) && Object.hasOwn(declaredInputs, remappedPublicName)) assertEqual(declaredInputs[remappedPublicName], declaredInputs[publicName], `Conflicting host directive input alias ${publicName}.`);
		declaredInputs[remappedPublicName] = privateName;
	}
}
function validateHostDirective(hostDirectiveConfig, directiveDef) {
	const type = hostDirectiveConfig.directive;
	if (directiveDef === null) {
		if (getComponentDef(type) !== null) throw new RuntimeError(310, `Host directive ${type.name} cannot be a component.`);
		throw new RuntimeError(307, `Could not resolve metadata for host directive ${type.name}. Make sure that the ${type.name} class is annotated with an @Directive decorator.`);
	}
	if (!directiveDef.standalone) throw new RuntimeError(308, `Host directive ${directiveDef.type.name} must be standalone.`);
	validateMappings("input", directiveDef, hostDirectiveConfig.inputs);
	validateMappings("output", directiveDef, hostDirectiveConfig.outputs);
}
function validateMappings(bindingType, def, hostDirectiveBindings) {
	const className = def.type.name;
	const bindings = bindingType === "input" ? def.inputs : def.outputs;
	for (const publicName in hostDirectiveBindings) if (Object.hasOwn(hostDirectiveBindings, publicName)) {
		if (!Object.hasOwn(bindings, publicName)) throw new RuntimeError(311, `Directive ${className} does not have an ${bindingType} with a public name of ${publicName}.`);
		const remappedPublicName = hostDirectiveBindings[publicName];
		if (Object.hasOwn(bindings, remappedPublicName) && remappedPublicName !== publicName) throw new RuntimeError(312, `Cannot alias ${bindingType} ${publicName} of host directive ${className} to ${remappedPublicName}, because it already has a different ${bindingType} with the same public name.`);
	}
}
function getSuperType(type) {
	return Object.getPrototypeOf(type.prototype).constructor;
}
function ɵɵInheritDefinitionFeature(definition) {
	let superType = getSuperType(definition.type);
	let shouldInheritFields = true;
	const inheritanceChain = [definition];
	while (superType && superType !== Function.prototype && superType !== Object.prototype) {
		let superDef = void 0;
		const cmpDef = Object.hasOwn(superType, NG_COMP_DEF) ? superType[NG_COMP_DEF] : void 0;
		const dirDef = Object.hasOwn(superType, NG_DIR_DEF) ? superType[NG_DIR_DEF] : void 0;
		if (isComponentDef(definition)) superDef = cmpDef ?? dirDef;
		else {
			if (cmpDef) throw new RuntimeError(903, ngDevMode && `Directives cannot inherit Components. Directive ${stringifyForError(definition.type)} is attempting to extend component ${stringifyForError(superType)}`);
			superDef = dirDef;
		}
		if (superDef) {
			if (shouldInheritFields) {
				inheritanceChain.push(superDef);
				const writeableDef = definition;
				writeableDef.inputs = maybeUnwrapEmpty(definition.inputs);
				writeableDef.declaredInputs = maybeUnwrapEmpty(definition.declaredInputs);
				writeableDef.outputs = maybeUnwrapEmpty(definition.outputs);
				const superHostBindings = superDef.hostBindings;
				superHostBindings && inheritHostBindings(definition, superHostBindings);
				const superViewQuery = superDef.viewQuery;
				const superContentQueries = superDef.contentQueries;
				superViewQuery && inheritViewQuery(definition, superViewQuery);
				superContentQueries && inheritContentQueries(definition, superContentQueries);
				mergeInputsWithTransforms(definition, superDef);
				fillProperties(definition.outputs, superDef.outputs);
				if (isComponentDef(superDef) && superDef.data.animation) {
					const defData = definition.data;
					defData.animation = (defData.animation || []).concat(superDef.data.animation);
				}
			}
			const features = superDef.features;
			if (features) for (let i = 0; i < features.length; i++) {
				const feature = features[i];
				if (feature && feature.ngInherit) feature(definition);
				if (feature === ɵɵInheritDefinitionFeature) shouldInheritFields = false;
			}
		}
		superType = Object.getPrototypeOf(superType);
	}
	mergeHostAttrsAcrossInheritance(inheritanceChain);
}
function mergeInputsWithTransforms(target, source) {
	for (const key in source.inputs) {
		if (!Object.hasOwn(source.inputs, key)) continue;
		if (Object.hasOwn(target.inputs, key)) continue;
		const value = source.inputs[key];
		if (value !== void 0) {
			target.inputs[key] = value;
			target.declaredInputs[key] = source.declaredInputs[key];
		}
	}
}
function mergeHostAttrsAcrossInheritance(inheritanceChain) {
	let hostVars = 0;
	let hostAttrs = null;
	for (let i = inheritanceChain.length - 1; i >= 0; i--) {
		const def = inheritanceChain[i];
		def.hostVars = hostVars += def.hostVars;
		def.hostAttrs = mergeHostAttrs(def.hostAttrs, hostAttrs = mergeHostAttrs(hostAttrs, def.hostAttrs));
	}
}
function maybeUnwrapEmpty(value) {
	if (value === EMPTY_OBJ) return {};
	else if (value === EMPTY_ARRAY) return [];
	else return value;
}
function inheritViewQuery(definition, superViewQuery) {
	const prevViewQuery = definition.viewQuery;
	if (prevViewQuery) definition.viewQuery = (rf, ctx) => {
		superViewQuery(rf, ctx);
		prevViewQuery(rf, ctx);
	};
	else definition.viewQuery = superViewQuery;
}
function inheritContentQueries(definition, superContentQueries) {
	const prevContentQueries = definition.contentQueries;
	if (prevContentQueries) definition.contentQueries = (rf, ctx, directiveIndex) => {
		superContentQueries(rf, ctx, directiveIndex);
		prevContentQueries(rf, ctx, directiveIndex);
	};
	else definition.contentQueries = superContentQueries;
}
function inheritHostBindings(definition, superHostBindings) {
	const prevHostBindings = definition.hostBindings;
	if (prevHostBindings) definition.hostBindings = (rf, ctx) => {
		superHostBindings(rf, ctx);
		prevHostBindings(rf, ctx);
	};
	else definition.hostBindings = superHostBindings;
}
function templateCreate(tNode, declarationLView, declarationTView, index, templateFn, decls, vars, flags) {
	if (declarationTView.firstCreatePass) {
		tNode.mergedAttrs = mergeHostAttrs(tNode.mergedAttrs, tNode.attrs);
		const embeddedTView = tNode.tView = createTView(2, tNode, templateFn, decls, vars, declarationTView.directiveRegistry, declarationTView.pipeRegistry, null, declarationTView.schemas, declarationTView.consts, null);
		if (declarationTView.queries !== null) {
			declarationTView.queries.template(declarationTView, tNode);
			embeddedTView.queries = declarationTView.queries.embeddedTView(tNode);
		}
	}
	if (flags) tNode.flags |= flags;
	setCurrentTNode(tNode, false);
	const comment = _locateOrCreateContainerAnchor(declarationTView, declarationLView, tNode, index);
	if (wasLastNodeCreated()) appendChild(declarationTView, declarationLView, comment, tNode);
	attachPatchData(comment, declarationLView);
	const lContainer = createLContainer(comment, declarationLView, comment, tNode);
	declarationLView[index + 28] = lContainer;
	addToEndOfViewTree(declarationLView, lContainer);
	populateDehydratedViewsInLContainer(lContainer, tNode, declarationLView);
}
function declareDirectiveHostTemplate(declarationLView, declarationTView, index, templateFn, decls, vars, tagName, attrs, flags, localRefsIndex, localRefExtractor) {
	const adjustedIndex = index + 28;
	let tNode;
	if (declarationTView.firstCreatePass) {
		tNode = getOrCreateTNode(declarationTView, adjustedIndex, 4, tagName || null, attrs || null);
		if (getBindingsEnabled()) resolveDirectives(declarationTView, declarationLView, tNode, getConstant(declarationTView.consts, localRefsIndex), findDirectiveDefMatches);
		registerPostOrderHooks(declarationTView, tNode);
	} else tNode = declarationTView.data[adjustedIndex];
	templateCreate(tNode, declarationLView, declarationTView, index, templateFn, decls, vars, flags);
	if (isDirectiveHost(tNode)) createDirectivesInstances(declarationTView, declarationLView, tNode);
	if (localRefsIndex != null) saveResolvedLocalsInData(declarationLView, tNode, localRefExtractor);
	return tNode;
}
function declareNoDirectiveHostTemplate(declarationLView, declarationTView, index, templateFn, decls, vars, tagName, attrs, flags, localRefsIndex, localRefExtractor) {
	const adjustedIndex = index + 28;
	let tNode;
	if (declarationTView.firstCreatePass) {
		tNode = getOrCreateTNode(declarationTView, adjustedIndex, 4, tagName || null, attrs || null);
		if (localRefsIndex != null) {
			const refs = getConstant(declarationTView.consts, localRefsIndex);
			tNode.localNames = [];
			for (let i = 0; i < refs.length; i += 2) tNode.localNames.push(refs[i], -1);
		}
	} else tNode = declarationTView.data[adjustedIndex];
	templateCreate(tNode, declarationLView, declarationTView, index, templateFn, decls, vars, flags);
	if (localRefsIndex != null) saveResolvedLocalsInData(declarationLView, tNode, localRefExtractor);
	return tNode;
}
function ɵɵtemplate(index, templateFn, decls, vars, tagName, attrsIndex, localRefsIndex, localRefExtractor) {
	const lView = getLView();
	const tView = getTView();
	declareDirectiveHostTemplate(lView, tView, index, templateFn, decls, vars, tagName, getConstant(tView.consts, attrsIndex), void 0, localRefsIndex, localRefExtractor);
	return ɵɵtemplate;
}
function ɵɵdomTemplate(index, templateFn, decls, vars, tagName, attrsIndex, localRefsIndex, localRefExtractor) {
	const lView = getLView();
	const tView = getTView();
	declareNoDirectiveHostTemplate(lView, tView, index, templateFn, decls, vars, tagName, getConstant(tView.consts, attrsIndex), void 0, localRefsIndex, localRefExtractor);
	return ɵɵdomTemplate;
}
var _locateOrCreateContainerAnchor = createContainerAnchorImpl;
function createContainerAnchorImpl(tView, lView, tNode, index) {
	lastNodeWasCreated(true);
	return lView[11].createComment(ngDevMode ? "container" : "");
}
var DeferDependenciesLoadingState;
(function(DeferDependenciesLoadingState) {
	DeferDependenciesLoadingState[DeferDependenciesLoadingState["NOT_STARTED"] = 0] = "NOT_STARTED";
	DeferDependenciesLoadingState[DeferDependenciesLoadingState["IN_PROGRESS"] = 1] = "IN_PROGRESS";
	DeferDependenciesLoadingState[DeferDependenciesLoadingState["COMPLETE"] = 2] = "COMPLETE";
	DeferDependenciesLoadingState[DeferDependenciesLoadingState["FAILED"] = 3] = "FAILED";
})(DeferDependenciesLoadingState || (DeferDependenciesLoadingState = {}));
var MINIMUM_SLOT = 0;
var LOADING_AFTER_SLOT = 1;
var DeferBlockState;
(function(DeferBlockState) {
	DeferBlockState[DeferBlockState["Placeholder"] = 0] = "Placeholder";
	DeferBlockState[DeferBlockState["Loading"] = 1] = "Loading";
	DeferBlockState[DeferBlockState["Complete"] = 2] = "Complete";
	DeferBlockState[DeferBlockState["Error"] = 3] = "Error";
})(DeferBlockState || (DeferBlockState = {}));
var DeferBlockInternalState;
(function(DeferBlockInternalState) {
	DeferBlockInternalState[DeferBlockInternalState["Initial"] = -1] = "Initial";
})(DeferBlockInternalState || (DeferBlockInternalState = {}));
var NEXT_DEFER_BLOCK_STATE = 0;
var STATE_IS_FROZEN_UNTIL = 2;
var LOADING_AFTER_CLEANUP_FN = 3;
var TRIGGER_CLEANUP_FNS = 4;
var PREFETCH_TRIGGER_CLEANUP_FNS = 5;
var SSR_UNIQUE_ID = 6;
var SSR_BLOCK_STATE = 7;
var ON_COMPLETE_FNS = 8;
var HYDRATE_TRIGGER_CLEANUP_FNS = 9;
var DeferBlockBehavior;
(function(DeferBlockBehavior) {
	DeferBlockBehavior[DeferBlockBehavior["Manual"] = 0] = "Manual";
	DeferBlockBehavior[DeferBlockBehavior["Playthrough"] = 1] = "Playthrough";
})(DeferBlockBehavior || (DeferBlockBehavior = {}));
function storeTriggerCleanupFn(type, lDetails, cleanupFn) {
	const key = getCleanupFnKeyByType(type);
	if (lDetails[key] === null) lDetails[key] = [];
	lDetails[key].push(cleanupFn);
}
function invokeTriggerCleanupFns(type, lDetails) {
	const key = getCleanupFnKeyByType(type);
	const cleanupFns = lDetails[key];
	if (cleanupFns !== null) {
		for (const cleanupFn of cleanupFns) cleanupFn();
		lDetails[key] = null;
	}
}
function invokeAllTriggerCleanupFns(lDetails) {
	invokeTriggerCleanupFns(1, lDetails);
	invokeTriggerCleanupFns(0, lDetails);
	invokeTriggerCleanupFns(2, lDetails);
}
function getCleanupFnKeyByType(type) {
	let key = TRIGGER_CLEANUP_FNS;
	if (type === 1) key = PREFETCH_TRIGGER_CLEANUP_FNS;
	else if (type === 2) key = HYDRATE_TRIGGER_CLEANUP_FNS;
	return key;
}
function getDeferBlockDataIndex(deferBlockIndex) {
	return deferBlockIndex + 1;
}
function getLDeferBlockDetails(lView, tNode) {
	const tView = lView[1];
	const slotIndex = getDeferBlockDataIndex(tNode.index);
	ngDevMode && assertIndexInDeclRange(tView, slotIndex);
	return lView[slotIndex];
}
function setLDeferBlockDetails(lView, deferBlockIndex, lDetails) {
	const tView = lView[1];
	const slotIndex = getDeferBlockDataIndex(deferBlockIndex);
	ngDevMode && assertIndexInDeclRange(tView, slotIndex);
	lView[slotIndex] = lDetails;
}
function getTDeferBlockDetails(tView, tNode) {
	const slotIndex = getDeferBlockDataIndex(tNode.index);
	ngDevMode && assertIndexInDeclRange(tView, slotIndex);
	return tView.data[slotIndex];
}
function setTDeferBlockDetails(tView, deferBlockIndex, deferBlockConfig) {
	const slotIndex = getDeferBlockDataIndex(deferBlockIndex);
	ngDevMode && assertIndexInDeclRange(tView, slotIndex);
	tView.data[slotIndex] = deferBlockConfig;
}
function getTemplateIndexForState(newState, hostLView, tNode) {
	const tView = hostLView[1];
	const tDetails = getTDeferBlockDetails(tView, tNode);
	switch (newState) {
		case DeferBlockState.Complete: return tDetails.primaryTmplIndex;
		case DeferBlockState.Loading: return tDetails.loadingTmplIndex;
		case DeferBlockState.Error: return tDetails.errorTmplIndex;
		case DeferBlockState.Placeholder: return tDetails.placeholderTmplIndex;
		default:
			ngDevMode && throwError(`Unexpected defer block state: ${newState}`);
			return null;
	}
}
function getMinimumDurationForState(tDetails, currentState) {
	if (currentState === DeferBlockState.Placeholder) return tDetails.placeholderBlockConfig?.[MINIMUM_SLOT] ?? null;
	else if (currentState === DeferBlockState.Loading) return tDetails.loadingBlockConfig?.[MINIMUM_SLOT] ?? null;
	return null;
}
function getLoadingBlockAfter(tDetails) {
	return tDetails.loadingBlockConfig?.[LOADING_AFTER_SLOT] ?? null;
}
function addDepsToRegistry(currentDeps, newDeps) {
	if (!currentDeps || currentDeps.length === 0) return newDeps;
	const currentDepSet = new Set(currentDeps);
	for (const dep of newDeps) currentDepSet.add(dep);
	return currentDeps.length === currentDepSet.size ? currentDeps : Array.from(currentDepSet);
}
function getPrimaryBlockTNode(tView, tDetails) {
	return getTNode(tView, tDetails.primaryTmplIndex + 28);
}
function assertDeferredDependenciesLoaded(tDetails) {
	assertEqual(tDetails.loadingState, DeferDependenciesLoadingState.COMPLETE, "Expecting all deferred dependencies to be loaded.");
}
function isTDeferBlockDetails(value) {
	return value !== null && typeof value === "object" && typeof value.primaryTmplIndex === "number";
}
function isDeferBlock(tView, tNode) {
	let tDetails = null;
	const slotIndex = getDeferBlockDataIndex(tNode.index);
	if (28 < slotIndex && slotIndex < tView.bindingStartIndex) tDetails = getTDeferBlockDetails(tView, tNode);
	return !!tDetails && isTDeferBlockDetails(tDetails);
}
function trackTriggerForDebugging(tView, tNode, textRepresentation) {
	const tDetails = getTDeferBlockDetails(tView, tNode);
	tDetails.debug ??= {};
	tDetails.debug.triggers ??= /* @__PURE__ */ new Set();
	tDetails.debug.triggers.add(textRepresentation);
}
var CachedInjectorService = class CachedInjectorService {
	cachedInjectors = /* @__PURE__ */ new Map();
	getOrCreateInjector(key, parentInjector, providers, debugName) {
		if (!this.cachedInjectors.has(key)) {
			const injector = providers.length > 0 ? createEnvironmentInjector(providers, parentInjector, debugName) : null;
			this.cachedInjectors.set(key, injector);
		}
		return this.cachedInjectors.get(key);
	}
	ngOnDestroy() {
		try {
			for (const injector of this.cachedInjectors.values()) if (injector !== null) injector.destroy();
		} finally {
			this.cachedInjectors.clear();
		}
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: CachedInjectorService,
		providedIn: "environment",
		factory: () => new CachedInjectorService()
	});
};
function onTimer(delay) {
	return (callback, injector) => scheduleTimerTrigger(delay, callback, injector);
}
function scheduleTimerTrigger(delay, callback, injector) {
	const scheduler = injector.get(TimerScheduler);
	const ngZone = injector.get(NgZone);
	const cleanupFn = () => scheduler.remove(callback);
	scheduler.add(delay, callback, ngZone);
	return cleanupFn;
}
var TimerScheduler = class TimerScheduler {
	executingCallbacks = false;
	timeoutId = null;
	invokeTimerAt = null;
	current = [];
	deferred = [];
	add(delay, callback, ngZone) {
		const target = this.executingCallbacks ? this.deferred : this.current;
		this.addToQueue(target, Date.now() + delay, callback);
		this.scheduleTimer(ngZone);
	}
	remove(callback) {
		const { current, deferred } = this;
		if (this.removeFromQueue(current, callback) === -1) this.removeFromQueue(deferred, callback);
		if (current.length === 0 && deferred.length === 0) this.clearTimeout();
	}
	addToQueue(target, invokeAt, callback) {
		let insertAtIndex = target.length;
		for (let i = 0; i < target.length; i += 2) if (target[i] > invokeAt) {
			insertAtIndex = i;
			break;
		}
		arrayInsert2(target, insertAtIndex, invokeAt, callback);
	}
	removeFromQueue(target, callback) {
		let index = -1;
		for (let i = 0; i < target.length; i += 2) if (target[i + 1] === callback) {
			index = i;
			break;
		}
		if (index > -1) arraySplice(target, index, 2);
		return index;
	}
	scheduleTimer(ngZone) {
		const callback = () => {
			this.clearTimeout();
			this.executingCallbacks = true;
			const current = [...this.current];
			const now = Date.now();
			for (let i = 0; i < current.length; i += 2) {
				const invokeAt = current[i];
				const callback = current[i + 1];
				if (invokeAt <= now) callback();
				else break;
			}
			let lastCallbackIndex = -1;
			for (let i = 0; i < this.current.length; i += 2) if (this.current[i] <= now) lastCallbackIndex = i + 1;
			else break;
			if (lastCallbackIndex >= 0) arraySplice(this.current, 0, lastCallbackIndex + 1);
			this.executingCallbacks = false;
			if (this.deferred.length > 0) {
				for (let i = 0; i < this.deferred.length; i += 2) {
					const invokeAt = this.deferred[i];
					const callback = this.deferred[i + 1];
					this.addToQueue(this.current, invokeAt, callback);
				}
				this.deferred.length = 0;
			}
			this.scheduleTimer(ngZone);
		};
		const FRAME_DURATION_MS = 16;
		if (this.current.length > 0) {
			const now = Date.now();
			const invokeAt = this.current[0];
			if (this.timeoutId === null || this.invokeTimerAt && this.invokeTimerAt - invokeAt > FRAME_DURATION_MS) {
				this.clearTimeout();
				const timeout = Math.max(invokeAt - now, FRAME_DURATION_MS);
				this.invokeTimerAt = invokeAt;
				this.timeoutId = ngZone.runOutsideAngular(() => {
					return setTimeout(() => ngZone.run(callback), timeout);
				});
			}
		}
	}
	clearTimeout() {
		if (this.timeoutId !== null) {
			clearTimeout(this.timeoutId);
			this.timeoutId = null;
		}
	}
	ngOnDestroy() {
		this.clearTimeout();
		this.current.length = 0;
		this.deferred.length = 0;
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: TimerScheduler,
		providedIn: "root",
		factory: () => new TimerScheduler()
	});
};
var DEFER_BLOCK_DEPENDENCY_INTERCEPTOR = /* @__PURE__ */ new InjectionToken("DEFER_BLOCK_DEPENDENCY_INTERCEPTOR");
var DEFER_BLOCK_CONFIG = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DEFER_BLOCK_CONFIG" : "");
function getOrCreateEnvironmentInjector(parentInjector, tDetails, providers) {
	return parentInjector.get(CachedInjectorService).getOrCreateInjector(tDetails, parentInjector, providers, ngDevMode ? "DeferBlock Injector" : "");
}
function createDeferBlockInjector(parentInjector, tDetails, providers) {
	if (parentInjector instanceof ChainedInjector) {
		const origInjector = parentInjector.injector;
		const parentEnvInjector = parentInjector.parentInjector;
		return new ChainedInjector(origInjector, getOrCreateEnvironmentInjector(parentEnvInjector, tDetails, providers));
	}
	const parentEnvInjector = parentInjector.get(EnvironmentInjector);
	if (parentEnvInjector !== parentInjector) return new ChainedInjector(parentInjector, getOrCreateEnvironmentInjector(parentEnvInjector, tDetails, providers));
	return getOrCreateEnvironmentInjector(parentInjector, tDetails, providers);
}
function renderDeferBlockState(newState, tNode, lContainer, skipTimerScheduling = false) {
	const hostLView = lContainer[3];
	const hostTView = hostLView[1];
	if (isDestroyed(hostLView)) return;
	ngDevMode && assertTNodeForLView(tNode, hostLView);
	const lDetails = getLDeferBlockDetails(hostLView, tNode);
	ngDevMode && assertDefined(lDetails, "Expected a defer block state defined");
	const currentState = lDetails[1];
	const ssrState = lDetails[SSR_BLOCK_STATE];
	if (ssrState !== null && newState < ssrState) return;
	if (isValidStateChange(currentState, newState) && isValidStateChange(lDetails[NEXT_DEFER_BLOCK_STATE] ?? -1, newState)) {
		getTDeferBlockDetails(hostTView, tNode);
		const needsScheduling = !skipTimerScheduling && false;
		if (ngDevMode && needsScheduling) assertDefined(applyDeferBlockStateWithSchedulingImpl, "Expected scheduling function to be defined");
		const applyStateFn = needsScheduling ? applyDeferBlockStateWithSchedulingImpl : applyDeferBlockState;
		try {
			applyStateFn(newState, lDetails, lContainer, tNode, hostLView);
		} catch (error) {
			handleUncaughtError(hostLView, error);
		}
	}
}
function findMatchingDehydratedViewForDeferBlock(lContainer, lDetails) {
	const dehydratedViewIx = lContainer[6]?.findIndex((view) => view.data["s"] === lDetails[1]) ?? -1;
	return {
		dehydratedView: dehydratedViewIx > -1 ? lContainer[6][dehydratedViewIx] : null,
		dehydratedViewIx
	};
}
function applyDeferBlockState(newState, lDetails, lContainer, tNode, hostLView) {
	profiler(ProfilerEvent.DeferBlockStateStart);
	const stateTmplIndex = getTemplateIndexForState(newState, hostLView, tNode);
	if (stateTmplIndex !== null) {
		lDetails[1] = newState;
		const hostTView = hostLView[1];
		const activeBlockTNode = getTNode(hostTView, stateTmplIndex + 28);
		const viewIndex = 0;
		removeLViewFromLContainer(lContainer, viewIndex);
		let injector;
		if (newState === DeferBlockState.Complete) {
			const tDetails = getTDeferBlockDetails(hostTView, tNode);
			const providers = tDetails.providers;
			if (providers && providers.length > 0) injector = createDeferBlockInjector(hostLView[9], tDetails, providers);
		}
		const { dehydratedView, dehydratedViewIx } = findMatchingDehydratedViewForDeferBlock(lContainer, lDetails);
		const embeddedLView = createAndRenderEmbeddedLView(hostLView, activeBlockTNode, null, {
			injector,
			dehydratedView
		});
		addLViewToLContainer(lContainer, embeddedLView, viewIndex, shouldAddViewToDom(activeBlockTNode, dehydratedView));
		markViewForRefresh(embeddedLView);
		if (dehydratedViewIx > -1) lContainer[6]?.splice(dehydratedViewIx, 1);
		if ((newState === DeferBlockState.Complete || newState === DeferBlockState.Error) && Array.isArray(lDetails[ON_COMPLETE_FNS])) {
			for (const callback of lDetails[ON_COMPLETE_FNS]) callback();
			lDetails[ON_COMPLETE_FNS] = null;
		}
	}
	profiler(ProfilerEvent.DeferBlockStateEnd);
}
function applyDeferBlockStateWithScheduling(newState, lDetails, lContainer, tNode, hostLView) {
	const now = Date.now();
	const hostTView = hostLView[1];
	const tDetails = getTDeferBlockDetails(hostTView, tNode);
	if (lDetails[STATE_IS_FROZEN_UNTIL] === null || lDetails[STATE_IS_FROZEN_UNTIL] <= now) {
		lDetails[STATE_IS_FROZEN_UNTIL] = null;
		const loadingAfter = getLoadingBlockAfter(tDetails);
		const inLoadingAfterPhase = lDetails[LOADING_AFTER_CLEANUP_FN] !== null;
		if (newState === DeferBlockState.Loading && loadingAfter !== null && !inLoadingAfterPhase) {
			lDetails[NEXT_DEFER_BLOCK_STATE] = newState;
			lDetails[LOADING_AFTER_CLEANUP_FN] = scheduleDeferBlockUpdate(loadingAfter, lDetails, tNode, lContainer, hostLView);
		} else {
			if (newState > DeferBlockState.Loading && inLoadingAfterPhase) {
				lDetails[LOADING_AFTER_CLEANUP_FN]();
				lDetails[LOADING_AFTER_CLEANUP_FN] = null;
				lDetails[NEXT_DEFER_BLOCK_STATE] = null;
			}
			applyDeferBlockState(newState, lDetails, lContainer, tNode, hostLView);
			const duration = getMinimumDurationForState(tDetails, newState);
			if (duration !== null) {
				lDetails[STATE_IS_FROZEN_UNTIL] = now + duration;
				scheduleDeferBlockUpdate(duration, lDetails, tNode, lContainer, hostLView);
			}
		}
	} else lDetails[NEXT_DEFER_BLOCK_STATE] = newState;
}
function scheduleDeferBlockUpdate(timeout, lDetails, tNode, lContainer, hostLView) {
	const callback = () => {
		const nextState = lDetails[NEXT_DEFER_BLOCK_STATE];
		lDetails[STATE_IS_FROZEN_UNTIL] = null;
		lDetails[NEXT_DEFER_BLOCK_STATE] = null;
		if (nextState !== null) renderDeferBlockState(nextState, tNode, lContainer);
	};
	return scheduleTimerTrigger(timeout, callback, hostLView[9]);
}
function isValidStateChange(currentState, newState) {
	return currentState < newState;
}
function renderPlaceholder(lView, tNode) {
	const lContainer = lView[tNode.index];
	ngDevMode && assertLContainer(lContainer);
	renderDeferBlockState(DeferBlockState.Placeholder, tNode, lContainer);
}
function renderDeferStateAfterResourceLoading(tDetails, tNode, lContainer) {
	ngDevMode && assertDefined(tDetails.loadingPromise, "Expected loading Promise to exist on this defer block");
	tDetails.loadingPromise.then(() => {
		if (tDetails.loadingState === DeferDependenciesLoadingState.COMPLETE) {
			ngDevMode && assertDeferredDependenciesLoaded(tDetails);
			renderDeferBlockState(DeferBlockState.Complete, tNode, lContainer);
		} else if (tDetails.loadingState === DeferDependenciesLoadingState.FAILED) renderDeferBlockState(DeferBlockState.Error, tNode, lContainer);
	});
}
var applyDeferBlockStateWithSchedulingImpl = null;
function ɵɵdeferEnableTimerScheduling(tView, tDetails, placeholderConfigIndex, loadingConfigIndex) {
	const tViewConsts = tView.consts;
	if (placeholderConfigIndex != null) tDetails.placeholderBlockConfig = getConstant(tViewConsts, placeholderConfigIndex);
	if (loadingConfigIndex != null) tDetails.loadingBlockConfig = getConstant(tViewConsts, loadingConfigIndex);
	if (applyDeferBlockStateWithSchedulingImpl === null) applyDeferBlockStateWithSchedulingImpl = applyDeferBlockStateWithScheduling;
}
function shouldTriggerDeferBlock(triggerType, lView) {
	if (triggerType === 0 && true) return false;
	if (lView[9].get(DEFER_BLOCK_CONFIG, null, { optional: true })?.behavior === DeferBlockBehavior.Manual) return false;
	return true;
}
function onViewportWrapper(trigger, callback, injector, wrapperOptions) {
	const ngZone = injector.get(NgZone);
	return onViewport(trigger, () => ngZone.run(callback), (options) => ngZone.runOutsideAngular(() => createIntersectionObserver(options)), wrapperOptions);
}
function getTriggerLView(deferredHostLView, deferredTNode, walkUpTimes) {
	if (walkUpTimes == null) return deferredHostLView;
	if (walkUpTimes >= 0) return walkUpViews(walkUpTimes, deferredHostLView);
	const deferredContainer = deferredHostLView[deferredTNode.index];
	ngDevMode && assertLContainer(deferredContainer);
	const triggerLView = deferredContainer[10] ?? null;
	if (ngDevMode && triggerLView !== null) {
		const renderedState = getLDeferBlockDetails(deferredHostLView, deferredTNode)[1];
		assertEqual(renderedState, DeferBlockState.Placeholder, "Expected a placeholder to be rendered in this defer block.");
		assertLView(triggerLView);
	}
	return triggerLView;
}
function getTriggerElement(triggerLView, triggerIndex) {
	const element = getNativeByIndex(28 + triggerIndex, triggerLView);
	ngDevMode && assertElement(element);
	return element;
}
function registerDomTrigger(initialLView, tNode, triggerIndex, walkUpTimes, registerFn, callback, type, options) {
	if (!shouldTriggerDeferBlock(type, initialLView)) return;
	const injector = initialLView[9];
	const zone = injector.get(NgZone);
	let poll;
	function pollDomTrigger() {
		if (isDestroyed(initialLView)) {
			poll.destroy();
			return;
		}
		const lDetails = getLDeferBlockDetails(initialLView, tNode);
		const renderedState = lDetails[1];
		if (renderedState !== DeferBlockInternalState.Initial && renderedState !== DeferBlockState.Placeholder) {
			poll.destroy();
			return;
		}
		const triggerLView = getTriggerLView(initialLView, tNode, walkUpTimes);
		if (!triggerLView) return;
		poll.destroy();
		if (isDestroyed(triggerLView)) return;
		const cleanup = registerFn(getTriggerElement(triggerLView, triggerIndex), () => {
			zone.run(() => {
				if (initialLView !== triggerLView) removeLViewOnDestroy(triggerLView, cleanup);
				callback();
			});
		}, injector, options);
		if (initialLView !== triggerLView) storeLViewOnDestroy(triggerLView, cleanup);
		storeTriggerCleanupFn(type, lDetails, cleanup);
	}
	poll = afterEveryRender({ read: pollDomTrigger }, { injector });
}
var Console = class Console {
	log(message) {
		console.log(message);
	}
	warn(message) {
		console.warn(message);
	}
	static ɵfac = function Console_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Console)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: Console,
		factory: Console.ɵfac,
		providedIn: "platform"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Console, [{
		type: Injectable,
		args: [{ providedIn: "platform" }]
	}], null, null);
})();
var DIDebugData = class {
	resolverToTokenToDependencies = /* @__PURE__ */ new WeakMap();
	resolverToProviders = /* @__PURE__ */ new WeakMap();
	resolverToEffects = /* @__PURE__ */ new WeakMap();
	standaloneInjectorToComponent = /* @__PURE__ */ new WeakMap();
	reset() {
		this.resolverToTokenToDependencies = /* @__PURE__ */ new WeakMap();
		this.resolverToProviders = /* @__PURE__ */ new WeakMap();
		this.standaloneInjectorToComponent = /* @__PURE__ */ new WeakMap();
	}
};
var frameworkDIDebugData = new DIDebugData();
function getFrameworkDIDebugData() {
	return frameworkDIDebugData;
}
function setupFrameworkInjectorProfiler() {
	frameworkDIDebugData.reset();
	setInjectorProfiler(injectorProfilerEventHandler);
}
function injectorProfilerEventHandler(injectorProfilerEvent) {
	const { context, type } = injectorProfilerEvent;
	if (type === 0) handleInjectEvent(context, injectorProfilerEvent.service);
	else if (type === 1) handleInstanceCreatedByInjectorEvent(context, injectorProfilerEvent.instance);
	else if (type === 2) handleProviderConfiguredEvent(context, injectorProfilerEvent.providerRecord);
	else if (type === 3) handleEffectCreatedEvent(context, injectorProfilerEvent.effect);
	else if (type === 4) handleEffectCreatedEvent(context, injectorProfilerEvent.effectPhase);
}
function handleEffectCreatedEvent(context, effect) {
	const diResolver = getDIResolver(context.injector);
	if (diResolver === null) throwError("An EffectCreated event must be run within an injection context.");
	const { resolverToEffects } = frameworkDIDebugData;
	const cleanupContainer = effect instanceof EffectRefImpl ? effect[SIGNAL] : effect.sequence;
	let trackedEffects = resolverToEffects.get(diResolver);
	if (!trackedEffects) {
		trackedEffects = [];
		resolverToEffects.set(diResolver, trackedEffects);
	}
	trackedEffects.push(effect);
	cleanupContainer.onDestroyFns ??= [];
	cleanupContainer.onDestroyFns.push(() => {
		const index = trackedEffects.indexOf(effect);
		if (index > -1) trackedEffects.splice(index, 1);
	});
}
function handleInjectEvent(context, data) {
	const diResolver = getDIResolver(context.injector);
	if (diResolver === null) throwError("An Inject event must be run within an injection context.");
	const diResolverToInstantiatedToken = frameworkDIDebugData.resolverToTokenToDependencies;
	if (!diResolverToInstantiatedToken.has(diResolver)) diResolverToInstantiatedToken.set(diResolver, /* @__PURE__ */ new WeakMap());
	if (!canBeHeldWeakly(context.token)) return;
	const instantiatedTokenToDependencies = diResolverToInstantiatedToken.get(diResolver);
	if (!instantiatedTokenToDependencies.has(context.token)) instantiatedTokenToDependencies.set(context.token, []);
	const { token, value, flags } = data;
	assertDefined(context.token, "Injector profiler context token is undefined.");
	const dependencies = instantiatedTokenToDependencies.get(context.token);
	assertDefined(dependencies, "Could not resolve dependencies for token.");
	if (context.injector instanceof NodeInjector) dependencies.push({
		token,
		value,
		flags,
		injectedIn: getNodeInjectorContext(context.injector)
	});
	else dependencies.push({
		token,
		value,
		flags
	});
}
function getNodeInjectorContext(injector) {
	if (!(injector instanceof NodeInjector)) throwError("getNodeInjectorContext must be called with a NodeInjector");
	const lView = getNodeInjectorLView(injector);
	const tNode = getNodeInjectorTNode(injector);
	if (tNode === null) return;
	assertTNodeForLView(tNode, lView);
	return {
		lView,
		tNode
	};
}
function handleInstanceCreatedByInjectorEvent(context, data) {
	const { value } = data;
	if (data.value == null) return;
	if (getDIResolver(context.injector) === null) throwError("An InjectorCreatedInstance event must be run within an injection context.");
	let standaloneComponent = void 0;
	if (typeof value === "object") standaloneComponent = value?.constructor;
	if (standaloneComponent == void 0 || !isStandaloneComponent(standaloneComponent)) return;
	const environmentInjector = context.injector.get(EnvironmentInjector, null, { optional: true });
	if (environmentInjector === null) return;
	const { standaloneInjectorToComponent } = frameworkDIDebugData;
	if (standaloneInjectorToComponent.has(environmentInjector)) return;
	standaloneInjectorToComponent.set(environmentInjector, standaloneComponent);
}
function isStandaloneComponent(value) {
	return !!getComponentDef(value)?.standalone;
}
function handleProviderConfiguredEvent(context, data) {
	const { resolverToProviders } = frameworkDIDebugData;
	let diResolver;
	if (context?.injector instanceof NodeInjector) diResolver = getNodeInjectorTNode(context.injector);
	else diResolver = context.injector;
	if (diResolver === null) throwError("A ProviderConfigured event must be run within an injection context.");
	if (!resolverToProviders.has(diResolver)) resolverToProviders.set(diResolver, []);
	resolverToProviders.get(diResolver).push(data);
}
function getDIResolver(injector) {
	let diResolver = null;
	if (injector === void 0) return diResolver;
	if (injector instanceof NodeInjector) diResolver = getNodeInjectorLView(injector);
	else diResolver = injector;
	return diResolver;
}
function canBeHeldWeakly(value) {
	return value !== null && (typeof value === "object" || typeof value === "function" || typeof value === "symbol");
}
function applyChanges(component) {
	ngDevMode && assertDefined(component, "component");
	markViewDirty(getComponentViewByInstance(component), 3);
	getRootComponents(component).forEach((rootComponent) => detectChanges(rootComponent));
}
function detectChanges(component) {
	const view = getComponentViewByInstance(component);
	view[2] |= 1024;
	detectChangesInternal(view);
}
var ControlFlowBlockType;
(function(ControlFlowBlockType) {
	ControlFlowBlockType[ControlFlowBlockType["Defer"] = 0] = "Defer";
	ControlFlowBlockType[ControlFlowBlockType["For"] = 1] = "For";
})(ControlFlowBlockType || (ControlFlowBlockType = {}));
function getControlFlowBlocks(node) {
	const lView = getLContext(node)?.lView;
	if (lView) return findControlFlowBlocks(node, lView);
	return [];
}
var deferBlockFinder = ({ node, lView, tView, slotIdx }) => {
	const slot = lView[slotIdx];
	if (!isLContainer(slot)) return null;
	const lContainer = slot;
	if (!(slotIdx === tView.bindingStartIndex - 1)) {
		const tNode = tView.data[slotIdx];
		const tDetails = getTDeferBlockDetails(tView, tNode);
		if (isTDeferBlockDetails(tDetails)) {
			const native = getNativeByTNode(tNode, lView);
			const lDetails = getLDeferBlockDetails(lView, tNode);
			if (!node.contains(native)) return null;
			const viewInjector = lView[9];
			const registry = viewInjector.get(DEHYDRATED_BLOCK_REGISTRY, null, { optional: true });
			const renderedLView = getRendererLView(lContainer);
			const rootNodes = [];
			const hydrationState = inferHydrationState(tDetails, lDetails, registry);
			if (renderedLView !== null) collectNativeNodes(renderedLView[1], renderedLView, renderedLView[1].firstChild, rootNodes);
			else if (hydrationState === "dehydrated") {
				const numberOfRootNodes = viewInjector.get(TransferState).get(NGH_DEFER_BLOCKS_KEY, {})[lDetails[SSR_UNIQUE_ID]]["r"];
				let collectedNodeCount = 0;
				let currentNode = lContainer[7].previousSibling;
				while (collectedNodeCount < numberOfRootNodes && currentNode) {
					rootNodes.unshift(currentNode);
					currentNode = currentNode.previousSibling;
					collectedNodeCount++;
				}
			}
			return {
				type: ControlFlowBlockType.Defer,
				state: stringifyState(lDetails[1]),
				incrementalHydrationState: hydrationState,
				hasErrorBlock: tDetails.errorTmplIndex !== null,
				loadingBlock: {
					exists: tDetails.loadingTmplIndex !== null,
					minimumTime: tDetails.loadingBlockConfig?.[MINIMUM_SLOT] ?? null,
					afterTime: tDetails.loadingBlockConfig?.[LOADING_AFTER_SLOT] ?? null
				},
				placeholderBlock: {
					exists: tDetails.placeholderTmplIndex !== null,
					minimumTime: tDetails.placeholderBlockConfig?.[MINIMUM_SLOT] ?? null
				},
				triggers: tDetails.debug?.triggers ? Array.from(tDetails.debug.triggers).sort() : [],
				hostNode: lContainer[0],
				rootNodes
			};
		}
	}
	return null;
};
var forLoopFinder = ({ lView, slotIdx }) => {
	const slot = lView[slotIdx];
	if (!isRepeaterMetadata(slot)) return null;
	const metadata = slot;
	const liveCollection = metadata.liveCollection;
	const items = [];
	if (liveCollection) for (let j = 0; j < liveCollection.length; j++) items.push(liveCollection.at(j));
	const lContainer = lView[slotIdx + 1];
	const rootNodes = [];
	if (isLContainer(lContainer)) for (let viewIdx = 10; viewIdx < lContainer.length; viewIdx++) {
		const viewAtIdx = lContainer[viewIdx];
		if (isLView(viewAtIdx)) {
			const viewTView = viewAtIdx[1];
			const viewNodes = collectNativeNodes(viewTView, viewAtIdx, viewTView.firstChild, []);
			rootNodes.push(...viewNodes);
		}
	}
	return {
		type: ControlFlowBlockType.For,
		items,
		hasEmptyBlock: metadata.hasEmptyBlock,
		rootNodes,
		hostNode: lContainer[0],
		trackExpression: getTrackExpression(metadata)
	};
};
var CONTROL_FLOW_BLOCK_FINDERS = [deferBlockFinder, forLoopFinder];
function findControlFlowBlocks(node, lView, results = []) {
	const tView = lView[1];
	for (let i = 28; i < tView.bindingStartIndex; i++) {
		const slot = lView[i];
		for (const finder of CONTROL_FLOW_BLOCK_FINDERS) {
			const block = finder({
				node,
				lView,
				tView,
				slotIdx: i
			});
			if (block) {
				results.push(block);
				break;
			}
		}
		if (isLContainer(slot)) {
			const lContainer = slot;
			if (isLView(lContainer[0])) findControlFlowBlocks(node, lContainer[0], results);
			for (let j = 10; j < lContainer.length; j++) findControlFlowBlocks(node, lContainer[j], results);
		} else if (isLView(slot)) findControlFlowBlocks(node, slot, results);
	}
	return results;
}
function stringifyState(state) {
	switch (state) {
		case DeferBlockState.Complete: return "complete";
		case DeferBlockState.Loading: return "loading";
		case DeferBlockState.Placeholder: return "placeholder";
		case DeferBlockState.Error: return "error";
		case DeferBlockInternalState.Initial: return "initial";
		default: throw new Error(`Unrecognized state ${state}`);
	}
}
function inferHydrationState(tDetails, lDetails, registry) {
	if (registry === null || lDetails[SSR_UNIQUE_ID] === null || tDetails.hydrateTriggers === null || tDetails.hydrateTriggers.has(7)) return "not-configured";
	return registry.has(lDetails[SSR_UNIQUE_ID]) ? "dehydrated" : "hydrated";
}
function getRendererLView(lContainer) {
	if (lContainer.length <= 10) return null;
	const lView = lContainer[10];
	ngDevMode && assertLView(lView);
	return lView;
}
function isRepeaterMetadata(value) {
	return value !== null && typeof value === "object" && "hasEmptyBlock" in value && "trackByFn" in value && typeof value.trackByFn === "function";
}
function getTrackExpression(metadata) {
	const trackByFn = metadata.trackByFn;
	if (trackByFn.name === "ɵɵrepeaterTrackByIndex") return "$index";
	if (trackByFn.name === "ɵɵrepeaterTrackByIdentity") return "item";
	return "function";
}
function getDependenciesFromInjectable(injector, token) {
	const instance = injector.get(token, null, {
		self: true,
		optional: true
	});
	if (instance === null) throw new Error(`Unable to determine instance of ${token} in given injector`);
	const unformattedDependencies = getDependenciesForTokenInInjector(token, injector);
	const resolutionPath = getInjectorResolutionPath(injector);
	return {
		instance,
		dependencies: unformattedDependencies.map((dep) => {
			const formattedDependency = { value: dep.value };
			const flags = dep.flags;
			formattedDependency.flags = {
				optional: (8 & flags) === 8,
				host: (1 & flags) === 1,
				self: (2 & flags) === 2,
				skipSelf: (4 & flags) === 4
			};
			for (let i = 0; i < resolutionPath.length; i++) {
				const injectorToCheck = resolutionPath[i];
				if (i === 0 && formattedDependency.flags.skipSelf) continue;
				if (formattedDependency.flags.host && injectorToCheck instanceof EnvironmentInjector) break;
				if (injectorToCheck.get(dep.token, null, {
					self: true,
					optional: true
				}) !== null) {
					if (formattedDependency.flags.host) {
						if (resolutionPath[0].get(dep.token, null, {
							...formattedDependency.flags,
							optional: true
						}) !== null) formattedDependency.providedIn = injectorToCheck;
						break;
					}
					formattedDependency.providedIn = injectorToCheck;
					break;
				}
				if (i === 0 && formattedDependency.flags.self) break;
			}
			if (dep.token) formattedDependency.token = dep.token;
			return formattedDependency;
		})
	};
}
function getDependenciesForTokenInInjector(token, injector) {
	const { resolverToTokenToDependencies } = getFrameworkDIDebugData();
	if (!(injector instanceof NodeInjector)) return resolverToTokenToDependencies.get(injector)?.get?.(token) ?? [];
	const lView = getNodeInjectorLView(injector);
	return (resolverToTokenToDependencies.get(lView)?.get(token) ?? []).filter((dependency) => {
		const dependencyNode = dependency.injectedIn?.tNode;
		if (dependencyNode === void 0) return false;
		const instanceNode = getNodeInjectorTNode(injector);
		assertTNode(dependencyNode);
		assertTNode(instanceNode);
		return dependencyNode === instanceNode;
	});
}
function getProviderImportsContainer(injector) {
	const { standaloneInjectorToComponent } = getFrameworkDIDebugData();
	if (standaloneInjectorToComponent.has(injector)) return standaloneInjectorToComponent.get(injector);
	const defTypeRef = injector.get(NgModuleRef$1, null, {
		self: true,
		optional: true
	});
	if (defTypeRef === null) return null;
	if (defTypeRef.instance === null) return null;
	return defTypeRef.instance.constructor;
}
function getNodeInjectorProviders(injector) {
	const diResolver = getNodeInjectorTNode(injector);
	const { resolverToProviders } = getFrameworkDIDebugData();
	const existingProviders = resolverToProviders.get(diResolver) ?? [];
	const specialProviders = Array.from(getAllSpecialProviders()).map((token) => ({
		token,
		isViewProvider: false,
		provider: token
	}));
	return [...existingProviders, ...specialProviders];
}
function getProviderImportPaths(providerImportsContainer) {
	const providerToPath = /* @__PURE__ */ new Map();
	walkProviderTree(providerImportsContainer, walkProviderTreeToDiscoverImportPaths(providerToPath, /* @__PURE__ */ new Set()), [], /* @__PURE__ */ new Set());
	return providerToPath;
}
function walkProviderTreeToDiscoverImportPaths(providerToPath, visitedContainers) {
	return (provider, container) => {
		if (!providerToPath.has(provider)) providerToPath.set(provider, [container]);
		if (!visitedContainers.has(container)) for (const prov of providerToPath.keys()) {
			const existingImportPath = providerToPath.get(prov);
			let containerDef = getInjectorDef(container);
			if (!containerDef) {
				const ngModule = container.ngModule;
				containerDef = getInjectorDef(ngModule);
			}
			if (!containerDef) return;
			const lastContainerAddedToPath = existingImportPath[0];
			let isNextStepInPath = false;
			deepForEach(containerDef.imports, (moduleImport) => {
				if (isNextStepInPath) return;
				isNextStepInPath = moduleImport.ngModule === lastContainerAddedToPath || moduleImport === lastContainerAddedToPath;
				if (isNextStepInPath) providerToPath.get(prov)?.unshift(container);
			});
		}
		visitedContainers.add(container);
	};
}
function getEnvironmentInjectorProviders(injector) {
	const providerRecordsWithoutImportPaths = getFrameworkDIDebugData().resolverToProviders.get(injector) ?? [];
	if (isPlatformInjector(injector)) return providerRecordsWithoutImportPaths;
	const providerImportsContainer = getProviderImportsContainer(injector);
	if (providerImportsContainer === null) return providerRecordsWithoutImportPaths;
	const providerToPath = getProviderImportPaths(providerImportsContainer);
	const providerRecords = [];
	for (const providerRecord of providerRecordsWithoutImportPaths) {
		const provider = providerRecord.provider;
		const token = provider.provide;
		if (token === ENVIRONMENT_INITIALIZER || token === INJECTOR_DEF_TYPES) continue;
		let importPath = providerToPath.get(provider) ?? [];
		if (!!getComponentDef(providerImportsContainer)?.standalone) importPath = [providerImportsContainer, ...importPath];
		providerRecords.push({
			...providerRecord,
			importPath
		});
	}
	return providerRecords;
}
function isPlatformInjector(injector) {
	return injector instanceof R3Injector && injector.scopes.has("platform");
}
function getInjectorProviders(injector) {
	if (injector instanceof NodeInjector) return getNodeInjectorProviders(injector);
	else if (injector instanceof EnvironmentInjector) return getEnvironmentInjectorProviders(injector);
	throwError("getInjectorProviders only supports NodeInjector and EnvironmentInjector");
}
function getInjectorMetadata(injector) {
	if (injector instanceof NodeInjector) {
		const lView = getNodeInjectorLView(injector);
		const tNode = getNodeInjectorTNode(injector);
		assertTNodeForLView(tNode, lView);
		return {
			type: "element",
			source: getNativeByTNode(tNode, lView)
		};
	}
	if (injector instanceof R3Injector) return {
		type: "environment",
		source: injector.source ?? null
	};
	if (injector instanceof NullInjector) return {
		type: "null",
		source: null
	};
	return null;
}
function getInjectorResolutionPath(injector) {
	const resolutionPath = [injector];
	getInjectorResolutionPathHelper(injector, resolutionPath);
	return resolutionPath;
}
function getInjectorResolutionPathHelper(injector, resolutionPath) {
	const parent = getInjectorParent(injector);
	if (parent === null) {
		if (injector instanceof NodeInjector) {
			const firstInjector = resolutionPath[0];
			if (firstInjector instanceof NodeInjector) {
				const moduleInjector = getModuleInjectorOfNodeInjector(firstInjector);
				if (moduleInjector === null) throwError("NodeInjector must have some connection to the module injector tree");
				resolutionPath.push(moduleInjector);
				getInjectorResolutionPathHelper(moduleInjector, resolutionPath);
			}
			return resolutionPath;
		}
	} else {
		resolutionPath.push(parent);
		getInjectorResolutionPathHelper(parent, resolutionPath);
	}
	return resolutionPath;
}
function getInjectorParent(injector) {
	if (injector instanceof R3Injector) return injector.parent;
	let tNode;
	let lView;
	if (injector instanceof NodeInjector) {
		tNode = getNodeInjectorTNode(injector);
		lView = getNodeInjectorLView(injector);
	} else if (injector instanceof NullInjector) return null;
	else if (injector instanceof ChainedInjector) return injector.parentInjector;
	else throwError("getInjectorParent only support injectors of type R3Injector, NodeInjector, NullInjector");
	const parentLocation = getParentInjectorLocation(tNode, lView);
	if (hasParentInjector(parentLocation)) {
		const parentInjectorIndex = getParentInjectorIndex(parentLocation);
		const parentLView = getParentInjectorView(parentLocation, lView);
		const parentTNode = parentLView[1].data[parentInjectorIndex + 8];
		return new NodeInjector(parentTNode, parentLView);
	} else {
		const injectorParent = lView[9].injector?.parent;
		if (injectorParent instanceof NodeInjector) return injectorParent;
	}
	return null;
}
function getModuleInjectorOfNodeInjector(injector) {
	let lView;
	if (injector instanceof NodeInjector) lView = getNodeInjectorLView(injector);
	else throwError("getModuleInjectorOfNodeInjector must be called with a NodeInjector");
	const inj = lView[9];
	const moduleInjector = inj instanceof ChainedInjector ? inj.parentInjector : inj.parent;
	if (!moduleInjector) throwError("NodeInjector must have some connection to the module injector tree");
	return moduleInjector;
}
function isComputedNode(node) {
	return node.kind === "computed";
}
function isTemplateEffectNode(node) {
	return node.kind === "template";
}
function isEffectNode(node) {
	return node.kind === "effect";
}
function isSignalNode(node) {
	return node.kind === "signal";
}
function isLinkedSignalNode(node) {
	return node.kind === "linkedSignal";
}
function isAfterRenderEffectPhaseNode(node) {
	return node.kind === "afterRenderEffectPhase";
}
function getTemplateConsumer(injector) {
	const tNode = getNodeInjectorTNode(injector);
	assertTNode(tNode);
	const lView = getNodeInjectorLView(injector);
	assertLView(lView);
	const templateLView = lView[tNode.index];
	if (isLView(templateLView)) return templateLView[24] ?? null;
	return null;
}
var signalDebugMap = /* @__PURE__ */ new WeakMap();
var signalDebugNodeMap = /* @__PURE__ */ new Map();
var watchCleanupRegistry = new FinalizationRegistry(({ id }) => {
	unwatchSignal(id);
	signalDebugNodeMap.delete(id);
});
var counter$1 = 0;
function isWatched(id) {
	const watchRef = signalDebugNodeMap.get(id)?.watch;
	if (!watchRef) return false;
	const watchNode = watchRef.deref();
	return watchNode !== void 0 && !watchNode.destroyed;
}
function getNodesAndEdgesFromSignalMap(signalMap) {
	const nodes = Array.from(signalMap.keys());
	const debugSignalGraphNodes = [];
	const edges = [];
	for (const [consumer, producers] of signalMap.entries()) {
		const consumerIndex = nodes.indexOf(consumer);
		let id = signalDebugMap.get(consumer);
		if (!id) {
			counter$1++;
			id = counter$1.toString();
			signalDebugMap.set(consumer, id);
		}
		if (isComputedNode(consumer)) {
			if (!signalDebugNodeMap.has(id)) {
				signalDebugNodeMap.set(id, { node: new WeakRef(consumer) });
				watchCleanupRegistry.register(consumer, { id });
			}
			debugSignalGraphNodes.push({
				label: consumer.debugName,
				value: consumer.value,
				kind: consumer.kind,
				epoch: consumer.version,
				debuggableFn: consumer.computation,
				watched: isWatched(id),
				id
			});
		} else if (isSignalNode(consumer)) {
			if (!signalDebugNodeMap.has(id)) {
				signalDebugNodeMap.set(id, { node: new WeakRef(consumer) });
				watchCleanupRegistry.register(consumer, { id });
			}
			debugSignalGraphNodes.push({
				label: consumer.debugName,
				value: consumer.value,
				kind: consumer.kind,
				epoch: consumer.version,
				watched: isWatched(id),
				id
			});
		} else if (isTemplateEffectNode(consumer)) debugSignalGraphNodes.push({
			label: consumer.debugName ?? consumer.lView?.[0]?.tagName?.toLowerCase?.(),
			kind: consumer.kind,
			epoch: consumer.version,
			debuggableFn: consumer.lView?.[8]?.constructor,
			watched: false,
			id
		});
		else if (isLinkedSignalNode(consumer)) {
			if (!signalDebugNodeMap.has(id)) {
				signalDebugNodeMap.set(id, { node: new WeakRef(consumer) });
				watchCleanupRegistry.register(consumer, { id });
			}
			debugSignalGraphNodes.push({
				label: consumer.debugName,
				value: consumer.value,
				kind: consumer.kind,
				epoch: consumer.version,
				debuggableFn: consumer.computation,
				watched: isWatched(id),
				id
			});
		} else if (isEffectNode(consumer)) debugSignalGraphNodes.push({
			label: consumer.debugName,
			kind: consumer.kind,
			epoch: consumer.version,
			debuggableFn: consumer.userFn,
			id
		});
		else if (isAfterRenderEffectPhaseNode(consumer)) debugSignalGraphNodes.push({
			label: consumer.debugName,
			kind: consumer.kind,
			epoch: consumer.version,
			debuggableFn: consumer.userFn,
			id
		});
		else debugSignalGraphNodes.push({
			label: consumer.debugName,
			kind: consumer.kind,
			epoch: consumer.version,
			watched: false,
			id
		});
		for (const producer of producers) edges.push({
			consumer: consumerIndex,
			producer: nodes.indexOf(producer)
		});
	}
	return {
		nodes: debugSignalGraphNodes,
		edges
	};
}
function extractEffectsFromInjector(injector) {
	let diResolver = injector;
	if (injector instanceof NodeInjector) diResolver = getNodeInjectorLView(injector);
	return (getFrameworkDIDebugData().resolverToEffects.get(diResolver) ?? []).map((effect) => {
		if (effect instanceof EffectRefImpl) return effect[SIGNAL];
		else return effect.signal[SIGNAL];
	});
}
function extractSignalNodesAndEdgesFromRoots(nodes, signalDependenciesMap = /* @__PURE__ */ new Map()) {
	for (const node of nodes) {
		if (signalDependenciesMap.has(node)) continue;
		const producerNodes = [];
		for (let link = node.producers; link !== void 0; link = link.nextProducer) {
			const producer = link.producer;
			producerNodes.push(producer);
		}
		signalDependenciesMap.set(node, producerNodes);
		extractSignalNodesAndEdgesFromRoots(producerNodes, signalDependenciesMap);
	}
	return signalDependenciesMap;
}
function getSignalGraph(injector) {
	let templateConsumer = null;
	if (!(injector instanceof NodeInjector) && !(injector instanceof R3Injector)) return throwError("getSignalGraph must be called with a NodeInjector or R3Injector");
	if (injector instanceof NodeInjector) templateConsumer = getTemplateConsumer(injector);
	const nonTemplateEffectNodes = extractEffectsFromInjector(injector);
	return getNodesAndEdgesFromSignalMap(extractSignalNodesAndEdgesFromRoots(templateConsumer ? [templateConsumer, ...nonTemplateEffectNodes] : nonTemplateEffectNodes));
}
function toggleWatchSignal(id) {
	const entry = signalDebugNodeMap.get(id);
	if (!entry) {
		console.warn(`Could not find signal with ID "${id}". The ID may be wrong, or it could have been garbage collected.`);
		return;
	}
	if (entry.watch) {
		const activeWatch = entry.watch.deref();
		if (activeWatch && !activeWatch.destroyed) {
			unwatchSignal(id);
			return;
		}
	}
	const node = entry.node.deref();
	if (!node) {
		unwatchSignal(id);
		signalDebugNodeMap.delete(id);
		return;
	}
	const watchNode = createDebugWatchNode(node);
	entry.watch = new WeakRef(watchNode);
	runDebugWatch(watchNode);
}
function createDebugWatchNode(targetNode) {
	const node = {
		...REACTIVE_NODE,
		consumerIsAlwaysLive: true,
		consumerAllowSignalWrites: true,
		dirty: true,
		kind: "effect",
		targetNode: new WeakRef(targetNode),
		destroyed: false,
		consumerMarkedDirty: () => {
			if (node.destroyed) return;
			queueMicrotask(() => runDebugWatch(node));
		}
	};
	return node;
}
function runDebugWatch(node) {
	if (node.destroyed) return;
	const targetNode = node.targetNode.deref();
	if (!targetNode) {
		node.destroyed = true;
		consumerDestroy(node);
		return;
	}
	node.dirty = false;
	if (node.version > 0 && !consumerPollProducersForChange(node)) return;
	node.version++;
	const prevConsumer = consumerBeforeComputation(node);
	try {
		producerUpdateValueVersion(targetNode);
		producerAccessed(targetNode);
		const name = targetNode.debugName ? targetNode.debugName : "DevTools signal watch";
		if ((isComputedNode(targetNode) || isLinkedSignalNode(targetNode)) && targetNode.value === ERRORED) {
			console.error(`[${name} (error)]:`, targetNode.error);
			return;
		}
		const value = isSignalNode(targetNode) || isComputedNode(targetNode) || isLinkedSignalNode(targetNode) ? targetNode.value : void 0;
		console.log(`[${name}]:`, value);
	} finally {
		consumerAfterComputation(node, prevConsumer);
	}
}
function unwatchSignal(id) {
	const entry = signalDebugNodeMap.get(id);
	if (entry?.watch) {
		const watchNode = entry.watch.deref();
		if (watchNode && !watchNode.destroyed) {
			watchNode.destroyed = true;
			consumerDestroy(watchNode);
		}
		entry.watch = void 0;
	}
}
var changeDetectionRuns = 0;
var changeDetectionSyncRuns = 0;
var counter = 0;
var nextInstanceDeepLinkId = 0;
var instanceDeepLinkIds = /* @__PURE__ */ new WeakMap();
function getComponentInstanceDeepLinkId(instance) {
	return instanceDeepLinkIds.get(instance);
}
function assignComponentInstanceDeepLinkId(instance) {
	const id = nextInstanceDeepLinkId++;
	instanceDeepLinkIds.set(instance, id);
	return id;
}
var DEEP_LINK_SCHEME = "angular-devtools";
function getDeepLinkProperties(instance) {
	if (typeof __NG_DEVTOOLS_CONNECTED__ === "undefined" || !__NG_DEVTOOLS_CONNECTED__) return void 0;
	return {
		url: `${DEEP_LINK_SCHEME}://component/${getComponentInstanceDeepLinkId(instance) ?? assignComponentInstanceDeepLinkId(instance)}`,
		description: "Component"
	};
}
var eventsStack = [];
function getBaseDocUrl() {
	const full = VERSION.full;
	return `https://${full.includes("-next") || full.includes("-rc") || full === "22.2.1" ? "next" : `v${VERSION.major}`}.angular.dev`;
}
function getLifecycleHookDocUrl(hookName) {
	const match = hookName.match(/:(ng\w+)$/);
	if (!match) return void 0;
	const lifecycleHook = match[1].toLowerCase();
	return `${getBaseDocUrl()}/guide/components/lifecycle#${lifecycleHook}`;
}
function getProfilerEventDocUrl(event, entryName) {
	const baseUrl = getBaseDocUrl();
	switch (event) {
		case ProfilerEvent.ChangeDetectionStart:
		case ProfilerEvent.ChangeDetectionEnd:
		case ProfilerEvent.ChangeDetectionSyncStart:
		case ProfilerEvent.ChangeDetectionSyncEnd: return `${baseUrl}/best-practices/runtime-performance`;
		case ProfilerEvent.AfterRenderHooksStart:
		case ProfilerEvent.AfterRenderHooksEnd: return `${baseUrl}/guide/components/lifecycle#aftereveryrender-and-afternextrender`;
		case ProfilerEvent.DeferBlockStateStart:
		case ProfilerEvent.DeferBlockStateEnd: return `${baseUrl}/guide/defer`;
		case ProfilerEvent.LifecycleHookStart: return getLifecycleHookDocUrl(entryName);
		default: return;
	}
}
function resolveTimestampDetail(detail, docUrl) {
	if (!docUrl) return detail;
	if (!detail) return {
		description: "Documentation",
		url: docUrl
	};
	return detail;
}
function measureStart(startEvent) {
	eventsStack.push([startEvent, counter]);
	console.timeStamp("Event_" + startEvent + "_" + counter++);
}
function measureEnd(startEvent, entryName, color, detail) {
	let top;
	do {
		top = eventsStack.pop();
		assertDefined(top, "Profiling error: could not find start event entry " + startEvent);
	} while (top[0] !== startEvent);
	const resolvedDetail = resolveTimestampDetail(detail, getProfilerEventDocUrl(startEvent, entryName));
	console.timeStamp(entryName, "Event_" + top[0] + "_" + top[1], void 0, "🅰️ Angular", void 0, color, resolvedDetail);
}
var chromeDevToolsInjectorProfiler = (event) => {
	const eventType = event.type;
	if (eventType === 5) measureStart(100);
	else if (eventType === 1) {
		const token = event.context.token;
		measureEnd(100, getProviderTokenMeasureName(token), "tertiary-dark");
	}
};
var devToolsProfiler = (event, instance, eventFn) => {
	switch (event) {
		case ProfilerEvent.BootstrapApplicationStart:
		case ProfilerEvent.BootstrapComponentStart:
		case ProfilerEvent.ChangeDetectionStart:
		case ProfilerEvent.ChangeDetectionSyncStart:
		case ProfilerEvent.AfterRenderHooksStart:
		case ProfilerEvent.ComponentStart:
		case ProfilerEvent.DeferBlockStateStart:
		case ProfilerEvent.DynamicComponentStart:
		case ProfilerEvent.TemplateCreateStart:
		case ProfilerEvent.LifecycleHookStart:
		case ProfilerEvent.TemplateUpdateStart:
		case ProfilerEvent.HostBindingsUpdateStart:
		case ProfilerEvent.OutputStart:
			measureStart(event);
			break;
		case ProfilerEvent.BootstrapApplicationEnd:
			measureEnd(ProfilerEvent.BootstrapApplicationStart, "Bootstrap application", "primary-dark");
			break;
		case ProfilerEvent.BootstrapComponentEnd:
			measureEnd(ProfilerEvent.BootstrapComponentStart, "Bootstrap component", "primary-dark");
			break;
		case ProfilerEvent.ChangeDetectionEnd:
			changeDetectionSyncRuns = 0;
			measureEnd(ProfilerEvent.ChangeDetectionStart, "Change detection " + changeDetectionRuns++, "primary-dark");
			break;
		case ProfilerEvent.ChangeDetectionSyncEnd:
			measureEnd(ProfilerEvent.ChangeDetectionSyncStart, "Synchronization " + changeDetectionSyncRuns++, "primary");
			break;
		case ProfilerEvent.AfterRenderHooksEnd:
			measureEnd(ProfilerEvent.AfterRenderHooksStart, "After render hooks", "primary");
			break;
		case ProfilerEvent.ComponentEnd: {
			const typeName = getComponentMeasureName(instance);
			measureEnd(ProfilerEvent.ComponentStart, typeName, "primary-light", getDeepLinkProperties(instance));
			break;
		}
		case ProfilerEvent.DeferBlockStateEnd:
			measureEnd(ProfilerEvent.DeferBlockStateStart, "Defer block", "primary-dark");
			break;
		case ProfilerEvent.DynamicComponentEnd:
			measureEnd(ProfilerEvent.DynamicComponentStart, "Dynamic component creation", "primary-dark");
			break;
		case ProfilerEvent.TemplateUpdateEnd:
			measureEnd(ProfilerEvent.TemplateUpdateStart, stringifyForError(eventFn) + " (update)", "secondary-dark");
			break;
		case ProfilerEvent.TemplateCreateEnd:
			measureEnd(ProfilerEvent.TemplateCreateStart, stringifyForError(eventFn) + " (create)", "secondary");
			break;
		case ProfilerEvent.HostBindingsUpdateEnd:
			measureEnd(ProfilerEvent.HostBindingsUpdateStart, "HostBindings", "secondary-dark");
			break;
		case ProfilerEvent.LifecycleHookEnd: {
			const typeName = getComponentMeasureName(instance);
			measureEnd(ProfilerEvent.LifecycleHookStart, `${typeName}:${stringifyForError(eventFn)}`, "tertiary");
			break;
		}
		case ProfilerEvent.OutputEnd:
			measureEnd(ProfilerEvent.OutputStart, stringifyForError(eventFn), "tertiary-light");
			break;
		default: throw new Error("Unexpected profiling event type: " + event);
	}
};
function getComponentMeasureName(instance) {
	return instance.constructor.name;
}
function getProviderTokenMeasureName(token) {
	if (isTypeProvider(token)) return token.name;
	else if (token.provide != null) return getProviderTokenMeasureName(token.provide);
	return token.toString();
}
function enableProfiling$1() {
	performanceMarkFeature("Chrome DevTools profiling");
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		const removeInjectorProfiler = setInjectorProfiler(chromeDevToolsInjectorProfiler);
		const removeProfiler = setProfiler(devToolsProfiler);
		return () => {
			removeInjectorProfiler();
			removeProfiler();
		};
	}
	return () => {};
}
function getTransferState(injector) {
	const transferState = retrieveTransferredState(injector.get(DOCUMENT$1), injector.get(APP_ID));
	const filteredEntries = {};
	for (const [key, value] of Object.entries(transferState)) if (!isInternalHydrationTransferStateKey(key)) filteredEntries[key] = value;
	return filteredEntries;
}
var GLOBAL_PUBLISH_EXPANDO_KEY = "ng";
var internalCoreGlobalUtils = { toggleWatchSignal };
var externalCoreGlobalUtils = {
	"ɵgetDependenciesFromInjectable": getDependenciesFromInjectable,
	"ɵgetInjectorProviders": getInjectorProviders,
	"ɵgetInjectorResolutionPath": getInjectorResolutionPath,
	"ɵgetInjectorMetadata": getInjectorMetadata,
	"ɵsetProfiler": setProfiler,
	"ɵgetSignalGraph": getSignalGraph,
	"ɵgetControlFlowBlocks": getControlFlowBlocks,
	"ɵgetTransferState": getTransferState,
	"ɵgetComponentInstanceDeepLinkId": getComponentInstanceDeepLinkId,
	getDirectiveMetadata: getDirectiveMetadata$1,
	getComponent,
	getContext,
	getListeners,
	getOwningComponent,
	getHostElement,
	getInjector,
	getRootComponents,
	getDirectives,
	applyChanges,
	isSignal,
	enableProfiling: enableProfiling$1
};
var _published = false;
function publishDefaultGlobalUtils$1() {
	if (!_published) {
		_published = true;
		if (typeof window !== "undefined") setupFrameworkInjectorProfiler();
		for (const [methodName, method] of Object.entries(externalCoreGlobalUtils)) publishGlobalUtil(methodName, method);
		for (const [methodName, method] of Object.entries(internalCoreGlobalUtils)) publishGlobalUtil(methodName, method);
	}
}
function publishGlobalUtil(name, fn) {
	publishUtil(name, fn);
}
function publishNonCoreGlobalUtil(name, fn) {
	publishUtil(name, fn);
}
function publishUtil(name, fn) {
	if (typeof COMPILED === "undefined" || !COMPILED) {
		const w = _global;
		ngDevMode && assertDefined(fn, "function not defined");
		w[GLOBAL_PUBLISH_EXPANDO_KEY] ??= {};
		w[GLOBAL_PUBLISH_EXPANDO_KEY][name] = fn;
	}
}
var TESTABILITY = new InjectionToken("");
var TESTABILITY_GETTER = new InjectionToken("");
var USE_PENDING_TASKS = new InjectionToken("USE_PENDING_TASKS", {
	providedIn: "root",
	factory: () => typeof Zone === "undefined"
});
var Testability = class Testability {
	_ngZone;
	registry;
	_isZoneStable = true;
	_callbacks = [];
	_taskTrackingZone = null;
	_destroyRef;
	pendingTasksInternal = inject(PendingTasksInternal);
	_usePendingTasks = inject(USE_PENDING_TASKS);
	constructor(_ngZone, registry, testabilityGetter) {
		this._ngZone = _ngZone;
		this.registry = registry;
		if (isInInjectionContext()) this._destroyRef = inject(DestroyRef, { optional: true }) ?? void 0;
		if (!_testabilityGetter) {
			setTestabilityGetter(testabilityGetter);
			testabilityGetter.addToWindow(registry);
		}
		this._watchAngularEvents();
		_ngZone.run(() => {
			this._taskTrackingZone = typeof Zone == "undefined" ? null : Zone.current.get("TaskTrackingZone");
		});
	}
	_watchAngularEvents() {
		const onUnstableSubscription = this._ngZone.onUnstable.subscribe({ next: () => {
			this._isZoneStable = false;
		} });
		let pendingTasksSubscription;
		let onStableSubscription;
		this._ngZone.runOutsideAngular(() => {
			if (this._usePendingTasks) pendingTasksSubscription = this.pendingTasksInternal.hasPendingTasksObservable.subscribe(() => {
				if (this.isStable()) this._ngZone.runOutsideAngular(() => {
					this._runCallbacksIfReady();
				});
			});
			onStableSubscription = this._ngZone.onStable.subscribe({ next: () => {
				NgZone.assertNotInAngularZone();
				queueMicrotask(() => {
					this._isZoneStable = true;
					this._runCallbacksIfReady();
				});
			} });
		});
		this._destroyRef?.onDestroy(() => {
			onUnstableSubscription.unsubscribe();
			pendingTasksSubscription?.unsubscribe();
			onStableSubscription.unsubscribe();
		});
	}
	isStable() {
		return this._isZoneStable && !this._ngZone.hasPendingMacrotasks && (!this._usePendingTasks || !this.pendingTasksInternal.hasPendingTasks);
	}
	_runCallbacksIfReady() {
		if (this.isStable()) queueMicrotask(() => {
			while (this._callbacks.length !== 0) {
				let cb = this._callbacks.pop();
				clearTimeout(cb.timeoutId);
				cb.doneCb();
			}
		});
		else {
			let pending = this.getPendingTasks();
			this._callbacks = this._callbacks.filter((cb) => {
				if (cb.updateCb && cb.updateCb(pending)) {
					clearTimeout(cb.timeoutId);
					return false;
				}
				return true;
			});
		}
	}
	getPendingTasks() {
		if (!this._taskTrackingZone) return [];
		return this._taskTrackingZone.macroTasks.map((t) => {
			return {
				source: t.source,
				creationLocation: t.creationLocation,
				data: t.data
			};
		});
	}
	addCallback(cb, timeout, updateCb) {
		let timeoutId = -1;
		if (timeout && timeout > 0) timeoutId = setTimeout(() => {
			this._callbacks = this._callbacks.filter((cb) => cb.timeoutId !== timeoutId);
			cb();
		}, timeout);
		this._callbacks.push({
			doneCb: cb,
			timeoutId,
			updateCb
		});
	}
	whenStable(doneCb, timeout, updateCb) {
		if (updateCb && !this._taskTrackingZone) throw new Error("Task tracking zone is required when passing an update callback to whenStable(). Is \"zone.js/plugins/task-tracking\" loaded?");
		this.addCallback(doneCb, timeout, updateCb);
		this._runCallbacksIfReady();
	}
	registerApplication(token) {
		this.registry.registerApplication(token, this);
	}
	unregisterApplication(token) {
		this.registry.unregisterApplication(token);
	}
	findProviders(using, provider, exactMatch) {
		return [];
	}
	static ɵfac = function Testability_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Testability)(ɵɵinject(NgZone), ɵɵinject(TestabilityRegistry), ɵɵinject(TESTABILITY_GETTER));
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: Testability,
		factory: Testability.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Testability, [{ type: Injectable }], () => [
		{ type: NgZone },
		{ type: TestabilityRegistry },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [TESTABILITY_GETTER]
			}]
		}
	], null);
})();
var TestabilityRegistry = class TestabilityRegistry {
	_applications = /* @__PURE__ */ new Map();
	registerApplication(token, testability) {
		this._applications.set(token, testability);
	}
	unregisterApplication(token) {
		this._applications.delete(token);
	}
	unregisterAllApplications() {
		this._applications.clear();
	}
	getTestability(elem) {
		return this._applications.get(elem) || null;
	}
	getAllTestabilities() {
		return Array.from(this._applications.values());
	}
	getAllRootElements() {
		return Array.from(this._applications.keys());
	}
	findTestabilityInTree(elem, findInAncestors = true) {
		return _testabilityGetter?.findTestabilityInTree(this, elem, findInAncestors) ?? null;
	}
	static ɵfac = function TestabilityRegistry_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TestabilityRegistry)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TestabilityRegistry,
		factory: TestabilityRegistry.ɵfac,
		providedIn: "platform"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TestabilityRegistry, [{
		type: Injectable,
		args: [{ providedIn: "platform" }]
	}], null, null);
})();
function setTestabilityGetter(getter) {
	_testabilityGetter = getter;
}
var _testabilityGetter;
var APP_BOOTSTRAP_LISTENER = new InjectionToken(ngDevMode ? "appBootstrapListener" : "");
function publishDefaultGlobalUtils() {
	ngDevMode && publishDefaultGlobalUtils$1();
}
function publishSignalConfiguration() {
	setThrowInvalidWriteToSignalError((node) => {
		let errorMessage = "";
		if (ngDevMode) {
			const activeConsumer = getActiveConsumer();
			if (activeConsumer && isReactiveLViewConsumer(activeConsumer)) {
				errorMessage = "Writing to signals is not allowed while Angular renders the template (eg. interpolations)";
				const componentName = activeConsumer.lView && getDeclarationComponentDef(activeConsumer.lView)?.type?.name;
				if (componentName) errorMessage += `. Template location: '${componentName}' component`;
			} else errorMessage = "Writing to signals is not allowed in a `computed`";
			if (node.debugName) errorMessage += `. Signal: '${node.debugName}'`;
		}
		throw new RuntimeError(-600, errorMessage);
	});
}
var MAXIMUM_REFRESH_RERUNS = 10;
function optionsReducer(dst, objs) {
	if (Array.isArray(objs)) return objs.reduce(optionsReducer, dst);
	return {
		...dst,
		...objs
	};
}
var ApplicationRef = class ApplicationRef {
	_runningTick = false;
	_destroyed = false;
	_destroyListeners = [];
	_views = [];
	internalErrorHandler = inject(INTERNAL_APPLICATION_ERROR_HANDLER);
	afterRenderManager = inject(AfterRenderManager);
	zonelessEnabled = inject(ZONELESS_ENABLED);
	rootEffectScheduler = inject(EffectScheduler);
	dirtyFlags = 0;
	tracingSnapshot = null;
	allTestViews = /* @__PURE__ */ new Set();
	autoDetectTestViews = /* @__PURE__ */ new Set();
	includeAllTestViews = false;
	afterTick = new import_cjs.Subject();
	get allViews() {
		return [...(this.includeAllTestViews ? this.allTestViews : this.autoDetectTestViews).keys(), ...this._views];
	}
	get destroyed() {
		return this._destroyed;
	}
	componentTypes = [];
	components = [];
	internalPendingTask = inject(PendingTasksInternal);
	get isStable() {
		return this.internalPendingTask.hasPendingTasksObservable.pipe((0, import_operators.map)((pending) => !pending));
	}
	constructor() {
		inject(TracingService, { optional: true });
	}
	whenStable() {
		let subscription;
		return new Promise((resolve) => {
			subscription = this.isStable.subscribe({ next: (stable) => {
				if (stable) resolve();
			} });
		}).finally(() => {
			subscription.unsubscribe();
		});
	}
	_injector = inject(EnvironmentInjector);
	_rendererFactory = null;
	get injector() {
		return this._injector;
	}
	bootstrap(component, rootSelectorOrNode) {
		return this.bootstrapImpl(component, rootSelectorOrNode);
	}
	bootstrapImpl(component, hostElementOrOptions, injector = Injector.NULL) {
		return this._injector.get(NgZone).run(() => {
			profiler(ProfilerEvent.BootstrapComponentStart);
			(typeof ngDevMode === "undefined" || ngDevMode) && warnIfDestroyed(this._destroyed);
			if (!this._injector.get(ApplicationInitStatus).done) {
				let errorMessage = "";
				if (typeof ngDevMode === "undefined" || ngDevMode) errorMessage = "Cannot bootstrap as there are still asynchronous initializers running." + (isStandalone(component) ? "" : " Bootstrap components in the `ngDoBootstrap` method of the root module.");
				throw new RuntimeError(405, errorMessage);
			}
			const componentDef = getComponentDef(component);
			const ngModule = this._injector.get(NgModuleRef$1);
			const componentFactory = new ComponentFactory(componentDef, ngModule);
			this.componentTypes.push(component);
			const { hostElement, directives, bindings } = normalizeBootstrapOptions(hostElementOrOptions);
			const selectorOrNode = hostElement || componentFactory.selector;
			const compRef = componentFactory.create(injector, [], selectorOrNode, ngModule.injector, directives, bindings);
			const nativeElement = compRef.location.nativeElement;
			const testability = compRef.injector.get(TESTABILITY, null);
			testability?.registerApplication(nativeElement);
			compRef.onDestroy(() => {
				this.detachView(compRef.hostView);
				remove(this.components, compRef);
				testability?.unregisterApplication(nativeElement);
			});
			this._loadComponent(compRef);
			if (typeof ngDevMode === "undefined" || ngDevMode) this._injector.get(Console).log(`Angular is running in development mode.`);
			profiler(ProfilerEvent.BootstrapComponentEnd, compRef);
			return compRef;
		});
	}
	tick() {
		if (!this.zonelessEnabled) this.dirtyFlags |= 1;
		this._tick();
	}
	_tick() {
		profiler(ProfilerEvent.ChangeDetectionStart);
		if (this.tracingSnapshot !== null) this.tracingSnapshot.run(TracingAction.CHANGE_DETECTION, this.tickImpl);
		else this.tickImpl();
	}
	tickImpl = () => {
		(typeof ngDevMode === "undefined" || ngDevMode) && warnIfDestroyed(this._destroyed);
		if (this._runningTick) {
			profiler(ProfilerEvent.ChangeDetectionEnd);
			throw new RuntimeError(101, ngDevMode && "ApplicationRef.tick is called recursively");
		}
		const prevConsumer = setActiveConsumer(null);
		try {
			this._runningTick = true;
			this.synchronize();
			if (typeof ngDevMode === "undefined" || ngDevMode) for (let view of this.allViews) view.checkNoChanges();
		} finally {
			this._runningTick = false;
			this.tracingSnapshot?.dispose();
			this.tracingSnapshot = null;
			setActiveConsumer(prevConsumer);
			this.afterTick.next();
			profiler(ProfilerEvent.ChangeDetectionEnd);
		}
	};
	synchronize() {
		if (this._rendererFactory === null && !this._injector.destroyed) this._rendererFactory = this._injector.get(RendererFactory2, null, { optional: true });
		let runs = 0;
		while (this.dirtyFlags !== 0 && runs++ < MAXIMUM_REFRESH_RERUNS) {
			profiler(ProfilerEvent.ChangeDetectionSyncStart);
			try {
				this.synchronizeOnce();
			} finally {
				profiler(ProfilerEvent.ChangeDetectionSyncEnd);
			}
		}
		if ((typeof ngDevMode === "undefined" || ngDevMode) && runs >= MAXIMUM_REFRESH_RERUNS) throw new RuntimeError(103, ngDevMode && "Infinite change detection while refreshing application views. Ensure views are not calling `markForCheck` on every template execution or that afterRender hooks always mark views for check.");
	}
	synchronizeOnce() {
		if (this.dirtyFlags & 16) {
			this.dirtyFlags &= -17;
			this.rootEffectScheduler.flush();
		}
		let ranDetectChanges = false;
		if (this.dirtyFlags & 7) {
			const useGlobalCheck = Boolean(this.dirtyFlags & 1);
			this.dirtyFlags &= -8;
			this.dirtyFlags |= 8;
			for (let { _lView } of this.allViews) {
				if (!useGlobalCheck && !requiresRefreshOrTraversal(_lView)) continue;
				detectChangesInternal(_lView, useGlobalCheck && !this.zonelessEnabled ? 0 : 1);
				ranDetectChanges = true;
			}
			this.dirtyFlags &= -5;
			this.syncDirtyFlagsWithViews();
			if (this.dirtyFlags & 23) return;
		}
		if (!ranDetectChanges) {
			this._rendererFactory?.begin?.();
			this._rendererFactory?.end?.();
		}
		if (this.dirtyFlags & 8) {
			this.dirtyFlags &= -9;
			this.afterRenderManager.execute();
		}
		this.syncDirtyFlagsWithViews();
	}
	syncDirtyFlagsWithViews() {
		if (this.allViews.some(({ _lView }) => requiresRefreshOrTraversal(_lView))) {
			this.dirtyFlags |= 2;
			return;
		} else this.dirtyFlags &= -8;
	}
	attachView(viewRef) {
		(typeof ngDevMode === "undefined" || ngDevMode) && warnIfDestroyed(this._destroyed);
		const view = viewRef;
		this._views.push(view);
		view.attachToAppRef(this);
	}
	detachView(viewRef) {
		(typeof ngDevMode === "undefined" || ngDevMode) && warnIfDestroyed(this._destroyed);
		const view = viewRef;
		remove(this._views, view);
		view.detachFromAppRef();
	}
	_loadComponent(componentRef) {
		this.attachView(componentRef.hostView);
		try {
			this.tick();
		} catch (e) {
			this.internalErrorHandler(e);
		}
		this.components.push(componentRef);
		const listeners = this._injector.get(APP_BOOTSTRAP_LISTENER, []);
		if (ngDevMode && !Array.isArray(listeners)) throw new RuntimeError(-209, `Unexpected type of the \`APP_BOOTSTRAP_LISTENER\` token value (expected an array, but got ${typeof listeners}). Please check that the \`APP_BOOTSTRAP_LISTENER\` token is configured as a \`multi: true\` provider.`);
		listeners.forEach((listener) => listener(componentRef));
	}
	ngOnDestroy() {
		if (this._destroyed) return;
		try {
			this._destroyListeners.forEach((listener) => listener());
			this._views.slice().forEach((view) => view.destroy());
		} finally {
			this._destroyed = true;
			this._views = [];
			this._destroyListeners = [];
		}
	}
	onDestroy(callback) {
		(typeof ngDevMode === "undefined" || ngDevMode) && warnIfDestroyed(this._destroyed);
		this._destroyListeners.push(callback);
		return () => remove(this._destroyListeners, callback);
	}
	destroy() {
		if (this._destroyed) throw new RuntimeError(406, ngDevMode && "This instance of the `ApplicationRef` has already been destroyed.");
		const injector = this._injector;
		if (injector.destroy && !injector.destroyed) injector.destroy();
	}
	get viewCount() {
		return this._views.length;
	}
	static ɵfac = function ApplicationRef_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ApplicationRef)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: ApplicationRef,
		factory: ApplicationRef.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ApplicationRef, [{ type: Service }], () => [], null);
})();
function normalizeBootstrapOptions(hostElementOrOptions) {
	if (hostElementOrOptions === void 0 || typeof hostElementOrOptions === "string" || hostElementOrOptions instanceof Element) return { hostElement: hostElementOrOptions };
	return hostElementOrOptions;
}
function warnIfDestroyed(destroyed) {
	if (destroyed) console.warn(formatRuntimeError(406, "This instance of the `ApplicationRef` has already been destroyed."));
}
function remove(list, el) {
	const index = list.indexOf(el);
	if (index > -1) list.splice(index, 1);
}
function onIdle$1(callback, injector, options) {
	const scheduler = injector.get(IdleScheduler);
	const cleanupFn = () => scheduler.remove(callback);
	scheduler.add(callback, options);
	return cleanupFn;
}
function onIdleWrapper(options) {
	return (callback, injector) => onIdle$1(callback, injector, options);
}
var IdleScheduler = class IdleScheduler {
	buckets = /* @__PURE__ */ new Map();
	callbackBucket = /* @__PURE__ */ new Map();
	applicationRef = inject(ApplicationRef);
	ngZone = inject(NgZone);
	idleService = inject(IDLE_SERVICE);
	add(callback, options) {
		const key = getIdleRequestKey(options);
		this.callbackBucket.set(callback, key);
		let bucket = this.buckets.get(key);
		if (bucket == null) {
			bucket = {
				idleId: null,
				queue: /* @__PURE__ */ new Set()
			};
			this.buckets.set(key, bucket);
		}
		bucket.queue.add(callback);
		this.scheduleBucket(bucket, options);
	}
	remove(callback) {
		const key = this.callbackBucket.get(callback);
		if (key === void 0) return;
		this.callbackBucket.delete(callback);
		const bucket = this.buckets.get(key);
		if (!bucket) return;
		bucket.queue.delete(callback);
		if (bucket.queue.size === 0) {
			this.cancelBucket(bucket);
			this.buckets.delete(key);
		}
	}
	scheduleBucket(bucket, options) {
		if (bucket.idleId !== null) return;
		const key = getIdleRequestKey(options);
		const callback = (deadline) => {
			for (const cb of bucket.queue) try {
				cb();
				this.applicationRef._tick();
			} finally {
				bucket.queue.delete(cb);
				this.callbackBucket.delete(cb);
				if (deadline && deadline.timeRemaining() === 0 && !deadline.didTimeout) break;
			}
			bucket.idleId = null;
			if (bucket.queue.size > 0) this.scheduleBucket(bucket, options);
			else this.buckets.delete(key);
		};
		bucket.idleId = this.idleService.requestOnIdle((deadline) => this.ngZone.run(() => callback(deadline)), options);
	}
	cancelBucket(bucket) {
		if (bucket.idleId !== null) {
			this.idleService.cancelOnIdle(bucket.idleId);
			bucket.idleId = null;
		}
	}
	ngOnDestroy() {
		for (const bucket of this.buckets.values()) this.cancelBucket(bucket);
		this.buckets.clear();
		this.callbackBucket.clear();
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: IdleScheduler,
		providedIn: "root",
		factory: () => new IdleScheduler()
	});
};
function getIdleRequestKey(options) {
	if (!options || options.timeout == null) return "";
	return `${options.timeout}`;
}
function scheduleDelayedTrigger(scheduleFn) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	renderPlaceholder(lView, tNode);
	if (!shouldTriggerDeferBlock(0, lView)) return;
	const injector = lView[9];
	storeTriggerCleanupFn(0, getLDeferBlockDetails(lView, tNode), scheduleFn(() => triggerDeferBlock(0, lView, tNode), injector));
}
function triggerPrefetching(tDetails, lView, tNode) {
	triggerResourceLoading(tDetails, lView, tNode);
}
function triggerResourceLoading(tDetails, lView, tNode) {
	const injector = lView[9];
	const tView = lView[1];
	if (tDetails.loadingState !== DeferDependenciesLoadingState.NOT_STARTED) return tDetails.loadingPromise ?? Promise.resolve();
	const lDetails = getLDeferBlockDetails(lView, tNode);
	const primaryBlockTNode = getPrimaryBlockTNode(tView, tDetails);
	tDetails.loadingState = DeferDependenciesLoadingState.IN_PROGRESS;
	invokeTriggerCleanupFns(1, lDetails);
	let dependenciesFn = tDetails.dependencyResolverFn;
	if (ngDevMode) {
		const deferDependencyInterceptor = injector.get(DEFER_BLOCK_DEPENDENCY_INTERCEPTOR, null, { optional: true });
		if (deferDependencyInterceptor) dependenciesFn = deferDependencyInterceptor.intercept(dependenciesFn);
	}
	const removeTask = injector.get(PendingTasks).add();
	if (!dependenciesFn) {
		tDetails.loadingPromise = Promise.resolve().then(() => {
			tDetails.loadingPromise = null;
			tDetails.loadingState = DeferDependenciesLoadingState.COMPLETE;
			removeTask();
		});
		return tDetails.loadingPromise;
	}
	tDetails.loadingPromise = Promise.allSettled(dependenciesFn()).then((results) => {
		let failed = false;
		let failedReason = null;
		const directiveDefs = [];
		const pipeDefs = [];
		for (let i = 0; i < results.length; i++) {
			const result = results[i];
			if (result.status === "fulfilled") {
				const dependency = result.value;
				const directiveDef = getComponentDef(dependency) || getDirectiveDef(dependency);
				if (directiveDef) directiveDefs.push(directiveDef);
				else {
					const pipeDef = getPipeDef$1(dependency);
					if (pipeDef) pipeDefs.push(pipeDef);
				}
			} else {
				failed = true;
				failedReason = result.reason instanceof Error ? result.reason : new Error(String(result.reason));
				break;
			}
		}
		if (failed) {
			tDetails.loadingState = DeferDependenciesLoadingState.FAILED;
			if (tDetails.errorTmplIndex === null) {
				const templateLocation = ngDevMode ? getTemplateLocationDetails(lView) : "";
				let errorMsg = "";
				if (ngDevMode) {
					errorMsg = `Loading dependencies for \`@defer\` block failed, but no \`@error\` block was configured${templateLocation}. Consider using the \`@error\` block to render an error state.`;
					const depsFn = tDetails.dependencyResolverFn;
					const errorReason = failedReason?.message;
					if (depsFn) errorMsg += `\n\nAngular tried to invoke the following dependency function (compiler-generated):\n\`\`\`\n${depsFn.toString()}\n\`\`\``;
					if (errorReason) errorMsg += depsFn ? `\n\nbut it resulted in the following error:\n\n${errorReason}` : `\n\nThe loading resulted in the following error:\n\n${errorReason}`;
				}
				handleUncaughtError(lView, new RuntimeError(-750, errorMsg));
			}
		} else {
			tDetails.loadingState = DeferDependenciesLoadingState.COMPLETE;
			const primaryBlockTView = primaryBlockTNode.tView;
			if (directiveDefs.length > 0) {
				primaryBlockTView.directiveRegistry = addDepsToRegistry(primaryBlockTView.directiveRegistry, directiveDefs);
				tDetails.providers = internalImportProvidersFrom(false, ...directiveDefs.map((def) => def.type));
			}
			if (pipeDefs.length > 0) primaryBlockTView.pipeRegistry = addDepsToRegistry(primaryBlockTView.pipeRegistry, pipeDefs);
		}
	});
	return tDetails.loadingPromise.finally(() => {
		tDetails.loadingPromise = null;
		removeTask();
	});
}
function triggerDeferBlock(triggerType, lView, tNode) {
	const tView = lView[1];
	const lContainer = lView[tNode.index];
	ngDevMode && assertLContainer(lContainer);
	if (!shouldTriggerDeferBlock(triggerType, lView)) return;
	const lDetails = getLDeferBlockDetails(lView, tNode);
	const tDetails = getTDeferBlockDetails(tView, tNode);
	invokeAllTriggerCleanupFns(lDetails);
	switch (tDetails.loadingState) {
		case DeferDependenciesLoadingState.NOT_STARTED:
			renderDeferBlockState(DeferBlockState.Loading, tNode, lContainer);
			triggerResourceLoading(tDetails, lView, tNode);
			if (tDetails.loadingState === DeferDependenciesLoadingState.IN_PROGRESS) renderDeferStateAfterResourceLoading(tDetails, tNode, lContainer);
			break;
		case DeferDependenciesLoadingState.IN_PROGRESS:
			renderDeferBlockState(DeferBlockState.Loading, tNode, lContainer);
			renderDeferStateAfterResourceLoading(tDetails, tNode, lContainer);
			break;
		case DeferDependenciesLoadingState.COMPLETE:
			ngDevMode && assertDeferredDependenciesLoaded(tDetails);
			renderDeferBlockState(DeferBlockState.Complete, tNode, lContainer);
			break;
		case DeferDependenciesLoadingState.FAILED:
			renderDeferBlockState(DeferBlockState.Error, tNode, lContainer);
			break;
		default: if (ngDevMode) throwError("Unknown defer block state");
	}
}
function shouldAttachTrigger(triggerType, lView, tNode) {
	if (triggerType === 0) return shouldAttachRegularTrigger(lView, tNode);
	else if (triggerType === 2) return !shouldAttachRegularTrigger(lView, tNode);
	return false;
}
function hasHydrateTriggers(flags) {
	return flags != null && (flags & 1) === 1;
}
function shouldAttachRegularTrigger(lView, tNode) {
	const injector = lView[9];
	const tDetails = getTDeferBlockDetails(lView[1], tNode);
	const incrementalHydrationEnabled = isIncrementalHydrationEnabled(injector);
	const _hasHydrateTriggers = hasHydrateTriggers(tDetails.flags);
	return !incrementalHydrationEnabled || !_hasHydrateTriggers;
}
function getHydrateTriggers(tView, tNode) {
	const tDetails = getTDeferBlockDetails(tView, tNode);
	return tDetails.hydrateTriggers ??= /* @__PURE__ */ new Map();
}
var _hmrWarningProduced = false;
function logHmrWarning(injector) {
	if (!_hmrWarningProduced) {
		_hmrWarningProduced = true;
		injector.get(Console).log(formatRuntimeError(-751, "Angular has detected that this application contains `@defer` blocks and the hot module replacement (HMR) mode is enabled. All `@defer` block dependencies will be loaded eagerly."));
	}
}
function ɵɵdefer(index, primaryTmplIndex, dependencyResolverFn, loadingTmplIndex, placeholderTmplIndex, errorTmplIndex, loadingConfigIndex, placeholderConfigIndex, enableTimerScheduling, flags) {
	const lView = getLView();
	const tView = getTView();
	const adjustedIndex = index + 28;
	const tNode = declareNoDirectiveHostTemplate(lView, tView, index, null, 0, 0);
	const injector = lView[9];
	const incrementalHydrationEnabled = isIncrementalHydrationEnabled(injector);
	if (tView.firstCreatePass) {
		performanceMarkFeature("NgDefer");
		if (ngDevMode) {
			logHmrWarning(injector);
			if (hasHydrateTriggers(flags) && !incrementalHydrationEnabled) warnIncrementalHydrationNotConfigured();
		}
		const tDetails = {
			primaryTmplIndex,
			loadingTmplIndex: loadingTmplIndex ?? null,
			placeholderTmplIndex: placeholderTmplIndex ?? null,
			errorTmplIndex: errorTmplIndex ?? null,
			placeholderBlockConfig: null,
			loadingBlockConfig: null,
			dependencyResolverFn: dependencyResolverFn ?? null,
			loadingState: DeferDependenciesLoadingState.NOT_STARTED,
			loadingPromise: null,
			providers: null,
			hydrateTriggers: null,
			debug: null,
			flags: flags ?? 0
		};
		enableTimerScheduling?.(tView, tDetails, placeholderConfigIndex, loadingConfigIndex);
		setTDeferBlockDetails(tView, adjustedIndex, tDetails);
	}
	const lContainer = lView[adjustedIndex];
	populateDehydratedViewsInLContainer(lContainer, tNode, lView);
	let ssrBlockState = null;
	let ssrUniqueId = null;
	if (lContainer[6]?.length > 0) {
		const info = lContainer[6][0].data;
		ssrUniqueId = info["di"] ?? null;
		ssrBlockState = info["s"];
	}
	const lDetails = [
		null,
		DeferBlockInternalState.Initial,
		null,
		null,
		null,
		null,
		ssrUniqueId,
		ssrBlockState,
		null,
		null
	];
	setLDeferBlockDetails(lView, adjustedIndex, lDetails);
	let registry = null;
	if (ssrUniqueId !== null && incrementalHydrationEnabled) {
		registry = injector.get(DEHYDRATED_BLOCK_REGISTRY);
		registry.add(ssrUniqueId, {
			lView,
			tNode,
			lContainer
		});
	}
	const onLViewDestroy = () => {
		invokeAllTriggerCleanupFns(lDetails);
		if (ssrUniqueId !== null) registry?.cleanup([ssrUniqueId]);
	};
	storeTriggerCleanupFn(0, lDetails, () => removeLViewOnDestroy(lView, onLViewDestroy));
	storeLViewOnDestroy(lView, onLViewDestroy);
}
function ɵɵdeferWhen(rawValue) {
	const lView = getLView();
	const tNode = getSelectedTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "when <expression>");
	if (!shouldAttachTrigger(0, lView, tNode)) return;
	if (bindingUpdated(lView, nextBindingIndex(), rawValue)) {
		const prevConsumer = setActiveConsumer(null);
		try {
			const value = Boolean(rawValue);
			const renderedState = getLDeferBlockDetails(lView, tNode)[1];
			if (value === false && renderedState === DeferBlockInternalState.Initial) renderPlaceholder(lView, tNode);
			else if (value === true && (renderedState === DeferBlockInternalState.Initial || renderedState === DeferBlockState.Placeholder)) triggerDeferBlock(0, lView, tNode);
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
}
function ɵɵdeferPrefetchWhen(rawValue) {
	const lView = getLView();
	const tNode = getSelectedTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "prefetch when <expression>");
	if (!shouldAttachTrigger(1, lView, tNode)) return;
	if (bindingUpdated(lView, nextBindingIndex(), rawValue)) {
		const prevConsumer = setActiveConsumer(null);
		try {
			const value = Boolean(rawValue);
			const tView = lView[1];
			const tDetails = getTDeferBlockDetails(tView, tNode);
			if (value === true && tDetails.loadingState === DeferDependenciesLoadingState.NOT_STARTED) triggerPrefetching(tDetails, lView, tNode);
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
}
function ɵɵdeferHydrateWhen(rawValue) {
	const lView = getLView();
	const tNode = getSelectedTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "hydrate when <expression>");
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	const bindingIndex = nextBindingIndex();
	getHydrateTriggers(getTView(), tNode).set(6, null);
	if (bindingUpdated(lView, bindingIndex, rawValue)) triggerDeferBlock(2, lView, tNode);
}
function ɵɵdeferHydrateNever() {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "hydrate never");
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	getHydrateTriggers(getTView(), tNode).set(7, null);
	triggerDeferBlock(2, lView, tNode);
}
function ɵɵdeferOnIdle(timeout) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) {
		const expression = timeout ? `on idle(${timeout})` : "on idle";
		trackTriggerForDebugging(lView[1], tNode, expression);
	}
	if (!shouldAttachTrigger(0, lView, tNode)) return;
	scheduleDelayedTrigger(onIdleWrapper({ timeout }));
}
function ɵɵdeferPrefetchOnIdle(timeout) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) {
		const expression = timeout ? `prefetch on idle(${timeout})` : "prefetch on idle";
		trackTriggerForDebugging(lView[1], tNode, expression);
	}
	if (!shouldAttachTrigger(1, lView, tNode)) return;
}
function ɵɵdeferHydrateOnIdle(timeout) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) {
		const expression = timeout ? `hydrate on idle(${timeout})` : "hydrate on idle";
		trackTriggerForDebugging(lView[1], tNode, expression);
	}
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	getHydrateTriggers(getTView(), tNode).set(0, null);
	triggerDeferBlock(2, lView, tNode);
}
function ɵɵdeferOnImmediate() {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "on immediate");
	if (!shouldAttachTrigger(0, lView, tNode)) return;
	if (getTDeferBlockDetails(lView[1], tNode).loadingTmplIndex === null) renderPlaceholder(lView, tNode);
	triggerDeferBlock(0, lView, tNode);
}
function ɵɵdeferPrefetchOnImmediate() {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "prefetch on immediate");
	if (!shouldAttachTrigger(1, lView, tNode)) return;
	const tView = lView[1];
	const tDetails = getTDeferBlockDetails(tView, tNode);
	if (tDetails.loadingState === DeferDependenciesLoadingState.NOT_STARTED) triggerResourceLoading(tDetails, lView, tNode);
}
function ɵɵdeferHydrateOnImmediate() {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "hydrate on immediate");
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	getHydrateTriggers(getTView(), tNode).set(1, null);
	triggerDeferBlock(2, lView, tNode);
}
function ɵɵdeferOnTimer(delay) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `on timer(${delay}ms)`);
	if (!shouldAttachTrigger(0, lView, tNode)) return;
	scheduleDelayedTrigger(onTimer(delay));
}
function ɵɵdeferPrefetchOnTimer(delay) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `prefetch on timer(${delay}ms)`);
	if (!shouldAttachTrigger(1, lView, tNode)) return;
}
function ɵɵdeferHydrateOnTimer(delay) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `hydrate on timer(${delay}ms)`);
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	getHydrateTriggers(getTView(), tNode).set(5, {
		type: 5,
		delay
	});
	triggerDeferBlock(2, lView, tNode);
}
function ɵɵdeferOnHover(triggerIndex, walkUpTimes) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `on hover${walkUpTimes === -1 ? "" : "(<target>)"}`);
	if (!shouldAttachTrigger(0, lView, tNode)) return;
	renderPlaceholder(lView, tNode);
}
function ɵɵdeferPrefetchOnHover(triggerIndex, walkUpTimes) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `prefetch on hover${walkUpTimes === -1 ? "" : "(<target>)"}`);
	if (!shouldAttachTrigger(1, lView, tNode)) return;
	const tView = lView[1];
	const tDetails = getTDeferBlockDetails(tView, tNode);
	if (tDetails.loadingState === DeferDependenciesLoadingState.NOT_STARTED) registerDomTrigger(lView, tNode, triggerIndex, walkUpTimes, onHover, () => triggerPrefetching(tDetails, lView, tNode), 1);
}
function ɵɵdeferHydrateOnHover() {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "hydrate on hover");
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	getHydrateTriggers(getTView(), tNode).set(4, null);
	triggerDeferBlock(2, lView, tNode);
}
function ɵɵdeferOnInteraction(triggerIndex, walkUpTimes) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `on interaction${walkUpTimes === -1 ? "" : "(<target>)"}`);
	if (!shouldAttachTrigger(0, lView, tNode)) return;
	renderPlaceholder(lView, tNode);
}
function ɵɵdeferPrefetchOnInteraction(triggerIndex, walkUpTimes) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `prefetch on interaction${walkUpTimes === -1 ? "" : "(<target>)"}`);
	if (!shouldAttachTrigger(1, lView, tNode)) return;
	const tView = lView[1];
	const tDetails = getTDeferBlockDetails(tView, tNode);
	if (tDetails.loadingState === DeferDependenciesLoadingState.NOT_STARTED) registerDomTrigger(lView, tNode, triggerIndex, walkUpTimes, onInteraction, () => triggerPrefetching(tDetails, lView, tNode), 1);
}
function ɵɵdeferHydrateOnInteraction() {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, "hydrate on interaction");
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	getHydrateTriggers(getTView(), tNode).set(3, null);
	triggerDeferBlock(2, lView, tNode);
}
function ɵɵdeferOnViewport(triggerIndex, walkUpTimes, options) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) {
		const args = [];
		if (walkUpTimes !== void 0 && walkUpTimes !== -1) args.push("<target>");
		if (options) args.push(JSON.stringify(options));
		trackTriggerForDebugging(lView[1], tNode, `on viewport${args.length === 0 ? "" : `(${args.join(", ")})`}`);
	}
	if (!shouldAttachTrigger(0, lView, tNode)) return;
	renderPlaceholder(lView, tNode);
}
function ɵɵdeferPrefetchOnViewport(triggerIndex, walkUpTimes, options) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) {
		const args = [];
		if (walkUpTimes !== void 0 && walkUpTimes !== -1) args.push("<target>");
		if (options) args.push(JSON.stringify(options));
		trackTriggerForDebugging(lView[1], tNode, `prefetch on viewport${args.length === 0 ? "" : `(${args.join(", ")})`}`);
	}
	if (!shouldAttachTrigger(1, lView, tNode)) return;
	const tView = lView[1];
	const tDetails = getTDeferBlockDetails(tView, tNode);
	if (tDetails.loadingState === DeferDependenciesLoadingState.NOT_STARTED) registerDomTrigger(lView, tNode, triggerIndex, walkUpTimes, onViewportWrapper, () => triggerPrefetching(tDetails, lView, tNode), 1, options);
}
function ɵɵdeferHydrateOnViewport(options) {
	const lView = getLView();
	const tNode = getCurrentTNode();
	if (ngDevMode) trackTriggerForDebugging(lView[1], tNode, `hydrate on viewport${options ? `(${JSON.stringify(options)})` : ""}`);
	if (!shouldAttachTrigger(2, lView, tNode)) return;
	getHydrateTriggers(getTView(), tNode).set(2, options ? {
		type: 2,
		intersectionObserverOptions: options
	} : null);
	triggerDeferBlock(2, lView, tNode);
}
function ɵɵariaProperty(name, value) {
	const lView = getLView();
	const bindingIndex = nextBindingIndex();
	if (bindingUpdated(lView, bindingIndex, value)) {
		const tView = getTView();
		const tNode = getSelectedTNode();
		if (setAllInputsForProperty(tNode, tView, lView, name, value)) {
			isComponentHost(tNode) && markDirtyIfOnPush(lView, tNode.index);
			ngDevMode && setNgReflectProperties(lView, tView, tNode, name, value);
		} else {
			ngDevMode && assertTNodeType(tNode, 2);
			const element = getNativeByTNode(tNode, lView);
			setElementAttribute(lView[11], element, null, tNode.value, name, value, null);
		}
		ngDevMode && storePropertyBindingMetadata(tView.data, tNode, name, bindingIndex);
	}
	return ɵɵariaProperty;
}
function ɵɵattribute(name, value, sanitizer, namespace) {
	const lView = getLView();
	const bindingIndex = nextBindingIndex();
	if (bindingUpdated(lView, bindingIndex, value)) {
		const tView = getTView();
		const tNode = getSelectedTNode();
		elementAttributeInternal(tNode, lView, name, value, sanitizer, namespace);
		ngDevMode && storePropertyBindingMetadata(tView.data, tNode, "attr." + name, bindingIndex);
	}
	return ɵɵattribute;
}
function ɵɵanimateEnter(value) {
	performanceMarkFeature("NgAnimateEnter");
	return ɵɵanimateEnter;
}
function ɵɵanimateEnterListener(value) {
	performanceMarkFeature("NgAnimateEnter");
	return ɵɵanimateEnterListener;
}
function ɵɵanimateLeave(value) {
	performanceMarkFeature("NgAnimateLeave");
	return ɵɵanimateLeave;
}
function ɵɵanimateLeaveListener(value) {
	performanceMarkFeature("NgAnimateLeave");
	return ɵɵanimateLeaveListener;
}
function ɵɵcomponentInstance() {
	const instance = getLView()[15][8];
	ngDevMode && assertDefined(instance, "Expected component instance to be defined");
	return instance;
}
var LiveCollection = class {
	destroy(item) {}
	updateValue(index, value) {}
	swap(index1, index2) {
		const startIdx = Math.min(index1, index2);
		const endIdx = Math.max(index1, index2);
		const endItem = this.detach(endIdx);
		if (endIdx - startIdx > 1) {
			const startItem = this.detach(startIdx);
			this.attach(startIdx, endItem);
			this.attach(endIdx, startItem);
		} else this.attach(startIdx, endItem);
	}
	move(prevIndex, newIdx) {
		this.attach(newIdx, this.detach(prevIndex));
	}
};
function valuesMatching(liveIdx, liveValue, newIdx, newValue, trackBy) {
	if (liveIdx === newIdx && Object.is(liveValue, newValue)) return 1;
	else if (Object.is(trackBy(liveIdx, liveValue), trackBy(newIdx, newValue))) return -1;
	return 0;
}
function recordDuplicateKeys(keyToIdx, key, idx) {
	const idxSoFar = keyToIdx.get(key);
	if (idxSoFar !== void 0) idxSoFar.add(idx);
	else keyToIdx.set(key, /* @__PURE__ */ new Set([idx]));
}
function reconcile(liveCollection, newCollection, trackByFn, reactiveConsumer) {
	let detachedItems = void 0;
	let liveKeysInTheFuture = void 0;
	let liveStartIdx = 0;
	let liveEndIdx = liveCollection.length - 1;
	const duplicateKeys = ngDevMode ? /* @__PURE__ */ new Map() : void 0;
	if (Array.isArray(newCollection)) {
		setActiveConsumer(reactiveConsumer);
		let newEndIdx = newCollection.length - 1;
		setActiveConsumer(null);
		while (liveStartIdx <= liveEndIdx && liveStartIdx <= newEndIdx) {
			const liveStartValue = liveCollection.at(liveStartIdx);
			const newStartValue = newCollection[liveStartIdx];
			if (ngDevMode) recordDuplicateKeys(duplicateKeys, trackByFn(liveStartIdx, newStartValue), liveStartIdx);
			const isStartMatching = valuesMatching(liveStartIdx, liveStartValue, liveStartIdx, newStartValue, trackByFn);
			if (isStartMatching !== 0) {
				if (isStartMatching < 0) liveCollection.updateValue(liveStartIdx, newStartValue);
				liveStartIdx++;
				continue;
			}
			const liveEndValue = liveCollection.at(liveEndIdx);
			const newEndValue = newCollection[newEndIdx];
			if (ngDevMode) recordDuplicateKeys(duplicateKeys, trackByFn(newEndIdx, newEndValue), newEndIdx);
			const isEndMatching = valuesMatching(liveEndIdx, liveEndValue, newEndIdx, newEndValue, trackByFn);
			if (isEndMatching !== 0) {
				if (isEndMatching < 0) liveCollection.updateValue(liveEndIdx, newEndValue);
				liveEndIdx--;
				newEndIdx--;
				continue;
			}
			const liveStartKey = trackByFn(liveStartIdx, liveStartValue);
			const liveEndKey = trackByFn(liveEndIdx, liveEndValue);
			const newStartKey = trackByFn(liveStartIdx, newStartValue);
			if (Object.is(newStartKey, liveEndKey)) {
				const newEndKey = trackByFn(newEndIdx, newEndValue);
				if (Object.is(newEndKey, liveStartKey)) {
					liveCollection.swap(liveStartIdx, liveEndIdx);
					liveCollection.updateValue(liveEndIdx, newEndValue);
					newEndIdx--;
					liveEndIdx--;
				} else liveCollection.move(liveEndIdx, liveStartIdx);
				liveCollection.updateValue(liveStartIdx, newStartValue);
				liveStartIdx++;
				continue;
			}
			detachedItems ??= new UniqueValueMultiKeyMap();
			liveKeysInTheFuture ??= initLiveItemsInTheFuture(liveCollection, liveStartIdx, liveEndIdx, trackByFn);
			if (attachPreviouslyDetached(liveCollection, detachedItems, liveStartIdx, newStartKey)) {
				liveCollection.updateValue(liveStartIdx, newStartValue);
				liveStartIdx++;
				liveEndIdx++;
			} else if (!liveKeysInTheFuture.has(newStartKey)) {
				const newItem = liveCollection.create(liveStartIdx, newCollection[liveStartIdx]);
				liveCollection.attach(liveStartIdx, newItem);
				liveStartIdx++;
				liveEndIdx++;
			} else {
				detachedItems.set(liveStartKey, liveCollection.detach(liveStartIdx));
				liveEndIdx--;
			}
		}
		while (liveStartIdx <= newEndIdx) {
			createOrAttach(liveCollection, detachedItems, trackByFn, liveStartIdx, newCollection[liveStartIdx]);
			liveStartIdx++;
		}
	} else if (newCollection != null) {
		setActiveConsumer(reactiveConsumer);
		const newCollectionIterator = newCollection[Symbol.iterator]();
		setActiveConsumer(null);
		let newIterationResult = newCollectionIterator.next();
		while (!newIterationResult.done && liveStartIdx <= liveEndIdx) {
			const liveValue = liveCollection.at(liveStartIdx);
			const newValue = newIterationResult.value;
			if (ngDevMode) recordDuplicateKeys(duplicateKeys, trackByFn(liveStartIdx, newValue), liveStartIdx);
			const isStartMatching = valuesMatching(liveStartIdx, liveValue, liveStartIdx, newValue, trackByFn);
			if (isStartMatching !== 0) {
				if (isStartMatching < 0) liveCollection.updateValue(liveStartIdx, newValue);
				liveStartIdx++;
				newIterationResult = newCollectionIterator.next();
			} else {
				detachedItems ??= new UniqueValueMultiKeyMap();
				liveKeysInTheFuture ??= initLiveItemsInTheFuture(liveCollection, liveStartIdx, liveEndIdx, trackByFn);
				const newKey = trackByFn(liveStartIdx, newValue);
				if (attachPreviouslyDetached(liveCollection, detachedItems, liveStartIdx, newKey)) {
					liveCollection.updateValue(liveStartIdx, newValue);
					liveStartIdx++;
					liveEndIdx++;
					newIterationResult = newCollectionIterator.next();
				} else if (!liveKeysInTheFuture.has(newKey)) {
					liveCollection.attach(liveStartIdx, liveCollection.create(liveStartIdx, newValue));
					liveStartIdx++;
					liveEndIdx++;
					newIterationResult = newCollectionIterator.next();
				} else {
					const liveKey = trackByFn(liveStartIdx, liveValue);
					detachedItems.set(liveKey, liveCollection.detach(liveStartIdx));
					liveEndIdx--;
				}
			}
		}
		while (!newIterationResult.done) {
			createOrAttach(liveCollection, detachedItems, trackByFn, liveCollection.length, newIterationResult.value);
			newIterationResult = newCollectionIterator.next();
		}
	}
	while (liveStartIdx <= liveEndIdx) liveCollection.destroy(liveCollection.detach(liveEndIdx--));
	detachedItems?.forEach((item) => {
		liveCollection.destroy(item);
	});
	if (ngDevMode) {
		let duplicatedKeysMsg = [];
		for (const [key, idxSet] of duplicateKeys) if (idxSet.size > 1) {
			const idx = [...idxSet].sort((a, b) => a - b);
			for (let i = 1; i < idx.length; i++) duplicatedKeysMsg.push(`key "${stringifyForError(key)}" at index "${idx[i - 1]}" and "${idx[i]}"`);
		}
		if (duplicatedKeysMsg.length > 0) {
			const message = formatRuntimeError(-955, "The provided track expression resulted in duplicated keys for a given collection. Adjust the tracking expression such that it uniquely identifies all the items in the collection. Duplicated keys were: \n" + duplicatedKeysMsg.join(", \n") + ".");
			console.warn(message);
		}
	}
}
function attachPreviouslyDetached(prevCollection, detachedItems, index, key) {
	if (detachedItems !== void 0 && detachedItems.has(key)) {
		prevCollection.attach(index, detachedItems.get(key));
		detachedItems.delete(key);
		return true;
	}
	return false;
}
function createOrAttach(liveCollection, detachedItems, trackByFn, index, value) {
	if (!attachPreviouslyDetached(liveCollection, detachedItems, index, trackByFn(index, value))) {
		const newItem = liveCollection.create(index, value);
		liveCollection.attach(index, newItem);
	} else liveCollection.updateValue(index, value);
}
function initLiveItemsInTheFuture(liveCollection, start, end, trackByFn) {
	const keys = /* @__PURE__ */ new Set();
	for (let i = start; i <= end; i++) keys.add(trackByFn(i, liveCollection.at(i)));
	return keys;
}
var UniqueValueMultiKeyMap = class {
	kvMap = /* @__PURE__ */ new Map();
	_vMap = void 0;
	has(key) {
		return this.kvMap.has(key);
	}
	delete(key) {
		if (!this.has(key)) return false;
		const value = this.kvMap.get(key);
		if (this._vMap !== void 0 && this._vMap.has(value)) {
			this.kvMap.set(key, this._vMap.get(value));
			this._vMap.delete(value);
		} else this.kvMap.delete(key);
		return true;
	}
	get(key) {
		return this.kvMap.get(key);
	}
	set(key, value) {
		if (this.kvMap.has(key)) {
			let prevValue = this.kvMap.get(key);
			if (ngDevMode && prevValue === value) throw new Error(`Detected a duplicated value ${value} for the key ${key}`);
			if (this._vMap === void 0) this._vMap = /* @__PURE__ */ new Map();
			const vMap = this._vMap;
			while (vMap.has(prevValue)) prevValue = vMap.get(prevValue);
			vMap.set(prevValue, value);
		} else this.kvMap.set(key, value);
	}
	forEach(cb) {
		for (let [key, value] of this.kvMap) {
			cb(value, key);
			if (this._vMap !== void 0) {
				const vMap = this._vMap;
				while (vMap.has(value)) {
					value = vMap.get(value);
					cb(value, key);
				}
			}
		}
	}
};
function ɵɵconditionalCreate(index, templateFn, decls, vars, tagName, attrsIndex, localRefsIndex, localRefExtractor) {
	performanceMarkFeature("NgControlFlow");
	const lView = getLView();
	const tView = getTView();
	declareNoDirectiveHostTemplate(lView, tView, index, templateFn, decls, vars, tagName, getConstant(tView.consts, attrsIndex), 256, localRefsIndex, localRefExtractor);
	return ɵɵconditionalBranchCreate;
}
function ɵɵconditionalBranchCreate(index, templateFn, decls, vars, tagName, attrsIndex, localRefsIndex, localRefExtractor) {
	performanceMarkFeature("NgControlFlow");
	createControlFlowBranch(index, templateFn, decls, vars, tagName, attrsIndex, localRefsIndex, localRefExtractor);
	return ɵɵconditionalBranchCreate;
}
function createControlFlowBranch(index, templateFn, decls, vars, tagName, attrsIndex, localRefsIndex, localRefExtractor) {
	const lView = getLView();
	const tView = getTView();
	declareNoDirectiveHostTemplate(lView, tView, index, templateFn, decls, vars, tagName, getConstant(tView.consts, attrsIndex), 512, localRefsIndex, localRefExtractor);
}
function ɵɵconditional(matchingTemplateIndex, contextValue) {
	performanceMarkFeature("NgControlFlow");
	const hostLView = getLView();
	const bindingIndex = nextBindingIndex();
	const prevMatchingTemplateIndex = hostLView[bindingIndex] !== NO_CHANGE ? hostLView[bindingIndex] : -1;
	const prevContainer = prevMatchingTemplateIndex !== -1 ? getLContainer(hostLView, 28 + prevMatchingTemplateIndex) : void 0;
	const viewInContainerIdx = 0;
	if (bindingUpdated(hostLView, bindingIndex, matchingTemplateIndex)) {
		const prevConsumer = setActiveConsumer(null);
		try {
			if (prevContainer !== void 0) removeLViewFromLContainer(prevContainer, viewInContainerIdx);
			if (matchingTemplateIndex !== -1) {
				const nextLContainerIndex = 28 + matchingTemplateIndex;
				const nextContainer = getLContainer(hostLView, nextLContainerIndex);
				const templateTNode = getExistingTNode(hostLView[1], nextLContainerIndex);
				const dehydratedView = findAndReconcileMatchingDehydratedViews(nextContainer, templateTNode, hostLView);
				addLViewToLContainer(nextContainer, createAndRenderEmbeddedLView(hostLView, templateTNode, contextValue, { dehydratedView }), viewInContainerIdx, shouldAddViewToDom(templateTNode, dehydratedView));
			}
		} finally {
			setActiveConsumer(prevConsumer);
		}
	} else if (prevContainer !== void 0) {
		const lView = getLViewFromLContainer(prevContainer, viewInContainerIdx);
		if (lView !== void 0) lView[8] = contextValue;
	}
}
var RepeaterContext = class {
	lContainer;
	$implicit;
	$index;
	constructor(lContainer, $implicit, $index) {
		this.lContainer = lContainer;
		this.$implicit = $implicit;
		this.$index = $index;
	}
	get $count() {
		return this.lContainer.length - 10;
	}
};
function ɵɵrepeaterTrackByIndex(index) {
	return index;
}
function ɵɵrepeaterTrackByIdentity(_, value) {
	return value;
}
var RepeaterMetadata = class {
	hasEmptyBlock;
	trackByFn;
	liveCollection;
	constructor(hasEmptyBlock, trackByFn, liveCollection) {
		this.hasEmptyBlock = hasEmptyBlock;
		this.trackByFn = trackByFn;
		this.liveCollection = liveCollection;
	}
};
function ɵɵrepeaterCreate(index, templateFn, decls, vars, tagName, attrsIndex, trackByFn, trackByUsesComponentInstance, emptyTemplateFn, emptyDecls, emptyVars, emptyTagName, emptyAttrsIndex) {
	performanceMarkFeature("NgControlFlow");
	ngDevMode && assertFunction(trackByFn, `A track expression must be a function, was ${typeof trackByFn} instead.`);
	const lView = getLView();
	const tView = getTView();
	const hasEmptyBlock = emptyTemplateFn !== void 0;
	const hostLView = getLView();
	const metadata = new RepeaterMetadata(hasEmptyBlock, trackByUsesComponentInstance ? trackByFn.bind(hostLView[15][8]) : trackByFn);
	hostLView[28 + index] = metadata;
	declareNoDirectiveHostTemplate(lView, tView, index + 1, templateFn, decls, vars, tagName, getConstant(tView.consts, attrsIndex), 256);
	if (hasEmptyBlock) {
		ngDevMode && assertDefined(emptyDecls, "Missing number of declarations for the empty repeater block.");
		ngDevMode && assertDefined(emptyVars, "Missing number of bindings for the empty repeater block.");
		declareNoDirectiveHostTemplate(lView, tView, index + 2, emptyTemplateFn, emptyDecls, emptyVars, emptyTagName, getConstant(tView.consts, emptyAttrsIndex), 512);
	}
}
function isViewExpensiveToRecreate(lView) {
	return lView.length - 28 > 2;
}
var OperationsCounter = class {
	created = 0;
	destroyed = 0;
	reset() {
		this.created = 0;
		this.destroyed = 0;
	}
	recordCreate() {
		this.created++;
	}
	recordDestroy() {
		this.destroyed++;
	}
	wasReCreated(collectionLen) {
		return collectionLen > 0 && this.created === this.destroyed && this.created === collectionLen;
	}
};
var LiveCollectionLContainerImpl = class extends LiveCollection {
	lContainer;
	hostLView;
	templateTNode;
	operationsCounter = ngDevMode ? new OperationsCounter() : void 0;
	needsIndexUpdate = false;
	constructor(lContainer, hostLView, templateTNode) {
		super();
		this.lContainer = lContainer;
		this.hostLView = hostLView;
		this.templateTNode = templateTNode;
	}
	get length() {
		return this.lContainer.length - 10;
	}
	at(index) {
		return this.getLView(index)[8].$implicit;
	}
	attach(index, lView) {
		const dehydratedView = lView[6];
		this.needsIndexUpdate ||= index !== this.length;
		addLViewToLContainer(this.lContainer, lView, index, shouldAddViewToDom(this.templateTNode, dehydratedView));
		clearDetachAnimationList(this.lContainer, index);
	}
	detach(index) {
		this.needsIndexUpdate ||= index !== this.length - 1;
		maybeInitDetachAnimationList(this.lContainer, index);
		return detachExistingView(this.lContainer, index);
	}
	create(index, value) {
		const dehydratedView = findMatchingDehydratedView(this.lContainer, this.templateTNode.tView.ssrId);
		const embeddedLView = createAndRenderEmbeddedLView(this.hostLView, this.templateTNode, new RepeaterContext(this.lContainer, value, index), { dehydratedView });
		ngDevMode && this.operationsCounter?.recordCreate();
		return embeddedLView;
	}
	destroy(lView) {
		destroyLView(lView[1], lView);
		ngDevMode && this.operationsCounter?.recordDestroy();
	}
	updateValue(index, value) {
		this.getLView(index)[8].$implicit = value;
	}
	reset() {
		this.needsIndexUpdate = false;
		ngDevMode && this.operationsCounter?.reset();
	}
	updateIndexes() {
		if (this.needsIndexUpdate) for (let i = 0; i < this.length; i++) this.getLView(i)[8].$index = i;
	}
	getLView(index) {
		return getExistingLViewFromLContainer(this.lContainer, index);
	}
};
function ɵɵrepeater(collection) {
	const prevConsumer = setActiveConsumer(null);
	const metadataSlotIdx = getSelectedIndex();
	try {
		const hostLView = getLView();
		const hostTView = hostLView[1];
		const metadata = hostLView[metadataSlotIdx];
		const containerIndex = metadataSlotIdx + 1;
		const lContainer = getLContainer(hostLView, containerIndex);
		if (metadata.liveCollection === void 0) metadata.liveCollection = new LiveCollectionLContainerImpl(lContainer, hostLView, getExistingTNode(hostTView, containerIndex));
		else metadata.liveCollection.reset();
		const liveCollection = metadata.liveCollection;
		reconcile(liveCollection, collection, metadata.trackByFn, prevConsumer);
		if (ngDevMode && metadata.trackByFn === ɵɵrepeaterTrackByIdentity && liveCollection.operationsCounter?.wasReCreated(liveCollection.length) && isViewExpensiveToRecreate(getExistingLViewFromLContainer(lContainer, 0))) {
			const message = formatRuntimeError(-956, `The configured tracking expression (track by identity) caused re-creation of the entire collection of size ${liveCollection.length}. This is an expensive operation requiring destruction and subsequent creation of DOM nodes, directives, components etc. Please review the "track expression" and make sure that it uniquely identifies items in a collection.`);
			console.warn(message);
		}
		liveCollection.updateIndexes();
		if (metadata.hasEmptyBlock) {
			const bindingIndex = nextBindingIndex();
			const isCollectionEmpty = liveCollection.length === 0;
			if (bindingUpdated(hostLView, bindingIndex, isCollectionEmpty)) {
				const emptyTemplateIndex = metadataSlotIdx + 2;
				const lContainerForEmpty = getLContainer(hostLView, emptyTemplateIndex);
				if (isCollectionEmpty) {
					const emptyTemplateTNode = getExistingTNode(hostTView, emptyTemplateIndex);
					const dehydratedView = findAndReconcileMatchingDehydratedViews(lContainerForEmpty, emptyTemplateTNode, hostLView);
					addLViewToLContainer(lContainerForEmpty, createAndRenderEmbeddedLView(hostLView, emptyTemplateTNode, void 0, { dehydratedView }), 0, shouldAddViewToDom(emptyTemplateTNode, dehydratedView));
				} else {
					if (hostTView.firstUpdatePass) removeDehydratedViews(lContainerForEmpty);
					removeLViewFromLContainer(lContainerForEmpty, 0);
				}
			}
		}
	} finally {
		setActiveConsumer(prevConsumer);
	}
}
function getLContainer(lView, index) {
	const lContainer = lView[index];
	ngDevMode && assertLContainer(lContainer);
	return lContainer;
}
function clearDetachAnimationList(lContainer, index) {
	if (lContainer.length <= 10) return;
	if (lContainer[10 + index]);
}
function maybeInitDetachAnimationList(lContainer, index) {
	if (lContainer.length <= 10) return;
	if (lContainer[10 + index]);
}
function detachExistingView(lContainer, index) {
	const existingLView = detachView(lContainer, index);
	ngDevMode && assertLView(existingLView);
	return existingLView;
}
function getExistingLViewFromLContainer(lContainer, index) {
	const existingLView = getLViewFromLContainer(lContainer, index);
	ngDevMode && assertLView(existingLView);
	return existingLView;
}
function getExistingTNode(tView, index) {
	const tNode = getTNode(tView, index);
	ngDevMode && assertTNode(tNode);
	return tNode;
}
var BoundaryError = class extends Error {
	constructor(message, options) {
		super(message, options);
		this.name = "BoundaryError";
	}
};
var LBoundary = class {
	hostLView;
	error = null;
	constructor(hostLView) {
		this.hostLView = hostLView;
	}
	reset() {
		this.error = null;
		markViewForRefresh(this.hostLView);
	}
};
function ɵɵboundaryCreate(index) {
	performanceMarkFeature("NgBoundary");
	const lView = getLView();
	lView[28 + index] = new LBoundary(lView);
}
function ɵɵgetBoundary(index) {
	return getLView()[28 + index];
}
function ɵɵboundaryUpdate(slotIndex, matchingTemplateIndex, primaryTemplateIndex) {
	const hostLView = getLView();
	const bindingIndex = nextBindingIndex();
	const prevMatchingTemplateIndex = hostLView[bindingIndex] !== NO_CHANGE ? hostLView[bindingIndex] : -1;
	const prevContainer = prevMatchingTemplateIndex !== -1 ? getLContainer(hostLView, 28 + prevMatchingTemplateIndex) : void 0;
	const viewInContainerIdx = 0;
	if (bindingUpdated(hostLView, bindingIndex, matchingTemplateIndex)) {
		const prevConsumer = setActiveConsumer(null);
		try {
			if (prevContainer !== void 0) removeLViewFromLContainer(prevContainer, viewInContainerIdx);
			if (matchingTemplateIndex !== -1) {
				const nextLContainerIndex = 28 + matchingTemplateIndex;
				const nextContainer = getLContainer(hostLView, nextLContainerIndex);
				const templateTNode = getExistingTNode(hostLView[1], nextLContainerIndex);
				const dehydratedView = findAndReconcileMatchingDehydratedViews(nextContainer, templateTNode, hostLView);
				let embeddedLView;
				try {
					const boundary = hostLView[28 + slotIndex];
					embeddedLView = createAndRenderEmbeddedLView(hostLView, templateTNode, matchingTemplateIndex === primaryTemplateIndex ? void 0 : {
						$error: boundary.error,
						$reset: () => boundary.reset()
					}, { dehydratedView });
					if (matchingTemplateIndex === primaryTemplateIndex) embeddedLView[27] = (error, details) => {
						const boundary = hostLView[28 + slotIndex];
						boundary.error = error;
						const errorHandler = hostLView[9]?.get(ErrorHandler, null);
						if (errorHandler) {
							details.boundary = {
								type: hostLView[15][8].constructor,
								reset: () => boundary.reset()
							};
							if (errorHandler.onViewError) errorHandler.onViewError(error, details);
							else errorHandler.handleError(error);
						}
						removeLViewFromLContainer(nextContainer, viewInContainerIdx);
						markViewForRefresh(hostLView);
					};
				} catch (e) {
					if (matchingTemplateIndex === primaryTemplateIndex) {
						const boundary = hostLView[28 + slotIndex];
						boundary.error = e;
						const errorHandler = hostLView[9]?.get(ErrorHandler, null);
						if (errorHandler) {
							const boundaryError = encapsulateBoundaryError(e);
							const declarationInstance = hostLView[15][8];
							const declarationType = declarationInstance.constructor;
							const details = {
								declarationInstance,
								declarationType,
								boundary: {
									type: declarationType,
									reset: () => boundary.reset()
								}
							};
							if (errorHandler.onViewError) errorHandler.onViewError(boundaryError, details);
							else errorHandler.handleError(boundaryError);
						}
						markViewForRefresh(hostLView);
						return;
					}
					throw e;
				}
				addLViewToLContainer(nextContainer, embeddedLView, viewInContainerIdx, shouldAddViewToDom(templateTNode, dehydratedView));
			} else {
				const boundary = hostLView[28 + slotIndex];
				throw new BoundaryError("Unhandled error in @boundary fell through.", { cause: boundary.error });
			}
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
}
function ɵɵproperty(propName, value, sanitizer) {
	const lView = getLView();
	const bindingIndex = nextBindingIndex();
	if (bindingUpdated(lView, bindingIndex, value)) {
		const tView = getTView();
		const tNode = getSelectedTNode();
		setPropertyAndInputs(tNode, lView, propName, value, lView[11], sanitizer);
		ngDevMode && storePropertyBindingMetadata(tView.data, tNode, propName, bindingIndex);
	}
	return ɵɵproperty;
}
function setDirectiveInputsWhichShadowsStyling(tView, tNode, lView, value, isClassBased) {
	setAllInputsForProperty(tNode, tView, lView, isClassBased ? "class" : "style", value);
}
function ɵɵelementStart(index, name, attrsIndex, localRefsIndex) {
	const lView = getLView();
	ngDevMode && assertTNodeCreationIndex(lView, index);
	const tView = lView[1];
	const adjustedIndex = index + 28;
	const tNode = tView.firstCreatePass ? directiveHostFirstCreatePass(adjustedIndex, lView, 2, name, findDirectiveDefMatches, getBindingsEnabled(), attrsIndex, localRefsIndex) : tView.data[adjustedIndex];
	if (isComponentHost(tNode)) {
		const tracingService = lView[10].tracingService;
		if (tracingService && tracingService.componentCreate) {
			const def = tView.data[tNode.directiveStart + tNode.componentOffset];
			return tracingService.componentCreate(getComponentName(def), () => {
				initializeElement(index, name, lView, tNode, localRefsIndex);
				return ɵɵelementStart;
			});
		}
	}
	initializeElement(index, name, lView, tNode, localRefsIndex);
	return ɵɵelementStart;
}
function initializeElement(index, name, lView, tNode, localRefsIndex) {
	elementLikeStartShared(tNode, lView, index, name, _locateOrCreateElementNode);
	if (isDirectiveHost(tNode)) {
		const tView = lView[1];
		createDirectivesInstances(tView, lView, tNode);
		executeContentQueries(tView, tNode, lView);
	}
	if (localRefsIndex != null) saveResolvedLocalsInData(lView, tNode);
	if (ngDevMode && lView[1].firstCreatePass) validateElementIsKnown(lView, tNode);
}
function ɵɵelementEnd() {
	const tView = getTView();
	const initialTNode = getCurrentTNode();
	ngDevMode && assertDefined(initialTNode, "No parent node to close.");
	const currentTNode = elementLikeEndShared(initialTNode);
	ngDevMode && assertTNodeType(currentTNode, 3);
	if (tView.firstCreatePass) directiveHostEndFirstCreatePass(tView, currentTNode);
	if (isSkipHydrationRootTNode(currentTNode)) leaveSkipHydrationBlock();
	decreaseElementDepthCount();
	if (currentTNode.classesWithoutHost != null && hasClassInput(currentTNode)) setDirectiveInputsWhichShadowsStyling(tView, currentTNode, getLView(), currentTNode.classesWithoutHost, true);
	if (currentTNode.stylesWithoutHost != null && hasStyleInput(currentTNode)) setDirectiveInputsWhichShadowsStyling(tView, currentTNode, getLView(), currentTNode.stylesWithoutHost, false);
	return ɵɵelementEnd;
}
function ɵɵelement(index, name, attrsIndex, localRefsIndex) {
	ɵɵelementStart(index, name, attrsIndex, localRefsIndex);
	ɵɵelementEnd();
	return ɵɵelement;
}
function ɵɵdomElementStart(index, name, attrsIndex, localRefsIndex) {
	const lView = getLView();
	ngDevMode && assertTNodeCreationIndex(lView, index);
	const tView = lView[1];
	const adjustedIndex = index + 28;
	const tNode = tView.firstCreatePass ? domOnlyFirstCreatePass(adjustedIndex, tView, 2, name, attrsIndex, localRefsIndex) : tView.data[adjustedIndex];
	elementLikeStartShared(tNode, lView, index, name, _locateOrCreateElementNode);
	if (localRefsIndex != null) saveResolvedLocalsInData(lView, tNode);
	if (ngDevMode && lView[1].firstCreatePass) validateElementIsKnown(lView, tNode);
	return ɵɵdomElementStart;
}
function ɵɵdomElementEnd() {
	const initialTNode = getCurrentTNode();
	ngDevMode && assertDefined(initialTNode, "No parent node to close.");
	const currentTNode = elementLikeEndShared(initialTNode);
	ngDevMode && assertTNodeType(currentTNode, 3);
	if (isSkipHydrationRootTNode(currentTNode)) leaveSkipHydrationBlock();
	decreaseElementDepthCount();
	return ɵɵdomElementEnd;
}
function ɵɵdomElement(index, name, attrsIndex, localRefsIndex) {
	ɵɵdomElementStart(index, name, attrsIndex, localRefsIndex);
	ɵɵdomElementEnd();
	return ɵɵdomElement;
}
var _locateOrCreateElementNode = (tView, lView, tNode, name, index) => {
	lastNodeWasCreated(true);
	return createElementNode(lView[11], name, getNamespace());
};
function ɵɵelementContainerStart(index, attrsIndex, localRefsIndex) {
	const lView = getLView();
	ngDevMode && assertTNodeCreationIndex(lView, index);
	const tView = lView[1];
	const adjustedIndex = index + 28;
	const tNode = tView.firstCreatePass ? directiveHostFirstCreatePass(adjustedIndex, lView, 8, "ng-container", findDirectiveDefMatches, getBindingsEnabled(), attrsIndex, localRefsIndex) : tView.data[adjustedIndex];
	elementLikeStartShared(tNode, lView, index, "ng-container", _locateOrCreateElementContainerNode);
	if (isDirectiveHost(tNode)) {
		const tView = lView[1];
		createDirectivesInstances(tView, lView, tNode);
		executeContentQueries(tView, tNode, lView);
	}
	if (localRefsIndex != null) saveResolvedLocalsInData(lView, tNode);
	return ɵɵelementContainerStart;
}
function ɵɵelementContainerEnd() {
	const tView = getTView();
	const initialTNode = getCurrentTNode();
	ngDevMode && assertDefined(initialTNode, "No parent node to close.");
	const currentTNode = elementLikeEndShared(initialTNode);
	if (tView.firstCreatePass) directiveHostEndFirstCreatePass(tView, currentTNode);
	ngDevMode && assertTNodeType(currentTNode, 8);
	return ɵɵelementContainerEnd;
}
function ɵɵelementContainer(index, attrsIndex, localRefsIndex) {
	ɵɵelementContainerStart(index, attrsIndex, localRefsIndex);
	ɵɵelementContainerEnd();
	return ɵɵelementContainer;
}
function ɵɵdomElementContainerStart(index, attrsIndex, localRefsIndex) {
	const lView = getLView();
	ngDevMode && assertTNodeCreationIndex(lView, index);
	const tView = lView[1];
	const adjustedIndex = index + 28;
	const tNode = tView.firstCreatePass ? domOnlyFirstCreatePass(adjustedIndex, tView, 8, "ng-container", attrsIndex, localRefsIndex) : tView.data[adjustedIndex];
	elementLikeStartShared(tNode, lView, index, "ng-container", _locateOrCreateElementContainerNode);
	if (localRefsIndex != null) saveResolvedLocalsInData(lView, tNode);
	return ɵɵdomElementContainerStart;
}
function ɵɵdomElementContainerEnd() {
	const initialTNode = getCurrentTNode();
	ngDevMode && assertDefined(initialTNode, "No parent node to close.");
	const currentTNode = elementLikeEndShared(initialTNode);
	ngDevMode && assertTNodeType(currentTNode, 8);
	return ɵɵelementContainerEnd;
}
function ɵɵdomElementContainer(index, attrsIndex, localRefsIndex) {
	ɵɵdomElementContainerStart(index, attrsIndex, localRefsIndex);
	ɵɵdomElementContainerEnd();
	return ɵɵdomElementContainer;
}
var _locateOrCreateElementContainerNode = (tView, lView, tNode, commentText, index) => {
	lastNodeWasCreated(true);
	return createCommentNode(lView[11], ngDevMode ? commentText : "");
};
var FOREIGN_CONTEXT = new InjectionToken("FOREIGN_CONTEXT");
var ForeignViewRef = class extends ViewRef$1 {
	get head() {
		const lView = this._lView;
		return lView[lView[1].firstChild.index];
	}
	get tail() {
		const lView = this._lView;
		return lView[lView[1].firstChild.next.index];
	}
};
function createForeignView(lContainer, index) {
	const declLView = lContainer[3];
	const declTNode = lContainer[5];
	const renderer = declLView[11];
	const tView = createTView(3, declTNode, null, 3, 0, null, null, null, null, null, null);
	const headTNode = tView.data[28] = createTNode(tView, null, 2, 28, "", null);
	const tailTNode = tView.data[29] = createTNode(tView, null, 2, 29, "", null);
	tView.firstChild = headTNode;
	headTNode.next = tailTNode;
	tailTNode.prev = headTNode;
	const lView = createLView(declLView, tView, null, 0, null, null, null, renderer, null, null, null);
	const headComment = lView[headTNode.index] = renderer.createComment(ngDevMode ? "foreign-view-head" : "");
	const tailComment = lView[tailTNode.index] = renderer.createComment(ngDevMode ? "foreign-view-tail" : "");
	lView[2] &= -5;
	const viewRef = new ForeignViewRef(lView);
	addLViewToLContainer(lContainer, lView, index);
	if (!headComment.parentNode) {
		const fragment = document.createDocumentFragment();
		fragment.appendChild(headComment);
		fragment.appendChild(tailComment);
		const fragmentSlotIndex = tailTNode.index + 1;
		lView[fragmentSlotIndex] = fragment;
	}
	return viewRef;
}
function ɵɵforeignComponent(index, foreignComponentIndex, props) {
	const lView = getLView();
	const tView = getTView();
	const adjustedIndex = index + 28;
	const foreignComponent = getConstant(tView.consts, foreignComponentIndex);
	let tNode;
	if (tView.firstCreatePass) {
		tNode = getOrCreateTNode(tView, adjustedIndex, 4, null, null);
		setCurrentTNodeAsNotParent();
	} else {
		tNode = tView.data[adjustedIndex];
		setCurrentTNode(tNode, false);
	}
	const renderer = lView[11];
	const comment = renderer.createComment(ngDevMode ? "foreign-component" : "");
	appendChild(tView, lView, comment, tNode);
	attachPatchData(comment, lView);
	const lContainer = createLContainer(comment, lView, comment, tNode);
	lView[adjustedIndex] = lContainer;
	addToEndOfViewTree(lView, lContainer);
	const viewRef = createForeignView(lContainer, 0);
	const node = createViewEffect(lView, lView[10].changeDetectionScheduler, () => {
		node.destroy();
		if (isDestroyed(lView)) return;
		const prevConsumer = setActiveConsumer(null);
		try {
			const resolvedProps = props ? props() : void 0;
			const context = getOrCreateInjectable(tNode, lView, FOREIGN_CONTEXT, 8);
			const [nodes, dispose] = foreignComponent[RENDER](resolvedProps, context ?? void 0);
			const tail = viewRef.tail;
			const parent = tail.parentNode;
			if (parent) for (let i = 0; i < nodes.length; i++) nativeInsertBefore(renderer, parent, nodes[i], tail, false);
			if (dispose) viewRef.onDestroy(dispose);
		} finally {
			setActiveConsumer(prevConsumer);
		}
	});
}
var ForeignContextInjector = class {
	context;
	constructor(context) {
		this.context = context;
	}
	get(token, notFoundValue) {
		return token === FOREIGN_CONTEXT ? this.context : notFoundValue;
	}
};
function resolveForeignContentContainer(index, foreignComponentConstIndex) {
	const lView = getLView();
	const adjustedIndex = index + 28;
	const lContainer = lView[adjustedIndex];
	ngDevMode && assertLContainer(lContainer);
	lContainer[2] |= 4;
	const tView = getTView();
	const tNode = tView.data[adjustedIndex];
	const foreignComponent = getConstant(tView.consts, foreignComponentConstIndex);
	ngDevMode && assertDefined(foreignComponent, "Foreign component must be defined in constant pool.");
	return [
		lView,
		lContainer,
		tNode,
		foreignComponent
	];
}
function ɵɵforeignContent(index, foreignComponentConstIndex) {
	const [lView, lContainer, tNode, foreignComponent] = resolveForeignContentContainer(index, foreignComponentConstIndex);
	const adapter = foreignComponent[CONTENT_ADAPTER];
	const onDestroy = foreignComponent[ON_DESTROY];
	const getContext = foreignComponent[GET_CONTEXT];
	const producer = () => {
		const options = getContext ? { embeddedViewInjector: new ForeignContextInjector(getContext()) } : void 0;
		const embeddedLView = createAndRenderEmbeddedLView(lView, tNode, null, options);
		addLViewToLContainer(lContainer, embeddedLView, lContainer.length - 10, false);
		onDestroy(() => {
			if (!isDestroyed(embeddedLView)) {
				const embeddedLViewIndex = lContainer.indexOf(embeddedLView, 10);
				ngDevMode && assertNotSame(embeddedLViewIndex, -1, "Embedded view not found in container");
				removeLViewFromLContainer(lContainer, embeddedLViewIndex - 10);
			}
		});
		const embeddedTView = embeddedLView[1];
		return collectNativeNodes(embeddedTView, embeddedLView, embeddedTView.firstChild, []);
	};
	return adapter(producer);
}
function ɵɵforeignContentFn(index, foreignComponentConstIndex) {
	const [lView, lContainer, tNode, foreignComponent] = resolveForeignContentContainer(index, foreignComponentConstIndex);
	const adapter = foreignComponent[CONTENT_ADAPTER];
	const onDestroy = foreignComponent[ON_DESTROY];
	const getContext = foreignComponent[GET_CONTEXT];
	return (...args) => {
		const producer = () => {
			const options = getContext ? { embeddedViewInjector: new ForeignContextInjector(getContext()) } : void 0;
			const embeddedLView = createAndRenderEmbeddedLView(lView, tNode, args, options);
			addLViewToLContainer(lContainer, embeddedLView, lContainer.length - 10, false);
			onDestroy(() => {
				if (!isDestroyed(embeddedLView)) {
					const embeddedLViewIndex = lContainer.indexOf(embeddedLView, 10);
					ngDevMode && assertNotSame(embeddedLViewIndex, -1, "Embedded view not found in container");
					removeLViewFromLContainer(lContainer, embeddedLViewIndex - 10);
				}
			});
			const embeddedTView = embeddedLView[1];
			return collectNativeNodes(embeddedTView, embeddedLView, embeddedTView.firstChild, []);
		};
		return adapter(producer);
	};
}
function ɵɵgetCurrentView() {
	return getLView();
}
function ɵɵdomProperty(propName, value, sanitizer) {
	const lView = getLView();
	const bindingIndex = nextBindingIndex();
	if (bindingUpdated(lView, bindingIndex, value)) {
		const tView = getTView();
		const tNode = getSelectedTNode();
		setDomProperty(tNode, lView, propName, value, lView[11], sanitizer);
		ngDevMode && storePropertyBindingMetadata(tView.data, tNode, propName, bindingIndex);
	}
	return ɵɵdomProperty;
}
function ɵɵsyntheticHostProperty(propName, value, sanitizer) {
	const lView = getLView();
	const bindingIndex = nextBindingIndex();
	if (bindingUpdated(lView, bindingIndex, value)) {
		const tView = getTView();
		const tNode = getSelectedTNode();
		setDomProperty(tNode, lView, propName, value, loadComponentRenderer(getCurrentDirectiveDef(tView.data), tNode, lView), sanitizer);
		ngDevMode && storePropertyBindingMetadata(tView.data, tNode, propName, bindingIndex);
	}
	return ɵɵsyntheticHostProperty;
}
var u = void 0;
function plural(val) {
	const i = Math.floor(Math.abs(val)), v = val.toString().replace(/^[^.]*\.?/, "").length;
	if (i === 1 && v === 0) return 1;
	return 5;
}
var localeEn = [
	"en",
	[["a", "p"], ["AM", "PM"]],
	[["AM", "PM"]],
	[
		[
			"S",
			"M",
			"T",
			"W",
			"T",
			"F",
			"S"
		],
		[
			"Sun",
			"Mon",
			"Tue",
			"Wed",
			"Thu",
			"Fri",
			"Sat"
		],
		[
			"Sunday",
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday"
		],
		[
			"Su",
			"Mo",
			"Tu",
			"We",
			"Th",
			"Fr",
			"Sa"
		]
	],
	u,
	[
		[
			"J",
			"F",
			"M",
			"A",
			"M",
			"J",
			"J",
			"A",
			"S",
			"O",
			"N",
			"D"
		],
		[
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		],
		[
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December"
		]
	],
	u,
	[
		["B", "A"],
		["BC", "AD"],
		["Before Christ", "Anno Domini"]
	],
	0,
	[6, 0],
	[
		"M/d/yy",
		"MMM d, y",
		"MMMM d, y",
		"EEEE, MMMM d, y"
	],
	[
		"h:mm a",
		"h:mm:ss a",
		"h:mm:ss a z",
		"h:mm:ss a zzzz"
	],
	[
		"{1}, {0}",
		u,
		u,
		u
	],
	[
		".",
		",",
		";",
		"%",
		"+",
		"-",
		"E",
		"×",
		"‰",
		"∞",
		"NaN",
		":"
	],
	[
		"#,##0.###",
		"#,##0%",
		"¤#,##0.00",
		"#E0"
	],
	"USD",
	"$",
	"US Dollar",
	{},
	"ltr",
	plural
];
var LOCALE_DATA = /* @__PURE__ */ Object.create(null);
function registerLocaleData(data, localeId, extraData) {
	if (typeof localeId !== "string") {
		extraData = localeId;
		localeId = data[LocaleDataIndex.LocaleId];
	}
	localeId = localeId.toLowerCase().replace(/_/g, "-");
	LOCALE_DATA[localeId] = data;
	if (extraData) LOCALE_DATA[localeId][LocaleDataIndex.ExtraData] = extraData;
}
function findLocaleData(locale) {
	const normalizedLocale = normalizeLocale(locale);
	let match = getLocaleData(normalizedLocale);
	if (match) return match;
	const parentLocale = normalizedLocale.split("-")[0];
	match = getLocaleData(parentLocale);
	if (match) return match;
	if (parentLocale === "en") return localeEn;
	throw new RuntimeError(701, ngDevMode && `Missing locale data for the locale "${locale}".`);
}
function getLocaleCurrencyCode(locale) {
	return findLocaleData(locale)[LocaleDataIndex.CurrencyCode] || null;
}
function getLocalePluralCase(locale) {
	return findLocaleData(locale)[LocaleDataIndex.PluralCase];
}
function getLocaleData(normalizedLocale) {
	if (!(normalizedLocale in LOCALE_DATA)) {
		const globalLocaleData = _global.ng && _global.ng.common && _global.ng.common.locales && _global.ng.common.locales[normalizedLocale];
		if (globalLocaleData !== void 0) LOCALE_DATA[normalizedLocale] = globalLocaleData;
		return globalLocaleData;
	}
	return LOCALE_DATA[normalizedLocale];
}
function unregisterAllLocaleData() {
	LOCALE_DATA = Object.create(null);
}
var LocaleDataIndex = {
	LocaleId: 0,
	DayPeriodsFormat: 1,
	DayPeriodsStandalone: 2,
	DaysFormat: 3,
	DaysStandalone: 4,
	MonthsFormat: 5,
	MonthsStandalone: 6,
	Eras: 7,
	FirstDayOfWeek: 8,
	WeekendRange: 9,
	DateFormat: 10,
	TimeFormat: 11,
	DateTimeFormat: 12,
	NumberSymbols: 13,
	NumberFormats: 14,
	CurrencyCode: 15,
	CurrencySymbol: 16,
	CurrencyName: 17,
	Currencies: 18,
	Directionality: 19,
	PluralCase: 20,
	ExtraData: 21
};
function normalizeLocale(locale) {
	return locale.toLowerCase().replace(/_/g, "-");
}
var pluralMapping = [
	"zero",
	"one",
	"two",
	"few",
	"many"
];
function getPluralCase(value, locale) {
	const result = pluralMapping[getLocalePluralCase(locale)(parseInt(value, 10))];
	return result !== void 0 ? result : "other";
}
var DEFAULT_LOCALE_ID = "en-US";
var USD_CURRENCY_CODE = "USD";
var ELEMENT_MARKER = { marker: "element" };
var ICU_MARKER = { marker: "ICU" };
var I18nCreateOpCode;
(function(I18nCreateOpCode) {
	I18nCreateOpCode[I18nCreateOpCode["SHIFT"] = 2] = "SHIFT";
	I18nCreateOpCode[I18nCreateOpCode["APPEND_EAGERLY"] = 1] = "APPEND_EAGERLY";
	I18nCreateOpCode[I18nCreateOpCode["COMMENT"] = 2] = "COMMENT";
})(I18nCreateOpCode || (I18nCreateOpCode = {}));
var LOCALE_ID$1 = DEFAULT_LOCALE_ID;
function setLocaleId(localeId) {
	ngDevMode && assertDefined(localeId, `Expected localeId to be defined`);
	if (typeof localeId === "string") LOCALE_ID$1 = localeId.toLowerCase().replace(/_/g, "-");
}
function getLocaleId() {
	return LOCALE_ID$1;
}
var changeMask = 0;
var changeMaskCounter = 0;
function setMaskBit(hasChange) {
	if (hasChange) changeMask = changeMask | 1 << Math.min(changeMaskCounter, 31);
	changeMaskCounter++;
}
function applyI18n(tView, lView, index) {
	try {
		if (changeMaskCounter > 0) {
			ngDevMode && assertDefined(tView, `tView should be defined`);
			const tI18n = tView.data[index];
			applyUpdateOpCodes(tView, lView, Array.isArray(tI18n) ? tI18n : tI18n.update, getBindingIndex() - changeMaskCounter - 1, changeMask);
		}
	} finally {
		changeMask = 0;
		changeMaskCounter = 0;
	}
}
function createNodeWithoutHydration(lView, textOrName, nodeType) {
	const renderer = lView[11];
	switch (nodeType) {
		case Node.COMMENT_NODE: return createCommentNode(renderer, textOrName);
		case Node.TEXT_NODE: return createTextNode(renderer, textOrName);
		case Node.ELEMENT_NODE: return createElementNode(renderer, textOrName, null);
	}
}
var _locateOrCreateNode = (lView, index, textOrName, nodeType) => {
	lastNodeWasCreated(true);
	return createNodeWithoutHydration(lView, textOrName, nodeType);
};
function locateOrCreateNodeImpl(lView, index, textOrName, nodeType) {
	const hydrationInfo = lView[6];
	const noOffsetIndex = index - 28;
	const isNodeCreationMode = !isI18nHydrationSupportEnabled() || !hydrationInfo || isInSkipHydrationBlock$1() || isDisconnectedNode$1(hydrationInfo, noOffsetIndex);
	lastNodeWasCreated(isNodeCreationMode);
	if (isNodeCreationMode) return createNodeWithoutHydration(lView, textOrName, nodeType);
	const native = locateI18nRNodeByIndex(hydrationInfo, noOffsetIndex);
	ngDevMode && assertDefined(native, "expected native element");
	ngDevMode && assertEqual(native.nodeType, nodeType, "expected matching nodeType");
	ngDevMode && nodeType === Node.ELEMENT_NODE && assertEqual(native.tagName.toLowerCase(), textOrName.toLowerCase(), "expecting matching tagName");
	ngDevMode && markRNodeAsClaimedByHydration(native);
	return native;
}
function enableLocateOrCreateI18nNodeImpl() {
	_locateOrCreateNode = locateOrCreateNodeImpl;
}
function applyCreateOpCodes(lView, createOpCodes, parentRNode, insertInFrontOf) {
	const renderer = lView[11];
	for (let i = 0; i < createOpCodes.length; i++) {
		const opCode = createOpCodes[i++];
		const text = createOpCodes[i];
		const isComment = (opCode & I18nCreateOpCode.COMMENT) === I18nCreateOpCode.COMMENT;
		const appendNow = (opCode & I18nCreateOpCode.APPEND_EAGERLY) === I18nCreateOpCode.APPEND_EAGERLY;
		const index = opCode >>> I18nCreateOpCode.SHIFT;
		let rNode = lView[index];
		let lastNodeWasCreated = false;
		if (rNode === null) {
			rNode = lView[index] = _locateOrCreateNode(lView, index, text, isComment ? Node.COMMENT_NODE : Node.TEXT_NODE);
			lastNodeWasCreated = wasLastNodeCreated();
		}
		if (appendNow && parentRNode !== null && lastNodeWasCreated) nativeInsertBefore(renderer, parentRNode, rNode, insertInFrontOf, false);
	}
}
function applyMutableOpCodes(tView, mutableOpCodes, lView, anchorRNode) {
	ngDevMode && assertDomNode(anchorRNode);
	const renderer = lView[11];
	let rootIdx = null;
	let rootRNode;
	for (let i = 0; i < mutableOpCodes.length; i++) {
		const opCode = mutableOpCodes[i];
		if (typeof opCode == "string") {
			const textNodeIndex = mutableOpCodes[++i];
			if (lView[textNodeIndex] === null) {
				ngDevMode && assertIndexInRange(lView, textNodeIndex);
				lView[textNodeIndex] = _locateOrCreateNode(lView, textNodeIndex, opCode, Node.TEXT_NODE);
			}
		} else if (typeof opCode == "number") switch (opCode & 1) {
			case 0:
				const parentIdx = getParentFromIcuCreateOpCode(opCode);
				if (rootIdx === null) {
					rootIdx = parentIdx;
					rootRNode = renderer.parentNode(anchorRNode);
				}
				let insertInFrontOf;
				let parentRNode;
				if (parentIdx === rootIdx) {
					insertInFrontOf = anchorRNode;
					parentRNode = rootRNode;
				} else {
					insertInFrontOf = null;
					parentRNode = unwrapRNode(lView[parentIdx]);
				}
				if (parentRNode !== null) {
					ngDevMode && assertDomNode(parentRNode);
					const refIdx = getRefFromIcuCreateOpCode(opCode);
					ngDevMode && assertGreaterThan(refIdx, 28, "Missing ref");
					const child = lView[refIdx];
					ngDevMode && assertDomNode(child);
					nativeInsertBefore(renderer, parentRNode, child, insertInFrontOf, false);
					const tIcu = getTIcu(tView, refIdx);
					if (tIcu !== null && typeof tIcu === "object") {
						ngDevMode && assertTIcu(tIcu);
						const caseIndex = getCurrentICUCaseIndex(tIcu, lView);
						if (caseIndex !== null) applyMutableOpCodes(tView, tIcu.create[caseIndex], lView, lView[tIcu.anchorIdx]);
					}
				}
				break;
			case 1:
				const elementNodeIndex = opCode >>> 1;
				const attrName = mutableOpCodes[++i];
				const attrValue = mutableOpCodes[++i];
				setElementAttribute(renderer, getNativeByIndex(elementNodeIndex, lView), null, null, attrName, attrValue, null);
				break;
			default: if (ngDevMode) throw new RuntimeError(700, `Unable to determine the type of mutate operation for "${opCode}"`);
		}
		else switch (opCode) {
			case ICU_MARKER:
				const commentValue = mutableOpCodes[++i];
				const commentNodeIndex = mutableOpCodes[++i];
				if (lView[commentNodeIndex] === null) {
					ngDevMode && assertEqual(typeof commentValue, "string", `Expected "${commentValue}" to be a comment node value`);
					ngDevMode && assertIndexInExpandoRange(lView, commentNodeIndex);
					attachPatchData(lView[commentNodeIndex] = _locateOrCreateNode(lView, commentNodeIndex, commentValue, Node.COMMENT_NODE), lView);
				}
				break;
			case ELEMENT_MARKER:
				const tagName = mutableOpCodes[++i];
				const elementNodeIndex = mutableOpCodes[++i];
				if (lView[elementNodeIndex] === null) {
					ngDevMode && assertEqual(typeof tagName, "string", `Expected "${tagName}" to be an element node tag name`);
					ngDevMode && assertIndexInExpandoRange(lView, elementNodeIndex);
					attachPatchData(lView[elementNodeIndex] = _locateOrCreateNode(lView, elementNodeIndex, tagName, Node.ELEMENT_NODE), lView);
				}
				break;
			default: ngDevMode && throwError(`Unable to determine the type of mutate operation for "${opCode}"`);
		}
	}
}
function applyUpdateOpCodes(tView, lView, updateOpCodes, bindingsStartIndex, changeMask) {
	for (let i = 0; i < updateOpCodes.length; i++) {
		const checkBit = updateOpCodes[i];
		const skipCodes = updateOpCodes[++i];
		if (checkBit & changeMask) {
			let value = "";
			for (let j = i + 1; j <= i + skipCodes; j++) {
				const opCode = updateOpCodes[j];
				if (typeof opCode == "string") value += opCode;
				else if (typeof opCode == "number") {
					if (opCode < 0) value += renderStringify(lView[bindingsStartIndex - opCode]);
					else {
						const nodeIndex = opCode >>> 2;
						switch (opCode & 3) {
							case 1:
								const propName = updateOpCodes[++j];
								const sanitizeFn = updateOpCodes[++j];
								const tNodeOrTagName = tView.data[nodeIndex];
								ngDevMode && assertDefined(tNodeOrTagName, "Experting TNode or string");
								if (typeof tNodeOrTagName === "string") setElementAttribute(lView[11], lView[nodeIndex], null, tNodeOrTagName, propName, value, sanitizeFn);
								else {
									const prevSelectedIndex = getSelectedIndex();
									setSelectedIndex(nodeIndex);
									try {
										setPropertyAndInputs(tNodeOrTagName, lView, propName, value, lView[11], sanitizeFn);
									} finally {
										setSelectedIndex(prevSelectedIndex);
									}
								}
								break;
							case 0:
								const rText = lView[nodeIndex];
								rText !== null && updateTextNode(lView[11], rText, value);
								break;
							case 2:
								applyIcuSwitchCase(tView, getTIcu(tView, nodeIndex), lView, value);
								break;
							case 3: applyIcuUpdateCase(tView, getTIcu(tView, nodeIndex), bindingsStartIndex, lView);
						}
					}
				}
			}
		} else {
			const opCode = updateOpCodes[i + 1];
			if (opCode > 0 && (opCode & 3) === 3) {
				const tIcu = getTIcu(tView, opCode >>> 2);
				if (lView[tIcu.currentCaseLViewIndex] < 0) applyIcuUpdateCase(tView, tIcu, bindingsStartIndex, lView);
			}
		}
		i += skipCodes;
	}
}
function applyIcuUpdateCase(tView, tIcu, bindingsStartIndex, lView) {
	ngDevMode && assertIndexInRange(lView, tIcu.currentCaseLViewIndex);
	let activeCaseIndex = lView[tIcu.currentCaseLViewIndex];
	if (activeCaseIndex !== null) {
		let mask = changeMask;
		if (activeCaseIndex < 0) {
			activeCaseIndex = lView[tIcu.currentCaseLViewIndex] = ~activeCaseIndex;
			mask = -1;
		}
		applyUpdateOpCodes(tView, lView, tIcu.update[activeCaseIndex], bindingsStartIndex, mask);
	}
}
function applyIcuSwitchCase(tView, tIcu, lView, value) {
	const caseIndex = getCaseIndex(tIcu, value);
	if (getCurrentICUCaseIndex(tIcu, lView) !== caseIndex) {
		applyIcuSwitchCaseRemove(tView, tIcu, lView);
		lView[tIcu.currentCaseLViewIndex] = caseIndex === null ? null : ~caseIndex;
		if (caseIndex !== null) {
			const anchorRNode = lView[tIcu.anchorIdx];
			if (anchorRNode) {
				ngDevMode && assertDomNode(anchorRNode);
				applyMutableOpCodes(tView, tIcu.create[caseIndex], lView, anchorRNode);
			}
			claimDehydratedIcuCase(lView, tIcu.anchorIdx, caseIndex);
		}
	}
}
function applyIcuSwitchCaseRemove(tView, tIcu, lView) {
	let activeCaseIndex = getCurrentICUCaseIndex(tIcu, lView);
	if (activeCaseIndex !== null) {
		const removeCodes = tIcu.remove[activeCaseIndex];
		for (let i = 0; i < removeCodes.length; i++) {
			const nodeOrIcuIndex = removeCodes[i];
			if (nodeOrIcuIndex > 0) {
				const rNode = getNativeByIndex(nodeOrIcuIndex, lView);
				rNode !== null && nativeRemoveNode(lView[11], rNode);
			} else applyIcuSwitchCaseRemove(tView, getTIcu(tView, ~nodeOrIcuIndex), lView);
		}
	}
}
function getCaseIndex(icuExpression, bindingValue) {
	let index = icuExpression.cases.indexOf(bindingValue);
	if (index === -1) switch (icuExpression.type) {
		case 1: {
			const resolvedCase = getPluralCase(bindingValue, getLocaleId());
			index = icuExpression.cases.indexOf(resolvedCase);
			if (index === -1 && resolvedCase !== "other") index = icuExpression.cases.indexOf("other");
			break;
		}
		case 0: index = icuExpression.cases.indexOf("other");
	}
	return index === -1 ? null : index;
}
function i18nCreateOpCodesToString(opcodes) {
	const createOpCodes = opcodes || (Array.isArray(this) ? this : []);
	let lines = [];
	for (let i = 0; i < createOpCodes.length; i++) {
		const opCode = createOpCodes[i++];
		const text = createOpCodes[i];
		const isComment = (opCode & I18nCreateOpCode.COMMENT) === I18nCreateOpCode.COMMENT;
		const appendNow = (opCode & I18nCreateOpCode.APPEND_EAGERLY) === I18nCreateOpCode.APPEND_EAGERLY;
		const index = opCode >>> I18nCreateOpCode.SHIFT;
		lines.push(`lView[${index}] = document.${isComment ? "createComment" : "createText"}(${JSON.stringify(text)});`);
		if (appendNow) lines.push(`parent.appendChild(lView[${index}]);`);
	}
	return lines;
}
function i18nUpdateOpCodesToString(opcodes) {
	const parser = new OpCodeParser(opcodes || (Array.isArray(this) ? this : []));
	let lines = [];
	function consumeOpCode(value) {
		const ref = value >>> 2;
		switch (value & 3) {
			case 0: return `(lView[${ref}] as Text).textContent = $$$`;
			case 1:
				const attrName = parser.consumeString();
				const sanitizationFn = parser.consumeFunction();
				return `(lView[${ref}] as Element).setAttribute('${attrName}', ${sanitizationFn ? `(${sanitizationFn})($$$)` : "$$$"})`;
			case 2: return `icuSwitchCase(${ref}, $$$)`;
			case 3: return `icuUpdateCase(${ref})`;
		}
		throw new Error("unexpected OpCode");
	}
	while (parser.hasMore()) {
		let mask = parser.consumeNumber();
		let size = parser.consumeNumber();
		const end = parser.i + size;
		const statements = [];
		let statement = "";
		while (parser.i < end) {
			let value = parser.consumeNumberOrString();
			if (typeof value === "string") statement += value;
			else if (value < 0) statement += "${lView[i" + value + "]}";
			else {
				const opCodeText = consumeOpCode(value);
				statements.push(opCodeText.replace("$$$", "`" + statement + "`") + ";");
				statement = "";
			}
		}
		lines.push(`if (mask & 0b${mask.toString(2)}) { ${statements.join(" ")} }`);
	}
	return lines;
}
function icuCreateOpCodesToString(opcodes) {
	const parser = new OpCodeParser(opcodes || (Array.isArray(this) ? this : []));
	let lines = [];
	function consumeOpCode(opCode) {
		const parent = getParentFromIcuCreateOpCode(opCode);
		const ref = getRefFromIcuCreateOpCode(opCode);
		switch (getInstructionFromIcuCreateOpCode(opCode)) {
			case 0: return `(lView[${parent}] as Element).appendChild(lView[${lastRef}])`;
			case 1: return `(lView[${ref}] as Element).setAttribute("${parser.consumeString()}", "${parser.consumeString()}")`;
		}
		throw new Error("Unexpected OpCode: " + getInstructionFromIcuCreateOpCode(opCode));
	}
	let lastRef = -1;
	while (parser.hasMore()) {
		let value = parser.consumeNumberStringOrMarker();
		if (value === ICU_MARKER) {
			const text = parser.consumeString();
			lastRef = parser.consumeNumber();
			lines.push(`lView[${lastRef}] = document.createComment("${text}")`);
		} else if (value === ELEMENT_MARKER) {
			const text = parser.consumeString();
			lastRef = parser.consumeNumber();
			lines.push(`lView[${lastRef}] = document.createElement("${text}")`);
		} else if (typeof value === "string") {
			lastRef = parser.consumeNumber();
			lines.push(`lView[${lastRef}] = document.createTextNode("${value}")`);
		} else if (typeof value === "number") {
			const line = consumeOpCode(value);
			line && lines.push(line);
		} else throw new Error("Unexpected value");
	}
	return lines;
}
function i18nRemoveOpCodesToString(opcodes) {
	const removeCodes = opcodes || (Array.isArray(this) ? this : []);
	let lines = [];
	for (let i = 0; i < removeCodes.length; i++) {
		const nodeOrIcuIndex = removeCodes[i];
		if (nodeOrIcuIndex > 0) lines.push(`remove(lView[${nodeOrIcuIndex}])`);
		else lines.push(`removeNestedICU(${~nodeOrIcuIndex})`);
	}
	return lines;
}
var OpCodeParser = class {
	i = 0;
	codes;
	constructor(codes) {
		this.codes = codes;
	}
	hasMore() {
		return this.i < this.codes.length;
	}
	consumeNumber() {
		let value = this.codes[this.i++];
		assertNumber(value, "expecting number in OpCode");
		return value;
	}
	consumeString() {
		let value = this.codes[this.i++];
		assertString(value, "expecting string in OpCode");
		return value;
	}
	consumeFunction() {
		let value = this.codes[this.i++];
		if (value === null || typeof value === "function") return value;
		throw new Error("expecting function in OpCode");
	}
	consumeNumberOrString() {
		let value = this.codes[this.i++];
		if (typeof value === "string") return value;
		assertNumber(value, "expecting number or string in OpCode");
		return value;
	}
	consumeNumberStringOrMarker() {
		let value = this.codes[this.i++];
		if (typeof value === "string" || typeof value === "number" || value == ICU_MARKER || value == ELEMENT_MARKER) return value;
		assertNumber(value, "expecting number, string, ICU_MARKER or ELEMENT_MARKER in OpCode");
		return value;
	}
};
var BINDING_REGEXP = /�(\d+):?\d*�/gi;
var ICU_REGEXP = /({\s*�\d+:?\d*�\s*,\s*\S{6}\s*,[\s\S]*})/gi;
var NESTED_ICU = /�(\d+)�/;
var ICU_BLOCK_REGEXP = /^\s*(�\d+:?\d*�)\s*,\s*(select|plural)\s*,/;
var MARKER = `�`;
var SUBTEMPLATE_REGEXP = /�\/?\*(\d+:\d+)�/gi;
var PH_REGEXP = /�(\/?[#*]\d+):?\d*�/gi;
var NGSP_UNICODE_REGEXP = /\uE500/g;
function replaceNgsp(value) {
	return value.replace(NGSP_UNICODE_REGEXP, " ");
}
function attachDebugGetter(obj, debugGetter) {
	if (ngDevMode) Object.defineProperty(obj, "debug", {
		get: debugGetter,
		enumerable: false
	});
	else throw new Error("This method should be guarded with `ngDevMode` so that it can be tree shaken in production!");
}
function i18nStartFirstCreatePass(tView, parentTNodeIndex, lView, index, message, subTemplateIndex) {
	const rootTNode = getCurrentParentTNode();
	const createOpCodes = [];
	const updateOpCodes = [];
	const existingTNodeStack = [[]];
	const astStack = [[]];
	if (ngDevMode) {
		attachDebugGetter(createOpCodes, i18nCreateOpCodesToString);
		attachDebugGetter(updateOpCodes, i18nUpdateOpCodesToString);
	}
	message = getTranslationForTemplate(message, subTemplateIndex);
	const msgParts = replaceNgsp(message).split(PH_REGEXP);
	for (let i = 0; i < msgParts.length; i++) {
		let value = msgParts[i];
		if ((i & 1) === 0) {
			const parts = i18nParseTextIntoPartsAndICU(value);
			for (let j = 0; j < parts.length; j++) {
				let part = parts[j];
				if ((j & 1) === 0) {
					const text = part;
					ngDevMode && assertString(text, "Parsed ICU part should be string");
					if (text !== "") i18nStartFirstCreatePassProcessTextNode(astStack[0], tView, rootTNode, existingTNodeStack[0], createOpCodes, updateOpCodes, lView, text);
				} else {
					const icuExpression = part;
					if (typeof icuExpression !== "object") throw new Error(`Unable to parse ICU expression in "${message}" message.`);
					const icuNodeIndex = createTNodeAndAddOpCode(tView, rootTNode, existingTNodeStack[0], lView, createOpCodes, ngDevMode ? `ICU ${index}:${icuExpression.mainBinding}` : "", true).index;
					ngDevMode && assertGreaterThanOrEqual(icuNodeIndex, 28, "Index must be in absolute LView offset");
					icuStart(astStack[0], tView, lView, updateOpCodes, parentTNodeIndex, icuExpression, icuNodeIndex);
				}
			}
		} else {
			const isClosing = value.charCodeAt(0) === 47;
			const type = value.charCodeAt(isClosing ? 1 : 0);
			ngDevMode && assertOneOf(type, 42, 35);
			const index = 28 + Number.parseInt(value.substring(isClosing ? 2 : 1));
			if (isClosing) {
				existingTNodeStack.shift();
				astStack.shift();
				setCurrentTNode(getCurrentParentTNode(), false);
			} else {
				const tNode = createTNodePlaceholder(tView, existingTNodeStack[0], index);
				existingTNodeStack.unshift([]);
				setCurrentTNode(tNode, true);
				const placeholderNode = {
					kind: 2,
					index,
					children: [],
					type: type === 35 ? 0 : 1
				};
				astStack[0].push(placeholderNode);
				astStack.unshift(placeholderNode.children);
			}
		}
	}
	tView.data[index] = {
		create: createOpCodes,
		update: updateOpCodes,
		ast: astStack[0],
		parentTNodeIndex
	};
}
function createTNodeAndAddOpCode(tView, rootTNode, existingTNodes, lView, createOpCodes, text, isICU) {
	const i18nNodeIdx = allocExpando(tView, lView, 1, null);
	let opCode = i18nNodeIdx << I18nCreateOpCode.SHIFT;
	let parentTNode = getCurrentParentTNode();
	if (rootTNode === parentTNode) parentTNode = null;
	if (parentTNode === null) opCode |= I18nCreateOpCode.APPEND_EAGERLY;
	if (isICU) {
		opCode |= I18nCreateOpCode.COMMENT;
		ensureIcuContainerVisitorLoaded(loadIcuContainerVisitor);
	}
	createOpCodes.push(opCode, text === null ? "" : text);
	const tNode = createTNodeAtIndex(tView, i18nNodeIdx, isICU ? 32 : 1, text === null ? ngDevMode ? "{{?}}" : "" : text, null);
	addTNodeAndUpdateInsertBeforeIndex(existingTNodes, tNode);
	const tNodeIdx = tNode.index;
	setCurrentTNode(tNode, false);
	if (parentTNode !== null && rootTNode !== parentTNode) setTNodeInsertBeforeIndex(parentTNode, tNodeIdx);
	return tNode;
}
function i18nStartFirstCreatePassProcessTextNode(ast, tView, rootTNode, existingTNodes, createOpCodes, updateOpCodes, lView, text) {
	const hasBinding = text.match(BINDING_REGEXP);
	const index = createTNodeAndAddOpCode(tView, rootTNode, existingTNodes, lView, createOpCodes, hasBinding ? null : text, false).index;
	if (hasBinding) generateBindingUpdateOpCodes(updateOpCodes, text, index, null, 0, null);
	ast.push({
		kind: 0,
		index
	});
}
function i18nAttributesFirstPass(tView, index, values) {
	const previousElement = getCurrentTNode();
	const previousElementIndex = previousElement.index;
	const updateOpCodes = [];
	if (ngDevMode) attachDebugGetter(updateOpCodes, i18nUpdateOpCodesToString);
	if (tView.firstCreatePass && tView.data[index] === null) {
		for (let i = 0; i < values.length; i += 2) {
			const attrName = values[i];
			const message = values[i + 1];
			if (message !== "") {
				if (ICU_REGEXP.test(message)) throw new Error(`ICU expressions are not supported in attributes. Message: "${message}".`);
				const tagName = previousElement.namespace ? `:${previousElement.namespace}:${previousElement.value}` : previousElement.value;
				generateBindingUpdateOpCodes(updateOpCodes, message, previousElementIndex, attrName, countBindings(updateOpCodes), i18nResolveSanitizer(attrName, tagName));
			}
		}
		tView.data[index] = updateOpCodes;
	}
}
function generateBindingUpdateOpCodes(updateOpCodes, str, destinationNode, attrName, bindingStart, sanitizeFn) {
	ngDevMode && assertGreaterThanOrEqual(destinationNode, 28, "Index must be in absolute LView offset");
	const maskIndex = updateOpCodes.length;
	const sizeIndex = maskIndex + 1;
	updateOpCodes.push(null, null);
	const startIndex = maskIndex + 2;
	if (ngDevMode) attachDebugGetter(updateOpCodes, i18nUpdateOpCodesToString);
	const textParts = str.split(BINDING_REGEXP);
	let mask = 0;
	for (let j = 0; j < textParts.length; j++) {
		const textValue = textParts[j];
		if (j & 1) {
			const bindingIndex = bindingStart + parseInt(textValue, 10);
			updateOpCodes.push(-1 - bindingIndex);
			mask = mask | toMaskBit(bindingIndex);
		} else if (textValue !== "") updateOpCodes.push(textValue);
	}
	updateOpCodes.push(destinationNode << 2 | (attrName ? 1 : 0));
	if (attrName) updateOpCodes.push(attrName, sanitizeFn);
	updateOpCodes[maskIndex] = mask;
	updateOpCodes[sizeIndex] = updateOpCodes.length - startIndex;
	return mask;
}
function countBindings(opCodes) {
	let count = 0;
	for (let i = 0; i < opCodes.length; i++) {
		const opCode = opCodes[i];
		if (typeof opCode === "number" && opCode < 0) count++;
	}
	return count;
}
function toMaskBit(bindingIndex) {
	return 1 << Math.min(bindingIndex, 31);
}
function removeInnerTemplateTranslation(message) {
	let match;
	let res = "";
	let index = 0;
	let inTemplate = false;
	let tagMatched;
	while ((match = SUBTEMPLATE_REGEXP.exec(message)) !== null) if (!inTemplate) {
		res += message.substring(index, match.index + match[0].length);
		tagMatched = match[1];
		inTemplate = true;
	} else if (match[0] === `${MARKER}/*${tagMatched}${MARKER}`) {
		index = match.index;
		inTemplate = false;
	}
	ngDevMode && assertEqual(inTemplate, false, `Tag mismatch: unable to find the end of the sub-template in the translation "${message}"`);
	res += message.slice(index);
	return res;
}
function getTranslationForTemplate(message, subTemplateIndex) {
	if (isRootTemplateMessage(subTemplateIndex)) return removeInnerTemplateTranslation(message);
	else {
		const start = message.indexOf(`:${subTemplateIndex}${MARKER}`) + 2 + subTemplateIndex.toString().length;
		const end = message.search(new RegExp(`${MARKER}\\/\\*\\d+:${subTemplateIndex}${MARKER}`));
		return removeInnerTemplateTranslation(message.substring(start, end));
	}
}
function icuStart(ast, tView, lView, updateOpCodes, parentIdx, icuExpression, anchorIdx) {
	ngDevMode && assertDefined(icuExpression, "ICU expression must be defined");
	let bindingMask = 0;
	const tIcu = {
		type: icuExpression.type,
		currentCaseLViewIndex: allocExpando(tView, lView, 1, null),
		anchorIdx,
		cases: [],
		create: [],
		remove: [],
		update: []
	};
	addUpdateIcuSwitch(updateOpCodes, icuExpression, anchorIdx);
	setTIcu(tView, anchorIdx, tIcu);
	const values = icuExpression.values;
	const cases = [];
	for (let i = 0; i < values.length; i++) {
		const valueArr = values[i];
		const nestedIcus = [];
		for (let j = 0; j < valueArr.length; j++) {
			const value = valueArr[j];
			if (typeof value !== "string") {
				const icuIndex = nestedIcus.push(value) - 1;
				valueArr[j] = `<!--�${icuIndex}�-->`;
			}
		}
		const caseAst = [];
		cases.push(caseAst);
		bindingMask = parseIcuCase(caseAst, tView, tIcu, lView, updateOpCodes, parentIdx, icuExpression.cases[i], valueArr.join(""), nestedIcus) | bindingMask;
	}
	if (bindingMask) addUpdateIcuUpdate(updateOpCodes, bindingMask, anchorIdx);
	ast.push({
		kind: 3,
		index: anchorIdx,
		cases,
		currentCaseLViewIndex: tIcu.currentCaseLViewIndex
	});
}
function parseICUBlock(pattern) {
	const cases = [];
	const values = [];
	let icuType = 1;
	let mainBinding = 0;
	pattern = pattern.replace(ICU_BLOCK_REGEXP, function(str, binding, type) {
		if (type === "select") icuType = 0;
		else icuType = 1;
		mainBinding = parseInt(binding.slice(1), 10);
		return "";
	});
	const parts = i18nParseTextIntoPartsAndICU(pattern);
	for (let pos = 0; pos < parts.length;) {
		let key = parts[pos++].trim();
		if (icuType === 1) key = key.replace(/\s*(?:=)?(\w+)\s*/, "$1");
		if (key.length) cases.push(key);
		const blocks = i18nParseTextIntoPartsAndICU(parts[pos++]);
		if (cases.length > values.length) values.push(blocks);
	}
	return {
		type: icuType,
		mainBinding,
		cases,
		values
	};
}
function i18nParseTextIntoPartsAndICU(pattern) {
	if (!pattern) return [];
	let prevPos = 0;
	const braceStack = [];
	const results = [];
	const braces = /[{}]/g;
	braces.lastIndex = 0;
	let match;
	while (match = braces.exec(pattern)) {
		const pos = match.index;
		if (match[0] == "}") {
			braceStack.pop();
			if (braceStack.length == 0) {
				const block = pattern.substring(prevPos, pos);
				if (ICU_BLOCK_REGEXP.test(block)) results.push(parseICUBlock(block));
				else results.push(block);
				prevPos = pos + 1;
			}
		} else {
			if (braceStack.length == 0) {
				const substring = pattern.substring(prevPos, pos);
				results.push(substring);
				prevPos = pos + 1;
			}
			braceStack.push("{");
		}
	}
	const substring = pattern.substring(prevPos);
	results.push(substring);
	return results;
}
function parseIcuCase(ast, tView, tIcu, lView, updateOpCodes, parentIdx, caseName, unsafeCaseHtml, nestedIcus) {
	const create = [];
	const remove = [];
	const update = [];
	if (ngDevMode) {
		attachDebugGetter(create, icuCreateOpCodesToString);
		attachDebugGetter(remove, i18nRemoveOpCodesToString);
		attachDebugGetter(update, i18nUpdateOpCodesToString);
	}
	tIcu.cases.push(caseName);
	tIcu.create.push(create);
	tIcu.remove.push(remove);
	tIcu.update.push(update);
	const inertBodyElement = getInertBodyHelper(getDocument()).getInertBodyElement(unsafeCaseHtml);
	ngDevMode && assertDefined(inertBodyElement, "Unable to generate inert body element");
	const inertRootNode = getTemplateContent(inertBodyElement) || inertBodyElement;
	if (inertRootNode) return walkIcuTree(ast, tView, tIcu, lView, updateOpCodes, create, remove, update, inertRootNode, parentIdx, nestedIcus, 0);
	else return 0;
}
function walkIcuTree(ast, tView, tIcu, lView, sharedUpdateOpCodes, create, remove, update, parentNode, parentIdx, nestedIcus, depth) {
	let bindingMask = 0;
	let currentNode = parentNode.firstChild;
	while (currentNode) {
		const newIndex = allocExpando(tView, lView, 1, null);
		switch (currentNode.nodeType) {
			case Node.ELEMENT_NODE:
				const element = currentNode;
				const tagName = element.tagName.toLowerCase();
				if (Object.hasOwn(VALID_ELEMENTS, tagName)) {
					addCreateNodeAndAppend(create, ELEMENT_MARKER, tagName, parentIdx, newIndex);
					tView.data[newIndex] = tagName;
					const elAttrs = element.attributes;
					for (let i = 0; i < elAttrs.length; i++) {
						const attr = elAttrs.item(i);
						const lowerAttrName = attr.name.toLowerCase();
						const hasBinding = !!attr.value.match(BINDING_REGEXP);
						const namespaceUri = element.namespaceURI;
						const namespace = namespaceUri && NAMESPACE_URIS[namespaceUri];
						const tagNameWithNamespace = namespace ? `:${namespace}:${tagName}` : tagName;
						if (hasBinding) {
							if (Object.hasOwn(VALID_ATTRS, lowerAttrName)) generateBindingUpdateOpCodes(update, attr.value, newIndex, attr.name, 0, i18nResolveSanitizer(lowerAttrName, tagNameWithNamespace));
							else ngDevMode && console.warn(`WARNING: ignoring unsafe attribute value ${lowerAttrName} on element ${tagName} (see https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss)`);
						} else if (VALID_ATTRS[lowerAttrName]) {
							let val = attr.value;
							if (i18nResolveSanitizer(lowerAttrName, tagNameWithNamespace)) {
								if (typeof ngDevMode !== "undefined" && ngDevMode) console.warn(`WARNING: ignoring unsafe attribute ${lowerAttrName} on element ${tagName} (see ${XSS_SECURITY_URL})`);
								addCreateAttribute(create, newIndex, attr.name, "unsafe:blocked");
							} else addCreateAttribute(create, newIndex, attr.name, val);
						} else if (typeof ngDevMode !== "undefined" && ngDevMode) console.warn(`WARNING: ignoring unknown attribute name ${lowerAttrName} on element ${tagName} (see ${XSS_SECURITY_URL})`);
					}
					const elementNode = {
						kind: 1,
						index: newIndex,
						children: []
					};
					ast.push(elementNode);
					bindingMask = walkIcuTree(elementNode.children, tView, tIcu, lView, sharedUpdateOpCodes, create, remove, update, currentNode, newIndex, nestedIcus, depth + 1) | bindingMask;
					addRemoveNode(remove, newIndex, depth);
				}
				break;
			case Node.TEXT_NODE:
				const value = currentNode.textContent || "";
				const hasBinding = value.match(BINDING_REGEXP);
				addCreateNodeAndAppend(create, null, hasBinding ? "" : value, parentIdx, newIndex);
				addRemoveNode(remove, newIndex, depth);
				if (hasBinding) bindingMask = generateBindingUpdateOpCodes(update, value, newIndex, null, 0, null) | bindingMask;
				ast.push({
					kind: 0,
					index: newIndex
				});
				break;
			case Node.COMMENT_NODE:
				const isNestedIcu = NESTED_ICU.exec(currentNode.textContent || "");
				if (isNestedIcu) {
					const nestedIcuIndex = parseInt(isNestedIcu[1], 10);
					const icuExpression = nestedIcus[nestedIcuIndex];
					addCreateNodeAndAppend(create, ICU_MARKER, ngDevMode ? `nested ICU ${nestedIcuIndex}` : "", parentIdx, newIndex);
					icuStart(ast, tView, lView, sharedUpdateOpCodes, parentIdx, icuExpression, newIndex);
					addRemoveNestedIcu(remove, newIndex, depth);
				}
		}
		currentNode = currentNode.nextSibling;
	}
	return bindingMask;
}
function addRemoveNode(remove, index, depth) {
	if (depth === 0) remove.push(index);
}
function addRemoveNestedIcu(remove, index, depth) {
	if (depth === 0) {
		remove.push(~index);
		remove.push(index);
	}
}
function addUpdateIcuSwitch(update, icuExpression, index) {
	update.push(toMaskBit(icuExpression.mainBinding), 2, -1 - icuExpression.mainBinding, index << 2 | 2);
}
function addUpdateIcuUpdate(update, bindingMask, index) {
	update.push(bindingMask, 1, index << 2 | 3);
}
function addCreateNodeAndAppend(create, marker, text, appendToParentIdx, createAtIdx) {
	if (marker !== null) create.push(marker);
	create.push(text, createAtIdx, icuCreateOpCode(0, appendToParentIdx, createAtIdx));
}
function addCreateAttribute(create, newIndex, attrName, attrValue) {
	create.push(newIndex << 1 | 1, attrName, attrValue);
}
function i18nResolveSanitizer(attrName, tagName) {
	let schemaContext;
	if (tagName) {
		const [ns, name] = splitNsName(tagName, false);
		schemaContext = checkSecurityContext(name, attrName, ns);
	} else schemaContext = checkSecurityContext("*", attrName);
	switch (schemaContext) {
		case SecurityContext.HTML: return ɵɵsanitizeHtml;
		case SecurityContext.STYLE: return ɵɵsanitizeStyle;
		case SecurityContext.SCRIPT: return ɵɵsanitizeScript;
		case SecurityContext.URL: return _sanitizeUrl;
		case SecurityContext.RESOURCE_URL: return ɵɵsanitizeResourceUrl;
		case SecurityContext.ATTRIBUTE_NO_BINDING: return ɵɵvalidateAttribute;
		default: return null;
	}
}
var ROOT_TEMPLATE_ID = 0;
var PP_MULTI_VALUE_PLACEHOLDERS_REGEXP = /\[(�.+?�?)\]/;
var PP_PLACEHOLDERS_REGEXP = /\[(�.+?�?)\]|(�\/?\*\d+:\d+�)/g;
var PP_ICU_VARS_REGEXP = /({\s*)(VAR_(PLURAL|SELECT)(_\d+)?)(\s*,)/g;
var PP_ICU_PLACEHOLDERS_REGEXP = /{([A-Z0-9_]+)}/g;
var PP_ICUS_REGEXP = /�I18N_EXP_(ICU(_\d+)?)�/g;
var PP_CLOSE_TEMPLATE_REGEXP = /\/\*/;
var PP_TEMPLATE_ID_REGEXP = /\d+\:(\d+)/;
function i18nPostprocess(message, replacements = {}) {
	let result = message;
	if (PP_MULTI_VALUE_PLACEHOLDERS_REGEXP.test(message)) {
		const matches = {};
		const templateIdsStack = [ROOT_TEMPLATE_ID];
		result = result.replace(PP_PLACEHOLDERS_REGEXP, (m, phs, tmpl) => {
			const content = phs || tmpl;
			const placeholders = matches[content] || [];
			if (!placeholders.length) {
				content.split("|").forEach((placeholder) => {
					const match = placeholder.match(PP_TEMPLATE_ID_REGEXP);
					const templateId = match ? parseInt(match[1], 10) : ROOT_TEMPLATE_ID;
					const isCloseTemplateTag = PP_CLOSE_TEMPLATE_REGEXP.test(placeholder);
					placeholders.push([
						templateId,
						isCloseTemplateTag,
						placeholder
					]);
				});
				matches[content] = placeholders;
			}
			if (!placeholders.length) throw new Error(`i18n postprocess: unmatched placeholder - ${content}`);
			const currentTemplateId = templateIdsStack[templateIdsStack.length - 1];
			let idx = 0;
			for (let i = 0; i < placeholders.length; i++) if (placeholders[i][0] === currentTemplateId) {
				idx = i;
				break;
			}
			const [templateId, isCloseTemplateTag, placeholder] = placeholders[idx];
			if (isCloseTemplateTag) templateIdsStack.pop();
			else if (currentTemplateId !== templateId) templateIdsStack.push(templateId);
			placeholders.splice(idx, 1);
			return placeholder;
		});
	}
	if (!Object.keys(replacements).length) return result;
	result = result.replace(PP_ICU_VARS_REGEXP, (match, start, key, _type, _idx, end) => {
		return Object.hasOwn(replacements, key) ? `${start}${replacements[key]}${end}` : match;
	});
	result = result.replace(PP_ICU_PLACEHOLDERS_REGEXP, (match, key) => {
		return Object.hasOwn(replacements, key) ? replacements[key] : match;
	});
	result = result.replace(PP_ICUS_REGEXP, (match, key) => {
		if (Object.hasOwn(replacements, key)) {
			const list = replacements[key];
			if (!list.length) throw new Error(`i18n postprocess: unmatched ICU - ${match} with key: ${key}`);
			return list.shift();
		}
		return match;
	});
	return result;
}
function ɵɵi18nStart(index, messageIndex, subTemplateIndex = -1) {
	const tView = getTView();
	const lView = getLView();
	const adjustedIndex = 28 + index;
	ngDevMode && assertDefined(tView, `tView should be defined`);
	const message = getConstant(tView.consts, messageIndex);
	const parentTNode = getCurrentParentTNode();
	if (tView.firstCreatePass) i18nStartFirstCreatePass(tView, parentTNode === null ? 0 : parentTNode.index, lView, adjustedIndex, message, subTemplateIndex);
	if (tView.type === 2) {
		const componentLView = lView[15];
		componentLView[2] |= 32;
	} else lView[2] |= 32;
	const tI18n = tView.data[adjustedIndex];
	const parentRNode = getClosestRElement(tView, parentTNode === lView[5] ? null : parentTNode, lView);
	const insertInFrontOf = parentTNode && parentTNode.type & 8 ? lView[parentTNode.index] : null;
	prepareI18nBlockForHydration(lView, adjustedIndex, parentTNode, subTemplateIndex);
	applyCreateOpCodes(lView, tI18n.create, parentRNode, insertInFrontOf);
	setInI18nBlock(true);
}
function ɵɵi18nEnd() {
	setInI18nBlock(false);
}
function ɵɵi18n(index, messageIndex, subTemplateIndex) {
	ɵɵi18nStart(index, messageIndex, subTemplateIndex);
	ɵɵi18nEnd();
}
function ɵɵi18nAttributes(index, attrsIndex) {
	const tView = getTView();
	ngDevMode && assertDefined(tView, `tView should be defined`);
	const attrs = getConstant(tView.consts, attrsIndex);
	i18nAttributesFirstPass(tView, index + 28, attrs);
}
function ɵɵi18nExp(value) {
	setMaskBit(bindingUpdated(getLView(), nextBindingIndex(), value));
	return ɵɵi18nExp;
}
function ɵɵi18nApply(index) {
	applyI18n(getTView(), getLView(), index + 28);
}
function ɵɵi18nPostprocess(message, replacements = {}) {
	return i18nPostprocess(message, replacements);
}
function ɵɵlistener(eventName, listenerFn, eventTargetResolver) {
	const lView = getLView();
	const tView = getTView();
	const tNode = getCurrentTNode();
	listenerInternal(tView, lView, lView[11], tNode, eventName, listenerFn, eventTargetResolver);
	return ɵɵlistener;
}
function ɵɵsyntheticHostListener(eventName, listenerFn) {
	const tNode = getCurrentTNode();
	const lView = getLView();
	const tView = getTView();
	listenerInternal(tView, lView, loadComponentRenderer(getCurrentDirectiveDef(tView.data), tNode, lView), tNode, eventName, listenerFn);
	return ɵɵsyntheticHostListener;
}
function ɵɵdomListener(eventName, listenerFn, eventTargetResolver) {
	const lView = getLView();
	const tView = getTView();
	const tNode = getCurrentTNode();
	if (tNode.type & 3 || eventTargetResolver) listenToDomEvent(tNode, tView, lView, eventTargetResolver, lView[11], eventName, listenerFn, wrapListener(tNode, lView, listenerFn));
	return ɵɵdomListener;
}
function listenerInternal(tView, lView, renderer, tNode, eventName, listenerFn, eventTargetResolver) {
	ngDevMode && assertTNodeType(tNode, 15);
	let processOutputs = true;
	let wrappedListener = null;
	if (tNode.type & 3 || eventTargetResolver) {
		wrappedListener ??= wrapListener(tNode, lView, listenerFn);
		if (listenToDomEvent(tNode, tView, lView, eventTargetResolver, renderer, eventName, listenerFn, wrappedListener)) processOutputs = false;
	}
	if (processOutputs) {
		const outputConfig = tNode.outputs?.[eventName];
		const hostDirectiveOutputConfig = tNode.hostDirectiveOutputs?.[eventName];
		if (hostDirectiveOutputConfig && hostDirectiveOutputConfig.length) for (let i = 0; i < hostDirectiveOutputConfig.length; i += 2) {
			const index = hostDirectiveOutputConfig[i];
			const lookupName = hostDirectiveOutputConfig[i + 1];
			wrappedListener ??= wrapListener(tNode, lView, listenerFn);
			listenToOutput(tNode, lView, index, lookupName, eventName, wrappedListener);
		}
		if (outputConfig && outputConfig.length) for (const index of outputConfig) {
			wrappedListener ??= wrapListener(tNode, lView, listenerFn);
			listenToOutput(tNode, lView, index, eventName, eventName, wrappedListener);
		}
	}
}
function ɵɵnextContext(level = 1) {
	return nextContextImpl(level);
}
function matchingProjectionSlotIndex(tNode, projectionSlots) {
	let wildcardNgContentIndex = null;
	const ngProjectAsAttrVal = getProjectAsAttrValue(tNode);
	for (let i = 0; i < projectionSlots.length; i++) {
		const slotValue = projectionSlots[i];
		if (slotValue === "*") {
			wildcardNgContentIndex = i;
			continue;
		}
		if (ngProjectAsAttrVal === null ? isNodeMatchingSelectorList(tNode, slotValue, true) : isSelectorInSelectorList(ngProjectAsAttrVal, slotValue)) return i;
	}
	return wildcardNgContentIndex;
}
function ɵɵprojectionDef(projectionSlots) {
	const componentNode = getLView()[15][5];
	if (!componentNode.projection) {
		const projectionHeads = componentNode.projection = newArray(projectionSlots ? projectionSlots.length : 1, null);
		const tails = projectionHeads.slice();
		let componentChild = componentNode.child;
		while (componentChild !== null) {
			if (componentChild.type !== 128) {
				const slotIndex = projectionSlots ? matchingProjectionSlotIndex(componentChild, projectionSlots) : 0;
				if (slotIndex !== null) {
					if (tails[slotIndex]) tails[slotIndex].projectionNext = componentChild;
					else projectionHeads[slotIndex] = componentChild;
					tails[slotIndex] = componentChild;
				}
			}
			componentChild = componentChild.next;
		}
	}
}
function ɵɵprojection(nodeIndex, selectorIndex = 0, attrs, fallbackTemplateFn, fallbackDecls, fallbackVars) {
	const lView = getLView();
	const tView = getTView();
	const fallbackIndex = fallbackTemplateFn ? nodeIndex + 1 : null;
	if (fallbackIndex !== null) declareNoDirectiveHostTemplate(lView, tView, fallbackIndex, fallbackTemplateFn, fallbackDecls, fallbackVars, null, attrs);
	const tProjectionNode = getOrCreateTNode(tView, 28 + nodeIndex, 16, null, attrs || null);
	if (tProjectionNode.projection === null) tProjectionNode.projection = selectorIndex;
	setCurrentTNodeAsNotParent();
	const isNodeCreationMode = !lView[6] || isInSkipHydrationBlock$1();
	if (lView[15][5].projection[tProjectionNode.projection] === null && fallbackIndex !== null) insertFallbackContent(lView, tView, fallbackIndex);
	else if (isNodeCreationMode && !isDetachedByI18n(tProjectionNode)) applyProjection(tView, lView, tProjectionNode);
}
function insertFallbackContent(lView, tView, fallbackIndex) {
	const adjustedIndex = 28 + fallbackIndex;
	const fallbackTNode = tView.data[adjustedIndex];
	const fallbackLContainer = lView[adjustedIndex];
	ngDevMode && assertTNode(fallbackTNode);
	ngDevMode && assertLContainer(fallbackLContainer);
	const dehydratedView = findMatchingDehydratedView(fallbackLContainer, fallbackTNode.tView.ssrId);
	addLViewToLContainer(fallbackLContainer, createAndRenderEmbeddedLView(lView, fallbackTNode, void 0, { dehydratedView }), 0, shouldAddViewToDom(fallbackTNode, dehydratedView));
}
function ɵɵcontentQuery(directiveIndex, predicate, flags, read) {
	createContentQuery(directiveIndex, predicate, flags, read);
	return ɵɵcontentQuery;
}
function ɵɵviewQuery(predicate, flags, read) {
	createViewQuery(predicate, flags, read);
	return ɵɵviewQuery;
}
function ɵɵqueryRefresh(queryList) {
	const lView = getLView();
	const tView = getTView();
	const queryIndex = getCurrentQueryIndex();
	setCurrentQueryIndex(queryIndex + 1);
	const tQuery = getTQuery(tView, queryIndex);
	if (queryList.dirty && isCreationMode(lView) === ((tQuery.metadata.flags & 2) === 2)) {
		if (tQuery.matches === null) queryList.reset([]);
		else {
			const result = getQueryResults(lView, queryIndex);
			queryList.reset(result, unwrapElementRef);
			queryList.notifyOnChanges();
		}
		return true;
	}
	return false;
}
function ɵɵloadQuery() {
	return loadQueryInternal(getLView(), getCurrentQueryIndex());
}
function ɵɵcontentQuerySignal(directiveIndex, target, predicate, flags, read) {
	bindQueryToSignal(target, createContentQuery(directiveIndex, predicate, flags, read));
	return ɵɵcontentQuerySignal;
}
function ɵɵviewQuerySignal(target, predicate, flags, read) {
	bindQueryToSignal(target, createViewQuery(predicate, flags, read));
	return ɵɵviewQuerySignal;
}
function ɵɵqueryAdvance(indexOffset = 1) {
	setCurrentQueryIndex(getCurrentQueryIndex() + indexOffset);
}
function ɵɵreference(index) {
	return load(getContextLView(), 28 + index);
}
function toTStylingRange(prev, next) {
	ngDevMode && assertNumberInRange(prev, 0, 32767);
	ngDevMode && assertNumberInRange(next, 0, 32767);
	return prev << 17 | next << 2;
}
function getTStylingRangePrev(tStylingRange) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	return tStylingRange >> 17 & 32767;
}
function getTStylingRangePrevDuplicate(tStylingRange) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	return (tStylingRange & 2) == 2;
}
function setTStylingRangePrev(tStylingRange, previous) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	ngDevMode && assertNumberInRange(previous, 0, 32767);
	return tStylingRange & 131071 | previous << 17;
}
function setTStylingRangePrevDuplicate(tStylingRange) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	return tStylingRange | 2;
}
function getTStylingRangeNext(tStylingRange) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	return (tStylingRange & 131068) >> 2;
}
function setTStylingRangeNext(tStylingRange, next) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	ngDevMode && assertNumberInRange(next, 0, 32767);
	return tStylingRange & -131069 | next << 2;
}
function getTStylingRangeNextDuplicate(tStylingRange) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	return (tStylingRange & 1) === 1;
}
function setTStylingRangeNextDuplicate(tStylingRange) {
	ngDevMode && assertNumber(tStylingRange, "expected number");
	return tStylingRange | 1;
}
function insertTStylingBinding(tData, tNode, tStylingKeyWithStatic, index, isHostBinding, isClassBinding) {
	ngDevMode && assertFirstUpdatePass(getTView());
	let tBindings = isClassBinding ? tNode.classBindings : tNode.styleBindings;
	let tmplHead = getTStylingRangePrev(tBindings);
	let tmplTail = getTStylingRangeNext(tBindings);
	tData[index] = tStylingKeyWithStatic;
	let isKeyDuplicateOfStatic = false;
	let tStylingKey;
	if (Array.isArray(tStylingKeyWithStatic)) {
		const staticKeyValueArray = tStylingKeyWithStatic;
		tStylingKey = staticKeyValueArray[1];
		if (tStylingKey === null || keyValueArrayIndexOf(staticKeyValueArray, tStylingKey) > 0) isKeyDuplicateOfStatic = true;
	} else tStylingKey = tStylingKeyWithStatic;
	if (isHostBinding) {
		if (tmplTail !== 0) {
			const previousNode = getTStylingRangePrev(tData[tmplHead + 1]);
			tData[index + 1] = toTStylingRange(previousNode, tmplHead);
			if (previousNode !== 0) tData[previousNode + 1] = setTStylingRangeNext(tData[previousNode + 1], index);
			tData[tmplHead + 1] = setTStylingRangePrev(tData[tmplHead + 1], index);
		} else {
			tData[index + 1] = toTStylingRange(tmplHead, 0);
			if (tmplHead !== 0) tData[tmplHead + 1] = setTStylingRangeNext(tData[tmplHead + 1], index);
			tmplHead = index;
		}
	} else {
		tData[index + 1] = toTStylingRange(tmplTail, 0);
		ngDevMode && assertEqual(tmplHead !== 0 && tmplTail === 0, false, "Adding template bindings after hostBindings is not allowed.");
		if (tmplHead === 0) tmplHead = index;
		else tData[tmplTail + 1] = setTStylingRangeNext(tData[tmplTail + 1], index);
		tmplTail = index;
	}
	if (isKeyDuplicateOfStatic) tData[index + 1] = setTStylingRangePrevDuplicate(tData[index + 1]);
	markDuplicates(tData, tStylingKey, index, true);
	markDuplicates(tData, tStylingKey, index, false);
	markDuplicateOfResidualStyling(tNode, tStylingKey, tData, index, isClassBinding);
	tBindings = toTStylingRange(tmplHead, tmplTail);
	if (isClassBinding) tNode.classBindings = tBindings;
	else tNode.styleBindings = tBindings;
}
function markDuplicateOfResidualStyling(tNode, tStylingKey, tData, index, isClassBinding) {
	const residual = isClassBinding ? tNode.residualClasses : tNode.residualStyles;
	if (residual != null && typeof tStylingKey == "string" && keyValueArrayIndexOf(residual, tStylingKey) >= 0) tData[index + 1] = setTStylingRangeNextDuplicate(tData[index + 1]);
}
function markDuplicates(tData, tStylingKey, index, isPrevDir) {
	const tStylingAtIndex = tData[index + 1];
	const isMap = tStylingKey === null;
	let cursor = isPrevDir ? getTStylingRangePrev(tStylingAtIndex) : getTStylingRangeNext(tStylingAtIndex);
	let foundDuplicate = false;
	while (cursor !== 0 && (foundDuplicate === false || isMap)) {
		ngDevMode && assertIndexInRange(tData, cursor);
		const tStylingValueAtCursor = tData[cursor];
		const tStyleRangeAtCursor = tData[cursor + 1];
		if (isStylingMatch(tStylingValueAtCursor, tStylingKey)) {
			foundDuplicate = true;
			tData[cursor + 1] = isPrevDir ? setTStylingRangeNextDuplicate(tStyleRangeAtCursor) : setTStylingRangePrevDuplicate(tStyleRangeAtCursor);
		}
		cursor = isPrevDir ? getTStylingRangePrev(tStyleRangeAtCursor) : getTStylingRangeNext(tStyleRangeAtCursor);
	}
	if (foundDuplicate) tData[index + 1] = isPrevDir ? setTStylingRangePrevDuplicate(tStylingAtIndex) : setTStylingRangeNextDuplicate(tStylingAtIndex);
}
function isStylingMatch(tStylingKeyCursor, tStylingKey) {
	ngDevMode && assertNotEqual(Array.isArray(tStylingKey), true, "Expected that 'tStylingKey' has been unwrapped");
	if (tStylingKeyCursor === null || tStylingKey == null || (Array.isArray(tStylingKeyCursor) ? tStylingKeyCursor[1] : tStylingKeyCursor) === tStylingKey) return true;
	else if (Array.isArray(tStylingKeyCursor) && typeof tStylingKey === "string") return keyValueArrayIndexOf(tStylingKeyCursor, tStylingKey) >= 0;
	return false;
}
var parserState = {
	textEnd: 0,
	key: 0,
	keyEnd: 0,
	value: 0,
	valueEnd: 0
};
function getLastParsedKey(text) {
	return text.substring(parserState.key, parserState.keyEnd);
}
function getLastParsedValue(text) {
	return text.substring(parserState.value, parserState.valueEnd);
}
function parseClassName(text) {
	resetParserState(text);
	return parseClassNameNext(text, consumeWhitespace(text, 0, parserState.textEnd));
}
function parseClassNameNext(text, index) {
	const end = parserState.textEnd;
	if (end === index) return -1;
	index = parserState.keyEnd = consumeClassToken(text, parserState.key = index, end);
	return consumeWhitespace(text, index, end);
}
function parseStyle(text) {
	resetParserState(text);
	return parseStyleNext(text, consumeWhitespace(text, 0, parserState.textEnd));
}
function parseStyleNext(text, startIndex) {
	const end = parserState.textEnd;
	let index = parserState.key = consumeWhitespace(text, startIndex, end);
	if (end === index) return -1;
	index = parserState.keyEnd = consumeStyleKey(text, index, end);
	index = consumeSeparator(text, index, end, 58);
	index = parserState.value = consumeWhitespace(text, index, end);
	index = parserState.valueEnd = consumeStyleValue(text, index, end);
	return consumeSeparator(text, index, end, 59);
}
function resetParserState(text) {
	parserState.key = 0;
	parserState.keyEnd = 0;
	parserState.value = 0;
	parserState.valueEnd = 0;
	parserState.textEnd = text.length;
}
function consumeWhitespace(text, startIndex, endIndex) {
	while (startIndex < endIndex && text.charCodeAt(startIndex) <= 32) startIndex++;
	return startIndex;
}
function consumeClassToken(text, startIndex, endIndex) {
	while (startIndex < endIndex && text.charCodeAt(startIndex) > 32) startIndex++;
	return startIndex;
}
function consumeStyleKey(text, startIndex, endIndex) {
	let ch;
	while (startIndex < endIndex && ((ch = text.charCodeAt(startIndex)) === 45 || ch === 95 || (ch & -33) >= 65 && (ch & -33) <= 90 || ch >= 48 && ch <= 57)) startIndex++;
	return startIndex;
}
function consumeSeparator(text, startIndex, endIndex, separator) {
	startIndex = consumeWhitespace(text, startIndex, endIndex);
	if (startIndex < endIndex) {
		if (ngDevMode && text.charCodeAt(startIndex) !== separator) malformedStyleError(text, String.fromCharCode(separator), startIndex);
		startIndex++;
	}
	return startIndex;
}
function consumeStyleValue(text, startIndex, endIndex) {
	let ch1 = -1;
	let ch2 = -1;
	let ch3 = -1;
	let i = startIndex;
	let lastChIndex = i;
	while (i < endIndex) {
		const ch = text.charCodeAt(i++);
		if (ch === 59) return lastChIndex;
		else if (ch === 34 || ch === 39) lastChIndex = i = consumeQuotedText(text, ch, i, endIndex);
		else if (startIndex === i - 4 && ch3 === 85 && ch2 === 82 && ch1 === 76 && ch === 40) lastChIndex = i = consumeQuotedText(text, 41, i, endIndex);
		else if (ch > 32) lastChIndex = i;
		ch3 = ch2;
		ch2 = ch1;
		ch1 = ch & -33;
	}
	return lastChIndex;
}
function consumeQuotedText(text, quoteCharCode, startIndex, endIndex) {
	let ch1 = -1;
	let index = startIndex;
	while (index < endIndex) {
		const ch = text.charCodeAt(index++);
		if (ch == quoteCharCode && ch1 !== 92) return index;
		if (ch == 92 && ch1 === 92) ch1 = 0;
		else ch1 = ch;
	}
	throw ngDevMode ? malformedStyleError(text, String.fromCharCode(quoteCharCode), endIndex) : /* @__PURE__ */ new Error();
}
function malformedStyleError(text, expecting, index) {
	ngDevMode && assertEqual(typeof text === "string", true, "String expected here");
	throw throwError(`Malformed style at location ${index} in string '` + text.substring(0, index) + "[>>" + text.substring(index, index + 1) + "<<]" + text.slice(index + 1) + `'. Expecting '${expecting}'.`);
}
function ɵɵstyleProp(prop, value, suffix) {
	checkStylingProperty(prop, value, suffix, false);
	return ɵɵstyleProp;
}
function ɵɵclassProp(className, value) {
	checkStylingProperty(className, value, null, true);
	return ɵɵclassProp;
}
function ɵɵstyleMap(styles) {
	checkStylingMap(styleKeyValueArraySet, styleStringParser, styles, false);
}
function styleStringParser(keyValueArray, text) {
	for (let i = parseStyle(text); i >= 0; i = parseStyleNext(text, i)) styleKeyValueArraySet(keyValueArray, getLastParsedKey(text), getLastParsedValue(text));
}
function ɵɵclassMap(classes) {
	checkStylingMap(classKeyValueArraySet, classStringParser, classes, true);
}
function classStringParser(keyValueArray, text) {
	for (let i = parseClassName(text); i >= 0; i = parseClassNameNext(text, i)) keyValueArraySet(keyValueArray, getLastParsedKey(text), true);
}
function checkStylingProperty(prop, value, suffix, isClassBased) {
	const lView = getLView();
	const tView = getTView();
	const bindingIndex = incrementBindingIndex(2);
	if (tView.firstUpdatePass) stylingFirstUpdatePass(tView, prop, bindingIndex, isClassBased);
	if (value !== NO_CHANGE && bindingUpdated(lView, bindingIndex, value)) {
		if (ngDevMode && !isClassBased) warnInvalidStylePropValue(prop, value);
		const tNode = tView.data[getSelectedIndex()];
		updateStyling(tView, tNode, lView, lView[11], prop, lView[bindingIndex + 1] = normalizeSuffix(value, suffix), isClassBased, bindingIndex);
	}
}
function warnInvalidStylePropValue(prop, value) {
	if (value == null || typeof value === "string" || typeof value === "number" || getSanitizationBypassType(value) === "Style") return;
	console.warn(formatRuntimeError(-318, `\`[style.${prop}]\` was bound to an invalid value. Expected a string, number, SafeValue, null, or undefined, but received \`${typeof value}\` (\`${stringifyInvalidStylePropValue(value)}\`).`));
}
function stringifyInvalidStylePropValue(value) {
	try {
		return stringify(value);
	} catch {
		return "[unstringifiable value]";
	}
}
function checkStylingMap(keyValueArraySet, stringParser, value, isClassBased) {
	const tView = getTView();
	const bindingIndex = incrementBindingIndex(2);
	if (tView.firstUpdatePass) stylingFirstUpdatePass(tView, null, bindingIndex, isClassBased);
	const lView = getLView();
	if (value !== NO_CHANGE && bindingUpdated(lView, bindingIndex, value)) {
		const tNode = tView.data[getSelectedIndex()];
		if (hasStylingInputShadow(tNode, isClassBased) && !isInHostBindings(tView, bindingIndex)) {
			if (ngDevMode) {
				const tStylingKey = tView.data[bindingIndex];
				assertEqual(Array.isArray(tStylingKey) ? tStylingKey[1] : tStylingKey, false, "Styling linked list shadow input should be marked as 'false'");
			}
			let staticPrefix = isClassBased ? tNode.classesWithoutHost : tNode.stylesWithoutHost;
			ngDevMode && isClassBased === false && staticPrefix !== null && assertEqual(staticPrefix.endsWith(";"), true, "Expecting static portion to end with ';'");
			if (staticPrefix !== null) value = concatStringsWithSpace(staticPrefix, value ? value : "");
			setDirectiveInputsWhichShadowsStyling(tView, tNode, lView, value, isClassBased);
		} else updateStylingMap(tView, tNode, lView, lView[11], lView[bindingIndex + 1], lView[bindingIndex + 1] = toStylingKeyValueArray(keyValueArraySet, stringParser, value), isClassBased, bindingIndex);
	}
}
function isInHostBindings(tView, bindingIndex) {
	return bindingIndex >= tView.expandoStartIndex;
}
function stylingFirstUpdatePass(tView, tStylingKey, bindingIndex, isClassBased) {
	ngDevMode && assertFirstUpdatePass(tView);
	const tData = tView.data;
	if (tData[bindingIndex + 1] === null) {
		const tNode = tData[getSelectedIndex()];
		ngDevMode && assertDefined(tNode, "TNode expected");
		const isHostBindings = isInHostBindings(tView, bindingIndex);
		if (hasStylingInputShadow(tNode, isClassBased) && tStylingKey === null && !isHostBindings) tStylingKey = false;
		tStylingKey = wrapInStaticStylingKey(tData, tNode, tStylingKey, isClassBased);
		insertTStylingBinding(tData, tNode, tStylingKey, bindingIndex, isHostBindings, isClassBased);
	}
}
function wrapInStaticStylingKey(tData, tNode, stylingKey, isClassBased) {
	const hostDirectiveDef = getCurrentDirectiveDef(tData);
	let residual = isClassBased ? tNode.residualClasses : tNode.residualStyles;
	if (hostDirectiveDef === null) {
		if ((isClassBased ? tNode.classBindings : tNode.styleBindings) === 0) {
			stylingKey = collectStylingFromDirectives(null, tData, tNode, stylingKey, isClassBased);
			stylingKey = collectStylingFromTAttrs(stylingKey, tNode.attrs, isClassBased);
			residual = null;
		}
	} else {
		const directiveStylingLast = tNode.directiveStylingLast;
		if (directiveStylingLast === -1 || tData[directiveStylingLast] !== hostDirectiveDef) {
			stylingKey = collectStylingFromDirectives(hostDirectiveDef, tData, tNode, stylingKey, isClassBased);
			if (residual === null) {
				let templateStylingKey = getTemplateHeadTStylingKey(tData, tNode, isClassBased);
				if (templateStylingKey !== void 0 && Array.isArray(templateStylingKey)) {
					templateStylingKey = collectStylingFromDirectives(null, tData, tNode, templateStylingKey[1], isClassBased);
					templateStylingKey = collectStylingFromTAttrs(templateStylingKey, tNode.attrs, isClassBased);
					setTemplateHeadTStylingKey(tData, tNode, isClassBased, templateStylingKey);
				}
			} else residual = collectResidual(tData, tNode, isClassBased);
		}
	}
	if (residual !== void 0) isClassBased ? tNode.residualClasses = residual : tNode.residualStyles = residual;
	return stylingKey;
}
function getTemplateHeadTStylingKey(tData, tNode, isClassBased) {
	const bindings = isClassBased ? tNode.classBindings : tNode.styleBindings;
	if (getTStylingRangeNext(bindings) === 0) return;
	return tData[getTStylingRangePrev(bindings)];
}
function setTemplateHeadTStylingKey(tData, tNode, isClassBased, tStylingKey) {
	const bindings = isClassBased ? tNode.classBindings : tNode.styleBindings;
	ngDevMode && assertNotEqual(getTStylingRangeNext(bindings), 0, "Expecting to have at least one template styling binding.");
	tData[getTStylingRangePrev(bindings)] = tStylingKey;
}
function collectResidual(tData, tNode, isClassBased) {
	let residual = void 0;
	const directiveEnd = tNode.directiveEnd;
	ngDevMode && assertNotEqual(tNode.directiveStylingLast, -1, "By the time this function gets called at least one hostBindings-node styling instruction must have executed.");
	for (let i = 1 + tNode.directiveStylingLast; i < directiveEnd; i++) {
		const attrs = tData[i].hostAttrs;
		residual = collectStylingFromTAttrs(residual, attrs, isClassBased);
	}
	return collectStylingFromTAttrs(residual, tNode.attrs, isClassBased);
}
function collectStylingFromDirectives(hostDirectiveDef, tData, tNode, stylingKey, isClassBased) {
	let currentDirective = null;
	const directiveEnd = tNode.directiveEnd;
	let directiveStylingLast = tNode.directiveStylingLast;
	if (directiveStylingLast === -1) directiveStylingLast = tNode.directiveStart;
	else directiveStylingLast++;
	while (directiveStylingLast < directiveEnd) {
		currentDirective = tData[directiveStylingLast];
		ngDevMode && assertDefined(currentDirective, "expected to be defined");
		stylingKey = collectStylingFromTAttrs(stylingKey, currentDirective.hostAttrs, isClassBased);
		if (currentDirective === hostDirectiveDef) break;
		directiveStylingLast++;
	}
	if (hostDirectiveDef !== null) tNode.directiveStylingLast = directiveStylingLast;
	return stylingKey;
}
function collectStylingFromTAttrs(stylingKey, attrs, isClassBased) {
	const desiredMarker = isClassBased ? 1 : 2;
	let currentMarker = -1;
	if (attrs !== null) for (let i = 0; i < attrs.length; i++) {
		const item = attrs[i];
		if (typeof item === "number") currentMarker = item;
		else if (currentMarker === desiredMarker) {
			if (!Array.isArray(stylingKey)) stylingKey = stylingKey === void 0 ? [] : ["", stylingKey];
			keyValueArraySet(stylingKey, item, isClassBased ? true : attrs[++i]);
		}
	}
	return stylingKey === void 0 ? null : stylingKey;
}
function toStylingKeyValueArray(keyValueArraySet, stringParser, value) {
	if (value == null || value === "") return EMPTY_ARRAY;
	const styleKeyValueArray = [];
	const unwrappedValue = unwrapSafeValue(value);
	if (Array.isArray(unwrappedValue)) for (let i = 0; i < unwrappedValue.length; i++) keyValueArraySet(styleKeyValueArray, unwrappedValue[i], true);
	else if (unwrappedValue instanceof Set) for (const current of unwrappedValue) keyValueArraySet(styleKeyValueArray, current, true);
	else if (typeof unwrappedValue === "object") {
		for (const key in unwrappedValue) if (Object.hasOwn(unwrappedValue, key)) keyValueArraySet(styleKeyValueArray, key, unwrappedValue[key]);
	} else if (typeof unwrappedValue === "string") stringParser(styleKeyValueArray, unwrappedValue);
	else ngDevMode && throwError("Unsupported styling type: " + typeof unwrappedValue + " (" + unwrappedValue + ")");
	return styleKeyValueArray;
}
function styleKeyValueArraySet(keyValueArray, key, value) {
	ngDevMode && warnInvalidStylePropValue(key, value);
	keyValueArraySet(keyValueArray, key, unwrapSafeValue(value));
}
function classKeyValueArraySet(keyValueArray, key, value) {
	const stringKey = String(key);
	if (stringKey !== "" && !stringKey.includes(" ")) keyValueArraySet(keyValueArray, stringKey, value);
}
function updateStylingMap(tView, tNode, lView, renderer, oldKeyValueArray, newKeyValueArray, isClassBased, bindingIndex) {
	if (oldKeyValueArray === NO_CHANGE) oldKeyValueArray = EMPTY_ARRAY;
	let oldIndex = 0;
	let newIndex = 0;
	let oldKey = 0 < oldKeyValueArray.length ? oldKeyValueArray[0] : null;
	let newKey = 0 < newKeyValueArray.length ? newKeyValueArray[0] : null;
	while (oldKey !== null || newKey !== null) {
		ngDevMode && assertLessThan(oldIndex, 999, "Are we stuck in infinite loop?");
		ngDevMode && assertLessThan(newIndex, 999, "Are we stuck in infinite loop?");
		const oldValue = oldIndex < oldKeyValueArray.length ? oldKeyValueArray[oldIndex + 1] : void 0;
		const newValue = newIndex < newKeyValueArray.length ? newKeyValueArray[newIndex + 1] : void 0;
		let setKey = null;
		let setValue = void 0;
		if (oldKey === newKey) {
			oldIndex += 2;
			newIndex += 2;
			if (oldValue !== newValue) {
				setKey = newKey;
				setValue = newValue;
			}
		} else if (newKey === null || oldKey !== null && oldKey < newKey) {
			oldIndex += 2;
			setKey = oldKey;
		} else {
			ngDevMode && assertDefined(newKey, "Expecting to have a valid key");
			newIndex += 2;
			setKey = newKey;
			setValue = newValue;
		}
		if (setKey !== null) updateStyling(tView, tNode, lView, renderer, setKey, setValue, isClassBased, bindingIndex);
		oldKey = oldIndex < oldKeyValueArray.length ? oldKeyValueArray[oldIndex] : null;
		newKey = newIndex < newKeyValueArray.length ? newKeyValueArray[newIndex] : null;
	}
}
function updateStyling(tView, tNode, lView, renderer, prop, value, isClassBased, bindingIndex) {
	if (!(tNode.type & 3)) return;
	const tData = tView.data;
	const tRange = tData[bindingIndex + 1];
	if (!isStylingValuePresent(getTStylingRangeNextDuplicate(tRange) ? findStylingValue(tData, tNode, lView, prop, getTStylingRangeNext(tRange), isClassBased) : void 0)) {
		if (!isStylingValuePresent(value)) {
			if (getTStylingRangePrevDuplicate(tRange)) value = findStylingValue(tData, null, lView, prop, bindingIndex, isClassBased);
		}
		applyStyling(renderer, isClassBased, getNativeByIndex(getSelectedIndex(), lView), prop, value);
	}
}
function findStylingValue(tData, tNode, lView, prop, index, isClassBased) {
	const isPrevDirection = tNode === null;
	let value = void 0;
	while (index > 0) {
		const rawKey = tData[index];
		const containsStatics = Array.isArray(rawKey);
		const key = containsStatics ? rawKey[1] : rawKey;
		const isStylingMap = key === null;
		let valueAtLViewIndex = lView[index + 1];
		if (valueAtLViewIndex === NO_CHANGE) valueAtLViewIndex = isStylingMap ? EMPTY_ARRAY : void 0;
		let currentValue = isStylingMap ? keyValueArrayGet(valueAtLViewIndex, prop) : key === prop ? valueAtLViewIndex : void 0;
		if (containsStatics && !isStylingValuePresent(currentValue)) currentValue = keyValueArrayGet(rawKey, prop);
		if (isStylingValuePresent(currentValue)) {
			value = currentValue;
			if (isPrevDirection) return value;
		}
		const tRange = tData[index + 1];
		index = isPrevDirection ? getTStylingRangePrev(tRange) : getTStylingRangeNext(tRange);
	}
	if (tNode !== null) {
		let residual = isClassBased ? tNode.residualClasses : tNode.residualStyles;
		if (residual != null) value = keyValueArrayGet(residual, prop);
	}
	return value;
}
function isStylingValuePresent(value) {
	return value !== void 0;
}
function normalizeSuffix(value, suffix) {
	if (value == null || value === "");
	else if (typeof suffix === "string") value = unwrapSafeValue(value) + suffix;
	else if (typeof value === "object") value = stringify(unwrapSafeValue(value));
	return value;
}
function hasStylingInputShadow(tNode, isClassBased) {
	return (tNode.flags & (isClassBased ? 8 : 16)) !== 0;
}
function ɵɵtext(index, value = "") {
	const lView = getLView();
	const tView = getTView();
	const adjustedIndex = index + 28;
	ngDevMode && assertTNodeCreationIndex(lView, index);
	const tNode = tView.firstCreatePass ? getOrCreateTNode(tView, adjustedIndex, 1, value, null) : tView.data[adjustedIndex];
	const textNative = _locateOrCreateTextNode(tView, lView, tNode, value);
	lView[adjustedIndex] = textNative;
	if (wasLastNodeCreated()) appendChild(tView, lView, textNative, tNode);
	setCurrentTNode(tNode, false);
}
var _locateOrCreateTextNode = (tView, lView, tNode, value) => {
	lastNodeWasCreated(true);
	return createTextNode(lView[11], value);
};
function interpolationV(lView, values) {
	ngDevMode && assertLessThan(2, values.length, "should have at least 3 values");
	let isBindingUpdated = false;
	let bindingIndex = getBindingIndex();
	for (let i = 1; i < values.length; i += 2) isBindingUpdated = bindingUpdated(lView, bindingIndex++, values[i]) || isBindingUpdated;
	setBindingIndex(bindingIndex);
	if (!isBindingUpdated) return NO_CHANGE;
	let content = values[0];
	for (let i = 1; i < values.length; i += 2) content += renderStringify(values[i]) + (i + 1 !== values.length ? values[i + 1] : "");
	return content;
}
function interpolation1(lView, prefix, v0, suffix = "") {
	return bindingUpdated(lView, nextBindingIndex(), v0) ? prefix + renderStringify(v0) + suffix : NO_CHANGE;
}
function interpolation2(lView, prefix, v0, i0, v1, suffix = "") {
	const different = bindingUpdated2(lView, getBindingIndex(), v0, v1);
	incrementBindingIndex(2);
	return different ? prefix + renderStringify(v0) + i0 + renderStringify(v1) + suffix : NO_CHANGE;
}
function interpolation3(lView, prefix, v0, i0, v1, i1, v2, suffix = "") {
	const different = bindingUpdated3(lView, getBindingIndex(), v0, v1, v2);
	incrementBindingIndex(3);
	return different ? prefix + renderStringify(v0) + i0 + renderStringify(v1) + i1 + renderStringify(v2) + suffix : NO_CHANGE;
}
function interpolation4(lView, prefix, v0, i0, v1, i1, v2, i2, v3, suffix = "") {
	const different = bindingUpdated4(lView, getBindingIndex(), v0, v1, v2, v3);
	incrementBindingIndex(4);
	return different ? prefix + renderStringify(v0) + i0 + renderStringify(v1) + i1 + renderStringify(v2) + i2 + renderStringify(v3) + suffix : NO_CHANGE;
}
function interpolation5(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, suffix = "") {
	const bindingIndex = getBindingIndex();
	let different = bindingUpdated4(lView, bindingIndex, v0, v1, v2, v3);
	different = bindingUpdated(lView, bindingIndex + 4, v4) || different;
	incrementBindingIndex(5);
	return different ? prefix + renderStringify(v0) + i0 + renderStringify(v1) + i1 + renderStringify(v2) + i2 + renderStringify(v3) + i3 + renderStringify(v4) + suffix : NO_CHANGE;
}
function interpolation6(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, suffix = "") {
	const bindingIndex = getBindingIndex();
	let different = bindingUpdated4(lView, bindingIndex, v0, v1, v2, v3);
	different = bindingUpdated2(lView, bindingIndex + 4, v4, v5) || different;
	incrementBindingIndex(6);
	return different ? prefix + renderStringify(v0) + i0 + renderStringify(v1) + i1 + renderStringify(v2) + i2 + renderStringify(v3) + i3 + renderStringify(v4) + i4 + renderStringify(v5) + suffix : NO_CHANGE;
}
function interpolation7(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, suffix = "") {
	const bindingIndex = getBindingIndex();
	let different = bindingUpdated4(lView, bindingIndex, v0, v1, v2, v3);
	different = bindingUpdated3(lView, bindingIndex + 4, v4, v5, v6) || different;
	incrementBindingIndex(7);
	return different ? prefix + renderStringify(v0) + i0 + renderStringify(v1) + i1 + renderStringify(v2) + i2 + renderStringify(v3) + i3 + renderStringify(v4) + i4 + renderStringify(v5) + i5 + renderStringify(v6) + suffix : NO_CHANGE;
}
function interpolation8(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, i6, v7, suffix = "") {
	const bindingIndex = getBindingIndex();
	let different = bindingUpdated4(lView, bindingIndex, v0, v1, v2, v3);
	different = bindingUpdated4(lView, bindingIndex + 4, v4, v5, v6, v7) || different;
	incrementBindingIndex(8);
	return different ? prefix + renderStringify(v0) + i0 + renderStringify(v1) + i1 + renderStringify(v2) + i2 + renderStringify(v3) + i3 + renderStringify(v4) + i4 + renderStringify(v5) + i5 + renderStringify(v6) + i6 + renderStringify(v7) + suffix : NO_CHANGE;
}
function ɵɵtextInterpolate(v0) {
	ɵɵtextInterpolate1("", v0);
	return ɵɵtextInterpolate;
}
function ɵɵtextInterpolate1(prefix, v0, suffix) {
	const lView = getLView();
	const interpolated = interpolation1(lView, prefix, v0, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate1;
}
function ɵɵtextInterpolate2(prefix, v0, i0, v1, suffix) {
	const lView = getLView();
	const interpolated = interpolation2(lView, prefix, v0, i0, v1, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate2;
}
function ɵɵtextInterpolate3(prefix, v0, i0, v1, i1, v2, suffix) {
	const lView = getLView();
	const interpolated = interpolation3(lView, prefix, v0, i0, v1, i1, v2, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate3;
}
function ɵɵtextInterpolate4(prefix, v0, i0, v1, i1, v2, i2, v3, suffix) {
	const lView = getLView();
	const interpolated = interpolation4(lView, prefix, v0, i0, v1, i1, v2, i2, v3, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate4;
}
function ɵɵtextInterpolate5(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, suffix) {
	const lView = getLView();
	const interpolated = interpolation5(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate5;
}
function ɵɵtextInterpolate6(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, suffix) {
	const lView = getLView();
	const interpolated = interpolation6(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate6;
}
function ɵɵtextInterpolate7(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, suffix) {
	const lView = getLView();
	const interpolated = interpolation7(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate7;
}
function ɵɵtextInterpolate8(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, i6, v7, suffix) {
	const lView = getLView();
	const interpolated = interpolation8(lView, prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, i6, v7, suffix);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolate8;
}
function ɵɵtextInterpolateV(values) {
	const lView = getLView();
	const interpolated = interpolationV(lView, values);
	if (interpolated !== NO_CHANGE) textBindingInternal(lView, getSelectedIndex(), interpolated);
	return ɵɵtextInterpolateV;
}
function textBindingInternal(lView, index, value) {
	ngDevMode && assertString(value, "Value should be a string");
	ngDevMode && assertNotSame(value, NO_CHANGE, "value should not be NO_CHANGE");
	ngDevMode && assertIndexInRange(lView, index);
	const element = getNativeByIndex(index, lView);
	ngDevMode && assertDefined(element, "native element should exist");
	updateTextNode(lView[11], element, value);
}
function ɵɵtwoWayProperty(propName, value, sanitizer) {
	if (isWritableSignal(value)) value = value();
	const lView = getLView();
	const bindingIndex = nextBindingIndex();
	if (bindingUpdated(lView, bindingIndex, value)) {
		const tView = getTView();
		const tNode = getSelectedTNode();
		setPropertyAndInputs(tNode, lView, propName, value, lView[11], sanitizer);
		ngDevMode && storePropertyBindingMetadata(tView.data, tNode, propName, bindingIndex);
	}
	return ɵɵtwoWayProperty;
}
function ɵɵtwoWayBindingSet(target, value) {
	const canWrite = isWritableSignal(target);
	canWrite && target.set(value);
	return canWrite;
}
function ɵɵtwoWayListener(eventName, listenerFn) {
	const lView = getLView();
	const tView = getTView();
	const tNode = getCurrentTNode();
	listenerInternal(tView, lView, lView[11], tNode, eventName, listenerFn);
	return ɵɵtwoWayListener;
}
var UNINITIALIZED_LET = {};
function ɵɵdeclareLet(index) {
	performanceMarkFeature("NgLet");
	const tView = getTView();
	const lView = getLView();
	const adjustedIndex = index + 28;
	setCurrentTNode(getOrCreateTNode(tView, adjustedIndex, 128, null, null), false);
	store(tView, lView, adjustedIndex, UNINITIALIZED_LET);
	return ɵɵdeclareLet;
}
function ɵɵstoreLet(value) {
	store(getTView(), getLView(), getSelectedIndex(), value);
	return value;
}
function ɵɵreadContextLet(index) {
	const value = load(getContextLView(), 28 + index);
	if (value === UNINITIALIZED_LET) throw new RuntimeError(314, ngDevMode && "Attempting to access a @let declaration whose value is not available yet");
	return value;
}
function ɵɵattachSourceLocations(templatePath, locations) {
	const tView = getTView();
	const lView = getLView();
	const renderer = lView[11];
	const attributeName = "data-ng-source-location";
	for (const [index, offset, line, column] of locations) {
		const tNode = getTNode(tView, index + 28);
		ngDevMode && assertTNodeType(tNode, 2);
		const node = getNativeByIndex(index + 28, lView);
		if (!node.hasAttribute(attributeName)) {
			const attributeValue = `${templatePath}@o:${offset},l:${line},c:${column}`;
			renderer.setAttribute(node, attributeName, attributeValue);
		}
	}
}
function ɵɵinterpolate(v0) {
	return bindingUpdated(getLView(), nextBindingIndex(), v0) ? renderStringify(v0) : NO_CHANGE;
}
function ɵɵinterpolate1(prefix, v0, suffix = "") {
	return interpolation1(getLView(), prefix, v0, suffix);
}
function ɵɵinterpolate2(prefix, v0, i0, v1, suffix = "") {
	return interpolation2(getLView(), prefix, v0, i0, v1, suffix);
}
function ɵɵinterpolate3(prefix, v0, i0, v1, i1, v2, suffix = "") {
	return interpolation3(getLView(), prefix, v0, i0, v1, i1, v2, suffix);
}
function ɵɵinterpolate4(prefix, v0, i0, v1, i1, v2, i2, v3, suffix = "") {
	return interpolation4(getLView(), prefix, v0, i0, v1, i1, v2, i2, v3, suffix);
}
function ɵɵinterpolate5(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, suffix = "") {
	return interpolation5(getLView(), prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, suffix);
}
function ɵɵinterpolate6(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, suffix = "") {
	return interpolation6(getLView(), prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, suffix);
}
function ɵɵinterpolate7(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, suffix = "") {
	return interpolation7(getLView(), prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, suffix);
}
function ɵɵinterpolate8(prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, i6, v7, suffix = "") {
	return interpolation8(getLView(), prefix, v0, i0, v1, i1, v2, i2, v3, i3, v4, i4, v5, i5, v6, i6, v7, suffix);
}
function ɵɵinterpolateV(values) {
	return interpolationV(getLView(), values);
}
function ɵɵarrowFunction(slotOffset, factory, context) {
	const bindingIndex = getBindingRoot() + slotOffset;
	const lView = getLView();
	return lView[bindingIndex] === NO_CHANGE ? updateBinding(lView, bindingIndex, factory(context, lView)) : getBinding(lView, bindingIndex);
}
function providersResolver(def, providers, isViewProviders) {
	const tView = getTView();
	if (tView.firstCreatePass) resolveProvider(providers, tView.data, tView.blueprint, isComponentDef(def), isViewProviders);
}
function resolveProvider(provider, tInjectables, lInjectablesBlueprint, isComponent, isViewProvider) {
	provider = resolveForwardRef(provider);
	if (Array.isArray(provider)) for (let i = 0; i < provider.length; i++) resolveProvider(provider[i], tInjectables, lInjectablesBlueprint, isComponent, isViewProvider);
	else {
		const tView = getTView();
		const lView = getLView();
		const tNode = getCurrentTNode();
		let token = isTypeProvider(provider) ? provider : resolveForwardRef(provider.provide);
		const providerFactory = providerToFactory(provider);
		if (ngDevMode) runInInjectorProfilerContext(new NodeInjector(tNode, lView), token, () => {
			emitProviderConfiguredEvent(provider, isViewProvider);
		});
		const beginIndex = tNode.providerIndexes & 1048575;
		const endIndex = tNode.directiveStart;
		const cptViewProvidersCount = tNode.providerIndexes >> 20;
		if (isTypeProvider(provider) || !provider.multi) {
			const factory = new NodeInjectorFactory(providerFactory, isViewProvider, ɵɵdirectiveInject, ngDevMode ? providerName(provider) : null);
			const existingFactoryIndex = indexOf(token, tInjectables, isViewProvider ? beginIndex : beginIndex + cptViewProvidersCount, endIndex);
			if (existingFactoryIndex === -1) {
				diPublicInInjector(getOrCreateNodeInjectorForNode(tNode, lView), tView, token);
				registerDestroyHooksIfSupported(tView, provider, tInjectables.length);
				tInjectables.push(token);
				tNode.directiveStart++;
				tNode.directiveEnd++;
				if (isViewProvider) tNode.providerIndexes += 1048576;
				lInjectablesBlueprint.push(factory);
				lView.push(factory);
			} else {
				lInjectablesBlueprint[existingFactoryIndex] = factory;
				lView[existingFactoryIndex] = factory;
			}
		} else {
			const existingProvidersFactoryIndex = indexOf(token, tInjectables, beginIndex + cptViewProvidersCount, endIndex);
			const existingViewProvidersFactoryIndex = indexOf(token, tInjectables, beginIndex, beginIndex + cptViewProvidersCount);
			const doesProvidersFactoryExist = existingProvidersFactoryIndex >= 0 && lInjectablesBlueprint[existingProvidersFactoryIndex];
			const doesViewProvidersFactoryExist = existingViewProvidersFactoryIndex >= 0 && lInjectablesBlueprint[existingViewProvidersFactoryIndex];
			if (isViewProvider && !doesViewProvidersFactoryExist || !isViewProvider && !doesProvidersFactoryExist) {
				diPublicInInjector(getOrCreateNodeInjectorForNode(tNode, lView), tView, token);
				const factory = multiFactory(isViewProvider ? multiViewProvidersFactoryResolver : multiProvidersFactoryResolver, lInjectablesBlueprint.length, isViewProvider, isComponent, providerFactory, provider);
				if (!isViewProvider && doesViewProvidersFactoryExist) lInjectablesBlueprint[existingViewProvidersFactoryIndex].providerFactory = factory;
				registerDestroyHooksIfSupported(tView, provider, tInjectables.length, 0);
				tInjectables.push(token);
				tNode.directiveStart++;
				tNode.directiveEnd++;
				if (isViewProvider) tNode.providerIndexes += 1048576;
				lInjectablesBlueprint.push(factory);
				lView.push(factory);
			} else {
				const indexInFactory = multiFactoryAdd(lInjectablesBlueprint[isViewProvider ? existingViewProvidersFactoryIndex : existingProvidersFactoryIndex], providerFactory, !isViewProvider && isComponent);
				registerDestroyHooksIfSupported(tView, provider, existingProvidersFactoryIndex > -1 ? existingProvidersFactoryIndex : existingViewProvidersFactoryIndex, indexInFactory);
			}
			if (!isViewProvider && isComponent && doesViewProvidersFactoryExist) lInjectablesBlueprint[existingViewProvidersFactoryIndex].componentProviders++;
		}
	}
}
function registerDestroyHooksIfSupported(tView, provider, contextIndex, indexInFactory) {
	const providerIsTypeProvider = isTypeProvider(provider);
	const providerIsClassProvider = isClassProvider(provider);
	if (providerIsTypeProvider || providerIsClassProvider) {
		const ngOnDestroy = (providerIsClassProvider ? resolveForwardRef(provider.useClass) : provider).prototype.ngOnDestroy;
		if (ngOnDestroy) {
			const hooks = tView.destroyHooks || (tView.destroyHooks = []);
			if (!providerIsTypeProvider && provider.multi) {
				ngDevMode && assertDefined(indexInFactory, "indexInFactory when registering multi factory destroy hook");
				const existingCallbacksIndex = hooks.indexOf(contextIndex);
				if (existingCallbacksIndex === -1) hooks.push(contextIndex, [indexInFactory, ngOnDestroy]);
				else hooks[existingCallbacksIndex + 1].push(indexInFactory, ngOnDestroy);
			} else hooks.push(contextIndex, ngOnDestroy);
		}
	}
}
function multiFactoryAdd(multiFactory, factory, isComponentProvider) {
	if (isComponentProvider) multiFactory.componentProviders++;
	return multiFactory.multi.push(factory) - 1;
}
function indexOf(item, arr, begin, end) {
	for (let i = begin; i < end; i++) if (arr[i] === item) return i;
	return -1;
}
function multiProvidersFactoryResolver(_, flags, tData, lData, tNode) {
	return multiResolve(this.multi, []);
}
function multiViewProvidersFactoryResolver(_, _flags, _tData, lView, tNode) {
	const factories = this.multi;
	let result;
	if (this.providerFactory) {
		const componentCount = this.providerFactory.componentProviders;
		const multiProviders = getNodeInjectable(lView, lView[1], this.providerFactory.index, tNode);
		result = multiProviders.slice(0, componentCount);
		multiResolve(factories, result);
		for (let i = componentCount; i < multiProviders.length; i++) result.push(multiProviders[i]);
	} else {
		result = [];
		multiResolve(factories, result);
	}
	return result;
}
function multiResolve(factories, result) {
	for (let i = 0; i < factories.length; i++) {
		const factory = factories[i];
		result.push(factory());
	}
	return result;
}
function multiFactory(factoryFn, index, isViewProvider, isComponent, f, provider) {
	const factory = new NodeInjectorFactory(factoryFn, isViewProvider, ɵɵdirectiveInject, ngDevMode ? providerName(provider) : null);
	factory.multi = [];
	factory.index = index;
	factory.componentProviders = 0;
	multiFactoryAdd(factory, f, isComponent && !isViewProvider);
	return factory;
}
function providerName(provider) {
	if (Array.isArray(provider)) return null;
	if (isTypeProvider(provider)) return provider.name;
	else if (isClassProvider(provider)) {
		if (provider.provide instanceof InjectionToken) return `('${provider.provide.toString()}':${provider.useClass.name})`;
		return provider.useClass.name;
	} else if (provider.provide instanceof InjectionToken) return provider.provide.toString();
	else if (typeof provider.provide === "string") return provider.provide;
	else return null;
}
function ɵɵProvidersFeature(providers, viewProviders) {
	return (definition) => {
		definition.providersResolver = (def, processProvidersFn) => providersResolver(def, processProvidersFn ? processProvidersFn(providers) : providers, false);
		if (viewProviders) definition.viewProvidersResolver = (def, processProvidersFn) => providersResolver(def, processProvidersFn ? processProvidersFn(viewProviders) : viewProviders, true);
	};
}
function ɵɵExternalStylesFeature(styleUrls) {
	return (definition) => {
		if (styleUrls.length < 1) return;
		definition.getExternalStyles = (encapsulationId) => {
			return styleUrls.map((value) => value + "?ngcomp" + (encapsulationId ? "=" + encodeURIComponent(encapsulationId) : "") + "&e=" + definition.encapsulation);
		};
	};
}
function ɵɵsetComponentScope(type, directives, pipes) {
	const def = type.ɵcmp;
	def.directiveDefs = extractDefListOrFactory(directives, extractDirectiveDef);
	def.pipeDefs = extractDefListOrFactory(pipes, getPipeDef$1);
}
function ɵɵsetNgModuleScope(type, scope) {
	return noSideEffects(() => {
		const ngModuleDef = getNgModuleDefOrThrow(type);
		ngModuleDef.declarations = convertToTypeArray(scope.declarations || EMPTY_ARRAY);
		ngModuleDef.imports = convertToTypeArray(scope.imports || EMPTY_ARRAY);
		ngModuleDef.exports = convertToTypeArray(scope.exports || EMPTY_ARRAY);
		if (scope.bootstrap) ngModuleDef.bootstrap = convertToTypeArray(scope.bootstrap);
		depsTracker.registerNgModule(type, scope);
	});
}
function convertToTypeArray(values) {
	if (typeof values === "function") return values;
	const flattenValues = flatten(values);
	if (flattenValues.some(isForwardRef)) return () => flattenValues.map(resolveForwardRef).map(maybeUnwrapModuleWithProviders);
	else return flattenValues.map(maybeUnwrapModuleWithProviders);
}
function maybeUnwrapModuleWithProviders(value) {
	return isModuleWithProviders(value) ? value.ngModule : value;
}
var _dehydratedBlockRegistryFactory = () => null;
var isIncrementalHydrationRuntimeActive = false;
new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "INCREMENTAL_HYDRATION_BOOTSTRAP" : "");
function createDehydratedBlockRegistry() {
	return _dehydratedBlockRegistryFactory();
}
function ɵɵenableIncrementalHydrationRuntime() {
	if (!isIncrementalHydrationRuntimeActive) {
		isIncrementalHydrationRuntimeActive = true;
		performanceMarkFeature("NgIncrementalHydration");
		_dehydratedBlockRegistryFactory = () => new DehydratedBlockRegistry();
	}
}
function resetIncrementalHydrationRuntimeForTests() {
	isIncrementalHydrationRuntimeActive = false;
	_dehydratedBlockRegistryFactory = () => null;
}
function ɵɵpureFunction0(slotOffset, pureFn) {
	const bindingIndex = getBindingRoot() + slotOffset;
	const lView = getLView();
	return lView[bindingIndex] === NO_CHANGE ? updateBinding(lView, bindingIndex, pureFn()) : getBinding(lView, bindingIndex);
}
function ɵɵpureFunction1(slotOffset, pureFn, exp) {
	return pureFunction1Internal(getLView(), getBindingRoot(), slotOffset, pureFn, exp);
}
function ɵɵpureFunction2(slotOffset, pureFn, exp1, exp2) {
	return pureFunction2Internal(getLView(), getBindingRoot(), slotOffset, pureFn, exp1, exp2);
}
function ɵɵpureFunction3(slotOffset, pureFn, exp1, exp2, exp3) {
	return pureFunction3Internal(getLView(), getBindingRoot(), slotOffset, pureFn, exp1, exp2, exp3);
}
function ɵɵpureFunction4(slotOffset, pureFn, exp1, exp2, exp3, exp4, thisArg) {
	return pureFunction4Internal(getLView(), getBindingRoot(), slotOffset, pureFn, exp1, exp2, exp3, exp4);
}
function ɵɵpureFunction5(slotOffset, pureFn, exp1, exp2, exp3, exp4, exp5) {
	const bindingIndex = getBindingRoot() + slotOffset;
	const lView = getLView();
	const different = bindingUpdated4(lView, bindingIndex, exp1, exp2, exp3, exp4);
	return bindingUpdated(lView, bindingIndex + 4, exp5) || different ? updateBinding(lView, bindingIndex + 5, pureFn(exp1, exp2, exp3, exp4, exp5)) : getBinding(lView, bindingIndex + 5);
}
function ɵɵpureFunction6(slotOffset, pureFn, exp1, exp2, exp3, exp4, exp5, exp6) {
	const bindingIndex = getBindingRoot() + slotOffset;
	const lView = getLView();
	const different = bindingUpdated4(lView, bindingIndex, exp1, exp2, exp3, exp4);
	return bindingUpdated2(lView, bindingIndex + 4, exp5, exp6) || different ? updateBinding(lView, bindingIndex + 6, pureFn(exp1, exp2, exp3, exp4, exp5, exp6)) : getBinding(lView, bindingIndex + 6);
}
function ɵɵpureFunction7(slotOffset, pureFn, exp1, exp2, exp3, exp4, exp5, exp6, exp7) {
	const bindingIndex = getBindingRoot() + slotOffset;
	const lView = getLView();
	let different = bindingUpdated4(lView, bindingIndex, exp1, exp2, exp3, exp4);
	return bindingUpdated3(lView, bindingIndex + 4, exp5, exp6, exp7) || different ? updateBinding(lView, bindingIndex + 7, pureFn(exp1, exp2, exp3, exp4, exp5, exp6, exp7)) : getBinding(lView, bindingIndex + 7);
}
function ɵɵpureFunction8(slotOffset, pureFn, exp1, exp2, exp3, exp4, exp5, exp6, exp7, exp8) {
	const bindingIndex = getBindingRoot() + slotOffset;
	const lView = getLView();
	const different = bindingUpdated4(lView, bindingIndex, exp1, exp2, exp3, exp4);
	return bindingUpdated4(lView, bindingIndex + 4, exp5, exp6, exp7, exp8) || different ? updateBinding(lView, bindingIndex + 8, pureFn(exp1, exp2, exp3, exp4, exp5, exp6, exp7, exp8)) : getBinding(lView, bindingIndex + 8);
}
function ɵɵpureFunctionV(slotOffset, pureFn, exps) {
	return pureFunctionVInternal(getLView(), getBindingRoot(), slotOffset, pureFn, exps);
}
function getPureFunctionReturnValue(lView, returnValueIndex) {
	ngDevMode && assertIndexInRange(lView, returnValueIndex);
	const lastReturnValue = lView[returnValueIndex];
	return lastReturnValue === NO_CHANGE ? void 0 : lastReturnValue;
}
function pureFunction1Internal(lView, bindingRoot, slotOffset, pureFn, exp, thisArg) {
	const bindingIndex = bindingRoot + slotOffset;
	return bindingUpdated(lView, bindingIndex, exp) ? updateBinding(lView, bindingIndex + 1, thisArg ? pureFn.call(thisArg, exp) : pureFn(exp)) : getPureFunctionReturnValue(lView, bindingIndex + 1);
}
function pureFunction2Internal(lView, bindingRoot, slotOffset, pureFn, exp1, exp2, thisArg) {
	const bindingIndex = bindingRoot + slotOffset;
	return bindingUpdated2(lView, bindingIndex, exp1, exp2) ? updateBinding(lView, bindingIndex + 2, thisArg ? pureFn.call(thisArg, exp1, exp2) : pureFn(exp1, exp2)) : getPureFunctionReturnValue(lView, bindingIndex + 2);
}
function pureFunction3Internal(lView, bindingRoot, slotOffset, pureFn, exp1, exp2, exp3, thisArg) {
	const bindingIndex = bindingRoot + slotOffset;
	return bindingUpdated3(lView, bindingIndex, exp1, exp2, exp3) ? updateBinding(lView, bindingIndex + 3, thisArg ? pureFn.call(thisArg, exp1, exp2, exp3) : pureFn(exp1, exp2, exp3)) : getPureFunctionReturnValue(lView, bindingIndex + 3);
}
function pureFunction4Internal(lView, bindingRoot, slotOffset, pureFn, exp1, exp2, exp3, exp4, thisArg) {
	const bindingIndex = bindingRoot + slotOffset;
	return bindingUpdated4(lView, bindingIndex, exp1, exp2, exp3, exp4) ? updateBinding(lView, bindingIndex + 4, thisArg ? pureFn.call(thisArg, exp1, exp2, exp3, exp4) : pureFn(exp1, exp2, exp3, exp4)) : getPureFunctionReturnValue(lView, bindingIndex + 4);
}
function pureFunctionVInternal(lView, bindingRoot, slotOffset, pureFn, exps, thisArg) {
	let bindingIndex = bindingRoot + slotOffset;
	let different = false;
	for (let i = 0; i < exps.length; i++) bindingUpdated(lView, bindingIndex++, exps[i]) && (different = true);
	return different ? updateBinding(lView, bindingIndex, pureFn.apply(thisArg, exps)) : getPureFunctionReturnValue(lView, bindingIndex);
}
function ɵɵpipe(index, pipeName) {
	const tView = getTView();
	let pipeDef;
	const adjustedIndex = index + 28;
	if (tView.firstCreatePass) {
		pipeDef = getPipeDef(pipeName, tView.pipeRegistry);
		tView.data[adjustedIndex] = pipeDef;
		if (pipeDef.onDestroy) (tView.destroyHooks ??= []).push(adjustedIndex, pipeDef.onDestroy);
	} else pipeDef = tView.data[adjustedIndex];
	const pipeFactory = pipeDef.factory || (pipeDef.factory = getFactoryDef(pipeDef.type, true));
	let previousInjectorProfilerContext;
	if (ngDevMode) previousInjectorProfilerContext = setInjectorProfilerContext({
		injector: new NodeInjector(getCurrentTNode(), getLView()),
		token: pipeDef.type
	});
	const previousInjectImplementation = setInjectImplementation(ɵɵdirectiveInject);
	try {
		const previousIncludeViewProviders = setIncludeViewProviders(false);
		const pipeInstance = pipeFactory();
		setIncludeViewProviders(previousIncludeViewProviders);
		store(tView, getLView(), adjustedIndex, pipeInstance);
		return pipeInstance;
	} finally {
		setInjectImplementation(previousInjectImplementation);
		ngDevMode && setInjectorProfilerContext(previousInjectorProfilerContext);
	}
}
function getPipeDef(name, registry) {
	if (registry) {
		if (ngDevMode) {
			if (registry.filter((pipe) => pipe.name === name).length > 1) console.warn(formatRuntimeError(313, getMultipleMatchingPipesMessage(name)));
		}
		for (let i = registry.length - 1; i >= 0; i--) {
			const pipeDef = registry[i];
			if (name === pipeDef.name) return pipeDef;
		}
	}
	if (ngDevMode) throw new RuntimeError(-302, getPipeNotFoundErrorMessage(name));
}
function getMultipleMatchingPipesMessage(name) {
	const lView = getLView();
	const context = lView[15][8];
	const hostIsStandalone = isHostComponentStandalone(lView);
	return `Multiple pipes match the name \`${name}\`${context ? ` in the '${context.constructor.name}' component` : ""}. ${`check ${hostIsStandalone ? "'@Component.imports' of this component" : "the imports of this module"}`}`;
}
function getPipeNotFoundErrorMessage(name) {
	const lView = getLView();
	const context = lView[15][8];
	const hostIsStandalone = isHostComponentStandalone(lView);
	return `The pipe '${name}' could not be found${context ? ` in the '${context.constructor.name}' component` : ""}. ${`Verify that it is ${hostIsStandalone ? "included in the '@Component.imports' of this component" : "declared or imported in this module"}`}`;
}
function ɵɵpipeBind1(index, offset, v1) {
	const adjustedIndex = index + 28;
	const lView = getLView();
	const pipeInstance = load(lView, adjustedIndex);
	return isPure(lView, adjustedIndex) ? pureFunction1Internal(lView, getBindingRoot(), offset, pipeInstance.transform, v1, pipeInstance) : pipeInstance.transform(v1);
}
function ɵɵpipeBind2(index, slotOffset, v1, v2) {
	const adjustedIndex = index + 28;
	const lView = getLView();
	const pipeInstance = load(lView, adjustedIndex);
	return isPure(lView, adjustedIndex) ? pureFunction2Internal(lView, getBindingRoot(), slotOffset, pipeInstance.transform, v1, v2, pipeInstance) : pipeInstance.transform(v1, v2);
}
function ɵɵpipeBind3(index, slotOffset, v1, v2, v3) {
	const adjustedIndex = index + 28;
	const lView = getLView();
	const pipeInstance = load(lView, adjustedIndex);
	return isPure(lView, adjustedIndex) ? pureFunction3Internal(lView, getBindingRoot(), slotOffset, pipeInstance.transform, v1, v2, v3, pipeInstance) : pipeInstance.transform(v1, v2, v3);
}
function ɵɵpipeBind4(index, slotOffset, v1, v2, v3, v4) {
	const adjustedIndex = index + 28;
	const lView = getLView();
	const pipeInstance = load(lView, adjustedIndex);
	return isPure(lView, adjustedIndex) ? pureFunction4Internal(lView, getBindingRoot(), slotOffset, pipeInstance.transform, v1, v2, v3, v4, pipeInstance) : pipeInstance.transform(v1, v2, v3, v4);
}
function ɵɵpipeBindV(index, slotOffset, values) {
	const adjustedIndex = index + 28;
	const lView = getLView();
	const pipeInstance = load(lView, adjustedIndex);
	return isPure(lView, adjustedIndex) ? pureFunctionVInternal(lView, getBindingRoot(), slotOffset, pipeInstance.transform, values, pipeInstance) : pipeInstance.transform.apply(pipeInstance, values);
}
function isPure(lView, index) {
	return lView[1].data[index].pure;
}
function ɵɵtemplateRefExtractor(tNode, lView) {
	return createTemplateRef(tNode, lView);
}
function ɵɵgetComponentDepsFactory(type, rawImports) {
	return () => {
		try {
			return depsTracker.getComponentDependencies(type, rawImports).dependencies;
		} catch (e) {
			console.error(`Computing dependencies in local compilation mode for the component "${type.name}" failed with the exception:`, e);
			throw e;
		}
	};
}
function ɵsetClassDebugInfo(type, debugInfo) {
	const def = getComponentDef(type);
	if (def !== null) def.debugInfo = debugInfo;
}
function ɵɵgetReplaceMetadataURL(id, timestamp, base) {
	const url = `./@ng/component?c=${id}&t=${encodeURIComponent(timestamp)}`;
	return new URL(url, base).href;
}
function ɵɵreplaceMetadata(type, applyMetadata, namespaces, locals, importMeta = null, id = null) {
	ngDevMode && assertComponentDef(type);
	const currentDef = getComponentDef(type);
	applyMetadata.apply(null, [
		type,
		namespaces,
		...locals
	]);
	const { newDef, oldDef } = mergeWithExistingDefinition(currentDef, getComponentDef(type));
	type[NG_COMP_DEF] = newDef;
	if (oldDef.tView) {
		const trackedViews = getTrackedLViews().values();
		for (const root of trackedViews) if (isRootView(root) && root[3] === null) recreateMatchingLViews(importMeta, id, newDef, oldDef, root);
	}
}
function mergeWithExistingDefinition(currentDef, newDef) {
	const clone = { ...currentDef };
	const replacement = Object.assign(currentDef, newDef, {
		directiveDefs: clone.directiveDefs,
		pipeDefs: clone.pipeDefs,
		setInput: clone.setInput,
		type: clone.type
	});
	ngDevMode && assertEqual(replacement, currentDef, "Expected definition to be merged in place");
	return {
		newDef: replacement,
		oldDef: clone
	};
}
function recreateMatchingLViews(importMeta, id, newDef, oldDef, rootLView) {
	ngDevMode && assertDefined(oldDef.tView, "Expected a component definition that has been instantiated at least once");
	const tView = rootLView[1];
	if (tView === oldDef.tView) {
		ngDevMode && assertComponentDef(oldDef.type);
		recreateLView(importMeta, id, newDef, oldDef, rootLView);
		return;
	}
	for (let i = 28; i < tView.bindingStartIndex; i++) {
		const current = rootLView[i];
		if (isLContainer(current)) {
			if (isLView(current[0])) recreateMatchingLViews(importMeta, id, newDef, oldDef, current[0]);
			for (let j = 10; j < current.length; j++) recreateMatchingLViews(importMeta, id, newDef, oldDef, current[j]);
		} else if (isLView(current)) recreateMatchingLViews(importMeta, id, newDef, oldDef, current);
	}
}
function clearRendererCache(factory, def) {
	factory.componentReplaced?.(def.id);
}
function recreateLView(importMeta, id, newDef, oldDef, lView) {
	const instance = lView[8];
	let host = lView[0];
	const parentLView = lView[3];
	ngDevMode && assertLView(parentLView);
	const tNode = lView[5];
	ngDevMode && assertTNodeType(tNode, 2);
	ngDevMode && assertNotEqual(newDef, oldDef, "Expected different component definition");
	const zone = lView[9].get(NgZone, null);
	const recreate = () => {
		if (oldDef.encapsulation === ViewEncapsulation$1.ShadowDom || oldDef.encapsulation === ViewEncapsulation$1.ExperimentalIsolatedShadowDom) {
			const newHost = host.cloneNode(false);
			host.replaceWith(newHost);
			host = newHost;
		}
		const newTView = getOrCreateComponentTView(newDef);
		const newLView = createLView(parentLView, newTView, instance, getInitialLViewFlagsFromDef(newDef), host, tNode, null, null, null, null, null);
		replaceLViewInTree(parentLView, lView, newLView, tNode.index);
		destroyLView(lView[1], lView);
		cleanupLView(lView);
		const rendererFactory = lView[10].rendererFactory;
		clearRendererCache(rendererFactory, oldDef);
		newLView[11] = rendererFactory.createRenderer(host, newDef);
		removeViewFromDOM(lView[1], lView);
		resetProjectionState(tNode);
		renderView(newTView, newLView, instance);
		newLView[2] &= -1025;
		refreshView(newTView, newLView, newTView.template, instance);
	};
	if (zone === null) executeWithInvalidateFallback(importMeta, id, recreate);
	else zone.run(() => executeWithInvalidateFallback(importMeta, id, recreate));
}
function executeWithInvalidateFallback(importMeta, id, callback) {
	try {
		callback();
	} catch (e) {
		const error = e;
		if (id !== null && error.message) {
			const toLog = error.message + (error.stack ? "\n" + error.stack : "");
			importMeta?.hot?.send?.("angular:invalidate", {
				id,
				message: toLog,
				error: true
			});
		}
		throw e;
	}
}
function replaceLViewInTree(parentLView, oldLView, newLView, index) {
	for (let i = 28; i < parentLView[1].bindingStartIndex; i++) {
		const current = parentLView[i];
		if ((isLView(current) || isLContainer(current)) && current[4] === oldLView) {
			current[4] = newLView;
			break;
		}
	}
	if (parentLView[12] === oldLView) parentLView[12] = newLView;
	if (parentLView[13] === oldLView) parentLView[13] = newLView;
	newLView[4] = oldLView[4];
	oldLView[4] = null;
	parentLView[index] = newLView;
}
function resetProjectionState(tNode) {
	if (tNode.projection !== null) {
		for (const current of tNode.projection) if (isTNodeShape(current)) {
			current.projectionNext = null;
			current.flags &= -3;
		}
		tNode.projection = null;
	}
}
var angularCoreEnv = (() => ({
	"ɵɵanimateEnter": ɵɵanimateEnter,
	"ɵɵanimateEnterListener": ɵɵanimateEnterListener,
	"ɵɵanimateLeave": ɵɵanimateLeave,
	"ɵɵanimateLeaveListener": ɵɵanimateLeaveListener,
	"ɵɵattribute": ɵɵattribute,
	"ɵɵdefineComponent": ɵɵdefineComponent,
	"ɵɵdefineDirective": ɵɵdefineDirective,
	"ɵɵdefineInjectable": ɵɵdefineInjectable,
	"ɵɵdefineInjector": ɵɵdefineInjector,
	"ɵɵdefineNgModule": ɵɵdefineNgModule,
	"ɵɵdefineService": ɵɵdefineService,
	"ɵɵdefinePipe": ɵɵdefinePipe,
	"ɵɵdirectiveInject": ɵɵdirectiveInject,
	"ɵɵgetInheritedFactory": ɵɵgetInheritedFactory,
	"ɵɵinject": ɵɵinject,
	"ɵɵinjectAttribute": ɵɵinjectAttribute,
	"ɵɵinvalidFactory": ɵɵinvalidFactory,
	"ɵɵinvalidFactoryDep": ɵɵinvalidFactoryDep,
	"ɵɵtemplateRefExtractor": ɵɵtemplateRefExtractor,
	"ɵɵresetView": ɵɵresetView,
	"ɵɵHostDirectivesFeature": ɵɵHostDirectivesFeature,
	"ɵɵNgOnChangesFeature": ɵɵNgOnChangesFeature,
	"ɵɵControlFeature": ɵɵControlFeature,
	"ɵɵProvidersFeature": ɵɵProvidersFeature,
	"ɵɵInheritDefinitionFeature": ɵɵInheritDefinitionFeature,
	"ɵɵExternalStylesFeature": ɵɵExternalStylesFeature,
	"ɵɵnextContext": ɵɵnextContext,
	"ɵɵnamespaceHTML": ɵɵnamespaceHTML,
	"ɵɵnamespaceMathML": ɵɵnamespaceMathML,
	"ɵɵnamespaceSVG": ɵɵnamespaceSVG,
	"ɵɵenableBindings": ɵɵenableBindings,
	"ɵɵdisableBindings": ɵɵdisableBindings,
	"ɵɵelementStart": ɵɵelementStart,
	"ɵɵelementEnd": ɵɵelementEnd,
	"ɵɵelement": ɵɵelement,
	"ɵɵforeignComponent": ɵɵforeignComponent,
	"ɵɵforeignContent": ɵɵforeignContent,
	"ɵɵforeignContentFn": ɵɵforeignContentFn,
	"ɵɵelementContainerStart": ɵɵelementContainerStart,
	"ɵɵelementContainerEnd": ɵɵelementContainerEnd,
	"ɵɵdomElement": ɵɵdomElement,
	"ɵɵdomElementStart": ɵɵdomElementStart,
	"ɵɵdomElementEnd": ɵɵdomElementEnd,
	"ɵɵdomElementContainer": ɵɵdomElementContainer,
	"ɵɵdomElementContainerStart": ɵɵdomElementContainerStart,
	"ɵɵdomElementContainerEnd": ɵɵdomElementContainerEnd,
	"ɵɵdomTemplate": ɵɵdomTemplate,
	"ɵɵdomListener": ɵɵdomListener,
	"ɵɵelementContainer": ɵɵelementContainer,
	"ɵɵpureFunction0": ɵɵpureFunction0,
	"ɵɵpureFunction1": ɵɵpureFunction1,
	"ɵɵpureFunction2": ɵɵpureFunction2,
	"ɵɵpureFunction3": ɵɵpureFunction3,
	"ɵɵpureFunction4": ɵɵpureFunction4,
	"ɵɵpureFunction5": ɵɵpureFunction5,
	"ɵɵpureFunction6": ɵɵpureFunction6,
	"ɵɵpureFunction7": ɵɵpureFunction7,
	"ɵɵpureFunction8": ɵɵpureFunction8,
	"ɵɵpureFunctionV": ɵɵpureFunctionV,
	"ɵɵgetCurrentView": ɵɵgetCurrentView,
	"ɵɵrestoreView": ɵɵrestoreView,
	"ɵɵlistener": ɵɵlistener,
	"ɵɵprojection": ɵɵprojection,
	"ɵɵsyntheticHostProperty": ɵɵsyntheticHostProperty,
	"ɵɵsyntheticHostListener": ɵɵsyntheticHostListener,
	"ɵɵpipeBind1": ɵɵpipeBind1,
	"ɵɵpipeBind2": ɵɵpipeBind2,
	"ɵɵpipeBind3": ɵɵpipeBind3,
	"ɵɵpipeBind4": ɵɵpipeBind4,
	"ɵɵpipeBindV": ɵɵpipeBindV,
	"ɵɵprojectionDef": ɵɵprojectionDef,
	"ɵɵdomProperty": ɵɵdomProperty,
	"ɵɵariaProperty": ɵɵariaProperty,
	"ɵɵproperty": ɵɵproperty,
	"ɵɵcontrol": ɵɵcontrol,
	"ɵɵcontrolCreate": ɵɵcontrolCreate,
	"ɵɵpipe": ɵɵpipe,
	"ɵɵqueryRefresh": ɵɵqueryRefresh,
	"ɵɵqueryAdvance": ɵɵqueryAdvance,
	"ɵɵviewQuery": ɵɵviewQuery,
	"ɵɵviewQuerySignal": ɵɵviewQuerySignal,
	"ɵɵloadQuery": ɵɵloadQuery,
	"ɵɵcontentQuery": ɵɵcontentQuery,
	"ɵɵcontentQuerySignal": ɵɵcontentQuerySignal,
	"ɵɵreference": ɵɵreference,
	"ɵɵclassMap": ɵɵclassMap,
	"ɵɵstyleMap": ɵɵstyleMap,
	"ɵɵstyleProp": ɵɵstyleProp,
	"ɵɵclassProp": ɵɵclassProp,
	"ɵɵadvance": ɵɵadvance,
	"ɵɵtemplate": ɵɵtemplate,
	"ɵɵconditional": ɵɵconditional,
	"ɵɵconditionalCreate": ɵɵconditionalCreate,
	"ɵɵconditionalBranchCreate": ɵɵconditionalBranchCreate,
	"ɵɵboundaryCreate": ɵɵboundaryCreate,
	"ɵɵboundaryUpdate": ɵɵboundaryUpdate,
	"ɵɵgetBoundary": ɵɵgetBoundary,
	"ɵɵdefer": ɵɵdefer,
	"ɵɵdeferWhen": ɵɵdeferWhen,
	"ɵɵdeferOnIdle": ɵɵdeferOnIdle,
	"ɵɵdeferOnImmediate": ɵɵdeferOnImmediate,
	"ɵɵdeferOnTimer": ɵɵdeferOnTimer,
	"ɵɵdeferOnHover": ɵɵdeferOnHover,
	"ɵɵdeferOnInteraction": ɵɵdeferOnInteraction,
	"ɵɵdeferOnViewport": ɵɵdeferOnViewport,
	"ɵɵdeferPrefetchWhen": ɵɵdeferPrefetchWhen,
	"ɵɵdeferPrefetchOnIdle": ɵɵdeferPrefetchOnIdle,
	"ɵɵdeferPrefetchOnImmediate": ɵɵdeferPrefetchOnImmediate,
	"ɵɵdeferPrefetchOnTimer": ɵɵdeferPrefetchOnTimer,
	"ɵɵdeferPrefetchOnHover": ɵɵdeferPrefetchOnHover,
	"ɵɵdeferPrefetchOnInteraction": ɵɵdeferPrefetchOnInteraction,
	"ɵɵdeferPrefetchOnViewport": ɵɵdeferPrefetchOnViewport,
	"ɵɵdeferHydrateWhen": ɵɵdeferHydrateWhen,
	"ɵɵdeferHydrateNever": ɵɵdeferHydrateNever,
	"ɵɵdeferHydrateOnIdle": ɵɵdeferHydrateOnIdle,
	"ɵɵdeferHydrateOnImmediate": ɵɵdeferHydrateOnImmediate,
	"ɵɵdeferHydrateOnTimer": ɵɵdeferHydrateOnTimer,
	"ɵɵdeferHydrateOnHover": ɵɵdeferHydrateOnHover,
	"ɵɵdeferHydrateOnInteraction": ɵɵdeferHydrateOnInteraction,
	"ɵɵdeferHydrateOnViewport": ɵɵdeferHydrateOnViewport,
	"ɵɵdeferEnableTimerScheduling": ɵɵdeferEnableTimerScheduling,
	"ɵɵenableIncrementalHydrationRuntime": ɵɵenableIncrementalHydrationRuntime,
	"ɵɵrepeater": ɵɵrepeater,
	"ɵɵrepeaterCreate": ɵɵrepeaterCreate,
	"ɵɵrepeaterTrackByIndex": ɵɵrepeaterTrackByIndex,
	"ɵɵrepeaterTrackByIdentity": ɵɵrepeaterTrackByIdentity,
	"ɵɵcomponentInstance": ɵɵcomponentInstance,
	"ɵɵtext": ɵɵtext,
	"ɵɵtextInterpolate": ɵɵtextInterpolate,
	"ɵɵtextInterpolate1": ɵɵtextInterpolate1,
	"ɵɵtextInterpolate2": ɵɵtextInterpolate2,
	"ɵɵtextInterpolate3": ɵɵtextInterpolate3,
	"ɵɵtextInterpolate4": ɵɵtextInterpolate4,
	"ɵɵtextInterpolate5": ɵɵtextInterpolate5,
	"ɵɵtextInterpolate6": ɵɵtextInterpolate6,
	"ɵɵtextInterpolate7": ɵɵtextInterpolate7,
	"ɵɵtextInterpolate8": ɵɵtextInterpolate8,
	"ɵɵtextInterpolateV": ɵɵtextInterpolateV,
	"ɵɵi18n": ɵɵi18n,
	"ɵɵi18nAttributes": ɵɵi18nAttributes,
	"ɵɵi18nExp": ɵɵi18nExp,
	"ɵɵi18nStart": ɵɵi18nStart,
	"ɵɵi18nEnd": ɵɵi18nEnd,
	"ɵɵi18nApply": ɵɵi18nApply,
	"ɵɵi18nPostprocess": ɵɵi18nPostprocess,
	"ɵɵresolveWindow": ɵɵresolveWindow,
	"ɵɵresolveDocument": ɵɵresolveDocument,
	"ɵɵresolveBody": ɵɵresolveBody,
	"ɵɵsetComponentScope": ɵɵsetComponentScope,
	"ɵɵsetNgModuleScope": ɵɵsetNgModuleScope,
	"ɵɵregisterNgModuleType": registerNgModuleType,
	"ɵɵgetComponentDepsFactory": ɵɵgetComponentDepsFactory,
	"ɵsetClassDebugInfo": ɵsetClassDebugInfo,
	"ɵɵdeclareLet": ɵɵdeclareLet,
	"ɵɵstoreLet": ɵɵstoreLet,
	"ɵɵarrowFunction": ɵɵarrowFunction,
	"ɵɵreadContextLet": ɵɵreadContextLet,
	"ɵɵattachSourceLocations": ɵɵattachSourceLocations,
	"ɵɵinterpolate": ɵɵinterpolate,
	"ɵɵinterpolate1": ɵɵinterpolate1,
	"ɵɵinterpolate2": ɵɵinterpolate2,
	"ɵɵinterpolate3": ɵɵinterpolate3,
	"ɵɵinterpolate4": ɵɵinterpolate4,
	"ɵɵinterpolate5": ɵɵinterpolate5,
	"ɵɵinterpolate6": ɵɵinterpolate6,
	"ɵɵinterpolate7": ɵɵinterpolate7,
	"ɵɵinterpolate8": ɵɵinterpolate8,
	"ɵɵinterpolateV": ɵɵinterpolateV,
	"ɵɵsanitizeHtml": ɵɵsanitizeHtml,
	"ɵɵsanitizeStyle": ɵɵsanitizeStyle,
	"ɵɵsanitizeResourceUrl": ɵɵsanitizeResourceUrl,
	"ɵɵsanitizeScript": ɵɵsanitizeScript,
	"ɵɵvalidateAttribute": ɵɵvalidateAttribute,
	"ɵɵsanitizeUrl": ɵɵsanitizeUrl,
	"ɵɵsanitizeUrlOrResourceUrl": ɵɵsanitizeUrlOrResourceUrl,
	"ɵɵtrustConstantHtml": ɵɵtrustConstantHtml,
	"ɵɵtrustConstantResourceUrl": ɵɵtrustConstantResourceUrl,
	"forwardRef": forwardRef,
	"resolveForwardRef": resolveForwardRef,
	"ɵɵtwoWayProperty": ɵɵtwoWayProperty,
	"ɵɵtwoWayBindingSet": ɵɵtwoWayBindingSet,
	"ɵɵtwoWayListener": ɵɵtwoWayListener,
	"ɵɵreplaceMetadata": ɵɵreplaceMetadata,
	"ɵɵgetReplaceMetadataURL": ɵɵgetReplaceMetadataURL
}))();
var jitOptions = null;
function getJitOptions() {
	return jitOptions;
}
function resetJitOptions() {
	jitOptions = null;
}
var moduleQueue = [];
function enqueueModuleForDelayedScoping(moduleType, ngModule) {
	moduleQueue.push({
		moduleType,
		ngModule
	});
}
var flushingModuleQueue = false;
function flushModuleScopingQueueAsMuchAsPossible() {
	if (!flushingModuleQueue) {
		flushingModuleQueue = true;
		try {
			for (let i = moduleQueue.length - 1; i >= 0; i--) {
				const { moduleType, ngModule } = moduleQueue[i];
				if (ngModule.declarations && ngModule.declarations.every(isResolvedDeclaration)) {
					moduleQueue.splice(i, 1);
					setScopeOnDeclaredComponents(moduleType, ngModule);
				}
			}
		} finally {
			flushingModuleQueue = false;
		}
	}
}
function isResolvedDeclaration(declaration) {
	if (Array.isArray(declaration)) return declaration.every(isResolvedDeclaration);
	return !!resolveForwardRef(declaration);
}
function compileNgModule(moduleType, ngModule = {}) {
	compileNgModuleDefs(moduleType, ngModule);
	if (ngModule.id !== void 0) registerNgModuleType(moduleType, ngModule.id);
	enqueueModuleForDelayedScoping(moduleType, ngModule);
}
function compileNgModuleDefs(moduleType, ngModule, allowDuplicateDeclarationsInRoot = false) {
	ngDevMode && assertDefined(moduleType, "Required value moduleType");
	ngDevMode && assertDefined(ngModule, "Required value ngModule");
	const declarations = flatten(ngModule.declarations || EMPTY_ARRAY);
	let ngModuleDef = null;
	Object.defineProperty(moduleType, NG_MOD_DEF, {
		configurable: true,
		get: () => {
			if (ngModuleDef === null) {
				if (ngDevMode && ngModule.imports && ngModule.imports.indexOf(moduleType) > -1) throw new Error(`'${stringifyForError(moduleType)}' module can't import itself`);
				ngModuleDef = getCompilerFacade({
					usage: 0,
					kind: "NgModule",
					type: moduleType
				}).compileNgModule(angularCoreEnv, `ng:///${moduleType.name}/ɵmod.js`, {
					type: moduleType,
					bootstrap: flatten(ngModule.bootstrap || EMPTY_ARRAY).map(resolveForwardRef),
					declarations: declarations.map(resolveForwardRef),
					imports: flatten(ngModule.imports || EMPTY_ARRAY).map(resolveForwardRef).map(expandModuleWithProviders),
					exports: flatten(ngModule.exports || EMPTY_ARRAY).map(resolveForwardRef).map(expandModuleWithProviders),
					schemas: ngModule.schemas ? flatten(ngModule.schemas) : null,
					id: ngModule.id || null
				});
				if (!ngModuleDef.schemas) ngModuleDef.schemas = [];
			}
			return ngModuleDef;
		}
	});
	let ngFactoryDef = null;
	Object.defineProperty(moduleType, NG_FACTORY_DEF, {
		get: () => {
			if (ngFactoryDef === null) {
				const compiler = getCompilerFacade({
					usage: 0,
					kind: "NgModule",
					type: moduleType
				});
				ngFactoryDef = compiler.compileFactory(angularCoreEnv, `ng:///${moduleType.name}/ɵfac.js`, {
					name: moduleType.name,
					type: moduleType,
					deps: reflectDependencies(moduleType),
					target: compiler.FactoryTarget.NgModule,
					typeArgumentCount: 0
				});
			}
			return ngFactoryDef;
		},
		configurable: !!ngDevMode
	});
	let ngInjectorDef = null;
	Object.defineProperty(moduleType, NG_INJ_DEF, {
		get: () => {
			if (ngInjectorDef === null) {
				ngDevMode && verifySemanticsOfNgModuleDef(moduleType, allowDuplicateDeclarationsInRoot);
				const meta = {
					name: moduleType.name,
					type: moduleType,
					providers: ngModule.providers || EMPTY_ARRAY,
					imports: [(ngModule.imports || EMPTY_ARRAY).map(resolveForwardRef), (ngModule.exports || EMPTY_ARRAY).map(resolveForwardRef)]
				};
				ngInjectorDef = getCompilerFacade({
					usage: 0,
					kind: "NgModule",
					type: moduleType
				}).compileInjector(angularCoreEnv, `ng:///${moduleType.name}/ɵinj.js`, meta);
			}
			return ngInjectorDef;
		},
		configurable: !!ngDevMode
	});
}
function generateStandaloneInDeclarationsError(type, location) {
	return `${`Unexpected "${stringifyForError(type)}" found in the "declarations" array of the`} ${location}, ${`"${stringifyForError(type)}" is marked as standalone and can't be declared in any NgModule - did you intend to import it instead (by adding it to the "imports" array)?`}`;
}
function verifySemanticsOfNgModuleDef(moduleType, allowDuplicateDeclarationsInRoot, importingModule) {
	if (verifiedNgModule.get(moduleType)) return;
	if (isStandalone(moduleType)) return;
	verifiedNgModule.set(moduleType, true);
	moduleType = resolveForwardRef(moduleType);
	let ngModuleDef;
	if (importingModule) {
		ngModuleDef = getNgModuleDef(moduleType);
		if (!ngModuleDef) throw new Error(`Unexpected value '${moduleType.name}' imported by the module '${importingModule.name}'. Please add an @NgModule annotation.`);
	} else ngModuleDef = getNgModuleDefOrThrow(moduleType);
	const errors = [];
	const declarations = maybeUnwrapFn(ngModuleDef.declarations);
	const imports = maybeUnwrapFn(ngModuleDef.imports);
	flatten(imports).map(unwrapModuleWithProvidersImports).forEach((modOrStandaloneCmpt) => {
		verifySemanticsOfNgModuleImport(modOrStandaloneCmpt, moduleType);
		verifySemanticsOfNgModuleDef(modOrStandaloneCmpt, false, moduleType);
	});
	const exports = maybeUnwrapFn(ngModuleDef.exports);
	declarations.forEach(verifyDeclarationsHaveDefinitions);
	declarations.forEach(verifyDirectivesHaveSelector);
	declarations.forEach((declarationType) => verifyNotStandalone(declarationType, moduleType));
	const combinedDeclarations = [...declarations.map(resolveForwardRef), ...flatten(imports.map(computeCombinedExports)).map(resolveForwardRef)];
	exports.forEach(verifyExportsAreDeclaredOrReExported);
	declarations.forEach((decl) => verifyDeclarationIsUnique(decl, allowDuplicateDeclarationsInRoot));
	const ngModule = getAnnotation(moduleType, "NgModule");
	if (ngModule) {
		ngModule.imports && flatten(ngModule.imports).map(unwrapModuleWithProvidersImports).forEach((mod) => {
			verifySemanticsOfNgModuleImport(mod, moduleType);
			verifySemanticsOfNgModuleDef(mod, false, moduleType);
		});
		ngModule.bootstrap && deepForEach(ngModule.bootstrap, verifyCorrectBootstrapType);
		ngModule.bootstrap && deepForEach(ngModule.bootstrap, verifyComponentIsPartOfNgModule);
	}
	if (errors.length) throw new Error(errors.join("\n"));
	function verifyDeclarationsHaveDefinitions(type) {
		type = resolveForwardRef(type);
		if (!(getComponentDef(type) || getDirectiveDef(type) || getPipeDef$1(type))) errors.push(`Unexpected value '${stringifyForError(type)}' declared by the module '${stringifyForError(moduleType)}'. Please add a @Pipe/@Directive/@Component annotation.`);
	}
	function verifyDirectivesHaveSelector(type) {
		type = resolveForwardRef(type);
		const def = getDirectiveDef(type);
		if (!getComponentDef(type) && !getPipeDef$1(type) && def && def.selectors.length == 0) errors.push(`Directive ${stringifyForError(type)} has no selector, please add it!`);
	}
	function verifyNotStandalone(type, moduleType) {
		type = resolveForwardRef(type);
		if ((getPipeDef$1(type) || getComponentDef(type) || getDirectiveDef(type))?.standalone) {
			const location = `"${stringifyForError(moduleType)}" NgModule`;
			errors.push(generateStandaloneInDeclarationsError(type, location));
		}
	}
	function verifyExportsAreDeclaredOrReExported(type) {
		type = resolveForwardRef(type);
		const kind = getComponentDef(type) && "component" || getDirectiveDef(type) && "directive" || getPipeDef$1(type) && "pipe";
		if (kind) {
			if (combinedDeclarations.lastIndexOf(type) === -1) errors.push(`Can't export ${kind} ${stringifyForError(type)} from ${stringifyForError(moduleType)} as it was neither declared nor imported!`);
		}
	}
	function verifyDeclarationIsUnique(type, suppressErrors) {
		type = resolveForwardRef(type);
		const existingModule = ownerNgModule.get(type);
		if (existingModule && existingModule !== moduleType) {
			if (!suppressErrors) {
				const modules = [existingModule, moduleType].map(stringifyForError).sort();
				errors.push(`Type ${stringifyForError(type)} is part of the declarations of 2 modules: ${modules[0]} and ${modules[1]}! Please consider moving ${stringifyForError(type)} to a higher module that imports ${modules[0]} and ${modules[1]}. You can also create a new NgModule that exports and includes ${stringifyForError(type)} then import that NgModule in ${modules[0]} and ${modules[1]}.`);
			}
		} else ownerNgModule.set(type, moduleType);
	}
	function verifyComponentIsPartOfNgModule(type) {
		type = resolveForwardRef(type);
		if (!ownerNgModule.get(type) && !isStandalone(type)) errors.push(`Component ${stringifyForError(type)} is not part of any NgModule or the module has not been imported into your module.`);
	}
	function verifyCorrectBootstrapType(type) {
		type = resolveForwardRef(type);
		if (!getComponentDef(type)) errors.push(`${stringifyForError(type)} cannot be used as an entry component.`);
		if (isStandalone(type)) errors.push(`The \`${stringifyForError(type)}\` class is a standalone component, which can not be used in the \`@NgModule.bootstrap\` array. Use the \`bootstrapApplication\` function for bootstrap instead.`);
	}
	function verifySemanticsOfNgModuleImport(type, importingModule) {
		type = resolveForwardRef(type);
		const directiveDef = getComponentDef(type) || getDirectiveDef(type);
		if (directiveDef !== null && !directiveDef.standalone) throw new Error(`Unexpected directive '${type.name}' imported by the module '${importingModule.name}'. Please add an @NgModule annotation.`);
		const pipeDef = getPipeDef$1(type);
		if (pipeDef !== null && !pipeDef.standalone) throw new Error(`Unexpected pipe '${type.name}' imported by the module '${importingModule.name}'. Please add an @NgModule annotation.`);
	}
}
function unwrapModuleWithProvidersImports(typeOrWithProviders) {
	typeOrWithProviders = resolveForwardRef(typeOrWithProviders);
	return typeOrWithProviders.ngModule || typeOrWithProviders;
}
function getAnnotation(type, name) {
	let annotation = null;
	collect(type.__annotations__);
	collect(type.decorators);
	return annotation;
	function collect(annotations) {
		if (annotations) annotations.forEach(readAnnotation);
	}
	function readAnnotation(decorator) {
		if (!annotation) {
			if (Object.getPrototypeOf(decorator).ngMetadataName == name) annotation = decorator;
			else if (decorator.type) {
				if (Object.getPrototypeOf(decorator.type).ngMetadataName == name) annotation = decorator.args[0];
			}
		}
	}
}
var ownerNgModule = /* @__PURE__ */ new WeakMap();
var verifiedNgModule = /* @__PURE__ */ new WeakMap();
function resetCompiledComponents() {
	ownerNgModule = /* @__PURE__ */ new WeakMap();
	verifiedNgModule = /* @__PURE__ */ new WeakMap();
	moduleQueue.length = 0;
	GENERATED_COMP_IDS.clear();
}
function computeCombinedExports(type) {
	type = resolveForwardRef(type);
	const ngModuleDef = getNgModuleDef(type);
	if (ngModuleDef === null) return [type];
	return flatten(maybeUnwrapFn(ngModuleDef.exports).map((type) => {
		if (getNgModuleDef(type)) {
			verifySemanticsOfNgModuleDef(type, false);
			return computeCombinedExports(type);
		} else return type;
	}));
}
function setScopeOnDeclaredComponents(moduleType, ngModule) {
	const declarations = flatten(ngModule.declarations || EMPTY_ARRAY);
	const transitiveScopes = transitiveScopesFor(moduleType);
	declarations.forEach((declaration) => {
		declaration = resolveForwardRef(declaration);
		if (Object.hasOwn(declaration, NG_COMP_DEF)) patchComponentDefWithScope(getComponentDef(declaration), transitiveScopes);
		else if (!Object.hasOwn(declaration, NG_DIR_DEF) && !Object.hasOwn(declaration, NG_PIPE_DEF)) declaration.ngSelectorScope = moduleType;
	});
}
function patchComponentDefWithScope(componentDef, transitiveScopes) {
	componentDef.directiveDefs = () => Array.from(transitiveScopes.compilation.directives).map((dir) => Object.hasOwn(dir, NG_COMP_DEF) ? getComponentDef(dir) : getDirectiveDef(dir)).filter((def) => !!def);
	componentDef.pipeDefs = () => Array.from(transitiveScopes.compilation.pipes).map((pipe) => getPipeDef$1(pipe));
	componentDef.schemas = transitiveScopes.schemas;
	componentDef.tView = null;
}
function transitiveScopesFor(type) {
	if (isNgModule(type)) {
		const scope = depsTracker.getNgModuleScope(type);
		return {
			schemas: getNgModuleDefOrThrow(type).schemas || null,
			...scope
		};
	} else if (isStandalone(type)) {
		if ((getComponentDef(type) || getDirectiveDef(type)) !== null) return {
			schemas: null,
			compilation: {
				directives: /* @__PURE__ */ new Set(),
				pipes: /* @__PURE__ */ new Set()
			},
			exported: {
				directives: /* @__PURE__ */ new Set([type]),
				pipes: /* @__PURE__ */ new Set()
			}
		};
		if (getPipeDef$1(type) !== null) return {
			schemas: null,
			compilation: {
				directives: /* @__PURE__ */ new Set(),
				pipes: /* @__PURE__ */ new Set()
			},
			exported: {
				directives: /* @__PURE__ */ new Set(),
				pipes: /* @__PURE__ */ new Set([type])
			}
		};
	}
	throw new Error(`${type.name} does not have a module def (ɵmod property)`);
}
function expandModuleWithProviders(value) {
	if (isModuleWithProviders(value)) return value.ngModule;
	return value;
}
var compilationDepth = 0;
function compileComponent(type, metadata) {
	(typeof ngDevMode === "undefined" || ngDevMode) && initNgDevMode();
	let ngComponentDef = null;
	maybeQueueResolutionOfComponentResources(type, metadata);
	addDirectiveFactoryDef(type, metadata);
	Object.defineProperty(type, NG_COMP_DEF, {
		get: () => {
			if (ngComponentDef === null) {
				const compiler = getCompilerFacade({
					usage: 0,
					kind: "component",
					type
				});
				if (metadata.foreignImports !== void 0) throw new Error(`Foreign components are not supported in JIT mode. Component '${type.name}' cannot specify 'foreignImports'.`);
				if (componentNeedsResolution(metadata)) {
					const error = [`Component '${type.name}' is not resolved:`];
					if (metadata.templateUrl) error.push(` - templateUrl: ${metadata.templateUrl}`);
					if (metadata.styleUrls && metadata.styleUrls.length) error.push(` - styleUrls: ${JSON.stringify(metadata.styleUrls)}`);
					if (metadata.styleUrl) error.push(` - styleUrl: ${metadata.styleUrl}`);
					error.push(`Did you run and wait for 'resolveComponentResources()'?`);
					throw new Error(error.join("\n"));
				}
				const options = getJitOptions();
				let preserveWhitespaces = metadata.preserveWhitespaces;
				if (preserveWhitespaces === void 0) {
					if (options !== null && options.preserveWhitespaces !== void 0) preserveWhitespaces = options.preserveWhitespaces;
					else preserveWhitespaces = false;
				}
				let encapsulation = metadata.encapsulation;
				if (encapsulation === void 0) {
					if (options !== null && options.defaultEncapsulation !== void 0) encapsulation = options.defaultEncapsulation;
					else encapsulation = ViewEncapsulation$1.Emulated;
				}
				const templateUrl = metadata.templateUrl || `ng:///${type.name}/template.html`;
				const baseMeta = directiveMetadata(type, metadata);
				const meta = {
					...baseMeta,
					typeSourceSpan: compiler.createParseSourceSpan("Component", type.name, templateUrl),
					template: metadata.template || "",
					preserveWhitespaces,
					styles: typeof metadata.styles === "string" ? [metadata.styles] : metadata.styles || EMPTY_ARRAY,
					animations: metadata.animations,
					declarations: [],
					changeDetection: metadata.changeDetection,
					encapsulation,
					viewProviders: metadata.viewProviders || null,
					hasDirectiveDependencies: !baseMeta.isStandalone || metadata.imports != null && metadata.imports.length > 0
				};
				compilationDepth++;
				try {
					if (meta.usesInheritance) addDirectiveDefToUndecoratedParents(type);
					ngComponentDef = compiler.compileComponent(angularCoreEnv, templateUrl, meta);
					if (meta.isStandalone) {
						const imports = flatten(metadata.imports || EMPTY_ARRAY);
						const { directiveDefs, pipeDefs } = getStandaloneDefFunctions(type, imports);
						ngComponentDef.directiveDefs = directiveDefs;
						ngComponentDef.pipeDefs = pipeDefs;
						ngComponentDef.dependencies = () => imports.map(resolveForwardRef);
					}
				} finally {
					compilationDepth--;
				}
				if (compilationDepth === 0) flushModuleScopingQueueAsMuchAsPossible();
				if (hasSelectorScope(type)) {
					const scopes = transitiveScopesFor(type.ngSelectorScope);
					patchComponentDefWithScope(ngComponentDef, scopes);
				}
				if (metadata.schemas) {
					if (meta.isStandalone) ngComponentDef.schemas = metadata.schemas;
					else throw new Error(`The 'schemas' was specified for the ${stringifyForError(type)} but is only valid on a component that is standalone.`);
				} else if (meta.isStandalone) ngComponentDef.schemas = [];
			}
			return ngComponentDef;
		},
		set: (def) => {
			ngComponentDef = def;
		},
		configurable: !!ngDevMode
	});
}
function getStandaloneDefFunctions(type, imports) {
	const directiveDefs = () => {
		if (ngDevMode) for (const rawDep of imports) verifyStandaloneImport(rawDep, type);
		if (!isComponent(type)) return [];
		return [...depsTracker.getStandaloneComponentScope(type, imports).compilation.directives].map((p) => getComponentDef(p) || getDirectiveDef(p)).filter((d) => d !== null);
	};
	const pipeDefs = () => {
		if (ngDevMode) for (const rawDep of imports) verifyStandaloneImport(rawDep, type);
		if (!isComponent(type)) return [];
		return [...depsTracker.getStandaloneComponentScope(type, imports).compilation.pipes].map((p) => getPipeDef$1(p)).filter((d) => d !== null);
	};
	return {
		directiveDefs,
		pipeDefs
	};
}
function hasSelectorScope(component) {
	return component.ngSelectorScope !== void 0;
}
function compileDirective(type, directive) {
	let ngDirectiveDef = null;
	addDirectiveFactoryDef(type, directive || {});
	Object.defineProperty(type, NG_DIR_DEF, {
		get: () => {
			if (ngDirectiveDef === null) {
				const meta = getDirectiveMetadata(type, directive || {});
				ngDirectiveDef = getCompilerFacade({
					usage: 0,
					kind: "directive",
					type
				}).compileDirective(angularCoreEnv, meta.sourceMapUrl, meta.metadata);
			}
			return ngDirectiveDef;
		},
		configurable: !!ngDevMode
	});
}
function getDirectiveMetadata(type, metadata) {
	const name = type && type.name;
	const sourceMapUrl = `ng:///${name}/ɵdir.js`;
	const compiler = getCompilerFacade({
		usage: 0,
		kind: "directive",
		type
	});
	const facade = directiveMetadata(type, metadata);
	facade.typeSourceSpan = compiler.createParseSourceSpan("Directive", name, sourceMapUrl);
	if (facade.usesInheritance) addDirectiveDefToUndecoratedParents(type);
	return {
		metadata: facade,
		sourceMapUrl
	};
}
function addDirectiveFactoryDef(type, metadata) {
	let ngFactoryDef = null;
	Object.defineProperty(type, NG_FACTORY_DEF, {
		get: () => {
			if (ngFactoryDef === null) {
				const meta = getDirectiveMetadata(type, metadata);
				const compiler = getCompilerFacade({
					usage: 0,
					kind: "directive",
					type
				});
				ngFactoryDef = compiler.compileFactory(angularCoreEnv, `ng:///${type.name}/ɵfac.js`, {
					name: meta.metadata.name,
					type: meta.metadata.type,
					typeArgumentCount: 0,
					deps: reflectDependencies(type),
					target: compiler.FactoryTarget.Directive
				});
			}
			return ngFactoryDef;
		},
		configurable: !!ngDevMode
	});
}
function extendsDirectlyFromObject(type) {
	return Object.getPrototypeOf(type.prototype) === Object.prototype;
}
function directiveMetadata(type, metadata) {
	const reflect = getReflect();
	const propMetadata = reflect.ownPropMetadata(type);
	return {
		name: type.name,
		legacyOptionalChaining: false,
		type,
		selector: metadata.selector !== void 0 ? metadata.selector : null,
		host: metadata.host || EMPTY_OBJ,
		propMetadata,
		inputs: metadata.inputs || EMPTY_ARRAY,
		outputs: metadata.outputs || EMPTY_ARRAY,
		queries: extractQueriesMetadata(type, propMetadata, isContentQuery),
		lifecycle: { usesOnChanges: reflect.hasLifecycleHook(type, "ngOnChanges") },
		controlCreate: reflect.hasLifecycleHook(type, "ɵngControlCreate") ? { passThroughInput: null } : null,
		typeSourceSpan: null,
		usesInheritance: !extendsDirectlyFromObject(type),
		exportAs: extractExportAs(metadata.exportAs),
		providers: metadata.providers || null,
		viewQueries: extractQueriesMetadata(type, propMetadata, isViewQuery),
		isStandalone: metadata.standalone === void 0 ? true : !!metadata.standalone,
		isSignal: !!metadata.signals,
		hostDirectives: metadata.hostDirectives?.map((directive) => typeof directive === "function" ? { directive } : directive) || null
	};
}
function addDirectiveDefToUndecoratedParents(type) {
	const objPrototype = Object.prototype;
	let parent = Object.getPrototypeOf(type.prototype).constructor;
	while (parent && parent !== objPrototype) {
		if (!getDirectiveDef(parent) && !getComponentDef(parent) && shouldAddAbstractDirective(parent)) compileDirective(parent, null);
		parent = Object.getPrototypeOf(parent);
	}
}
function convertToR3QueryPredicate(selector) {
	return typeof selector === "string" ? splitByComma(selector) : resolveForwardRef(selector);
}
function convertToR3QueryMetadata(propertyName, ann) {
	return {
		propertyName,
		predicate: convertToR3QueryPredicate(ann.selector),
		descendants: ann.descendants,
		first: ann.first,
		read: ann.read ? ann.read : null,
		static: !!ann.static,
		emitDistinctChangesOnly: !!ann.emitDistinctChangesOnly,
		isSignal: !!ann.isSignal
	};
}
function extractQueriesMetadata(type, propMetadata, isQueryAnn) {
	const signalQueriesMeta = [];
	const decoratorQueriesMeta = [];
	for (const field in propMetadata) if (Object.hasOwn(propMetadata, field)) {
		const annotations = propMetadata[field];
		annotations.forEach((ann) => {
			if (isQueryAnn(ann)) {
				if (!ann.selector) throw new Error(`Can't construct a query for the property "${field}" of "${stringifyForError(type)}" since the query selector wasn't defined.`);
				if (annotations.some(isInputAnnotation)) throw new Error(`Cannot combine @Input decorators with query decorators`);
				const queryMeta = convertToR3QueryMetadata(field, ann);
				if (queryMeta.isSignal) signalQueriesMeta.push(queryMeta);
				else decoratorQueriesMeta.push(queryMeta);
			}
		});
	}
	return [...signalQueriesMeta, ...decoratorQueriesMeta];
}
function extractExportAs(exportAs) {
	return exportAs === void 0 ? null : splitByComma(exportAs);
}
function isContentQuery(value) {
	const name = value.ngMetadataName;
	return name === "ContentChild" || name === "ContentChildren";
}
function isViewQuery(value) {
	const name = value.ngMetadataName;
	return name === "ViewChild" || name === "ViewChildren";
}
function isInputAnnotation(value) {
	return value.ngMetadataName === "Input";
}
function splitByComma(value) {
	return value.split(",").map((piece) => piece.trim());
}
var LIFECYCLE_HOOKS = [
	"ngOnChanges",
	"ngOnInit",
	"ngOnDestroy",
	"ngDoCheck",
	"ngAfterViewInit",
	"ngAfterViewChecked",
	"ngAfterContentInit",
	"ngAfterContentChecked"
];
function shouldAddAbstractDirective(type) {
	const reflect = getReflect();
	if (LIFECYCLE_HOOKS.some((hookName) => reflect.hasLifecycleHook(type, hookName))) return true;
	const propMetadata = reflect.propMetadata(type);
	for (const field in propMetadata) {
		const annotations = propMetadata[field];
		for (let i = 0; i < annotations.length; i++) {
			const current = annotations[i];
			const metadataName = current.ngMetadataName;
			if (isInputAnnotation(current) || isContentQuery(current) || isViewQuery(current) || metadataName === "Output" || metadataName === "HostBinding" || metadataName === "HostListener") return true;
		}
	}
	return false;
}
function compilePipe(type, meta) {
	let ngPipeDef = null;
	let ngFactoryDef = null;
	Object.defineProperty(type, NG_FACTORY_DEF, {
		get: () => {
			if (ngFactoryDef === null) {
				const metadata = getPipeMetadata(type, meta);
				const compiler = getCompilerFacade({
					usage: 0,
					kind: "pipe",
					type: metadata.type
				});
				ngFactoryDef = compiler.compileFactory(angularCoreEnv, `ng:///${metadata.name}/ɵfac.js`, {
					name: metadata.name,
					type: metadata.type,
					typeArgumentCount: 0,
					deps: reflectDependencies(type),
					target: compiler.FactoryTarget.Pipe
				});
			}
			return ngFactoryDef;
		},
		configurable: !!ngDevMode
	});
	Object.defineProperty(type, NG_PIPE_DEF, {
		get: () => {
			if (ngPipeDef === null) {
				const metadata = getPipeMetadata(type, meta);
				ngPipeDef = getCompilerFacade({
					usage: 0,
					kind: "pipe",
					type: metadata.type
				}).compilePipe(angularCoreEnv, `ng:///${metadata.name}/ɵpipe.js`, metadata);
			}
			return ngPipeDef;
		},
		configurable: !!ngDevMode
	});
}
function getPipeMetadata(type, meta) {
	return {
		type,
		name: type.name,
		pipeName: meta.name,
		pure: meta.pure !== void 0 ? meta.pure : true,
		isStandalone: meta.standalone === void 0 ? true : !!meta.standalone
	};
}
var Directive = makeDecorator("Directive", (dir = {}) => dir, void 0, void 0, (type, meta) => compileDirective(type, meta));
var Component = makeDecorator("Component", (c = {}) => ({
	changeDetection: ChangeDetectionStrategy.Eager,
	...c
}), Directive, void 0, (type, meta) => compileComponent(type, meta));
var Pipe = makeDecorator("Pipe", (p) => ({
	pure: true,
	...p
}), void 0, void 0, (type, meta) => compilePipe(type, meta));
var Input = makePropDecorator("Input", (arg) => {
	if (!arg) return {};
	return typeof arg === "string" ? { alias: arg } : arg;
});
var Output = makePropDecorator("Output", (alias) => ({ alias }));
var HostBinding = makePropDecorator("HostBinding", (hostPropertyName) => ({ hostPropertyName }));
var HostListener = makePropDecorator("HostListener", (eventName, args) => ({
	eventName,
	args
}));
var NgModule = makeDecorator("NgModule", (ngModule) => ngModule, void 0, void 0, (type, meta) => compileNgModule(type, meta));
var CONSECUTIVE_MICROTASK_NOTIFICATION_LIMIT = 100;
var consecutiveMicrotaskNotifications = 0;
var stackFromLastFewNotifications = [];
function trackMicrotaskNotificationForDebugging() {
	consecutiveMicrotaskNotifications++;
	if (CONSECUTIVE_MICROTASK_NOTIFICATION_LIMIT - consecutiveMicrotaskNotifications < 5) {
		const stack = (/* @__PURE__ */ new Error()).stack;
		if (stack) stackFromLastFewNotifications.push(stack);
	}
	if (consecutiveMicrotaskNotifications === CONSECUTIVE_MICROTASK_NOTIFICATION_LIMIT) throw new RuntimeError(103, "Angular could not stabilize because there were endless change notifications within the browser event loop. The stack from the last several notifications: \n" + stackFromLastFewNotifications.join("\n"));
}
var ChangeDetectionSchedulerImpl = class ChangeDetectionSchedulerImpl {
	applicationErrorHandler = inject(INTERNAL_APPLICATION_ERROR_HANDLER);
	appRef = inject(ApplicationRef);
	taskService = inject(PendingTasksInternal);
	ngZone = inject(NgZone);
	zonelessEnabled = inject(ZONELESS_ENABLED);
	tracing = inject(TracingService, { optional: true });
	zoneIsDefined = typeof Zone !== "undefined" && !!Zone.root.run;
	schedulerTickApplyArgs = [{ data: { "__scheduler_tick__": true } }];
	subscriptions = new import_cjs.Subscription();
	angularZoneId = this.zoneIsDefined ? this.ngZone._inner?.get(angularZoneInstanceIdProperty) : null;
	scheduleInRootZone = !this.zonelessEnabled && this.zoneIsDefined && (inject(SCHEDULE_IN_ROOT_ZONE, { optional: true }) ?? false);
	cancelScheduledCallback = null;
	useMicrotaskScheduler = false;
	runningTick = false;
	pendingRenderTaskId = null;
	constructor() {
		this.subscriptions.add(this.appRef.afterTick.subscribe(() => {
			const task = this.taskService.add();
			if (!this.runningTick) {
				this.cleanup();
				if (!this.zonelessEnabled || this.appRef.includeAllTestViews) {
					this.taskService.remove(task);
					return;
				}
			}
			this.switchToMicrotaskScheduler();
			this.taskService.remove(task);
		}));
		this.subscriptions.add(this.ngZone.onUnstable.subscribe(() => {
			if (!this.runningTick) this.cleanup();
		}));
	}
	switchToMicrotaskScheduler() {
		this.ngZone.runOutsideAngular(() => {
			const task = this.taskService.add();
			this.useMicrotaskScheduler = true;
			queueMicrotask(() => {
				this.useMicrotaskScheduler = false;
				this.taskService.remove(task);
			});
		});
	}
	notify(source) {
		if (!this.zonelessEnabled && source === 5) return;
		switch (source) {
			case 0:
			case 2:
				this.appRef.dirtyFlags |= 2;
				break;
			case 3:
			case 4:
			case 5:
			case 1:
				this.appRef.dirtyFlags |= 4;
				break;
			case 6:
				this.appRef.dirtyFlags |= 2;
				break;
			case 12:
				this.appRef.dirtyFlags |= 16;
				break;
			case 13:
				this.appRef.dirtyFlags |= 2;
				break;
			case 11: break;
			default: this.appRef.dirtyFlags |= 8;
		}
		this.appRef.tracingSnapshot = this.tracing?.snapshot(this.appRef.tracingSnapshot) ?? null;
		if (!this.shouldScheduleTick()) return;
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			if (this.useMicrotaskScheduler) trackMicrotaskNotificationForDebugging();
			else {
				consecutiveMicrotaskNotifications = 0;
				stackFromLastFewNotifications.length = 0;
			}
		}
		const scheduleCallback = this.useMicrotaskScheduler ? scheduleCallbackWithMicrotask : scheduleCallbackWithRafRace;
		this.pendingRenderTaskId = this.taskService.add();
		if (this.scheduleInRootZone) this.cancelScheduledCallback = Zone.root.run(() => scheduleCallback(() => this.tick()));
		else this.cancelScheduledCallback = this.ngZone.runOutsideAngular(() => scheduleCallback(() => this.tick()));
	}
	shouldScheduleTick() {
		if (this.appRef.destroyed) return false;
		if (this.pendingRenderTaskId !== null || this.runningTick || this.appRef._runningTick) return false;
		if (!this.zonelessEnabled && this.zoneIsDefined && Zone.current.get("isAngularZone_ID" + this.angularZoneId)) return false;
		return true;
	}
	tick() {
		if (this.runningTick || this.appRef.destroyed) return;
		if (this.appRef.dirtyFlags === 0) {
			this.cleanup();
			return;
		}
		if (!this.zonelessEnabled && this.appRef.dirtyFlags & 7) this.appRef.dirtyFlags |= 1;
		const task = this.taskService.add();
		try {
			this.ngZone.run(() => {
				this.runningTick = true;
				this.appRef._tick();
			}, void 0, this.schedulerTickApplyArgs);
		} catch (e) {
			this.applicationErrorHandler(e);
		} finally {
			this.taskService.remove(task);
			this.cleanup();
		}
	}
	ngOnDestroy() {
		this.subscriptions.unsubscribe();
		this.cleanup();
	}
	cleanup() {
		this.runningTick = false;
		this.cancelScheduledCallback?.();
		this.cancelScheduledCallback = null;
		if (this.pendingRenderTaskId !== null) {
			const taskId = this.pendingRenderTaskId;
			this.pendingRenderTaskId = null;
			this.taskService.remove(taskId);
		}
	}
	static ɵfac = function ChangeDetectionSchedulerImpl_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ChangeDetectionSchedulerImpl)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: ChangeDetectionSchedulerImpl,
		factory: ChangeDetectionSchedulerImpl.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChangeDetectionSchedulerImpl, [{ type: Service }], () => [], null);
})();
function provideZonelessChangeDetection() {
	performanceMarkFeature("NgZoneless");
	if ((typeof ngDevMode === "undefined" || ngDevMode) && typeof Zone !== "undefined" && Zone) {
		const message = formatRuntimeError(914, "The application is using zoneless change detection, but is still loading Zone.js. Consider removing Zone.js to get the full benefits of zoneless. In applications using the Angular CLI, Zone.js is typically included in the \"polyfills\" section of the angular.json file.");
		console.warn(message);
	}
	return makeEnvironmentProviders([...provideZonelessChangeDetectionInternal(), typeof ngDevMode === "undefined" || ngDevMode ? [{
		provide: PROVIDED_ZONELESS,
		useValue: true
	}] : []]);
}
function provideZonelessChangeDetectionInternal() {
	return [
		{
			provide: ChangeDetectionScheduler,
			useExisting: ChangeDetectionSchedulerImpl
		},
		{
			provide: NgZone,
			useClass: NoopNgZone
		},
		{
			provide: ZONELESS_ENABLED,
			useValue: true
		}
	];
}
var Compiler = class Compiler {
	compileModuleSync(moduleType) {
		return new NgModuleFactory(moduleType);
	}
	compileModuleAsync(moduleType) {
		return Promise.resolve(this.compileModuleSync(moduleType));
	}
	clearCache() {}
	clearCacheFor(type) {}
	getModuleId(moduleType) {}
	static ɵfac = function Compiler_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Compiler)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: Compiler,
		factory: Compiler.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Compiler, [{ type: Service }], null, null);
})();
var COMPILER_OPTIONS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "compilerOptions" : "");
var CompilerFactory = class {};
function getGlobalLocale() {
	if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode && typeof goog !== "undefined" && goog.LOCALE !== "en") return goog.LOCALE;
	else return typeof $localize !== "undefined" && $localize.locale || "en-US";
}
var LOCALE_ID = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "LocaleId" : "", { factory: () => inject(LOCALE_ID, {
	optional: true,
	skipSelf: true
}) || getGlobalLocale() });
var DEFAULT_CURRENCY_CODE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DefaultCurrencyCode" : "", { factory: () => USD_CURRENCY_CODE });
var TRANSLATIONS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Translations" : "");
var TRANSLATIONS_FORMAT = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "TranslationsFormat" : "");
var MissingTranslationStrategy;
(function(MissingTranslationStrategy) {
	MissingTranslationStrategy[MissingTranslationStrategy["Error"] = 0] = "Error";
	MissingTranslationStrategy[MissingTranslationStrategy["Warning"] = 1] = "Warning";
	MissingTranslationStrategy[MissingTranslationStrategy["Ignore"] = 2] = "Ignore";
})(MissingTranslationStrategy || (MissingTranslationStrategy = {}));
function getDeferBlocks(lView, deferBlocks) {
	const tView = lView[1];
	for (let i = 28; i < tView.bindingStartIndex; i++) if (isLContainer(lView[i])) {
		const lContainer = lView[i];
		if (!(i === tView.bindingStartIndex - 1)) {
			const tNode = tView.data[i];
			const tDetails = getTDeferBlockDetails(tView, tNode);
			if (isTDeferBlockDetails(tDetails)) {
				deferBlocks.push({
					lContainer,
					lView,
					tNode,
					tDetails
				});
				continue;
			}
		}
		if (isLView(lContainer[0])) getDeferBlocks(lContainer[0], deferBlocks);
		for (let j = 10; j < lContainer.length; j++) getDeferBlocks(lContainer[j], deferBlocks);
	} else if (isLView(lView[i])) getDeferBlocks(lView[i], deferBlocks);
}
var DebugEventListener = class {
	name;
	callback;
	constructor(name, callback) {
		this.name = name;
		this.callback = callback;
	}
};
function asNativeElements(debugEls) {
	return debugEls.map((el) => el.nativeElement);
}
var DebugNode = class {
	nativeNode;
	constructor(nativeNode) {
		this.nativeNode = nativeNode;
	}
	get parent() {
		const parent = this.nativeNode.parentNode;
		return parent ? new DebugElement(parent) : null;
	}
	get injector() {
		return getInjector(this.nativeNode);
	}
	get componentInstance() {
		const nativeElement = this.nativeNode;
		return nativeElement && (getComponent(nativeElement) || getOwningComponent(nativeElement));
	}
	get context() {
		return getComponent(this.nativeNode) || getContext(this.nativeNode);
	}
	get listeners() {
		return getListeners(this.nativeNode).filter((listener) => listener.type === "dom");
	}
	get references() {
		return getLocalRefs(this.nativeNode);
	}
	get providerTokens() {
		return getInjectionTokens(this.nativeNode);
	}
};
var DebugElement = class extends DebugNode {
	constructor(nativeNode) {
		ngDevMode && assertDomNode(nativeNode);
		super(nativeNode);
	}
	get nativeElement() {
		return this.nativeNode.nodeType == Node.ELEMENT_NODE ? this.nativeNode : null;
	}
	get name() {
		const context = getLContext(this.nativeNode);
		const lView = context ? context.lView : null;
		if (lView !== null) return lView[1].data[context.nodeIndex].value;
		else return this.nativeNode.nodeName;
	}
	get properties() {
		const context = getLContext(this.nativeNode);
		const lView = context ? context.lView : null;
		if (lView === null) return {};
		const tData = lView[1].data;
		const tNode = tData[context.nodeIndex];
		const properties = {};
		copyDomProperties(this.nativeElement, properties);
		collectPropertyBindings(properties, tNode, lView, tData);
		return properties;
	}
	get attributes() {
		const attributes = {};
		const element = this.nativeElement;
		if (!element) return attributes;
		const context = getLContext(element);
		const lView = context ? context.lView : null;
		if (lView === null) return {};
		const tNodeAttrs = lView[1].data[context.nodeIndex].attrs;
		const lowercaseTNodeAttrs = [];
		if (tNodeAttrs) {
			let i = 0;
			while (i < tNodeAttrs.length) {
				const attrName = tNodeAttrs[i];
				if (typeof attrName !== "string") break;
				attributes[attrName] = tNodeAttrs[i + 1];
				lowercaseTNodeAttrs.push(attrName.toLowerCase());
				i += 2;
			}
		}
		for (const attr of element.attributes) if (!lowercaseTNodeAttrs.includes(attr.name)) attributes[attr.name] = attr.value;
		return attributes;
	}
	get styles() {
		return this.nativeElement?.style ?? {};
	}
	get classes() {
		const result = {};
		const className = this.nativeElement.className;
		(typeof className !== "string" ? className.baseVal.split(" ") : className.split(" ")).forEach((value) => result[value] = true);
		return result;
	}
	get childNodes() {
		const childNodes = this.nativeNode.childNodes;
		const children = [];
		for (let i = 0; i < childNodes.length; i++) {
			const element = childNodes[i];
			children.push(getDebugNode(element));
		}
		return children;
	}
	get children() {
		const nativeElement = this.nativeElement;
		if (!nativeElement) return [];
		const childNodes = nativeElement.children;
		const children = [];
		for (let i = 0; i < childNodes.length; i++) {
			const element = childNodes[i];
			children.push(getDebugNode(element));
		}
		return children;
	}
	query(predicate) {
		return this.queryAll(predicate)[0] || null;
	}
	queryAll(predicate) {
		const matches = [];
		_queryAll(this, predicate, matches, true);
		return matches;
	}
	queryAllNodes(predicate) {
		const matches = [];
		_queryAll(this, predicate, matches, false);
		return matches;
	}
	triggerEventHandler(eventName, eventObj) {
		const node = this.nativeNode;
		const invokedListeners = [];
		this.listeners.forEach((listener) => {
			if (listener.name === eventName) {
				const callback = listener.callback;
				callback.call(node, eventObj);
				invokedListeners.push(callback);
			}
		});
		if (typeof node.eventListeners === "function") node.eventListeners(eventName).forEach((listener) => {
			if (listener.toString().indexOf("__ngUnwrap__") !== -1) {
				const unwrappedListener = listener("__ngUnwrap__");
				return invokedListeners.indexOf(unwrappedListener) === -1 && unwrappedListener.call(node, eventObj);
			}
		});
	}
};
function copyDomProperties(element, properties) {
	if (element) {
		let obj = Object.getPrototypeOf(element);
		const NodePrototype = Node.prototype;
		while (obj !== null && obj !== NodePrototype) {
			const descriptors = Object.getOwnPropertyDescriptors(obj);
			for (let key in descriptors) if (!key.startsWith("__") && !key.startsWith("on")) {
				const value = element[key];
				if (isPrimitiveValue(value)) properties[key] = value;
			}
			obj = Object.getPrototypeOf(obj);
		}
	}
}
function isPrimitiveValue(value) {
	return typeof value === "string" || typeof value === "boolean" || typeof value === "number" || value === null;
}
function _queryAll(parentElement, predicate, matches, elementsOnly) {
	const context = getLContext(parentElement.nativeNode);
	const lView = context ? context.lView : null;
	if (lView !== null) {
		const parentTNode = lView[1].data[context.nodeIndex];
		_queryNodeChildren(parentTNode, lView, predicate, matches, elementsOnly, parentElement.nativeNode);
	} else _queryNativeNodeDescendants(parentElement.nativeNode, predicate, matches, elementsOnly);
}
function _queryNodeChildren(tNode, lView, predicate, matches, elementsOnly, rootNativeNode) {
	ngDevMode && assertTNodeForLView(tNode, lView);
	const nativeNode = getNativeByTNodeOrNull(tNode, lView);
	if (tNode.type & 11) {
		_addQueryMatch(nativeNode, predicate, matches, elementsOnly, rootNativeNode);
		if (isComponentHost(tNode)) {
			const componentView = getComponentLViewByIndex(tNode.index, lView);
			if (componentView && componentView[1].firstChild) _queryNodeChildren(componentView[1].firstChild, componentView, predicate, matches, elementsOnly, rootNativeNode);
		} else {
			if (tNode.child) _queryNodeChildren(tNode.child, lView, predicate, matches, elementsOnly, rootNativeNode);
			nativeNode && _queryNativeNodeDescendants(nativeNode, predicate, matches, elementsOnly);
		}
		const nodeOrContainer = lView[tNode.index];
		if (isLContainer(nodeOrContainer)) _queryNodeChildrenInContainer(nodeOrContainer, predicate, matches, elementsOnly, rootNativeNode);
	} else if (tNode.type & 4) {
		const lContainer = lView[tNode.index];
		_addQueryMatch(lContainer[7], predicate, matches, elementsOnly, rootNativeNode);
		_queryNodeChildrenInContainer(lContainer, predicate, matches, elementsOnly, rootNativeNode);
	} else if (tNode.type & 16) {
		const componentView = lView[15];
		const head = componentView[5].projection[tNode.projection];
		if (Array.isArray(head)) for (let nativeNode of head) _addQueryMatch(nativeNode, predicate, matches, elementsOnly, rootNativeNode);
		else if (head) {
			const nextLView = componentView[3];
			const nextTNode = nextLView[1].data[head.index];
			_queryNodeChildren(nextTNode, nextLView, predicate, matches, elementsOnly, rootNativeNode);
		}
	} else if (tNode.child) _queryNodeChildren(tNode.child, lView, predicate, matches, elementsOnly, rootNativeNode);
	if (rootNativeNode !== nativeNode) {
		const nextTNode = tNode.flags & 2 ? tNode.projectionNext : tNode.next;
		if (nextTNode) _queryNodeChildren(nextTNode, lView, predicate, matches, elementsOnly, rootNativeNode);
	}
}
function _queryNodeChildrenInContainer(lContainer, predicate, matches, elementsOnly, rootNativeNode) {
	for (let i = 10; i < lContainer.length; i++) {
		const childView = lContainer[i];
		const firstChild = childView[1].firstChild;
		if (firstChild) _queryNodeChildren(firstChild, childView, predicate, matches, elementsOnly, rootNativeNode);
	}
}
function _addQueryMatch(nativeNode, predicate, matches, elementsOnly, rootNativeNode) {
	if (rootNativeNode !== nativeNode) {
		const debugNode = getDebugNode(nativeNode);
		if (!debugNode) return;
		if (elementsOnly && debugNode instanceof DebugElement && predicate(debugNode) && matches.indexOf(debugNode) === -1) matches.push(debugNode);
		else if (!elementsOnly && predicate(debugNode) && matches.indexOf(debugNode) === -1) matches.push(debugNode);
	}
}
function _queryNativeNodeDescendants(parentNode, predicate, matches, elementsOnly) {
	const nodes = parentNode.childNodes;
	const length = nodes.length;
	for (let i = 0; i < length; i++) {
		const node = nodes[i];
		const debugNode = getDebugNode(node);
		if (debugNode) {
			if (elementsOnly && debugNode instanceof DebugElement && predicate(debugNode) && matches.indexOf(debugNode) === -1) matches.push(debugNode);
			else if (!elementsOnly && predicate(debugNode) && matches.indexOf(debugNode) === -1) matches.push(debugNode);
			_queryNativeNodeDescendants(node, predicate, matches, elementsOnly);
		}
	}
}
function collectPropertyBindings(properties, tNode, lView, tData) {
	let bindingIndexes = tNode.propertyBindings;
	if (bindingIndexes !== null) for (let i = 0; i < bindingIndexes.length; i++) {
		const bindingIndex = bindingIndexes[i];
		const metadataParts = tData[bindingIndex].split(INTERPOLATION_DELIMITER);
		const propertyName = metadataParts[0];
		if (metadataParts.length > 1) {
			let value = metadataParts[1];
			for (let j = 1; j < metadataParts.length - 1; j++) value += renderStringify(lView[bindingIndex + j - 1]) + metadataParts[j + 1];
			properties[propertyName] = value;
		} else properties[propertyName] = lView[bindingIndex];
	}
}
var NG_DEBUG_PROPERTY = "__ng_debug__";
function getDebugNode(nativeNode) {
	if (nativeNode instanceof Node) {
		if (!Object.hasOwn(nativeNode, NG_DEBUG_PROPERTY)) nativeNode[NG_DEBUG_PROPERTY] = nativeNode.nodeType == Node.ELEMENT_NODE ? new DebugElement(nativeNode) : new DebugNode(nativeNode);
		return nativeNode[NG_DEBUG_PROPERTY];
	}
	return null;
}
//#endregion
//#region node_modules/@angular/core/fesm2022/_resource-chunk.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var OutputEmitterRef = class {
	destroyed = false;
	listeners = null;
	errorHandler = inject(ErrorHandler, { optional: true });
	isEmitting = false;
	hasNullListeners = false;
	destroyRef = inject(DestroyRef);
	constructor() {
		this.destroyRef.onDestroy(() => {
			this.destroyed = true;
			this.listeners = null;
		});
	}
	subscribe(callback) {
		if (this.destroyed) throw new RuntimeError(953, ngDevMode && "Unexpected subscription to destroyed `OutputRef`. The owning directive/component is destroyed.");
		(this.listeners ??= []).push(callback);
		return { unsubscribe: () => {
			const index = this.listeners ? this.listeners.indexOf(callback) : -1;
			if (index > -1) {
				if (this.isEmitting) {
					this.hasNullListeners = true;
					this.listeners[index] = null;
				} else this.listeners.splice(index, 1);
			}
		} };
	}
	emit(value) {
		if (this.destroyed) {
			console.warn(formatRuntimeError(953, ngDevMode && "Unexpected emit for destroyed `OutputRef`. The owning directive/component is destroyed."));
			return;
		}
		if (this.listeners === null) return;
		this.isEmitting = true;
		const previousConsumer = setActiveConsumer(null);
		try {
			for (const listenerFn of this.listeners) try {
				if (listenerFn !== null) listenerFn(value);
			} catch (err) {
				this.errorHandler?.handleError(err);
			}
		} finally {
			if (this.hasNullListeners) {
				this.hasNullListeners = false;
				this.listeners && removeNullValues(this.listeners);
			}
			setActiveConsumer(previousConsumer);
			this.isEmitting = false;
		}
	}
};
function removeNullValues(arr) {
	let i = arr.length - 1;
	while (i > -1) {
		if (arr[i] === null) arr.splice(i, 1);
		i--;
	}
}
function getOutputDestroyRef(ref) {
	return ref.destroyRef;
}
var CACHE_ACTIVE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "STATE_CACHE_ACTIVE" : "");
function computed(computation, options) {
	const getter = createComputed(computation, options?.equal);
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		const debugName = options?.debugName;
		getter[SIGNAL].debugName = debugName;
		getter.toString = () => `[Computed${debugName ? " (" + debugName + ")" : ""}: ${getter()}]`;
	}
	return getter;
}
function untracked(nonReactiveReadsFn) {
	return untracked$1(nonReactiveReadsFn);
}
var ResourceDependencyError = class extends Error {
	dependency;
	constructor(dependency) {
		super("Dependency error", { cause: dependency.error() });
		this.name = "ResourceDependencyError";
		this.dependency = dependency;
	}
};
var ResourceParamsStatus = class ResourceParamsStatus extends Error {
	_brand;
	constructor(msg) {
		super(msg);
	}
	static IDLE = new ResourceParamsStatus("IDLE");
	static LOADING = new ResourceParamsStatus("LOADING");
};
var identityFn = (v) => v;
function linkedSignal(optionsOrComputation, options) {
	if (typeof optionsOrComputation === "function") return upgradeLinkedSignalGetter(createLinkedSignal(optionsOrComputation, identityFn, options?.equal), options?.debugName, options?.set);
	else return upgradeLinkedSignalGetter(createLinkedSignal(optionsOrComputation.source, optionsOrComputation.computation, optionsOrComputation.equal), optionsOrComputation.debugName, optionsOrComputation.set);
}
function upgradeLinkedSignalGetter(getter, debugName, customSet) {
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		getter[SIGNAL].debugName = debugName;
		getter.toString = () => `[LinkedSignal${debugName ? " (" + debugName + ")" : ""}: ${getter()}]`;
	}
	const node = getter[SIGNAL];
	const upgradedGetter = getter;
	if (customSet !== void 0) {
		const rawSet = (newValue) => linkedSignalSetFn(node, newValue);
		upgradedGetter.set = (newValue) => customSet(newValue, rawSet);
		upgradedGetter.update = (updateFn) => customSet(updateFn(untracked(getter)), rawSet);
	} else {
		upgradedGetter.set = (newValue) => linkedSignalSetFn(node, newValue);
		upgradedGetter.update = (updateFn) => linkedSignalUpdateFn(node, updateFn);
	}
	upgradedGetter.asReadonly = signalAsReadonlyFn.bind(getter);
	return upgradedGetter;
}
function resource(options) {
	if (ngDevMode && !options?.injector) assertInInjectionContext(resource);
	const oldNameForParams = options.request;
	return new ResourceImpl(options.params ?? oldNameForParams ?? (() => null), getLoader(options), options.defaultValue, options.equal ? wrapEqualityFn(options.equal) : void 0, options.debugName, options.injector ?? inject(Injector), options.id);
}
var BaseWritableResource = class {
	value;
	isLoading;
	constructor(value, debugName) {
		this.value = value;
		this.value.set = this.set.bind(this);
		this.value.update = this.update.bind(this);
		this.value.asReadonly = signalAsReadonlyFn;
		this.isLoading = computed(() => this.status() === "loading" || this.status() === "reloading", ngDevMode ? createDebugNameObject(debugName, "isLoading") : void 0);
	}
	isError = computed(() => this.status() === "error");
	update(updateFn) {
		this.set(updateFn(untracked(this.value)));
	}
	isValueDefined = computed(() => {
		if (this.isError()) return false;
		return this.value() !== void 0;
	});
	_snapshot;
	get snapshot() {
		return this._snapshot ??= computed(() => {
			const status = this.status();
			if (status === "error") return {
				status: "error",
				error: this.error()
			};
			else return {
				status,
				value: this.value()
			};
		});
	}
	hasValue() {
		return this.isValueDefined();
	}
	asReadonly() {
		return this;
	}
};
var ResourceImpl = class extends BaseWritableResource {
	loaderFn;
	equal;
	debugName;
	transferCacheKey;
	pendingTasks;
	state;
	extRequest;
	effectRef;
	pendingController;
	resolvePendingTask = void 0;
	destroyed = false;
	unregisterOnDestroy;
	status;
	error;
	transferState;
	constructor(request, loaderFn, defaultValue, equal, debugName, injector, transferCacheKey, getInitialStream) {
		if (isInParamsFunction()) throw invalidResourceCreationInParams();
		super(computed(() => {
			const streamValue = this.state().stream?.();
			if (!streamValue) return defaultValue;
			if (this.state().status === "loading" && this.error()) return defaultValue;
			if (!isResolved(streamValue)) throw new ResourceValueError(this.error());
			return streamValue.value;
		}, {
			equal,
			...ngDevMode ? createDebugNameObject(debugName, "value") : void 0
		}), debugName);
		this.loaderFn = loaderFn;
		this.equal = equal;
		this.debugName = debugName;
		this.transferCacheKey = transferCacheKey;
		const cacheState = injector.get(CACHE_ACTIVE, void 0, { optional: true }) ?? { isActive: false };
		this.transferState = injector.get(TransferState, void 0, { optional: true }) ?? void 0;
		this.extRequest = linkedSignal(() => {
			try {
				setInParamsFunction(true);
				return {
					request: request(paramsContext),
					reload: 0
				};
			} catch (error) {
				rethrowFatalErrors(error);
				if (error === ResourceParamsStatus.IDLE) return {
					status: "idle",
					reload: 0
				};
				else if (error === ResourceParamsStatus.LOADING) return {
					status: "loading",
					reload: 0
				};
				return {
					error,
					reload: 0
				};
			} finally {
				setInParamsFunction(false);
			}
		}, ngDevMode ? createDebugNameObject(debugName, "extRequest") : void 0);
		this.state = linkedSignal({
			source: this.extRequest,
			computation: (extRequest, previous) => {
				let { request, status, error } = extRequest;
				let stream;
				if (error) {
					status = "resolved";
					stream = signal({ error: encapsulateResourceError(error) }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0);
				} else if (!status) {
					if (!previous) {
						const transferState = this.transferState;
						const cacheKey = this.transferCacheKey;
						if (cacheState.isActive && cacheKey && transferState && request !== void 0) {
							if (transferState.hasKey(cacheKey)) stream = signal({ value: transferState.get(cacheKey, defaultValue) }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0);
						}
						if (!stream) stream = getInitialStream?.(extRequest.request);
						getInitialStream = void 0;
						status = request === void 0 ? "idle" : stream ? "resolved" : "loading";
					} else {
						status = request === void 0 ? "idle" : "loading";
						if (previous.value.extRequest.request === request) stream = previous.value.stream;
					}
				}
				return {
					extRequest,
					status,
					previousStatus: previous ? projectStatusOfState(previous.value) : "idle",
					stream
				};
			},
			...ngDevMode ? createDebugNameObject(debugName, "state") : void 0
		});
		this.effectRef = effect(this.loadEffect.bind(this), {
			injector,
			manualCleanup: true,
			...ngDevMode ? createDebugNameObject(debugName, "loadEffect") : void 0
		});
		this.pendingTasks = injector.get(PendingTasks);
		this.unregisterOnDestroy = injector.get(DestroyRef).onDestroy(() => this.destroy());
		this.status = computed(() => projectStatusOfState(this.state()), ngDevMode ? createDebugNameObject(debugName, "status") : void 0);
		this.error = computed(() => {
			const stream = this.state().stream?.();
			return stream && !isResolved(stream) ? stream.error : void 0;
		}, ngDevMode ? createDebugNameObject(debugName, "error") : void 0);
	}
	set(value) {
		if (this.destroyed) return;
		const error = untracked(this.error);
		const state = untracked(this.state);
		if (!error) {
			const current = untracked(this.value);
			if (state.status === "local" && (this.equal ? this.equal(current, value) : current === value)) return;
		}
		this.state.set({
			extRequest: state.extRequest,
			status: "local",
			previousStatus: "local",
			stream: signal({ value }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0)
		});
		this.abortInProgressLoad();
	}
	reload() {
		const { status } = untracked(this.state);
		if (status === "idle" || status === "loading") return false;
		this.extRequest.update(({ request, reload }) => ({
			request,
			reload: reload + 1
		}));
		return true;
	}
	destroy() {
		this.destroyed = true;
		this.unregisterOnDestroy();
		this.effectRef.destroy();
		this.abortInProgressLoad();
		this.state.set({
			extRequest: {
				request: void 0,
				reload: 0
			},
			status: "idle",
			previousStatus: "idle",
			stream: void 0
		});
	}
	async loadEffect() {
		const extRequest = this.extRequest();
		const { status: currentStatus, previousStatus } = untracked(this.state);
		if (extRequest.request === void 0) return;
		else if (currentStatus !== "loading") return;
		this.abortInProgressLoad();
		let resolvePendingTask = this.resolvePendingTask = this.pendingTasks.add();
		const { signal: abortSignal } = this.pendingController = new AbortController();
		try {
			const stream = untracked(() => {
				return this.loaderFn({
					params: extRequest.request,
					abortSignal,
					previous: { status: previousStatus }
				});
			});
			const shouldDiscard = () => abortSignal.aborted || untracked(this.extRequest) !== extRequest;
			if (isSignal(stream)) {
				if (shouldDiscard()) return;
				this.state.set({
					extRequest,
					status: "resolved",
					previousStatus: "resolved",
					stream
				});
				saveToTransferState(untracked(stream), this.transferCacheKey, this.transferState);
			} else {
				const resolvedStream = await stream;
				if (shouldDiscard()) return;
				this.state.set({
					extRequest,
					status: "resolved",
					previousStatus: "resolved",
					stream: resolvedStream
				});
				saveToTransferState(resolvedStream ? untracked(resolvedStream) : void 0, this.transferCacheKey, this.transferState);
			}
		} catch (err) {
			rethrowFatalErrors(err);
			if (abortSignal.aborted || untracked(this.extRequest) !== extRequest) return;
			this.state.set({
				extRequest,
				status: "resolved",
				previousStatus: "error",
				stream: signal({ error: encapsulateResourceError(err) }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0)
			});
		} finally {
			resolvePendingTask?.();
			resolvePendingTask = void 0;
		}
	}
	abortInProgressLoad() {
		untracked(() => this.pendingController?.abort());
		this.pendingController = void 0;
		this.resolvePendingTask?.();
		this.resolvePendingTask = void 0;
	}
};
function saveToTransferState(result, transferCacheKey, transferState) {
	if (transferCacheKey && transferState && result && isResolved(result)) transferState.set(transferCacheKey, result.value);
}
function wrapEqualityFn(equal) {
	return (a, b) => a === void 0 || b === void 0 ? a === b : equal(a, b);
}
function getLoader(options) {
	if (isStreamingResourceOptions(options)) return options.stream;
	return async (params) => {
		try {
			return signal({ value: await options.loader(params) }, ngDevMode ? createDebugNameObject(options.debugName, "stream") : void 0);
		} catch (err) {
			return signal({ error: encapsulateResourceError(err) }, ngDevMode ? createDebugNameObject(options.debugName, "stream") : void 0);
		}
	};
}
function isStreamingResourceOptions(options) {
	return !!options.stream;
}
function projectStatusOfState(state) {
	switch (state.status) {
		case "loading": return state.extRequest.reload === 0 ? "loading" : "reloading";
		case "resolved": return isResolved(state.stream()) ? "resolved" : "error";
		default: return state.status;
	}
}
function isResolved(state) {
	return state.error === void 0;
}
function createDebugNameObject(resourceDebugName, internalSignalDebugName) {
	return { debugName: `Resource${resourceDebugName ? "#" + resourceDebugName : ""}.${internalSignalDebugName}` };
}
function encapsulateResourceError(error) {
	if (isErrorLike(error)) return error;
	return new ResourceWrappedError(error);
}
var ResourceValueError = class extends Error {
	constructor(error) {
		super(ngDevMode ? `Resource is currently in an error state (see Error.cause for details): ${error.message}` : error.message, { cause: error });
	}
};
var ResourceWrappedError = class extends Error {
	constructor(error) {
		super(ngDevMode ? `Resource returned an error that's not an Error instance: ${String(error)}. Check this error's .cause for the actual error.` : String(error), { cause: error });
	}
};
function chain(resource) {
	switch (resource.status()) {
		case "idle": throw ResourceParamsStatus.IDLE;
		case "error": throw new ResourceDependencyError(resource);
		case "loading":
		case "reloading": throw ResourceParamsStatus.LOADING;
	}
	return resource.value();
}
var paramsContext = { chain };
var inParamsFunction = false;
function isInParamsFunction() {
	return inParamsFunction;
}
function setInParamsFunction(value) {
	inParamsFunction = value;
}
function invalidResourceCreationInParams() {
	return new RuntimeError(992, ngDevMode && `Cannot create a resource inside the \`params\` of another resource`);
}
function rethrowFatalErrors(error) {
	if (error instanceof RuntimeError && error.code === 992) throw error;
}
//#endregion
//#region node_modules/@angular/core/fesm2022/primitives-event-dispatch.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var EventType = {
	CLICK: "click",
	CLICKMOD: "clickmod",
	DBLCLICK: "dblclick",
	FOCUS: "focus",
	FOCUSIN: "focusin",
	BLUR: "blur",
	FOCUSOUT: "focusout",
	SUBMIT: "submit",
	KEYDOWN: "keydown",
	KEYPRESS: "keypress",
	KEYUP: "keyup",
	MOUSEOVER: "mouseover",
	MOUSEOUT: "mouseout",
	MOUSEENTER: "mouseenter",
	MOUSELEAVE: "mouseleave",
	POINTEROVER: "pointerover",
	POINTEROUT: "pointerout",
	POINTERENTER: "pointerenter",
	POINTERLEAVE: "pointerleave",
	ERROR: "error",
	LOAD: "load",
	TOUCHSTART: "touchstart",
	TOUCHEND: "touchend",
	TOUCHMOVE: "touchmove",
	TOGGLE: "toggle"
};
EventType.MOUSEENTER, EventType.MOUSELEAVE;
var BUBBLE_EVENT_TYPES = [
	EventType.CLICK,
	EventType.DBLCLICK,
	EventType.FOCUSIN,
	EventType.FOCUSOUT,
	EventType.KEYDOWN,
	EventType.KEYUP,
	EventType.KEYPRESS,
	EventType.MOUSEOVER,
	EventType.MOUSEOUT,
	EventType.SUBMIT,
	EventType.TOUCHSTART,
	EventType.TOUCHEND,
	EventType.TOUCHMOVE,
	"touchcancel",
	"auxclick",
	"change",
	"compositionstart",
	"compositionupdate",
	"compositionend",
	"beforeinput",
	"input",
	"select",
	"copy",
	"cut",
	"paste",
	"mousedown",
	"mouseup",
	"wheel",
	"contextmenu",
	"dragover",
	"dragenter",
	"dragleave",
	"drop",
	"dragstart",
	"dragend",
	"pointerdown",
	"pointermove",
	"pointerup",
	"pointercancel",
	"pointerover",
	"pointerout",
	"gotpointercapture",
	"lostpointercapture",
	"ended",
	"loadedmetadata",
	"pagehide",
	"pageshow",
	"visibilitychange",
	"beforematch"
];
var CAPTURE_EVENT_TYPES = [
	EventType.FOCUS,
	EventType.BLUR,
	EventType.ERROR,
	EventType.LOAD,
	EventType.TOGGLE
];
var isCaptureEventType = (eventType) => CAPTURE_EVENT_TYPES.indexOf(eventType) >= 0;
var EARLY_EVENT_TYPES = BUBBLE_EVENT_TYPES.concat(CAPTURE_EVENT_TYPES);
var isEarlyEventType = (eventType) => EARLY_EVENT_TYPES.indexOf(eventType) >= 0;
typeof navigator !== "undefined" && /Macintosh/.test(navigator.userAgent);
EventType.CLICK;
var Restriction;
(function(Restriction) {
	Restriction[Restriction["I_AM_THE_JSACTION_FRAMEWORK"] = 0] = "I_AM_THE_JSACTION_FRAMEWORK";
})(Restriction || (Restriction = {}));
//#endregion
//#region node_modules/@angular/core/fesm2022/core.mjs
/**
* @license Angular v22.2.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var ɵINPUT_SIGNAL_BRAND_WRITE_TYPE = /* @__PURE__ */ Symbol();
function createInputSignal(initialValue, options) {
	const node = Object.create(INPUT_SIGNAL_NODE);
	node.value = initialValue;
	node.transformFn = options?.transform;
	function inputValueFn() {
		producerAccessed(node);
		if (node.value === REQUIRED_UNSET_VALUE) {
			let message = null;
			if (ngDevMode) {
				const name = options?.debugName ?? options?.alias;
				message = `Input${name ? ` "${name}"` : ""} is required but no value is available yet.`;
			}
			throw new RuntimeError(-950, message);
		}
		return node.value;
	}
	inputValueFn[SIGNAL] = node;
	if (ngDevMode) {
		inputValueFn.toString = () => `[Input Signal: ${inputValueFn()}]`;
		node.debugName = options?.debugName;
	}
	return inputValueFn;
}
var Framework;
(function(Framework) {
	Framework["Angular"] = "angular";
	Framework["ACX"] = "acx";
	Framework["Wiz"] = "wiz";
})(Framework || (Framework = {}));
var HostAttributeToken = class {
	attributeName;
	constructor(attributeName) {
		this.attributeName = attributeName;
	}
	__NG_ELEMENT_ID__ = () => ɵɵinjectAttribute(this.attributeName);
	toString() {
		return `HostAttributeToken ${this.attributeName}`;
	}
};
var HOST_TAG_NAME = /* @__PURE__ */ (() => {
	const HOST_TAG_NAME_TOKEN = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "HOST_TAG_NAME" : "");
	HOST_TAG_NAME_TOKEN.__NG_ELEMENT_ID__ = (flags) => {
		const tNode = getCurrentTNode();
		if (tNode === null) throw new RuntimeError(-204, ngDevMode && "HOST_TAG_NAME can only be injected in directives and components during construction time (in a class constructor or as a class field initializer)");
		if (tNode.type & 2) return tNode.value;
		if (flags & 8) return null;
		throw new RuntimeError(-204, ngDevMode && `HOST_TAG_NAME was used on ${getDevModeNodeName(tNode)} which doesn't have an underlying element in the DOM. This is invalid, and so the dependency should be marked as optional.`);
	};
	return HOST_TAG_NAME_TOKEN;
})();
function getDevModeNodeName(tNode) {
	if (tNode.type & 8) return "an <ng-container>";
	else if (tNode.type & 4) return "an <ng-template>";
	else if (tNode.type & 128) return "an @let declaration";
	else return "a node";
}
function maybeUnwrapDefaultExport(input) {
	return isWrappedDefaultExport(input) ? input["default"] : input;
}
function isWrappedDefaultExport(value) {
	return value && typeof value === "object" && "default" in value;
}
function injectAsync(loader, options) {
	if (ngDevMode) assertInInjectionContext(injectAsync);
	const injector = inject(Injector);
	let loadedPromise = null;
	const load = () => {
		if (!loadedPromise) loadedPromise = loader();
		return loadedPromise;
	};
	if (options?.prefetch) options.prefetch().then(() => load()).catch(() => {});
	return () => load().then((loadedToken) => injector.get(maybeUnwrapDefaultExport(loadedToken)));
}
function onIdle(options) {
	if (ngDevMode) assertInInjectionContext(onIdle);
	const idleService = inject(IDLE_SERVICE);
	const { promise, resolve } = promiseWithResolvers();
	idleService.requestOnIdle(() => resolve(), options);
	return promise;
}
var FactoryTarget;
(function(FactoryTarget) {
	FactoryTarget[FactoryTarget["Directive"] = 0] = "Directive";
	FactoryTarget[FactoryTarget["Component"] = 1] = "Component";
	FactoryTarget[FactoryTarget["Injectable"] = 2] = "Injectable";
	FactoryTarget[FactoryTarget["Pipe"] = 3] = "Pipe";
	FactoryTarget[FactoryTarget["NgModule"] = 4] = "NgModule";
	FactoryTarget[FactoryTarget["Service"] = 5] = "Service";
})(FactoryTarget || (FactoryTarget = {}));
var R3TemplateDependencyKind;
(function(R3TemplateDependencyKind) {
	R3TemplateDependencyKind[R3TemplateDependencyKind["Directive"] = 0] = "Directive";
	R3TemplateDependencyKind[R3TemplateDependencyKind["Pipe"] = 1] = "Pipe";
	R3TemplateDependencyKind[R3TemplateDependencyKind["NgModule"] = 2] = "NgModule";
})(R3TemplateDependencyKind || (R3TemplateDependencyKind = {}));
var ViewEncapsulation;
(function(ViewEncapsulation) {
	ViewEncapsulation[ViewEncapsulation["Emulated"] = 0] = "Emulated";
	ViewEncapsulation[ViewEncapsulation["None"] = 2] = "None";
	ViewEncapsulation[ViewEncapsulation["ShadowDom"] = 3] = "ShadowDom";
	ViewEncapsulation[ViewEncapsulation["ExperimentalIsolatedShadowDom"] = 4] = "ExperimentalIsolatedShadowDom";
})(ViewEncapsulation || (ViewEncapsulation = {}));
function output(opts) {
	ngDevMode && assertInInjectionContext(output);
	return new OutputEmitterRef();
}
function inputFunction(initialValue, opts) {
	ngDevMode && assertInInjectionContext(input);
	return createInputSignal(initialValue, opts);
}
function inputRequiredFunction(opts) {
	ngDevMode && assertInInjectionContext(input);
	return createInputSignal(REQUIRED_UNSET_VALUE, opts);
}
var input = (() => {
	inputFunction.required = inputRequiredFunction;
	return inputFunction;
})();
function createModelSignal(initialValue, opts) {
	const node = Object.create(INPUT_SIGNAL_NODE);
	const emitterRef = new OutputEmitterRef();
	node.value = initialValue;
	function getter() {
		producerAccessed(node);
		assertModelSet(node.value);
		return node.value;
	}
	getter[SIGNAL] = node;
	getter.asReadonly = signalAsReadonlyFn.bind(getter);
	getter.set = (newValue) => {
		if (!node.equal(node.value, newValue)) {
			signalSetFn(node, newValue);
			emitterRef.emit(newValue);
		}
	};
	getter.update = (updateFn) => {
		assertModelSet(node.value);
		getter.set(updateFn(node.value));
	};
	getter.subscribe = emitterRef.subscribe.bind(emitterRef);
	getter.destroyRef = emitterRef.destroyRef;
	if (ngDevMode) {
		getter.toString = () => `[Model Signal: ${getter()}]`;
		node.debugName = opts?.debugName;
	}
	return getter;
}
function assertModelSet(value) {
	if (value === REQUIRED_UNSET_VALUE) throw new RuntimeError(952, ngDevMode && "Model is required but no value is available yet.");
}
function modelFunction(initialValue, opts) {
	ngDevMode && assertInInjectionContext(model);
	return createModelSignal(initialValue, opts);
}
function modelRequiredFunction(opts) {
	ngDevMode && assertInInjectionContext(model);
	return createModelSignal(REQUIRED_UNSET_VALUE, opts);
}
var model = (() => {
	modelFunction.required = modelRequiredFunction;
	return modelFunction;
})();
function viewChildFn(locator, opts) {
	ngDevMode && assertInInjectionContext(viewChild);
	return createSingleResultOptionalQuerySignalFn(opts);
}
function viewChildRequiredFn(locator, opts) {
	ngDevMode && assertInInjectionContext(viewChild);
	return createSingleResultRequiredQuerySignalFn(opts);
}
var viewChild = (() => {
	viewChildFn.required = viewChildRequiredFn;
	return viewChildFn;
})();
function viewChildren(locator, opts) {
	ngDevMode && assertInInjectionContext(viewChildren);
	return createMultiResultQuerySignalFn(opts);
}
function contentChildFn(locator, opts) {
	ngDevMode && assertInInjectionContext(contentChild);
	return createSingleResultOptionalQuerySignalFn(opts);
}
function contentChildRequiredFn(locator, opts) {
	ngDevMode && assertInInjectionContext(contentChildren);
	return createSingleResultRequiredQuerySignalFn(opts);
}
var contentChild = (() => {
	contentChildFn.required = contentChildRequiredFn;
	return contentChildFn;
})();
function contentChildren(locator, opts) {
	return createMultiResultQuerySignalFn(opts);
}
function mergeApplicationConfig(...configs) {
	return configs.reduce((prev, curr) => {
		return Object.assign(prev, curr, { providers: [...prev.providers, ...curr.providers] });
	}, { providers: [] });
}
var emitDistinctChangesOnlyDefaultValue = true;
var Query = class {};
var ContentChildren = makePropDecorator("ContentChildren", (selector, opts = {}) => ({
	selector,
	first: false,
	isViewQuery: false,
	descendants: false,
	emitDistinctChangesOnly: emitDistinctChangesOnlyDefaultValue,
	...opts
}), Query);
var ContentChild = makePropDecorator("ContentChild", (selector, opts = {}) => ({
	selector,
	first: true,
	isViewQuery: false,
	descendants: true,
	...opts
}), Query);
var ViewChildren = makePropDecorator("ViewChildren", (selector, opts = {}) => ({
	selector,
	first: false,
	isViewQuery: true,
	descendants: true,
	emitDistinctChangesOnly: emitDistinctChangesOnlyDefaultValue,
	...opts
}), Query);
var ViewChild = makePropDecorator("ViewChild", (selector, opts) => ({
	selector,
	first: true,
	isViewQuery: true,
	descendants: true,
	...opts
}), Query);
var ApplicationModule = class ApplicationModule {
	constructor(appRef) {}
	static ɵfac = function ApplicationModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ApplicationModule)(ɵɵinject(ApplicationRef));
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({ type: ApplicationModule });
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ApplicationModule, [{ type: NgModule }], () => [{ type: ApplicationRef }], null);
})();
var REQUEST = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "REQUEST" : "", {
	providedIn: "platform",
	factory: () => null
});
var RESPONSE_INIT = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "RESPONSE_INIT" : "", {
	providedIn: "platform",
	factory: () => null
});
var REQUEST_CONTEXT = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "REQUEST_CONTEXT" : "", {
	providedIn: "platform",
	factory: () => null
});
function withEventReplay() {
	return [{
		provide: IS_EVENT_REPLAY_ENABLED,
		useFactory: () => {
			let isEnabled = true;
			performanceMarkFeature("NgEventReplay");
			return isEnabled;
		}
	}];
}
function collectDomEventsInfo(tView, lView, eventTypesToReplay) {
	const domEventsInfo = /* @__PURE__ */ new Map();
	const lCleanup = lView[7];
	const tCleanup = tView.cleanup;
	if (!tCleanup || !lCleanup) return domEventsInfo;
	for (let i = 0; i < tCleanup.length;) {
		const firstParam = tCleanup[i++];
		const secondParam = tCleanup[i++];
		if (typeof firstParam !== "string") continue;
		const eventType = firstParam;
		if (!isEarlyEventType(eventType)) continue;
		if (isCaptureEventType(eventType)) eventTypesToReplay.capture.add(eventType);
		else eventTypesToReplay.regular.add(eventType);
		const listenerElement = unwrapRNode(lView[secondParam]);
		i++;
		const useCaptureOrIndx = tCleanup[i++];
		if (!(typeof useCaptureOrIndx === "boolean" || useCaptureOrIndx >= 0)) continue;
		if (!domEventsInfo.has(listenerElement)) domEventsInfo.set(listenerElement, [eventType]);
		else domEventsInfo.get(listenerElement).push(eventType);
	}
	return domEventsInfo;
}
var isI18nHydrationRuntimeSupportEnabled = false;
function enableI18nHydrationRuntimeSupport() {
	if (!isI18nHydrationRuntimeSupportEnabled) {
		isI18nHydrationRuntimeSupportEnabled = true;
		enableLocateOrCreateI18nNodeImpl();
		enablePrepareI18nBlockForHydrationImpl();
		enableClaimDehydratedIcuCaseImpl();
	}
}
var CLIENT_RENDER_MODE_FLAG = "ngcm";
function withDomHydration() {
	return makeEnvironmentProviders([{
		provide: IS_HYDRATION_DOM_REUSE_ENABLED,
		useFactory: () => {
			let isEnabled = true;
			performanceMarkFeature("NgHydration");
			return isEnabled;
		}
	}, {
		provide: ENVIRONMENT_INITIALIZER,
		useValue: () => {
			setIsI18nHydrationSupportEnabled(false);
		},
		multi: true
	}]);
}
function withI18nSupport() {
	return [{
		provide: IS_I18N_HYDRATION_ENABLED,
		useFactory: () => inject(IS_HYDRATION_DOM_REUSE_ENABLED)
	}, {
		provide: ENVIRONMENT_INITIALIZER,
		useValue: () => {
			if (inject(IS_HYDRATION_DOM_REUSE_ENABLED)) {
				enableI18nHydrationRuntimeSupport();
				setIsI18nHydrationSupportEnabled(true);
				performanceMarkFeature("NgI18nHydration");
			}
		},
		multi: true
	}];
}
function withIncrementalHydration() {
	return [
		withEventReplay(),
		{
			provide: IS_INCREMENTAL_HYDRATION_ENABLED,
			useValue: true
		},
		{
			provide: DEHYDRATED_BLOCK_REGISTRY,
			useFactory: createDehydratedBlockRegistry
		}
	];
}
var STABILITY_WARNING_THRESHOLD = 9e3;
var DebugTaskTrackerImpl = class {
	openTasks = /* @__PURE__ */ new Map();
	add(taskId) {
		this.openTasks.set(taskId, /* @__PURE__ */ new Error("Task stack tracking error"));
	}
	remove(taskId) {
		this.openTasks.delete(taskId);
	}
};
function provideStabilityDebugging() {
	const taskTracker = new DebugTaskTrackerImpl();
	const { openTasks } = taskTracker;
	return makeEnvironmentProviders([{
		provide: DEBUG_TASK_TRACKER,
		useValue: taskTracker
	}, provideAppInitializer(() => {
		if (typeof ngDevMode === "undefined" || !ngDevMode) console.warn("Stability debugging utility was provided in production mode. This will cause debug code to be included in production bundles. If this is intentional because you are debugging stability issues in a production environment, you can ignore this warning.");
		const ngZone = inject(NgZone);
		const applicationRef = inject(ApplicationRef);
		let _taskTrackingZone = null;
		if (typeof Zone !== "undefined") ngZone.run(() => {
			_taskTrackingZone = Zone.current.get("TaskTrackingZone");
		});
		ngZone.runOutsideAngular(() => {
			const timeoutId = setTimeout(() => {
				console.debug(`---- Application did not stabilize within ${STABILITY_WARNING_THRESHOLD / 1e3} seconds ----`);
				if (typeof Zone !== "undefined" && !_taskTrackingZone) console.info("Zone.js is present but no TaskTrackingZone found. To enable better debugging of tasks in the Angular Zone, import \"zone.js/plugins/task-tracking\" in your application.");
				if (_taskTrackingZone?.macroTasks?.length) {
					console.group("Macrotasks keeping Angular Zone unstable:");
					for (const t of _taskTrackingZone?.macroTasks ?? []) console.debug(t.creationLocation.stack);
					console.groupEnd();
				}
				console.group("PendingTasks keeping application unstable:");
				for (const error of openTasks.values()) console.debug(error.stack);
				console.groupEnd();
			}, STABILITY_WARNING_THRESHOLD);
			applicationRef.whenStable().then(() => {
				clearTimeout(timeoutId);
			});
		});
	})]);
}
var DefaultIterableDifferFactory = class {
	supports(obj) {
		return isListLikeIterable(obj);
	}
	create(trackByFn) {
		return new DefaultIterableDiffer(trackByFn);
	}
};
var trackByIdentity = (index, item) => item;
var DefaultIterableDiffer = class {
	length = 0;
	collection;
	_linkedRecords = null;
	_unlinkedRecords = null;
	_previousItHead = null;
	_itHead = null;
	_itTail = null;
	_additionsHead = null;
	_additionsTail = null;
	_movesHead = null;
	_movesTail = null;
	_removalsHead = null;
	_removalsTail = null;
	_identityChangesHead = null;
	_identityChangesTail = null;
	_trackByFn;
	constructor(trackByFn) {
		this._trackByFn = trackByFn || trackByIdentity;
	}
	forEachItem(fn) {
		let record;
		for (record = this._itHead; record !== null; record = record._next) fn(record);
	}
	forEachOperation(fn) {
		let nextIt = this._itHead;
		let nextRemove = this._removalsHead;
		let addRemoveOffset = 0;
		let moveOffsets = null;
		while (nextIt || nextRemove) {
			const record = !nextRemove || nextIt && nextIt.currentIndex < getPreviousIndex(nextRemove, addRemoveOffset, moveOffsets) ? nextIt : nextRemove;
			const adjPreviousIndex = getPreviousIndex(record, addRemoveOffset, moveOffsets);
			const currentIndex = record.currentIndex;
			if (record === nextRemove) {
				addRemoveOffset--;
				nextRemove = nextRemove._nextRemoved;
			} else {
				nextIt = nextIt._next;
				if (record.previousIndex == null) addRemoveOffset++;
				else {
					if (!moveOffsets) moveOffsets = [];
					const localMovePreviousIndex = adjPreviousIndex - addRemoveOffset;
					const localCurrentIndex = currentIndex - addRemoveOffset;
					if (localMovePreviousIndex != localCurrentIndex) {
						for (let i = 0; i < localMovePreviousIndex; i++) {
							const offset = i < moveOffsets.length ? moveOffsets[i] : moveOffsets[i] = 0;
							const index = offset + i;
							if (localCurrentIndex <= index && index < localMovePreviousIndex) moveOffsets[i] = offset + 1;
						}
						const previousIndex = record.previousIndex;
						moveOffsets[previousIndex] = localCurrentIndex - localMovePreviousIndex;
					}
				}
			}
			if (adjPreviousIndex !== currentIndex) fn(record, adjPreviousIndex, currentIndex);
		}
	}
	forEachPreviousItem(fn) {
		let record;
		for (record = this._previousItHead; record !== null; record = record._nextPrevious) fn(record);
	}
	forEachAddedItem(fn) {
		let record;
		for (record = this._additionsHead; record !== null; record = record._nextAdded) fn(record);
	}
	forEachMovedItem(fn) {
		let record;
		for (record = this._movesHead; record !== null; record = record._nextMoved) fn(record);
	}
	forEachRemovedItem(fn) {
		let record;
		for (record = this._removalsHead; record !== null; record = record._nextRemoved) fn(record);
	}
	forEachIdentityChange(fn) {
		let record;
		for (record = this._identityChangesHead; record !== null; record = record._nextIdentityChange) fn(record);
	}
	diff(collection) {
		if (collection == null) collection = [];
		if (!isListLikeIterable(collection)) throw new RuntimeError(900, ngDevMode && `Error trying to diff '${stringify(collection)}'. Only arrays and iterables are allowed`);
		if (this.check(collection)) return this;
		else return null;
	}
	onDestroy() {}
	check(collection) {
		this._reset();
		let record = this._itHead;
		let mayBeDirty = false;
		let index;
		let item;
		let itemTrackBy;
		if (Array.isArray(collection)) {
			this.length = collection.length;
			for (let index = 0; index < this.length; index++) {
				item = collection[index];
				itemTrackBy = this._trackByFn(index, item);
				if (record === null || !Object.is(record.trackById, itemTrackBy)) {
					record = this._mismatch(record, item, itemTrackBy, index);
					mayBeDirty = true;
				} else {
					if (mayBeDirty) record = this._verifyReinsertion(record, item, itemTrackBy, index);
					if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
				}
				record = record._next;
			}
		} else {
			index = 0;
			iterateListLike(collection, (item) => {
				itemTrackBy = this._trackByFn(index, item);
				if (record === null || !Object.is(record.trackById, itemTrackBy)) {
					record = this._mismatch(record, item, itemTrackBy, index);
					mayBeDirty = true;
				} else {
					if (mayBeDirty) record = this._verifyReinsertion(record, item, itemTrackBy, index);
					if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
				}
				record = record._next;
				index++;
			});
			this.length = index;
		}
		this._truncate(record);
		this.collection = collection;
		return this.isDirty;
	}
	get isDirty() {
		return this._additionsHead !== null || this._movesHead !== null || this._removalsHead !== null || this._identityChangesHead !== null;
	}
	_reset() {
		if (this.isDirty) {
			let record;
			for (record = this._previousItHead = this._itHead; record !== null; record = record._next) record._nextPrevious = record._next;
			for (record = this._additionsHead; record !== null; record = record._nextAdded) record.previousIndex = record.currentIndex;
			this._additionsHead = this._additionsTail = null;
			for (record = this._movesHead; record !== null; record = record._nextMoved) record.previousIndex = record.currentIndex;
			this._movesHead = this._movesTail = null;
			this._removalsHead = this._removalsTail = null;
			this._identityChangesHead = this._identityChangesTail = null;
		}
	}
	_mismatch(record, item, itemTrackBy, index) {
		let previousRecord;
		if (record === null) previousRecord = this._itTail;
		else {
			previousRecord = record._prev;
			this._remove(record);
		}
		record = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(itemTrackBy, null);
		if (record !== null) {
			if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
			this._reinsertAfter(record, previousRecord, index);
		} else {
			record = this._linkedRecords === null ? null : this._linkedRecords.get(itemTrackBy, index);
			if (record !== null) {
				if (!Object.is(record.item, item)) this._addIdentityChange(record, item);
				this._moveAfter(record, previousRecord, index);
			} else record = this._addAfter(new IterableChangeRecord_(item, itemTrackBy), previousRecord, index);
		}
		return record;
	}
	_verifyReinsertion(record, item, itemTrackBy, index) {
		let reinsertRecord = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(itemTrackBy, null);
		if (reinsertRecord !== null) record = this._reinsertAfter(reinsertRecord, record._prev, index);
		else if (record.currentIndex != index) {
			record.currentIndex = index;
			this._addToMoves(record, index);
		}
		return record;
	}
	_truncate(record) {
		while (record !== null) {
			const nextRecord = record._next;
			this._addToRemovals(this._unlink(record));
			record = nextRecord;
		}
		if (this._unlinkedRecords !== null) this._unlinkedRecords.clear();
		if (this._additionsTail !== null) this._additionsTail._nextAdded = null;
		if (this._movesTail !== null) this._movesTail._nextMoved = null;
		if (this._itTail !== null) this._itTail._next = null;
		if (this._removalsTail !== null) this._removalsTail._nextRemoved = null;
		if (this._identityChangesTail !== null) this._identityChangesTail._nextIdentityChange = null;
	}
	_reinsertAfter(record, prevRecord, index) {
		if (this._unlinkedRecords !== null) this._unlinkedRecords.remove(record);
		const prev = record._prevRemoved;
		const next = record._nextRemoved;
		if (prev === null) this._removalsHead = next;
		else prev._nextRemoved = next;
		if (next === null) this._removalsTail = prev;
		else next._prevRemoved = prev;
		this._insertAfter(record, prevRecord, index);
		this._addToMoves(record, index);
		return record;
	}
	_moveAfter(record, prevRecord, index) {
		this._unlink(record);
		this._insertAfter(record, prevRecord, index);
		this._addToMoves(record, index);
		return record;
	}
	_addAfter(record, prevRecord, index) {
		this._insertAfter(record, prevRecord, index);
		if (this._additionsTail === null) this._additionsTail = this._additionsHead = record;
		else this._additionsTail = this._additionsTail._nextAdded = record;
		return record;
	}
	_insertAfter(record, prevRecord, index) {
		const next = prevRecord === null ? this._itHead : prevRecord._next;
		record._next = next;
		record._prev = prevRecord;
		if (next === null) this._itTail = record;
		else next._prev = record;
		if (prevRecord === null) this._itHead = record;
		else prevRecord._next = record;
		if (this._linkedRecords === null) this._linkedRecords = new _DuplicateMap();
		this._linkedRecords.put(record);
		record.currentIndex = index;
		return record;
	}
	_remove(record) {
		return this._addToRemovals(this._unlink(record));
	}
	_unlink(record) {
		if (this._linkedRecords !== null) this._linkedRecords.remove(record);
		const prev = record._prev;
		const next = record._next;
		if (prev === null) this._itHead = next;
		else prev._next = next;
		if (next === null) this._itTail = prev;
		else next._prev = prev;
		return record;
	}
	_addToMoves(record, toIndex) {
		if (record.previousIndex === toIndex) return record;
		if (this._movesTail === null) this._movesTail = this._movesHead = record;
		else this._movesTail = this._movesTail._nextMoved = record;
		return record;
	}
	_addToRemovals(record) {
		if (this._unlinkedRecords === null) this._unlinkedRecords = new _DuplicateMap();
		this._unlinkedRecords.put(record);
		record.currentIndex = null;
		record._nextRemoved = null;
		if (this._removalsTail === null) {
			this._removalsTail = this._removalsHead = record;
			record._prevRemoved = null;
		} else {
			record._prevRemoved = this._removalsTail;
			this._removalsTail = this._removalsTail._nextRemoved = record;
		}
		return record;
	}
	_addIdentityChange(record, item) {
		record.item = item;
		if (this._identityChangesTail === null) this._identityChangesTail = this._identityChangesHead = record;
		else this._identityChangesTail = this._identityChangesTail._nextIdentityChange = record;
		return record;
	}
};
var IterableChangeRecord_ = class {
	item;
	trackById;
	currentIndex = null;
	previousIndex = null;
	_nextPrevious = null;
	_prev = null;
	_next = null;
	_prevDup = null;
	_nextDup = null;
	_prevRemoved = null;
	_nextRemoved = null;
	_nextAdded = null;
	_nextMoved = null;
	_nextIdentityChange = null;
	constructor(item, trackById) {
		this.item = item;
		this.trackById = trackById;
	}
};
var _DuplicateItemRecordList = class {
	_head = null;
	_tail = null;
	add(record) {
		if (this._head === null) {
			this._head = this._tail = record;
			record._nextDup = null;
			record._prevDup = null;
		} else {
			this._tail._nextDup = record;
			record._prevDup = this._tail;
			record._nextDup = null;
			this._tail = record;
		}
	}
	get(trackById, atOrAfterIndex) {
		let record;
		for (record = this._head; record !== null; record = record._nextDup) if ((atOrAfterIndex === null || atOrAfterIndex <= record.currentIndex) && Object.is(record.trackById, trackById)) return record;
		return null;
	}
	remove(record) {
		const prev = record._prevDup;
		const next = record._nextDup;
		if (prev === null) this._head = next;
		else prev._nextDup = next;
		if (next === null) this._tail = prev;
		else next._prevDup = prev;
		return this._head === null;
	}
};
var _DuplicateMap = class {
	map = /* @__PURE__ */ new Map();
	put(record) {
		const key = record.trackById;
		let duplicates = this.map.get(key);
		if (!duplicates) {
			duplicates = new _DuplicateItemRecordList();
			this.map.set(key, duplicates);
		}
		duplicates.add(record);
	}
	get(trackById, atOrAfterIndex) {
		const key = trackById;
		const recordList = this.map.get(key);
		return recordList ? recordList.get(trackById, atOrAfterIndex) : null;
	}
	remove(record) {
		const key = record.trackById;
		if (this.map.get(key).remove(record)) this.map.delete(key);
		return record;
	}
	get isEmpty() {
		return this.map.size === 0;
	}
	clear() {
		this.map.clear();
	}
};
function getPreviousIndex(item, addRemoveOffset, moveOffsets) {
	const previousIndex = item.previousIndex;
	if (previousIndex === null) return previousIndex;
	let moveOffset = 0;
	if (moveOffsets && previousIndex < moveOffsets.length) moveOffset = moveOffsets[previousIndex];
	return previousIndex + addRemoveOffset + moveOffset;
}
var DefaultKeyValueDifferFactory = class {
	supports(obj) {
		return obj instanceof Map || isJsObject(obj);
	}
	create() {
		return new DefaultKeyValueDiffer();
	}
};
var DefaultKeyValueDiffer = class {
	_records = /* @__PURE__ */ new Map();
	_mapHead = null;
	_appendAfter = null;
	_previousMapHead = null;
	_changesHead = null;
	_changesTail = null;
	_additionsHead = null;
	_additionsTail = null;
	_removalsHead = null;
	get isDirty() {
		return this._additionsHead !== null || this._changesHead !== null || this._removalsHead !== null;
	}
	forEachItem(fn) {
		let record;
		for (record = this._mapHead; record !== null; record = record._next) fn(record);
	}
	forEachPreviousItem(fn) {
		let record;
		for (record = this._previousMapHead; record !== null; record = record._nextPrevious) fn(record);
	}
	forEachChangedItem(fn) {
		let record;
		for (record = this._changesHead; record !== null; record = record._nextChanged) fn(record);
	}
	forEachAddedItem(fn) {
		let record;
		for (record = this._additionsHead; record !== null; record = record._nextAdded) fn(record);
	}
	forEachRemovedItem(fn) {
		let record;
		for (record = this._removalsHead; record !== null; record = record._nextRemoved) fn(record);
	}
	diff(map) {
		if (!map) map = /* @__PURE__ */ new Map();
		else if (!(map instanceof Map || isJsObject(map))) throw new RuntimeError(900, ngDevMode && `Error trying to diff '${stringify(map)}'. Only maps and objects are allowed`);
		return this.check(map) ? this : null;
	}
	check(map) {
		this._reset();
		let insertBefore = this._mapHead;
		this._appendAfter = null;
		this._forEach(map, (value, key) => {
			if (insertBefore && insertBefore.key === key) {
				this._maybeAddToChanges(insertBefore, value);
				this._appendAfter = insertBefore;
				insertBefore = insertBefore._next;
			} else {
				const record = this._getOrCreateRecordForKey(key, value);
				insertBefore = this._insertBeforeOrAppend(insertBefore, record);
			}
		});
		if (insertBefore) {
			if (insertBefore._prev) insertBefore._prev._next = null;
			this._removalsHead = insertBefore;
			for (let record = insertBefore; record !== null; record = record._nextRemoved) {
				if (record === this._mapHead) this._mapHead = null;
				this._records.delete(record.key);
				record._nextRemoved = record._next;
				record.previousValue = record.currentValue;
				record.currentValue = null;
				record._prev = null;
				record._next = null;
			}
		}
		if (this._changesTail) this._changesTail._nextChanged = null;
		if (this._additionsTail) this._additionsTail._nextAdded = null;
		return this.isDirty;
	}
	_insertBeforeOrAppend(before, record) {
		if (before) {
			const prev = before._prev;
			record._next = before;
			record._prev = prev;
			before._prev = record;
			if (prev) prev._next = record;
			if (before === this._mapHead) this._mapHead = record;
			this._appendAfter = before;
			return before;
		}
		if (this._appendAfter) {
			this._appendAfter._next = record;
			record._prev = this._appendAfter;
		} else this._mapHead = record;
		this._appendAfter = record;
		return null;
	}
	_getOrCreateRecordForKey(key, value) {
		if (this._records.has(key)) {
			const record = this._records.get(key);
			this._maybeAddToChanges(record, value);
			const prev = record._prev;
			const next = record._next;
			if (prev) prev._next = next;
			if (next) next._prev = prev;
			record._next = null;
			record._prev = null;
			return record;
		}
		const record = new KeyValueChangeRecord_(key);
		this._records.set(key, record);
		record.currentValue = value;
		this._addToAdditions(record);
		return record;
	}
	_reset() {
		if (this.isDirty) {
			let record;
			this._previousMapHead = this._mapHead;
			for (record = this._previousMapHead; record !== null; record = record._next) record._nextPrevious = record._next;
			for (record = this._changesHead; record !== null; record = record._nextChanged) record.previousValue = record.currentValue;
			for (record = this._additionsHead; record != null; record = record._nextAdded) record.previousValue = record.currentValue;
			this._changesHead = this._changesTail = null;
			this._additionsHead = this._additionsTail = null;
			this._removalsHead = null;
		}
	}
	_maybeAddToChanges(record, newValue) {
		if (!Object.is(newValue, record.currentValue)) {
			record.previousValue = record.currentValue;
			record.currentValue = newValue;
			this._addToChanges(record);
		}
	}
	_addToAdditions(record) {
		if (this._additionsHead === null) this._additionsHead = this._additionsTail = record;
		else {
			this._additionsTail._nextAdded = record;
			this._additionsTail = record;
		}
	}
	_addToChanges(record) {
		if (this._changesHead === null) this._changesHead = this._changesTail = record;
		else {
			this._changesTail._nextChanged = record;
			this._changesTail = record;
		}
	}
	_forEach(obj, fn) {
		if (obj instanceof Map) obj.forEach(fn);
		else Object.keys(obj).forEach((k) => fn(obj[k], k));
	}
};
var KeyValueChangeRecord_ = class {
	key;
	previousValue = null;
	currentValue = null;
	_nextPrevious = null;
	_next = null;
	_prev = null;
	_nextAdded = null;
	_nextRemoved = null;
	_nextChanged = null;
	constructor(key) {
		this.key = key;
	}
};
function defaultIterableDiffersFactory() {
	return new IterableDiffers([new DefaultIterableDifferFactory()]);
}
var IterableDiffers = class IterableDiffers {
	factories;
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: IterableDiffers,
		providedIn: "root",
		factory: defaultIterableDiffersFactory
	});
	constructor(factories) {
		this.factories = factories;
	}
	static create(factories, parent) {
		if (parent != null) {
			const copied = parent.factories.slice();
			factories = factories.concat(copied);
		}
		return new IterableDiffers(factories);
	}
	static extend(factories) {
		return {
			provide: IterableDiffers,
			useFactory: () => {
				const parent = inject(IterableDiffers, {
					optional: true,
					skipSelf: true
				});
				return IterableDiffers.create(factories, parent || defaultIterableDiffersFactory());
			}
		};
	}
	find(iterable) {
		const factory = this.factories.find((f) => f.supports(iterable));
		if (factory != null) return factory;
		else throw new RuntimeError(901, ngDevMode && `Cannot find a differ supporting object '${iterable}' of type '${getTypeNameForDebugging(iterable)}'`);
	}
};
function getTypeNameForDebugging(type) {
	return type["name"] || typeof type;
}
function defaultKeyValueDiffersFactory() {
	return new KeyValueDiffers([new DefaultKeyValueDifferFactory()]);
}
var KeyValueDiffers = class KeyValueDiffers {
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: KeyValueDiffers,
		providedIn: "root",
		factory: defaultKeyValueDiffersFactory
	});
	factories;
	constructor(factories) {
		this.factories = factories;
	}
	static create(factories, parent) {
		if (parent) {
			const copied = parent.factories.slice();
			factories = factories.concat(copied);
		}
		return new KeyValueDiffers(factories);
	}
	static extend(factories) {
		return {
			provide: KeyValueDiffers,
			useFactory: () => {
				const parent = inject(KeyValueDiffers, {
					optional: true,
					skipSelf: true
				});
				return KeyValueDiffers.create(factories, parent || defaultKeyValueDiffersFactory());
			}
		};
	}
	find(kv) {
		const factory = this.factories.find((f) => f.supports(kv));
		if (factory) return factory;
		throw new RuntimeError(901, ngDevMode && `Cannot find a differ supporting object '${kv}'`);
	}
};
var ChangeDetectorRef = class {
	static __NG_ELEMENT_ID__ = injectChangeDetectorRef;
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(ChangeDetectorRef);
function injectChangeDetectorRef(flags) {
	return createViewRef(getCurrentTNode(), getLView(), (flags & 16) === 16);
}
function createViewRef(tNode, lView, isPipe) {
	if (isComponentHost(tNode) && !isPipe) {
		const componentView = getComponentLViewByIndex(tNode.index, lView);
		return new ViewRef$1(componentView, componentView);
	} else if (tNode.type & 175) {
		const hostComponentView = lView[15];
		return new ViewRef$1(hostComponentView, lView);
	}
	return null;
}
var keyValDiff = [new DefaultKeyValueDifferFactory()];
var defaultIterableDiffers = new IterableDiffers([new DefaultIterableDifferFactory()]);
var defaultKeyValueDiffers = new KeyValueDiffers(keyValDiff);
function exhaustiveCheckNoChangesInterval(interval) {
	return provideEnvironmentInitializer(() => {
		const applicationRef = inject(ApplicationRef);
		const errorHandler = inject(ErrorHandler);
		const scheduler = inject(ChangeDetectionSchedulerImpl);
		const ngZone = inject(NgZone);
		function scheduleCheckNoChanges() {
			ngZone.runOutsideAngular(() => {
				setTimeout(() => {
					if (applicationRef.destroyed) return;
					if (scheduler.pendingRenderTaskId || scheduler.runningTick) {
						scheduleCheckNoChanges();
						return;
					}
					for (const view of applicationRef.allViews) try {
						checkNoChangesInternal(view._lView, true);
					} catch (e) {
						errorHandler.handleError(e);
					}
					scheduleCheckNoChanges();
				}, interval);
			});
		}
		scheduleCheckNoChanges();
	});
}
function provideCheckNoChangesConfig(options) {
	return makeEnvironmentProviders(typeof ngDevMode === "undefined" || ngDevMode ? [{
		provide: UseExhaustiveCheckNoChanges,
		useValue: options.exhaustive
	}, options?.interval !== void 0 ? exhaustiveCheckNoChangesInterval(options.interval) : []] : []);
}
var NgZoneChangeDetectionScheduler = class NgZoneChangeDetectionScheduler {
	zone = inject(NgZone);
	changeDetectionScheduler = inject(ChangeDetectionScheduler);
	applicationRef = inject(ApplicationRef);
	applicationErrorHandler = inject(INTERNAL_APPLICATION_ERROR_HANDLER);
	_onMicrotaskEmptySubscription;
	initialize() {
		if (this._onMicrotaskEmptySubscription) return;
		this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({ next: () => {
			if (this.changeDetectionScheduler.runningTick) return;
			this.zone.run(() => {
				try {
					this.applicationRef.dirtyFlags |= 1;
					this.applicationRef._tick();
				} catch (e) {
					this.applicationErrorHandler(e);
				}
			});
		} });
	}
	ngOnDestroy() {
		this._onMicrotaskEmptySubscription?.unsubscribe();
	}
	static ɵfac = function NgZoneChangeDetectionScheduler_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || NgZoneChangeDetectionScheduler)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: NgZoneChangeDetectionScheduler,
		factory: NgZoneChangeDetectionScheduler.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgZoneChangeDetectionScheduler, [{ type: Service }], null, null);
})();
var PROVIDED_NG_ZONE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "provideZoneChangeDetection token" : "", { factory: () => false });
function internalProvideZoneChangeDetection({ ngZoneFactory, scheduleInRootZone }) {
	ngZoneFactory ??= () => new NgZone({
		...getNgZoneOptions(),
		scheduleInRootZone
	});
	return [
		{
			provide: ZONELESS_ENABLED,
			useValue: false
		},
		{
			provide: NgZone,
			useFactory: ngZoneFactory
		},
		{
			provide: ENVIRONMENT_INITIALIZER,
			multi: true,
			useFactory: () => {
				const ngZoneChangeDetectionScheduler = inject(NgZoneChangeDetectionScheduler, { optional: true });
				if ((typeof ngDevMode === "undefined" || ngDevMode) && ngZoneChangeDetectionScheduler === null) throw new RuntimeError(402, "A required Injectable was not found in the dependency injection tree. If you are bootstrapping an NgModule, make sure that the `BrowserModule` is imported.");
				return () => ngZoneChangeDetectionScheduler.initialize();
			}
		},
		{
			provide: ENVIRONMENT_INITIALIZER,
			multi: true,
			useFactory: () => {
				const service = inject(ZoneStablePendingTask);
				return () => {
					service.initialize();
				};
			}
		},
		{
			provide: SCHEDULE_IN_ROOT_ZONE,
			useValue: scheduleInRootZone ?? false
		}
	];
}
function provideZoneChangeDetection(options) {
	const scheduleInRootZone = options?.scheduleInRootZone;
	const zoneProviders = internalProvideZoneChangeDetection({
		ngZoneFactory: () => {
			const ngZoneOptions = getNgZoneOptions(options);
			ngZoneOptions.scheduleInRootZone = scheduleInRootZone;
			if (ngZoneOptions.shouldCoalesceEventChangeDetection) performanceMarkFeature("NgZone_CoalesceEvent");
			return new NgZone(ngZoneOptions);
		},
		scheduleInRootZone
	});
	return makeEnvironmentProviders([{
		provide: PROVIDED_NG_ZONE,
		useValue: true
	}, zoneProviders]);
}
function getNgZoneOptions(options) {
	return {
		enableLongStackTrace: typeof ngDevMode === "undefined" ? false : !!ngDevMode,
		shouldCoalesceEventChangeDetection: options?.eventCoalescing ?? false,
		shouldCoalesceRunChangeDetection: options?.runCoalescing ?? false
	};
}
var ZoneStablePendingTask = class ZoneStablePendingTask {
	subscription = new import_cjs.Subscription();
	initialized = false;
	zone = inject(NgZone);
	pendingTasks = inject(PendingTasksInternal);
	initialize() {
		if (this.initialized) return;
		this.initialized = true;
		let task = null;
		if (!this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks) task = this.pendingTasks.add();
		this.zone.runOutsideAngular(() => {
			this.subscription.add(this.zone.onStable.subscribe(() => {
				NgZone.assertNotInAngularZone();
				queueMicrotask(() => {
					if (task !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks) {
						this.pendingTasks.remove(task);
						task = null;
					}
				});
			}));
		});
		this.subscription.add(this.zone.onUnstable.subscribe(() => {
			NgZone.assertInAngularZone();
			task ??= this.pendingTasks.add();
		}));
	}
	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
	static ɵfac = function ZoneStablePendingTask_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ZoneStablePendingTask)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: ZoneStablePendingTask,
		factory: ZoneStablePendingTask.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ZoneStablePendingTask, [{ type: Service }], null, null);
})();
function compileNgModuleFactory(injector, options, moduleType) {
	ngDevMode && assertNgModuleType(moduleType);
	const moduleFactory = new NgModuleFactory(moduleType);
	return Promise.resolve(moduleFactory);
}
var OVERSIZED_IMAGE_TOLERANCE = 1200;
var ImagePerformanceWarning = class ImagePerformanceWarning {
	window = null;
	observer = null;
	options = inject(IMAGE_CONFIG);
	lcpImageUrl;
	start() {}
	ngOnDestroy() {
		this.observer?.disconnect();
	}
	initPerformanceObserver() {
		if (typeof PerformanceObserver === "undefined") return null;
		const observer = new PerformanceObserver((entryList) => {
			const entries = entryList.getEntries();
			if (entries.length === 0) return;
			const imgSrc = entries[entries.length - 1].element?.src ?? "";
			if (imgSrc.startsWith("data:") || imgSrc.startsWith("blob:")) return;
			this.lcpImageUrl = imgSrc;
		});
		observer.observe({
			type: "largest-contentful-paint",
			buffered: true
		});
		return observer;
	}
	scanImages() {
		const images = getDocument().querySelectorAll("img");
		let lcpElementFound, lcpElementLoadedCorrectly = false;
		for (let index = 0; index < images.length; index++) {
			const image = images[index];
			if (!image) continue;
			if (!this.options?.disableImageSizeWarning) {
				if (!image.getAttribute("ng-img") && this.isOversized(image)) logOversizedImageWarning(image.src);
			}
			if (!this.options?.disableImageLazyLoadWarning && this.lcpImageUrl) {
				if (image.src === this.lcpImageUrl) {
					lcpElementFound = true;
					if (image.loading !== "lazy" || image.getAttribute("ng-img")) lcpElementLoadedCorrectly = true;
				}
			}
		}
		if (lcpElementFound && !lcpElementLoadedCorrectly && this.lcpImageUrl && !this.options?.disableImageLazyLoadWarning) logLazyLCPWarning(this.lcpImageUrl);
	}
	isOversized(image) {
		if (!this.window) return false;
		const nonOversizedImageExtentions = [".svg"];
		const imageSource = (image.src || "").toLowerCase();
		if (nonOversizedImageExtentions.some((extension) => imageSource.endsWith(extension))) return false;
		const computedStyle = this.window.getComputedStyle(image);
		let renderedWidth = parseFloat(computedStyle.getPropertyValue("width"));
		let renderedHeight = parseFloat(computedStyle.getPropertyValue("height"));
		const boxSizing = computedStyle.getPropertyValue("box-sizing");
		if (computedStyle.getPropertyValue("object-fit") === `cover`) return false;
		if (boxSizing === "border-box") {
			const paddingTop = computedStyle.getPropertyValue("padding-top");
			const paddingRight = computedStyle.getPropertyValue("padding-right");
			const paddingBottom = computedStyle.getPropertyValue("padding-bottom");
			const paddingLeft = computedStyle.getPropertyValue("padding-left");
			renderedWidth -= parseFloat(paddingRight) + parseFloat(paddingLeft);
			renderedHeight -= parseFloat(paddingTop) + parseFloat(paddingBottom);
		}
		const intrinsicWidth = image.naturalWidth;
		const intrinsicHeight = image.naturalHeight;
		const recommendedWidth = this.window.devicePixelRatio * renderedWidth;
		const recommendedHeight = this.window.devicePixelRatio * renderedHeight;
		const oversizedWidth = intrinsicWidth - recommendedWidth >= OVERSIZED_IMAGE_TOLERANCE;
		const oversizedHeight = intrinsicHeight - recommendedHeight >= OVERSIZED_IMAGE_TOLERANCE;
		return oversizedWidth || oversizedHeight;
	}
	static ɵfac = function ImagePerformanceWarning_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ImagePerformanceWarning)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: ImagePerformanceWarning,
		factory: ImagePerformanceWarning.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ImagePerformanceWarning, [{ type: Service }], null, null);
})();
function logLazyLCPWarning(src) {
	console.warn(formatRuntimeError(-913, `An image with src ${src} is the Largest Contentful Paint (LCP) element but was given a "loading" value of "lazy", which can negatively impact application loading performance. This warning can be addressed by changing the loading value of the LCP image to "eager", or by using the NgOptimizedImage directive's prioritization utilities. For more information about addressing or disabling this warning, see ${ERROR_DETAILS_PAGE_BASE_URL}/NG0913`));
}
function logOversizedImageWarning(src) {
	console.warn(formatRuntimeError(-913, `An image with src ${src} has intrinsic file dimensions much larger than its rendered size. This can negatively impact application loading performance. For more information about addressing or disabling this warning, see ${ERROR_DETAILS_PAGE_BASE_URL}/NG0913`));
}
var PLATFORM_DESTROY_LISTENERS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "PlatformDestroyListeners" : "");
var ENABLE_ROOT_COMPONENT_BOOTSTRAP = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ENABLE_ROOT_COMPONENT_BOOTSTRAP" : "");
function isApplicationBootstrapConfig(config) {
	return !config.moduleRef;
}
function bootstrap(config) {
	const envInjector = isApplicationBootstrapConfig(config) ? config.r3Injector : config.moduleRef.injector;
	const ngZone = envInjector.get(NgZone);
	return ngZone.run(() => {
		if (isApplicationBootstrapConfig(config)) config.r3Injector.resolveInjectorInitializers();
		else config.moduleRef.resolveInjectorInitializers();
		const exceptionHandler = envInjector.get(INTERNAL_APPLICATION_ERROR_HANDLER);
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			if (envInjector.get(PROVIDED_ZONELESS) && envInjector.get(PROVIDED_NG_ZONE)) console.warn(formatRuntimeError(408, "Both provideZoneChangeDetection and provideZonelessChangeDetection are provided. This is likely a mistake. Update the application providers to use only one of the two."));
		}
		let onErrorSubscription;
		ngZone.runOutsideAngular(() => {
			onErrorSubscription = ngZone.onError.subscribe({ next: exceptionHandler });
		});
		if (isApplicationBootstrapConfig(config)) {
			const destroyListener = () => envInjector.destroy();
			const onPlatformDestroyListeners = config.platformInjector.get(PLATFORM_DESTROY_LISTENERS);
			onPlatformDestroyListeners.add(destroyListener);
			envInjector.onDestroy(() => {
				onErrorSubscription.unsubscribe();
				onPlatformDestroyListeners.delete(destroyListener);
			});
		} else {
			const destroyListener = () => config.moduleRef.destroy();
			const onPlatformDestroyListeners = config.platformInjector.get(PLATFORM_DESTROY_LISTENERS);
			onPlatformDestroyListeners.add(destroyListener);
			config.moduleRef.onDestroy(() => {
				remove(config.allPlatformModules, config.moduleRef);
				onErrorSubscription.unsubscribe();
				onPlatformDestroyListeners.delete(destroyListener);
			});
		}
		return _callAndReportToErrorHandler(exceptionHandler, ngZone, () => {
			const pendingTasks = envInjector.get(PendingTasksInternal);
			const taskId = pendingTasks.add();
			const initStatus = envInjector.get(ApplicationInitStatus);
			initStatus.runInitializers();
			return initStatus.donePromise.then(() => {
				setLocaleId(envInjector.get(LOCALE_ID, DEFAULT_LOCALE_ID) || "en-US");
				if (!envInjector.get(ENABLE_ROOT_COMPONENT_BOOTSTRAP, true)) {
					if (isApplicationBootstrapConfig(config)) return envInjector.get(ApplicationRef);
					config.allPlatformModules.push(config.moduleRef);
					return config.moduleRef;
				}
				if (typeof ngDevMode === "undefined" || ngDevMode) envInjector.get(ImagePerformanceWarning).start();
				if (isApplicationBootstrapConfig(config)) {
					const appRef = envInjector.get(ApplicationRef);
					if (config.rootComponent !== void 0) appRef.bootstrap(config.rootComponent);
					return appRef;
				} else {
					moduleBootstrapImpl?.(config.moduleRef, config.allPlatformModules);
					return config.moduleRef;
				}
			}).finally(() => void pendingTasks.remove(taskId));
		});
	});
}
var moduleBootstrapImpl;
function setModuleBootstrapImpl() {
	moduleBootstrapImpl = _moduleDoBootstrap;
}
function _moduleDoBootstrap(moduleRef, allPlatformModules) {
	const appRef = moduleRef.injector.get(ApplicationRef);
	if (moduleRef._bootstrapComponents.length > 0) moduleRef._bootstrapComponents.forEach((f) => appRef.bootstrap(f));
	else if (moduleRef.instance.ngDoBootstrap) moduleRef.instance.ngDoBootstrap(appRef);
	else throw new RuntimeError(-403, ngDevMode && `The module ${stringify(moduleRef.instance.constructor)} was bootstrapped, but it does not declare "@NgModule.bootstrap" components nor a "ngDoBootstrap" method. Please define one of these.`);
	allPlatformModules.push(moduleRef);
}
function _callAndReportToErrorHandler(errorHandler, ngZone, callback) {
	try {
		const result = callback();
		if (isPromise(result)) return result.catch((e) => {
			ngZone.runOutsideAngular(() => errorHandler(e));
			throw e;
		});
		return result;
	} catch (e) {
		ngZone.runOutsideAngular(() => errorHandler(e));
		throw e;
	}
}
var PlatformRef = class PlatformRef {
	_injector;
	_modules = [];
	_destroyListeners = [];
	_destroyed = false;
	constructor(_injector) {
		this._injector = _injector;
	}
	bootstrapModuleFactory(moduleFactory, options) {
		const allAppProviders = [
			provideZonelessChangeDetectionInternal(),
			...options?.applicationProviders ?? [],
			errorHandlerEnvironmentInitializer,
			...ngDevMode ? [validAppIdInitializer] : []
		];
		const moduleRef = createNgModuleRefWithProviders(moduleFactory.moduleType, this.injector, allAppProviders);
		setModuleBootstrapImpl();
		return bootstrap({
			moduleRef,
			allPlatformModules: this._modules,
			platformInjector: this.injector
		});
	}
	bootstrapModule(moduleType, compilerOptions = []) {
		const options = optionsReducer({}, compilerOptions);
		setModuleBootstrapImpl();
		return compileNgModuleFactory(this.injector, options, moduleType).then((moduleFactory) => this.bootstrapModuleFactory(moduleFactory, options));
	}
	onDestroy(callback) {
		this._destroyListeners.push(callback);
	}
	get injector() {
		return this._injector;
	}
	destroy() {
		if (this._destroyed) throw new RuntimeError(404, ngDevMode && "The platform has already been destroyed!");
		this._modules.slice().forEach((module) => module.destroy());
		this._destroyListeners.forEach((listener) => listener());
		const destroyListeners = this._injector.get(PLATFORM_DESTROY_LISTENERS, null);
		if (destroyListeners) {
			destroyListeners.forEach((listener) => listener());
			destroyListeners.clear();
		}
		this._destroyed = true;
	}
	get destroyed() {
		return this._destroyed;
	}
	static ɵfac = function PlatformRef_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || PlatformRef)(ɵɵinject(Injector));
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: PlatformRef,
		factory: PlatformRef.ɵfac,
		providedIn: "platform"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PlatformRef, [{
		type: Injectable,
		args: [{ providedIn: "platform" }]
	}], () => [{ type: Injector }], null);
})();
function serializeInjector(injector) {
	const metadata = getInjectorMetadata(injector);
	if (metadata?.type === "null") return {
		name: "Null Injector",
		type: "null",
		providers: [],
		children: []
	};
	let allProviders = [];
	if (metadata?.type === "element" || metadata?.type === "environment") allProviders = getInjectorProviders(injector).map((record) => {
		return {
			token: record.token,
			value: injector.get(record.token, null, {
				optional: true,
				self: true
			})
		};
	});
	if (metadata?.type === "element") {
		const tNode = getNodeInjectorTNode(injector);
		const viewProvidersCount = tNode ? tNode.providerIndexes >> 20 : 0;
		const viewProviders = allProviders.slice(0, viewProvidersCount);
		const resolvedProviders = allProviders.slice(viewProvidersCount);
		return {
			name: injector.constructor.name,
			type: "element",
			providers: resolvedProviders,
			viewProviders,
			children: [],
			hostElement: metadata.source
		};
	}
	return {
		name: metadata?.source ?? injector.constructor.name ?? "Unknown Injector",
		type: "environment",
		providers: allProviders,
		children: []
	};
}
var diGraphTool = {
	name: "angular:di_graph",
	description: `
Exposes the Angular Dependency Injection (DI) graph of the application.

This tool extracts both the element injector tree (associated with DOM elements and components)
and the environment injector tree (associated with modules and standalone application roots).
It captures the relationship structure and the providers resolved at each level.

Returns:
- \`elementInjectorRoots\`: An array of root element injectors (one for each Angular application
  root found). Each node forms a tree hierarchy:
  - \`name\`: The constructor name of this injector.
  - \`type\`: 'element'.
  - \`providers\`: Array of providers configured on this injector.
    - \`token\`: The DI token.
    - \`value\`: The resolved value of that provider if it was instantiated.
  - \`hostElement\`: The DOM element that this injector is associated with.
  - \`children\`: Array of child element injectors.
- \`environmentInjectorRoot\`: The root environment injector. It forms a tree hierarchy of nodes
  representing all environment injectors:
  - \`name\`: The identifier for the environment injector.
  - \`type\`: 'environment' or 'null'.
  - \`providers\`: Array of providers configured on this injector.
    - \`token\`: The DI token.
    - \`value\`: The resolved value of that provider if it was instantiated.
  - \`children\`: Array of child environment injectors.
  `.trim(),
	inputSchema: {
		type: "object",
		properties: {}
	},
	execute: async () => {
		const roots = Array.from(document.querySelectorAll("[ng-version]"));
		if (roots.length === 0) throw new Error("Could not find Angular root element ([ng-version]) on the page.");
		return discoverDiGraph(roots);
	}
};
function discoverDiGraph(roots) {
	const rootLViews = roots.map((root) => {
		const lContext = getLContext(root);
		if (!lContext?.lView) throw new Error(`Could not find an \`LView\` for root \`<${root.tagName.toLowerCase()}>\`, is it an Angular component?`);
		return lContext.lView;
	});
	return {
		elementInjectorRoots: rootLViews.map((rootLView) => walkElementInjectors(rootLView)),
		environmentInjectorRoot: collectEnvInjectors(rootLViews)
	};
}
function walkElementInjectors(rootLView) {
	if (rootLView[1].type !== 0) throw new Error(`Expected a root LView but got type: \`${rootLView[1].type}\`.`);
	const stack = [];
	for (const [tNode, lView] of walkLViewDirectives(rootLView)) {
		const serialized = serializeInjector(new NodeInjector(tNode, lView));
		while (stack.length > 0) {
			const [lastTNode, lastLView, lastInjector] = stack[stack.length - 1];
			const isDescendantInSameView = isTNodeDescendant(tNode, lastTNode);
			const isDescendantInDifferentView = isLViewDescendantOfTNode(lView, lastLView, lastTNode);
			if (isDescendantInSameView || isDescendantInDifferentView) {
				lastInjector.children.push(serialized);
				break;
			} else stack.pop();
		}
		stack.push([
			tNode,
			lView,
			serialized
		]);
	}
	if (stack.length === 0) throw new Error(`Expected at least one component/directive in the root \`LView\`.`);
	const [, , rootInjector] = stack[0];
	return rootInjector;
}
function collectEnvInjectors(rootLViews) {
	const serializedEnvInjectorMap = /* @__PURE__ */ new Map();
	let rootEnvInjector = void 0;
	function serializeAncestors(injector) {
		const existing = serializedEnvInjectorMap.get(injector);
		if (existing) return existing;
		const serialized = serializeInjector(injector);
		serializedEnvInjectorMap.set(injector, serialized);
		const parentInjector = getParentEnvInjector(injector);
		if (parentInjector) serializeAncestors(parentInjector).children.push(serialized);
		else if (!rootEnvInjector) rootEnvInjector = serialized;
		else if (rootEnvInjector !== serialized) throw new Error("Expected only one root environment injector, but found multiple.", { cause: {
			firstRoot: rootEnvInjector,
			secondRoot: serialized
		} });
		return serialized;
	}
	for (const rootLView of rootLViews) for (const [, lView] of walkLViewDirectives(rootLView)) serializeAncestors(lView[9]);
	if (!rootEnvInjector) throw new Error("Expected a root environment injector but did not find one.");
	return rootEnvInjector;
}
function isTNodeDescendant(node, ancestor) {
	let curr = node;
	while (curr) {
		if (curr === ancestor) return true;
		curr = curr.parent;
	}
	return false;
}
function isLViewDescendantOfTNode(lView, parentLView, parentTNode) {
	let currentLView = lView;
	let hostTNode = null;
	while (currentLView && currentLView !== parentLView) {
		hostTNode = currentLView[5];
		currentLView = getLViewParent(currentLView);
	}
	return currentLView === parentLView && hostTNode !== null && isTNodeDescendant(hostTNode, parentTNode);
}
function getParentEnvInjector(injector) {
	if (injector instanceof ChainedInjector) return injector.parentInjector;
	else if (injector instanceof R3Injector) return injector.parent;
	else if (injector instanceof NullInjector) return;
	else throw new Error(`Unknown injector type: "${injector.constructor.name}".`);
}
var signalGraphTool = {
	name: "angular:signal_graph",
	description: `
Exposes the Angular signal dependency graph for a given DOM element.

This tool extracts the reactive dependency graph (signals, computeds, and effects) that
are transitive dependencies of the effects of that element. It will include signals
authored in other components/services and depended upon by the target component, but
will *not* include signals only used in descendant components effects.

Params:
- \`target\`: The element to get the signal graph for. Must be the host element of an
  Angular component.

Returns:
- \`nodes\`: An array of reactive nodes discovered in the context. Each node contains:
  - \`kind\`: The type of reactive node ('signal', 'computed', 'effect', or 'template'
    for component template effects).
  - \`value\`: The current evaluated value of the node (if applicable).
  - \`label\`: The symbol name of the associated signal if available (ex.
    \`const foo = signal(0);\` has \`label: 'foo'\`).
  - \`epoch\`: The internal version number of the node's value.
- \`edges\`: An array of dependency links representing which nodes read from which other
  nodes.
  - \`consumer\`: The index in the \`nodes\` array of the node that depends on the value.
  - \`producer\`: The index in the \`nodes\` array of the node that provides the value.

Example: An edge with \`{consumer: 2, producer: 0}\` means that \`nodes[2]\` (e.g. an
\`effect\`) reads the value of \`nodes[0]\` (e.g. a \`signal\`).
  `.trim(),
	inputSchema: {
		type: "object",
		properties: { target: {
			type: "object",
			description: "The element to get the signal graph for.",
			"x-mcp-type": "HTMLElement"
		} },
		required: ["target"]
	},
	execute: async ({ target }) => {
		if (!(target instanceof HTMLElement)) throw new Error("Invalid input: \"target\" must be an HTMLElement.");
		const injector = getInjector(target);
		if (injector instanceof NullInjector) throw new Error("Invalid input: \"target\" is not the host element of an Angular component.");
		const graph = getSignalGraph(injector);
		return {
			nodes: graph.nodes.map(({ id, debuggableFn, ...node }) => node),
			edges: graph.edges
		};
	}
};
function registerAiTools() {
	if (typeof window === "undefined" || !window.addEventListener) return () => {};
	function listener(inputEvent) {
		inputEvent.respondWith({
			name: "Angular",
			tools: [diGraphTool, signalGraphTool]
		});
	}
	window.addEventListener("devtoolstooldiscovery", listener);
	return () => {
		window.removeEventListener("devtoolstooldiscovery", listener);
	};
}
var _platformInjector = null;
var _unregisterAiTools = null;
function createPlatform(injector) {
	if (getPlatform()) throw new RuntimeError(400, ngDevMode && "There can be only one platform. Destroy the previous one to create a new one.");
	publishDefaultGlobalUtils();
	publishSignalConfiguration();
	if (typeof ngDevMode !== "undefined" && ngDevMode) _unregisterAiTools = registerAiTools();
	_platformInjector = null;
	const platform = injector.get(PlatformRef);
	runPlatformInitializers(injector);
	return platform;
}
function createPlatformFactory(parentPlatformFactory, name, providers = []) {
	const desc = `Platform: ${name}`;
	const marker = new InjectionToken(desc);
	return (extraProviders = []) => {
		let platform = getPlatform();
		if (!platform) {
			const platformProviders = [
				...providers,
				...extraProviders,
				{
					provide: marker,
					useValue: true
				}
			];
			platform = parentPlatformFactory?.(platformProviders) ?? createPlatform(createPlatformInjector(platformProviders, desc));
		}
		return platform;
	};
}
function createPlatformInjector(providers = [], name) {
	return Injector.create({
		name,
		providers: [
			{
				provide: INJECTOR_SCOPE,
				useValue: "platform"
			},
			{
				provide: PLATFORM_DESTROY_LISTENERS,
				useValue: /* @__PURE__ */ new Set([() => _platformInjector = null])
			},
			...providers
		]
	});
}
function assertPlatform(requiredToken) {
	const platform = getPlatform();
	if (!platform) throw new RuntimeError(-401, ngDevMode && "No platform exists!");
	if ((typeof ngDevMode === "undefined" || ngDevMode) && !platform.injector.get(requiredToken, null)) throw new RuntimeError(400, "A platform with a different configuration has been created. Please destroy it first.");
	return platform;
}
function getPlatform() {
	return null;
}
function destroyPlatform() {
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		_unregisterAiTools?.();
		_unregisterAiTools = null;
	}
	getPlatform()?.destroy();
}
function createOrReusePlatformInjector(providers = []) {
	if (_platformInjector) return _platformInjector;
	publishDefaultGlobalUtils();
	if (typeof ngDevMode !== "undefined" && ngDevMode) _unregisterAiTools = registerAiTools();
	const injector = createPlatformInjector(providers);
	publishSignalConfiguration();
	runPlatformInitializers(injector);
	return injector;
}
function providePlatformInitializer(initializerFn) {
	return {
		provide: PLATFORM_INITIALIZER,
		useValue: initializerFn,
		multi: true
	};
}
function runPlatformInitializers(injector) {
	const inits = injector.get(PLATFORM_INITIALIZER, null);
	runInInjectionContext(injector, () => {
		inits?.forEach((init) => init());
	});
}
function internalCreateApplication(config) {
	const { rootComponent, appProviders, platformProviders, platformRef } = config;
	profiler(ProfilerEvent.BootstrapApplicationStart);
	if (!platformRef) throw new RuntimeError(-401, ngDevMode && "Missing Platform: This may be due to using `bootstrapApplication` on the server without passing a `BootstrapContext`. Please make sure that `bootstrapApplication` is called with a `context` argument.");
	try {
		const platformInjector = platformRef?.injector ?? createOrReusePlatformInjector(platformProviders);
		if ((typeof ngDevMode === "undefined" || ngDevMode) && rootComponent !== void 0) assertStandaloneComponentType(rootComponent);
		return bootstrap({
			r3Injector: new EnvironmentNgModuleRefAdapter({
				providers: [
					provideZonelessChangeDetectionInternal(),
					errorHandlerEnvironmentInitializer,
					...ngDevMode ? [validAppIdInitializer] : [],
					...appProviders || []
				],
				parent: platformInjector,
				debugName: typeof ngDevMode === "undefined" || ngDevMode ? "Environment Injector" : "",
				runEnvironmentInitializers: false
			}).injector,
			platformInjector,
			rootComponent
		});
	} catch (e) {
		return Promise.reject(e);
	} finally {
		profiler(ProfilerEvent.BootstrapApplicationEnd);
	}
}
var SerializedViewCollection = class {
	views = [];
	indexByContent = /* @__PURE__ */ new Map();
	add(serializedView) {
		const viewAsString = JSON.stringify(serializedView);
		if (!this.indexByContent.has(viewAsString)) {
			const index = this.views.length;
			this.views.push(serializedView);
			this.indexByContent.set(viewAsString, index);
			return index;
		}
		return this.indexByContent.get(viewAsString);
	}
	getAll() {
		return this.views;
	}
};
var tViewSsrId = 0;
function getSsrId(tView) {
	if (!tView.ssrId) tView.ssrId = `t${tViewSsrId++}`;
	return tView.ssrId;
}
function calcNumRootNodes(tView, lView, tNode) {
	const rootNodes = [];
	collectNativeNodes(tView, lView, tNode, rootNodes);
	return rootNodes.length;
}
function calcNumRootNodesInLContainer(lContainer) {
	const rootNodes = [];
	collectNativeNodesInLContainer(lContainer, rootNodes);
	return rootNodes.length;
}
function annotateComponentLViewForHydration(lView, context) {
	const hostElement = lView[0];
	if (hostElement && !hostElement.hasAttribute("ngSkipHydration")) return annotateHostElementForHydration(hostElement, lView, null, context);
	return null;
}
function annotateLContainerForHydration(lContainer, context) {
	const componentLView = unwrapLView(lContainer[0]);
	const componentLViewNghIndex = annotateComponentLViewForHydration(componentLView, context);
	if (componentLViewNghIndex === null) return;
	const hostElement = unwrapRNode(componentLView[0]);
	const rootLView = lContainer[3];
	const rootLViewNghIndex = annotateHostElementForHydration(hostElement, rootLView, null, context);
	const renderer = componentLView[11];
	const finalIndex = `${componentLViewNghIndex}|${rootLViewNghIndex}`;
	renderer.setAttribute(hostElement, "ngh", finalIndex);
}
function annotateForHydration(appRef, doc) {
	const injector = appRef.injector;
	const isI18nHydrationEnabledVal = isI18nHydrationEnabled(injector);
	const isIncrementalHydrationEnabledVal = isIncrementalHydrationEnabled(injector);
	const serializedViewCollection = new SerializedViewCollection();
	const corruptedTextNodes = /* @__PURE__ */ new Map();
	const viewRefs = appRef._views;
	const shouldReplayEvents = injector.get(IS_EVENT_REPLAY_ENABLED, false);
	const eventTypesToReplay = {
		regular: /* @__PURE__ */ new Set(),
		capture: /* @__PURE__ */ new Set()
	};
	const deferBlocks = /* @__PURE__ */ new Map();
	appRef.injector.get(APP_ID);
	for (const viewRef of viewRefs) {
		const lNode = getLNodeForHydration(viewRef);
		if (lNode !== null) {
			const context = {
				serializedViewCollection,
				corruptedTextNodes,
				isI18nHydrationEnabled: isI18nHydrationEnabledVal,
				isIncrementalHydrationEnabled: isIncrementalHydrationEnabledVal,
				i18nChildren: /* @__PURE__ */ new Map(),
				eventTypesToReplay,
				shouldReplayEvents,
				deferBlocks
			};
			if (isLContainer(lNode)) annotateLContainerForHydration(lNode, context);
			else annotateComponentLViewForHydration(lNode, context);
			insertCorruptedTextNodeMarkers(corruptedTextNodes, doc);
		}
	}
	const serializedViews = serializedViewCollection.getAll();
	const transferState = injector.get(TransferState);
	transferState.set(NGH_DATA_KEY, serializedViews);
	if (deferBlocks.size > 0) {
		const blocks = {};
		for (const [id, info] of deferBlocks.entries()) blocks[id] = info;
		transferState.set(NGH_DEFER_BLOCKS_KEY, blocks);
	}
	return eventTypesToReplay;
}
function serializeLContainer(lContainer, tNode, lView, parentDeferBlockId, context) {
	const views = [];
	let lastViewAsString = "";
	for (let i = 10; i < lContainer.length; i++) {
		let childLView = lContainer[i];
		let template;
		let numRootNodes;
		let serializedView;
		if (isRootView(childLView)) {
			childLView = childLView[28];
			if (isLContainer(childLView)) {
				numRootNodes = calcNumRootNodesInLContainer(childLView) + 2;
				annotateLContainerForHydration(childLView, context);
				const componentLView = unwrapLView(childLView[0]);
				serializedView = {
					["i"]: componentLView[1].ssrId,
					["r"]: numRootNodes
				};
			}
		}
		if (!serializedView) {
			const childTView = childLView[1];
			if (childTView.type === 1) {
				template = childTView.ssrId;
				numRootNodes = 1;
			} else {
				template = getSsrId(childTView);
				numRootNodes = calcNumRootNodes(childTView, childLView, childTView.firstChild);
			}
			serializedView = {
				["i"]: template,
				["r"]: numRootNodes
			};
			let isHydrateNeverBlock = false;
			if (isDeferBlock(lView[1], tNode)) {
				const lDetails = getLDeferBlockDetails(lView, tNode);
				const tDetails = getTDeferBlockDetails(lView[1], tNode);
				if (context.isIncrementalHydrationEnabled && tDetails.hydrateTriggers !== null) {
					const deferBlockId = `d${context.deferBlocks.size}`;
					if (tDetails.hydrateTriggers.has(7)) isHydrateNeverBlock = true;
					let rootNodes = [];
					collectNativeNodesInLContainer(lContainer, rootNodes);
					const deferBlockInfo = {
						["r"]: rootNodes.length,
						["s"]: lDetails[1]
					};
					const serializedTriggers = serializeHydrateTriggers(tDetails.hydrateTriggers);
					if (serializedTriggers.length > 0) deferBlockInfo["t"] = serializedTriggers;
					if (parentDeferBlockId !== null) deferBlockInfo["p"] = parentDeferBlockId;
					context.deferBlocks.set(deferBlockId, deferBlockInfo);
					const node = unwrapRNode(lContainer);
					if (node !== void 0) {
						if (node.nodeType === Node.COMMENT_NODE) annotateDeferBlockAnchorForHydration(node, deferBlockId);
					} else {
						ngDevMode && validateNodeExists(node, childLView, tNode);
						ngDevMode && validateMatchingNode(node, Node.COMMENT_NODE, null, childLView, tNode, true);
						annotateDeferBlockAnchorForHydration(node, deferBlockId);
					}
					if (!isHydrateNeverBlock) annotateDeferBlockRootNodesWithJsAction(tDetails, rootNodes, deferBlockId, context);
					parentDeferBlockId = deferBlockId;
					serializedView["di"] = deferBlockId;
				}
				serializedView["s"] = lDetails[1];
			}
			if (!isHydrateNeverBlock) {
				const childHostElement = unwrapRNode(childLView[0]);
				if (childLView[1].type !== 1 || childHostElement === null || !childHostElement.hasAttribute("ngSkipHydration")) Object.assign(serializedView, serializeLView(lContainer[i], parentDeferBlockId, context));
			}
		}
		const currentViewAsString = JSON.stringify(serializedView);
		if (views.length > 0 && currentViewAsString === lastViewAsString) {
			const previousView = views[views.length - 1];
			previousView["x"] ??= 1;
			previousView["x"]++;
		} else {
			lastViewAsString = currentViewAsString;
			views.push(serializedView);
		}
	}
	return views;
}
function serializeHydrateTriggers(triggerMap) {
	const serializableDeferBlockTrigger = /* @__PURE__ */ new Set([
		0,
		1,
		2,
		5
	]);
	let triggers = [];
	for (let [trigger, details] of triggerMap) if (serializableDeferBlockTrigger.has(trigger)) {
		if (details === null) triggers.push(trigger);
		else if (details.type === 5) triggers.push({
			trigger,
			delay: details.delay
		});
		else triggers.push({
			trigger,
			intersectionObserverOptions: details.intersectionObserverOptions
		});
	}
	return triggers;
}
function appendSerializedNodePath(ngh, tNode, lView, excludedParentNodes) {
	const noOffsetIndex = tNode.index - 28;
	ngh["n"] ??= {};
	ngh["n"][noOffsetIndex] ??= calcPathForNode(tNode, lView, excludedParentNodes);
}
function appendDisconnectedNodeIndex(ngh, tNodeOrNoOffsetIndex) {
	const noOffsetIndex = typeof tNodeOrNoOffsetIndex === "number" ? tNodeOrNoOffsetIndex : tNodeOrNoOffsetIndex.index - 28;
	ngh["d"] ??= [];
	if (!ngh["d"].includes(noOffsetIndex)) ngh["d"].push(noOffsetIndex);
}
function serializeLView(lView, parentDeferBlockId = null, context) {
	const ngh = {};
	const tView = lView[1];
	const i18nChildren = getOrComputeI18nChildren(tView, context);
	const nativeElementsToEventTypes = context.shouldReplayEvents ? collectDomEventsInfo(tView, lView, context.eventTypesToReplay) : null;
	for (let i = 28; i < tView.bindingStartIndex; i++) {
		const tNode = tView.data[i];
		const noOffsetIndex = i - 28;
		const i18nData = trySerializeI18nBlock(lView, i, context);
		if (i18nData) {
			ngh["l"] ??= {};
			ngh["l"][noOffsetIndex] = i18nData.caseQueue;
			for (const nodeNoOffsetIndex of i18nData.disconnectedNodes) appendDisconnectedNodeIndex(ngh, nodeNoOffsetIndex);
			for (const nodeNoOffsetIndex of i18nData.disjointNodes) {
				const tNode = tView.data[nodeNoOffsetIndex + 28];
				ngDevMode && assertTNode(tNode);
				appendSerializedNodePath(ngh, tNode, lView, i18nChildren);
			}
			continue;
		}
		if (!isTNodeShape(tNode)) continue;
		if (isDetachedByI18n(tNode)) continue;
		if (isLContainer(lView[i]) && tNode.tView) {
			ngh["t"] ??= {};
			ngh["t"][noOffsetIndex] = getSsrId(tNode.tView);
		}
		if (isDisconnectedNode(tNode, lView) && isContentProjectedNode(tNode)) {
			appendDisconnectedNodeIndex(ngh, tNode);
			continue;
		}
		if (Array.isArray(tNode.projection)) for (const projectionHeadTNode of tNode.projection) {
			if (!projectionHeadTNode) continue;
			if (!Array.isArray(projectionHeadTNode)) {
				if (!isProjectionTNode(projectionHeadTNode) && !isInSkipHydrationBlock(projectionHeadTNode)) {
					if (isDisconnectedNode(projectionHeadTNode, lView)) appendDisconnectedNodeIndex(ngh, projectionHeadTNode);
					else appendSerializedNodePath(ngh, projectionHeadTNode, lView, i18nChildren);
				}
			} else throw unsupportedProjectionOfDomNodes(unwrapRNode(lView[i]));
		}
		conditionallyAnnotateNodePath(ngh, tNode, lView, i18nChildren);
		if (isLContainer(lView[i])) {
			const hostNode = lView[i][0];
			if (Array.isArray(hostNode)) {
				const targetNode = unwrapRNode(hostNode);
				if (!targetNode.hasAttribute("ngSkipHydration")) annotateHostElementForHydration(targetNode, hostNode, parentDeferBlockId, context);
			}
			ngh["c"] ??= {};
			ngh["c"][noOffsetIndex] = serializeLContainer(lView[i], tNode, lView, parentDeferBlockId, context);
		} else if (Array.isArray(lView[i]) && !isLetDeclaration(tNode)) {
			const targetNode = unwrapRNode(lView[i][0]);
			if (!targetNode.hasAttribute("ngSkipHydration")) annotateHostElementForHydration(targetNode, lView[i], parentDeferBlockId, context);
		} else if (tNode.type & 8) {
			ngh["e"] ??= {};
			ngh["e"][noOffsetIndex] = calcNumRootNodes(tView, lView, tNode.child);
		} else if (tNode.type & 144) {
			let nextTNode = tNode.next;
			while (nextTNode !== null && nextTNode.type & 144) nextTNode = nextTNode.next;
			if (nextTNode && !isInSkipHydrationBlock(nextTNode)) appendSerializedNodePath(ngh, nextTNode, lView, i18nChildren);
		} else if (tNode.type & 1) processTextNodeBeforeSerialization(context, unwrapRNode(lView[i]));
		if (nativeElementsToEventTypes && tNode.type & 2) {
			const nativeElement = unwrapRNode(lView[i]);
			if (nativeElementsToEventTypes.has(nativeElement)) setJSActionAttributes(nativeElement, nativeElementsToEventTypes.get(nativeElement), parentDeferBlockId);
		}
	}
	return ngh;
}
function conditionallyAnnotateNodePath(ngh, tNode, lView, excludedParentNodes) {
	if (isProjectionTNode(tNode)) return;
	if (tNode.projectionNext && tNode.projectionNext !== tNode.next && !isInSkipHydrationBlock(tNode.projectionNext)) appendSerializedNodePath(ngh, tNode.projectionNext, lView, excludedParentNodes);
	if (tNode.prev === null && tNode.parent !== null && isDisconnectedNode(tNode.parent, lView) && !isDisconnectedNode(tNode, lView)) appendSerializedNodePath(ngh, tNode, lView, excludedParentNodes);
}
function componentUsesShadowDomEncapsulation(lView) {
	const instance = lView[8];
	if (!instance?.constructor) return false;
	const def = getComponentDef(instance.constructor);
	return def?.encapsulation === ViewEncapsulation$1.ShadowDom || def?.encapsulation === ViewEncapsulation$1.ExperimentalIsolatedShadowDom;
}
function annotateHostElementForHydration(element, lView, parentDeferBlockId, context) {
	const renderer = lView[11];
	if (hasI18n(lView) && !isI18nHydrationSupportEnabled() || componentUsesShadowDomEncapsulation(lView)) {
		renderer.setAttribute(element, SKIP_HYDRATION_ATTR_NAME, "");
		return null;
	} else {
		const ngh = serializeLView(lView, parentDeferBlockId, context);
		const index = context.serializedViewCollection.add(ngh);
		renderer.setAttribute(element, "ngh", index.toString());
		return index;
	}
}
function annotateDeferBlockAnchorForHydration(comment, deferBlockId) {
	comment.textContent = `ngh=${deferBlockId}`;
}
function insertCorruptedTextNodeMarkers(corruptedTextNodes, doc) {
	for (const [textNode, marker] of corruptedTextNodes) textNode.after(doc.createComment(marker));
}
function isContentProjectedNode(tNode) {
	let currentTNode = tNode;
	while (currentTNode != null) {
		if (isComponentHost(currentTNode)) return true;
		currentTNode = currentTNode.parent;
	}
	return false;
}
function annotateDeferBlockRootNodesWithJsAction(tDetails, rootNodes, parentDeferBlockId, context) {
	const actionList = convertHydrateTriggersToJsAction(tDetails.hydrateTriggers);
	for (let et of actionList) context.eventTypesToReplay.regular.add(et);
	if (actionList.length > 0) {
		const elementNodes = rootNodes.filter((rn) => rn.nodeType === Node.ELEMENT_NODE);
		for (let rNode of elementNodes) setJSActionAttributes(rNode, actionList, parentDeferBlockId);
	}
}
function getCurrentClosestComponentInstance(predicate) {
	let lView = getLView();
	while (lView) {
		if (lView[1].type === 1 && predicate(lView[8])) return lView[8];
		if (isRootView(lView)) break;
		else lView = getLViewParent(lView);
	}
	return null;
}
var PERFORMANCE_MARK_PREFIX = "🅰️";
var enablePerfLogging = false;
function startMeasuring(label) {
	if (!enablePerfLogging) return;
	const { startLabel } = labels(label);
	performance.mark(startLabel);
}
function stopMeasuring(label) {
	if (!enablePerfLogging) return;
	const { startLabel, labelName, endLabel } = labels(label);
	performance.mark(endLabel);
	performance.measure(labelName, startLabel, endLabel);
	performance.clearMarks(startLabel);
	performance.clearMarks(endLabel);
}
function labels(label) {
	const labelName = `${PERFORMANCE_MARK_PREFIX}:${label}`;
	return {
		labelName,
		startLabel: `start:${labelName}`,
		endLabel: `end:${labelName}`
	};
}
var warningLogged = false;
function enableProfiling() {
	if (!warningLogged && (typeof performance === "undefined" || !performance.mark || !performance.measure)) {
		warningLogged = true;
		console.warn("Performance API is not supported on this platform");
		return;
	}
	enablePerfLogging = true;
}
function disableProfiling() {
	enablePerfLogging = false;
}
function ɵassertType(value) {}
function booleanAttribute(value) {
	return typeof value === "boolean" ? value : value != null && value !== "false";
}
function numberAttribute(value, fallbackValue = NaN) {
	return !isNaN(parseFloat(value)) && !isNaN(Number(value)) ? Number(value) : fallbackValue;
}
function afterRenderEffect(callbackOrSpec, options) {
	ngDevMode && assertNotInReactiveContext(afterRenderEffect, "Call `afterRenderEffect` outside of a reactive context. For example, create the render effect inside the component constructor`.");
	if (ngDevMode && !options?.injector) assertInInjectionContext(afterRenderEffect);
	return NOOP_AFTER_RENDER_REF;
}
function ɵɵngDeclareDirective(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: "directive",
		type: decl.type
	}).compileDirectiveDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵfac.js`, decl);
}
function ɵɵngDeclareClassMetadata(decl) {
	setClassMetadata(decl.type, decl.decorators, decl.ctorParameters ?? null, decl.propDecorators ?? null);
}
function ɵɵngDeclareClassMetadataAsync(decl) {
	setClassMetadataAsync(decl.type, decl.resolveDeferredDeps, (...types) => {
		const meta = decl.resolveMetadata(...types);
		setClassMetadata(decl.type, meta.decorators, meta.ctorParameters, meta.propDecorators);
	});
}
function ɵɵngDeclareComponent(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: "component",
		type: decl.type
	}).compileComponentDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵcmp.js`, decl);
}
function ɵɵngDeclareFactory(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: getFactoryKind(decl.target),
		type: decl.type
	}).compileFactoryDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵfac.js`, decl);
}
function getFactoryKind(target) {
	switch (target) {
		case FactoryTarget.Directive: return "directive";
		case FactoryTarget.Component: return "component";
		case FactoryTarget.Injectable: return "injectable";
		case FactoryTarget.Pipe: return "pipe";
		case FactoryTarget.NgModule: return "NgModule";
		case FactoryTarget.Service: return "service";
	}
}
function ɵɵngDeclareInjectable(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: "injectable",
		type: decl.type
	}).compileInjectableDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵprov.js`, decl);
}
function ɵɵngDeclareInjector(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: "NgModule",
		type: decl.type
	}).compileInjectorDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵinj.js`, decl);
}
function ɵɵngDeclareNgModule(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: "NgModule",
		type: decl.type
	}).compileNgModuleDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵmod.js`, decl);
}
function ɵɵngDeclarePipe(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: "pipe",
		type: decl.type
	}).compilePipeDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵpipe.js`, decl);
}
function ɵɵngDeclareService(decl) {
	return getCompilerFacade({
		usage: 1,
		kind: "service",
		type: decl.type
	}).compileServiceDeclaration(angularCoreEnv, `ng:///${decl.type.name}/ɵprov.js`, decl);
}
function getModuleFactory(id) {
	const type = getRegisteredNgModuleType(id);
	if (!type) throw noModuleError(id);
	return new NgModuleFactory(type);
}
function getNgModuleById(id) {
	const type = getRegisteredNgModuleType(id);
	if (!type) throw noModuleError(id);
	return type;
}
function noModuleError(id) {
	return new RuntimeError(920, ngDevMode && `No module with ID ${id} loaded`);
}
var ViewRef = class extends ChangeDetectorRef {};
var EmbeddedViewRef = class extends ViewRef {};
var platformCore = createPlatformFactory(null, "core", []);
function createComponent(component, options) {
	ngDevMode && assertComponentDef(component);
	const componentDef = getComponentDef(component);
	const elementInjector = options.elementInjector || getNullInjector();
	const componentRef = new ComponentFactory(componentDef).create(elementInjector, options.projectableNodes, options.hostElement, options.environmentInjector, options.directives, options.bindings);
	if (options.onError) componentRef.hostView._lView[27] = options.onError;
	return componentRef;
}
function reflectComponentType(component) {
	const componentDef = getComponentDef(component);
	if (!componentDef) return null;
	const factory = new ComponentFactory(componentDef);
	return {
		get selector() {
			return factory.selector;
		},
		get type() {
			return factory.componentType;
		},
		get inputs() {
			return factory.inputs;
		},
		get outputs() {
			return factory.outputs;
		},
		get ngContentSelectors() {
			return factory.ngContentSelectors;
		},
		get isStandalone() {
			return componentDef.standalone;
		},
		get isSignal() {
			return componentDef.signals;
		}
	};
}
function resourceFromSnapshots(source) {
	return new SnapshotResource(isSignal(source) ? source : computed(source));
}
var SnapshotResource = class {
	snapshot;
	constructor(snapshot) {
		this.snapshot = snapshot;
	}
	get state() {
		return this.snapshot();
	}
	value = computed(() => {
		if (this.state.status === "error") throw new ResourceValueError(this.state.error);
		return this.state.value;
	});
	status = computed(() => this.state.status);
	error = computed(() => this.state.status === "error" ? this.state.error : void 0);
	isLoading = computed(() => this.state.status === "loading" || this.state.status === "reloading");
	isValueDefined = computed(() => this.state.status !== "error" && this.state.value !== void 0);
	hasValue() {
		return this.isValueDefined();
	}
};
function debounced(source, wait, options) {
	if (isInParamsFunction()) throw invalidResourceCreationInParams();
	if (ngDevMode && !options?.injector) assertInInjectionContext(debounced);
	const injector = options?.injector ?? inject(Injector);
	let active;
	let pendingValue;
	let activeTimer;
	const cancelTimer = () => {
		if (activeTimer !== void 0) {
			clearTimeout(activeTimer);
			activeTimer = void 0;
		}
	};
	injector.get(DestroyRef).onDestroy(() => {
		cancelTimer();
		active = void 0;
	});
	const state = linkedSignal({
		source: () => {
			try {
				setInParamsFunction(true);
				return {
					value: source(),
					thrown: false
				};
			} catch (err) {
				rethrowFatalErrors(err);
				return {
					error: err,
					thrown: true
				};
			} finally {
				setInParamsFunction(false);
			}
		},
		computation: (res, previous) => {
			if (previous !== void 0) return previous.value;
			if (res.thrown) return {
				status: "error",
				error: res.error
			};
			return {
				status: "resolved",
				value: res.value
			};
		}
	});
	effect(() => {
		let value;
		try {
			setInParamsFunction(true);
			value = source();
		} catch (err) {
			rethrowFatalErrors(err);
			state.set({
				status: "error",
				error: err
			});
			cancelTimer();
			active = pendingValue = void 0;
			return;
		} finally {
			setInParamsFunction(false);
		}
		const currentState = untracked(state);
		const equal = options?.equal ?? Object.is;
		if (currentState.status === "reloading" || currentState.status === "loading") {
			if (equal(value, pendingValue)) return;
		} else if (currentState.status === "resolved") {
			if (equal(value, currentState.value)) return;
		}
		cancelTimer();
		const result = (typeof wait === "number" ? () => new Promise((resolve) => {
			activeTimer = setTimeout(() => {
				activeTimer = void 0;
				resolve();
			}, wait);
		}) : wait)(value, currentState);
		if (result === void 0) {
			state.set({
				status: "resolved",
				value
			});
			active = pendingValue = void 0;
		} else {
			if (currentState.status !== "loading" && currentState.status !== "error") state.set({
				status: "loading",
				value: currentState.value
			});
			active = result;
			pendingValue = value;
			result.then(() => {
				if (active === result) {
					state.set({
						status: "resolved",
						value
					});
					active = pendingValue = void 0;
				}
			});
		}
	}, { injector });
	return resourceFromSnapshots(state);
}
function isDevMode() {
	return typeof ngDevMode === "undefined" || !!ngDevMode;
}
function enableProdMode() {
	if (typeof ngDevMode === "undefined" || ngDevMode) _global["ngDevMode"] = false;
}
async function declareExperimentalWebMcpTool(tool, injector) {}
function provideExperimentalWebMcpTools(tools) {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
		for (const tool of tools) declareExperimentalWebMcpTool(tool);
	})]);
}
//#endregion
export { isDevMode as $, ɵɵdeferPrefetchOnTimer as $a, ZONELESS_ENABLED as $c, unwrapSafeValue as $i, Output as $n, ɵɵloadQuery as $o, findLocaleData as $r, ɵɵtextInterpolate5 as $s, AfterRenderManager as $t, contentChild as A, ɵɵcontrol as Aa, InjectionToken as Ac, provideZonelessChangeDetection as Ai, ɵunwrapWritableSignal as Al, HydrationStatus as An, ɵɵgetCurrentView as Ao, _sanitizeUrl as Ar, ɵɵresolveDocument as As, ɵɵngDeclareInjector as At, destroyPlatform as B, ɵɵdeferHydrateOnTimer as Ba, NoopNgZone as Bc, resetJitOptions as Bi, ɵɵresetView as Bl, LOCALE_ID as Bn, ɵɵinjectAttribute as Bo, bypassSanitizationTrustUrl as Br, ɵɵstoreLet as Bs, computed as Bt, ViewChildren as C, ɵɵclassProp as Ca, ErrorHandler as Cc, noSideEffects as Ci, resolveForwardRef as Cl, DeferBlockState as Cn, ɵɵelementStart as Co, TracingService as Cr, ɵɵreference as Cs, ɵassertType as Ct, assertPlatform as D, ɵɵconditionalCreate as Da, INJECTOR$1 as Dc, provideAppInitializer as Di, store as Dl, Host as Dn, ɵɵforeignContentFn as Do, ViewEncapsulation$1 as Dr, ɵɵrepeaterTrackByIndex as Ds, ɵɵngDeclareDirective as Dt, annotateForHydration as E, ɵɵconditionalBranchCreate as Ea, IMAGE_CONFIG_DEFAULTS as Ec, performanceMarkFeature as Ei, signal as El, ElementRef as En, ɵɵforeignContent as Eo, ViewContainerRef as Er, ɵɵrepeaterTrackByIdentity as Es, ɵɵngDeclareComponent as Et, createPlatformFactory as F, ɵɵdeferHydrateNever as Fa, NG_INJ_DEF as Fc, registerNgModuleType as Fi, ɵɵinject as Fl, Injectable as Fn, ɵɵi18nAttributes as Fo, asNativeElements as Fr, ɵɵsanitizeStyle as Fs, OutputEmitterRef as Ft, getModuleFactory as G, ɵɵdeferOnImmediate as Ga, PendingTasksInternal as Gc, setClassMetadataAsync as Gi, NO_CHANGE as Gn, ɵɵinterpolate4 as Go, compileNgModuleDefs as Gr, ɵɵtemplate as Gs, resource as Gt, enableProdMode as H, ɵɵdeferHydrateWhen as Ha, PLATFORM_INITIALIZER as Hc, restoreComponentResolutionQueue as Hi, setAlternateWeakRefImpl as Hl, MAX_ANIMATION_TIMEOUT as Hn, ɵɵinterpolate1 as Ho, compileComponent as Hr, ɵɵstyleProp as Hs, getOutputDestroyRef as Ht, debounced as I, ɵɵdeferHydrateOnHover as Ia, NG_MOD_DEF as Ic, renderDeferBlockState as Ii, ɵɵinvalidFactoryDep as Il, Input as In, ɵɵi18nEnd as Io, bypassSanitizationTrustHtml as Ir, ɵɵsanitizeUrl as Is, ResourceDependencyError as It, injectAsync as J, ɵɵdeferOnViewport as Ja, SecurityContext as Jc, setTestabilityGetter as Ji, NgModuleFactory as Jn, ɵɵinterpolate7 as Jo, createNgModule as Jr, ɵɵtextInterpolate as Js, ANIMATIONS_DISABLED as Jt, getNgModuleById as K, ɵɵdeferOnInteraction as Ka, R3Injector as Kc, setDocument as Ki, NO_ERRORS_SCHEMA as Kn, ɵɵinterpolate5 as Ko, compilePipe as Kr, ɵɵtemplateRefExtractor as Ks, setInParamsFunction as Kt, declareExperimentalWebMcpTool as L, ɵɵdeferHydrateOnIdle as La, NG_PIPE_DEF as Lc, resetCompiledComponents as Li, ɵɵnamespaceHTML as Ll, JSACTION_BLOCK_ELEMENT_MAP as Ln, ɵɵi18nExp as Lo, bypassSanitizationTrustResourceUrl as Lr, ɵɵsanitizeUrlOrResourceUrl as Ls, ResourceImpl as Lt, createComponent as M, ɵɵdeclareLet as Ma, NG_COMP_DEF as Mc, publishNonCoreGlobalUtil as Mi, ɵɵdefineInjector as Ml, IS_HYDRATION_DOM_REUSE_ENABLED as Mn, ɵɵgetReplaceMetadataURL as Mo, afterNextRender as Mr, ɵɵsanitizeHtml as Ms, ɵɵngDeclarePipe as Mt, createOrReusePlatformInjector as N, ɵɵdefer as Na, NG_DIR_DEF as Nc, readHydrationInfo as Ni, ɵɵdisableBindings as Nl, IS_INCREMENTAL_HYDRATION_ENABLED as Nn, ɵɵi18n as No, allLeavingAnimations as Nr, ɵɵsanitizeResourceUrl as Ns, ɵɵngDeclareService as Nt, booleanAttribute as O, ɵɵcontentQuery as Oa, INJECTOR_SCOPE as Oc, provideIdleServiceWith as Oi, stringify as Ol, HostBinding as On, ɵɵgetBoundary as Oo, ViewRef$1 as Or, ɵɵreplaceMetadata as Os, ɵɵngDeclareFactory as Ot, createPlatform as P, ɵɵdeferEnableTimerScheduling as Pa, NG_ELEMENT_ID as Pc, registerLocaleData as Pi, ɵɵenableBindings as Pl, Inject as Pn, ɵɵi18nApply as Po, allowSanitizationBypassAndThrow as Pr, ɵɵsanitizeScript as Ps, CACHE_ACTIVE as Pt, internalProvideZoneChangeDetection as Q, ɵɵdeferPrefetchOnInteraction as Qa, XSS_SECURITY_URL as Qc, unregisterAllLocaleData as Qi, Optional as Qn, ɵɵlistener as Qo, enableProfiling$1 as Qr, ɵɵtextInterpolate4 as Qs, AcxViewEncapsulation as Qt, defaultIterableDiffers as R, ɵɵdeferHydrateOnImmediate as Ra, NG_PROV_DEF as Rc, resetIncrementalHydrationEnabledWarnedForTests as Ri, ɵɵnamespaceMathML as Rl, JSACTION_EVENT_CONTRACT as Rn, ɵɵi18nPostprocess as Ro, bypassSanitizationTrustScript as Rr, ɵɵsetComponentScope as Rs, ResourceParamsStatus as Rt, ViewChild as S, ɵɵclassMap as Sa, EnvironmentInjector as Sc, markForRefresh as Si, provideEnvironmentInitializer as Sl, DeferBlockBehavior as Sn, ɵɵelementEnd as So, TracingAction as Sr, ɵɵreadContextLet as Ss, ɵINPUT_SIGNAL_BRAND_WRITE_TYPE as St, afterRenderEffect as T, ɵɵconditional as Ta, IMAGE_CONFIG as Tc, patchComponentDefWithScope as Ti, setInjectorProfilerContext as Tl, EVENT_REPLAY_QUEUE as Tn, ɵɵforeignComponent as To, USE_PENDING_TASKS as Tr, ɵɵrepeaterCreate as Ts, ɵɵngDeclareClassMetadataAsync as Tt, enableProfiling as U, ɵɵdeferOnHover as Ua, PROVIDED_ZONELESS as Uc, setAllowDuplicateNgModuleIdsForTest as Ui, setCurrentInjector as Ul, MissingTranslationStrategy as Un, ɵɵinterpolate2 as Uo, compileDirective as Ur, ɵɵsyntheticHostListener as Us, isInParamsFunction as Ut, disableProfiling as V, ɵɵdeferHydrateOnViewport as Va, PLATFORM_ID as Vc, resolveComponentResources as Vi, ɵɵrestoreView as Vl, LocaleDataIndex as Vn, ɵɵinterpolate as Vo, clearResolutionOfComponentResourcesQueue as Vr, ɵɵstyleMap as Vs, encapsulateResourceError as Vt, getCurrentClosestComponentInstance as W, ɵɵdeferOnIdle as Wa, PendingTasks as Wc, setClassMetadata as Wi, SIGNAL as Wl, NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR as Wn, ɵɵinterpolate3 as Wo, compileNgModule as Wr, ɵɵsyntheticHostProperty as Ws, linkedSignal as Wt, input as X, ɵɵdeferPrefetchOnIdle as Xa, VERSION as Xc, triggerResourceLoading as Xi, NgModuleRef as Xn, ɵɵinterpolateV as Xo, describeDomNode as Xr, ɵɵtextInterpolate2 as Xs, APP_INITIALIZER as Xt, injectChangeDetectorRef as Y, ɵɵdeferPrefetchOnHover as Ya, TransferState as Yc, transitiveScopesFor as Yi, NgModuleFactory$1 as Yn, ɵɵinterpolate8 as Yo, depsTracker as Yr, ɵɵtextInterpolate1 as Ys, APP_BOOTSTRAP_LISTENER as Yt, internalCreateApplication as Z, ɵɵdeferPrefetchOnImmediate as Za, Version as Zc, twoWayBinding as Zi, NgModuleRef$1 as Zn, ɵɵinvalidFactory as Zo, devModeEqual as Zr, ɵɵtextInterpolate3 as Zs, AcxChangeDetectionStrategy as Zt, PlatformRef as _, ɵɵarrowFunction as _a, ChangeDetectionScheduler as _c, isComponentDefPendingResolution as _i, isWritableSignal as _l, DEFER_BLOCK_DEPENDENCY_INTERCEPTOR as _n, ɵɵdomTemplate as _o, TRANSLATIONS_FORMAT as _r, ɵɵpureFunction7 as _s, viewChildren as _t, ContentChildren as a, ɵɵControlFeature as aa, ɵɵtrustConstantResourceUrl as ac, getDebugNode as ai, effect as al, ChangeDetectionStrategy as an, ɵɵdefineNgModule as ao, RendererFactory2 as ar, ɵɵpipeBind4 as as, output as at, REQUEST_CONTEXT as b, ɵɵboundaryCreate as ba, ENVIRONMENT_INITIALIZER as bc, isSubscribable as bi, promiseWithResolvers as bl, DebugEventListener as bn, ɵɵelementContainerEnd as bo, TestabilityRegistry as br, ɵɵqueryAdvance as bs, withI18nSupport as bt, EmbeddedViewRef as c, ɵɵInheritDefinitionFeature as ca, ɵɵtwoWayProperty as cc, getDocument as ci, getComponentDef as cl, Component as cn, ɵɵdirectiveInject as co, SSR_CONTENT_INTEGRITY_MARKER as cr, ɵɵprojectionDef as cs, provideExperimentalWebMcpTools as ct, HOST_TAG_NAME as d, ɵɵadvance as da, ɵɵviewQuerySignal as dc, getLocaleCurrencyCode as di, importProvidersFrom as dl, ComponentRef$1 as dn, ɵɵdomElementContainerEnd as do, Service as dr, ɵɵpureFunction1 as ds, provideZoneChangeDetection as dt, ɵgetUnknownElementStrictMode as ea, ɵɵtextInterpolate6 as ec, flushModuleScopingQueueAsMuchAsPossible as ei, _global as el, ApplicationInitStatus as en, ɵɵdeferPrefetchOnViewport as eo, Pipe as er, ɵɵnextContext as es, maybeUnwrapDefaultExport as et, HostAttributeToken as f, ɵɵanimateEnter as fa, require_operators as fc, getLocalePluralCase as fi, inject as fl, Console as fn, ɵɵdomElementContainerStart as fo, SimpleChange as fr, ɵɵpureFunction2 as fs, reflectComponentType as ft, PROVIDED_NG_ZONE as g, ɵɵariaProperty as ga, CSP_NONCE as gc, inputBinding as gi, isStandalone as gl, DEFER_BLOCK_CONFIG as gn, ɵɵdomProperty as go, TRANSLATIONS as gr, ɵɵpureFunction6 as gs, viewChild as gt, PERFORMANCE_MARK_PREFIX as h, ɵɵanimateLeaveListener as ha, CONTAINER_HEADER_OFFSET as hc, inferTagNameFromDefinition as hi, isSignal as hl, DEFAULT_LOCALE_ID as hn, ɵɵdomListener as ho, TESTABILITY_GETTER as hr, ɵɵpureFunction5 as hs, stopMeasuring as ht, ContentChild as i, ɵsetUnknownPropertyStrictMode as ia, ɵɵtrustConstantHtml as ic, getComponentInstanceDeepLinkId as ii, createInjector as il, CUSTOM_ELEMENTS_SCHEMA as in, ɵɵdefineDirective as io, Renderer2 as ir, ɵɵpipeBind3 as is, onIdle as it, contentChildren as j, ɵɵcontrolCreate as ja, Injector as jc, provideZonelessChangeDetectionInternal as ji, ɵɵdefineInjectable as jl, IS_ENABLED_BLOCKING_INITIAL_NAVIGATION as jn, ɵɵgetInheritedFactory as jo, afterEveryRender as jr, ɵɵresolveWindow as js, ɵɵngDeclareNgModule as jt, compileNgModuleFactory as k, ɵɵcontentQuerySignal as ka, INTERNAL_APPLICATION_ERROR_HANDLER as kc, provideNgReflectAttributes as ki, truncateMiddle as kl, HostListener as kn, ɵɵgetComponentDepsFactory as ko, _sanitizeHtml as kr, ɵɵresolveBody as ks, ɵɵngDeclareInjectable as kt, FactoryTarget as l, ɵɵNgOnChangesFeature as la, ɵɵvalidateAttribute as lc, getHostElement as li, getDirectiveDef as ll, ComponentFactory as ln, ɵɵdomElement as lo, Sanitizer as lr, ɵɵproperty as ls, providePlatformInitializer as lt, KeyValueDiffers as m, ɵɵanimateLeave as ma, APP_ID as mc, getTransferState as mi, isInjectable as ml, DEFAULT_CURRENCY_CODE as mn, ɵɵdomElementStart as mo, TESTABILITY as mr, ɵɵpureFunction4 as ms, startMeasuring as mt, CLIENT_RENDER_MODE_FLAG as n, ɵsetClassDebugInfo as na, ɵɵtextInterpolate8 as nc, getAsyncClassMetadataFn as ni, assertNotInReactiveContext as nl, Attribute as nn, ɵɵdeferWhen as no, QueryList as nr, ɵɵpipeBind1 as ns, model as nt, DefaultIterableDiffer as o, ɵɵExternalStylesFeature as oa, ɵɵtwoWayBindingSet as oc, getDeferBlocks as oi, formatRuntimeError as ol, Compiler as on, ɵɵdefinePipe as oo, RendererStyleFlags2 as or, ɵɵpipeBindV as os, platformCore as ot, IterableDiffers as p, ɵɵanimateEnterListener as pa, ANIMATION_MODULE_TYPE as pc, getSanitizationBypassType as pi, isEnvironmentProviders as pl, ControlFlowBlockType as pn, ɵɵdomElementEnd as po, SkipSelf as pr, ɵɵpureFunction3 as ps, resourceFromSnapshots as pt, getPlatform as q, ɵɵdeferOnTimer as qa, RuntimeError as qc, setLocaleId as qi, NgModule as qn, ɵɵinterpolate6 as qo, createEnvironmentInjector as qr, ɵɵtext as qs, untracked as qt, ChangeDetectorRef as r, ɵsetUnknownElementStrictMode as ra, ɵɵtextInterpolateV as rc, getClosestComponentName as ri, convertToBitFlags as rl, COMPILER_OPTIONS as rn, ɵɵdefineComponent as ro, ReflectionCapabilities as rr, ɵɵpipeBind2 as rs, numberAttribute as rt, ENABLE_ROOT_COMPONENT_BOOTSTRAP as s, ɵɵHostDirectivesFeature as sa, ɵɵtwoWayListener as sc, getDirectives as si, forwardRef as sl, CompilerFactory as sn, ɵɵdefineService as so, SHARED_STYLES_HOST as sr, ɵɵprojection as ss, provideCheckNoChangesConfig as st, ApplicationModule as t, ɵgetUnknownPropertyStrictMode as ta, ɵɵtextInterpolate7 as tc, generateStandaloneInDeclarationsError as ti, assertInInjectionContext as tl, ApplicationRef as tn, ɵɵdeferPrefetchWhen as to, ProfilerEvent as tr, ɵɵpipe as ts, mergeApplicationConfig as tt, Framework as u, ɵɵProvidersFeature as ua, ɵɵviewQuery as uc, getLContext as ui, getInjectableDef as ul, ComponentRef as un, ɵɵdomElementContainer as uo, Self as ur, ɵɵpureFunction0 as us, provideStabilityDebugging as ut, Query as v, ɵɵattachSourceLocations as va, DOCUMENT$1 as vc, isNgModule as vi, makeEnvironmentProviders as vl, DEHYDRATED_BLOCK_REGISTRY as vn, ɵɵelement as vo, TemplateRef as vr, ɵɵpureFunction8 as vs, withDomHydration as vt, ViewRef as w, ɵɵcomponentInstance as wa, EventEmitter as wc, outputBinding as wi, runInInjectionContext as wl, Directive as wn, ɵɵenableIncrementalHydrationRuntime as wo, Type as wr, ɵɵrepeater as ws, ɵɵngDeclareClassMetadata as wt, RESPONSE_INIT as x, ɵɵboundaryUpdate as xa, EffectScheduler as xc, isViewDirty as xi, provideBrowserGlobalErrorListeners as xl, DebugNode as xn, ɵɵelementContainerStart as xo, TimerScheduler as xr, ɵɵqueryRefresh as xs, withIncrementalHydration as xt, REQUEST as y, ɵɵattribute as ya, DestroyRef as yc, isPromise as yi, makeStateKey as yl, DebugElement as yn, ɵɵelementContainer as yo, Testability as yr, ɵɵpureFunctionV as ys, withEventReplay as yt, defaultKeyValueDiffers as z, ɵɵdeferHydrateOnInteraction as za, NgZone as zc, resetIncrementalHydrationRuntimeForTests as zi, ɵɵnamespaceSVG as zl, LContext as zn, ɵɵi18nStart as zo, bypassSanitizationTrustStyle as zr, ɵɵsetNgModuleScope as zs, chain as zt };
